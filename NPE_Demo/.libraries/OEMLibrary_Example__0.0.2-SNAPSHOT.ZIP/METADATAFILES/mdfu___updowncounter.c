#include <RISMD.h>
#include <lcfu___updowncounter.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_UPDOWNCOUNTER_DOWN[] RISMD_ATTRIBUTES = "Down";
static RISMDInterfaceVariable const lcmd_var_UPDOWNCOUNTER_DOWN RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_UPDOWNCOUNTER_DOWN, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_UPDOWNCOUNTER,LC_VD_DOWN), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_UPDOWNCOUNTER_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_UPDOWNCOUNTER_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_UPDOWNCOUNTER_ENO, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_UPDOWNCOUNTER,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDSimpleNumType const risMdType_SINT;
static char const lcmd_var_name_UPDOWNCOUNTER_ERRORCODE[] RISMD_ATTRIBUTES = "ErrorCode";
static RISMDInterfaceVariable const lcmd_var_UPDOWNCOUNTER_ERRORCODE RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_UPDOWNCOUNTER_ERRORCODE, &risMdType_SINT, offsetof(LC_TD_FunctionBlock_UPDOWNCOUNTER,LC_VD_ERRORCODE), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_UPDOWNCOUNTER_RESET[] RISMD_ATTRIBUTES = "Reset";
static RISMDInterfaceVariable const lcmd_var_UPDOWNCOUNTER_RESET RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_UPDOWNCOUNTER_RESET, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_UPDOWNCOUNTER,LC_VD_RESET), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_UPDOWNCOUNTER_UP[] RISMD_ATTRIBUTES = "Up";
static RISMDInterfaceVariable const lcmd_var_UPDOWNCOUNTER_UP RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_UPDOWNCOUNTER_UP, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_UPDOWNCOUNTER,LC_VD_UP), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_UPDOWNCOUNTER_VALUE[] RISMD_ATTRIBUTES = "Value";
static RISMDInterfaceVariable const lcmd_var_UPDOWNCOUNTER_VALUE RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_UPDOWNCOUNTER_VALUE, &risMdType_SINT, offsetof(LC_TD_FunctionBlock_UPDOWNCOUNTER,LC_VD_VALUE), RISMD_VARIABLE_SECTION_OUTPUT);

static RISMDReference const lcmd_var_list_UPDOWNCOUNTER[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_UPDOWNCOUNTER_DOWN),
  INIT_RISMDReference(&lcmd_var_UPDOWNCOUNTER_ENO),
  INIT_RISMDReference(&lcmd_var_UPDOWNCOUNTER_ERRORCODE),
  INIT_RISMDReference(&lcmd_var_UPDOWNCOUNTER_RESET),
  INIT_RISMDReference(&lcmd_var_UPDOWNCOUNTER_UP),
  INIT_RISMDReference(&lcmd_var_UPDOWNCOUNTER_VALUE),
};

static char const lcmd_type_name_UPDOWNCOUNTER[] RISMD_ATTRIBUTES = "UPDOWNCOUNTER";
RISMDPOUType const lcmd_type_UPDOWNCOUNTER RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_UPDOWNCOUNTER, sizeof(LC_TD_FunctionBlock_UPDOWNCOUNTER), 6, lcmd_var_list_UPDOWNCOUNTER);
