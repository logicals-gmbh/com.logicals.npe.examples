#include <RISMD.h>
#include <lcfu___cntrl_pidt1.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_CNTRL_PIDT1_AUTO[] RISMD_ATTRIBUTES = "Auto";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_AUTO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_AUTO, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_AUTO), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_CNTRL_PIDT1_CYCLEFLAG[] RISMD_ATTRIBUTES = "CycleFlag";
static RISMDStdVariable const lcmd_var_CNTRL_PIDT1_CYCLEFLAG RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_CNTRL_PIDT1_CYCLEFLAG, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_CYCLEFLAG));

extern RISMDSimpleNumType const risMdType_LREAL;
static char const lcmd_var_name_CNTRL_PIDT1_D[] RISMD_ATTRIBUTES = "D";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_D RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_D, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_D), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_CNTRL_PIDT1_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_ENO, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_CNTRL_PIDT1_I[] RISMD_ATTRIBUTES = "I";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_I RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_I, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_I), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_CNTRL_PIDT1_INP[] RISMD_ATTRIBUTES = "Inp";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_INP RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_INP, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_INP), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_CNTRL_PIDT1_IOLD[] RISMD_ATTRIBUTES = "IOld";
static RISMDStdVariable const lcmd_var_CNTRL_PIDT1_IOLD RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_CNTRL_PIDT1_IOLD, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_IOLD));

static char const lcmd_var_name_CNTRL_PIDT1_KP[] RISMD_ATTRIBUTES = "Kp";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_KP RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_KP, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_KP), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_CNTRL_PIDT1_KV[] RISMD_ATTRIBUTES = "Kv";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_KV RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_KV, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_KV), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_CNTRL_PIDT1_LD[] RISMD_ATTRIBUTES = "Ld";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_LD RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_LD, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_LD), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_CNTRL_PIDT1_LU[] RISMD_ATTRIBUTES = "Lu";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_LU RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_LU, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_LU), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_CNTRL_PIDT1_LVD[] RISMD_ATTRIBUTES = "Lvd";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_LVD RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_LVD, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_LVD), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_CNTRL_PIDT1_LVU[] RISMD_ATTRIBUTES = "Lvu";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_LVU RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_LVU, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_LVU), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_CNTRL_PIDT1_OUT[] RISMD_ATTRIBUTES = "Out";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_OUT RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_OUT, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_OUT), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_CNTRL_PIDT1_P[] RISMD_ATTRIBUTES = "P";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_P RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_P, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_P), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_CNTRL_PIDT1_T1[] RISMD_ATTRIBUTES = "T1";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_T1 RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_T1, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_T1), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_CNTRL_PIDT1_TI[] RISMD_ATTRIBUTES = "TI";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_TI RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_TI, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_TI), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_CNTRL_PIDT1_YHAND[] RISMD_ATTRIBUTES = "YHand";
static RISMDInterfaceVariable const lcmd_var_CNTRL_PIDT1_YHAND RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_CNTRL_PIDT1_YHAND, &risMdType_LREAL, offsetof(LC_TD_FunctionBlock_CNTRL_PIDT1,LC_VD_YHAND), RISMD_VARIABLE_SECTION_INPUT);

static RISMDReference const lcmd_var_list_CNTRL_PIDT1[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_AUTO),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_CYCLEFLAG),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_D),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_ENO),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_I),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_INP),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_IOLD),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_KP),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_KV),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_LD),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_LU),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_LVD),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_LVU),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_OUT),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_P),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_T1),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_TI),
  INIT_RISMDReference(&lcmd_var_CNTRL_PIDT1_YHAND),
};

static char const lcmd_type_name_CNTRL_PIDT1[] RISMD_ATTRIBUTES = "CNTRL_PIDT1";
RISMDPOUType const lcmd_type_CNTRL_PIDT1 RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_CNTRL_PIDT1, sizeof(LC_TD_FunctionBlock_CNTRL_PIDT1), 18, lcmd_var_list_CNTRL_PIDT1);
