#ifndef LC_PROT_LCFU___PIDT1_CONFIG_C__H
#define LC_PROT_LCFU___PIDT1_CONFIG_C__H

#include <LC3CGBase.h>
#include <lcfu___cntrl_pidt1.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_PIDT1_CONFIG_C
{
  LC_TD_LREAL LC_VD_INP;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_LREAL LC_VD_OUT;
  LC_TD_FunctionBlock_CNTRL_PIDT1 LC_VD_PIDT1;
} LCCG_StructAttrib LC_TD_FunctionBlock_PIDT1_CONFIG_C;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_PIDT1_CONFIG_C(p) \
{ \
  LC_INIT_LREAL(&((p)->LC_VD_INP)); \
  LC_INIT_LREAL(&((p)->LC_VD_OUT)); \
  LC_INIT_FunctionBlock_CNTRL_PIDT1(&((p)->LC_VD_PIDT1)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_PIDT1_CONFIG_C(p,RF) \
{ \
  LC_WINIT_LREAL(&((p)->LC_VD_INP),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_OUT),RF); \
  LC_WINIT_FunctionBlock_CNTRL_PIDT1(&((p)->LC_VD_PIDT1),0); \
}

/*                            Prototype                        */
void  lcfu___PIDT1_CONFIG_C(LC_TD_FunctionBlock_PIDT1_CONFIG_C* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
