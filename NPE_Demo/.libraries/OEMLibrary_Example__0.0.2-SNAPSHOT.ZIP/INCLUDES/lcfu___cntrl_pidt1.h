#ifndef LC_PROT_LCFU___CNTRL_PIDT1__H
#define LC_PROT_LCFU___CNTRL_PIDT1__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__CONVERT.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_CNTRL_PIDT1
{
  LC_TD_BOOL LC_VD_AUTO;
  LC_TD_LREAL LC_VD_INP;
  LC_TD_LREAL LC_VD_KP;
  LC_TD_LREAL LC_VD_KV;
  LC_TD_LREAL LC_VD_LVD;
  LC_TD_LREAL LC_VD_LVU;
  LC_TD_LREAL LC_VD_T1;
  LC_TD_LREAL LC_VD_TI;
  LC_TD_LREAL LC_VD_YHAND;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_LD;
  LC_TD_BOOL LC_VD_LU;
  LC_TD_LREAL LC_VD_D;
  LC_TD_LREAL LC_VD_I;
  LC_TD_LREAL LC_VD_OUT;
  LC_TD_LREAL LC_VD_P;
  LC_TD_BOOL LC_VD_CYCLEFLAG;
  LC_TD_LREAL LC_VD_IOLD;
} LCCG_StructAttrib LC_TD_FunctionBlock_CNTRL_PIDT1;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_CNTRL_PIDT1(LC_TD_FunctionBlock_CNTRL_PIDT1* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_CNTRL_PIDT1(p) LC_INIT_FUN_FunctionBlock_CNTRL_PIDT1((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_CNTRL_PIDT1(LC_TD_FunctionBlock_CNTRL_PIDT1* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_CNTRL_PIDT1(p,RF) LC_WINIT_FUN_FunctionBlock_CNTRL_PIDT1((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___CNTRL_PIDT1(LC_TD_FunctionBlock_CNTRL_PIDT1* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
