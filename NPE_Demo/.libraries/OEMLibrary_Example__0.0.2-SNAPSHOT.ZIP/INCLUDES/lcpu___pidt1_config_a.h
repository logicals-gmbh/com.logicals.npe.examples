#ifndef LC_PROT_LCPU___PIDT1_CONFIG_A__H
#define LC_PROT_LCPU___PIDT1_CONFIG_A__H

#include <LC3CGBase.h>
#include <lcfu___cntrl_pidt1.h>
#include <lcpu___pidt1_config_a.gv.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Program_PIDT1_CONFIG_A
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_FunctionBlock_CNTRL_PIDT1 LC_VD_PIDT1;
} LCCG_StructAttrib LC_TD_Program_PIDT1_CONFIG_A;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_Program_PIDT1_CONFIG_A(p) \
  LC_INIT_FunctionBlock_CNTRL_PIDT1(&((p)->LC_VD_PIDT1)); \

#define LC_INIT_Program_PIDT1_CONFIG_A(p) \
{ \
  LC_INIT_NONDMA_Program_PIDT1_CONFIG_A(p) \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_Program_PIDT1_CONFIG_A(p,RF) \
  LC_WINIT_FunctionBlock_CNTRL_PIDT1(&((p)->LC_VD_PIDT1),0); \

#define LC_WINIT_Program_PIDT1_CONFIG_A(p,RF) \
{ \
  LC_WINIT_NONDMA_Program_PIDT1_CONFIG_A(p,RF) \
}

/*                            Prototype                        */
void  lcpu___PIDT1_CONFIG_A(LC_TD_Program_PIDT1_CONFIG_A* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
