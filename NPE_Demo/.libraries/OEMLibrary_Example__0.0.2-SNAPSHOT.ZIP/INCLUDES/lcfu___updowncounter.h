#ifndef LC_PROT_LCFU___UPDOWNCOUNTER__H
#define LC_PROT_LCFU___UPDOWNCOUNTER__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_UPDOWNCOUNTER
{
  LC_TD_BOOL LC_VD_DOWN;
  LC_TD_BOOL LC_VD_RESET;
  LC_TD_BOOL LC_VD_UP;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_SINT LC_VD_ERRORCODE;
  LC_TD_SINT LC_VD_VALUE;
} LCCG_StructAttrib LC_TD_FunctionBlock_UPDOWNCOUNTER;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_UPDOWNCOUNTER(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_UP)); \
  LC_INIT_BOOL(&((p)->LC_VD_DOWN)); \
  LC_INIT_BOOL(&((p)->LC_VD_RESET)); \
  LC_INIT_SINT(&((p)->LC_VD_ERRORCODE)); \
  LC_INIT_SINT(&((p)->LC_VD_VALUE)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_UPDOWNCOUNTER(p,RF) \
{ \
  LC_WINIT_BOOL(&((p)->LC_VD_UP),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_DOWN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_RESET),RF); \
  LC_WINIT_SINT(&((p)->LC_VD_ERRORCODE),RF); \
  LC_WINIT_SINT(&((p)->LC_VD_VALUE),RF); \
}

/*                            Prototype                        */
void  lcfu___UPDOWNCOUNTER(LC_TD_FunctionBlock_UPDOWNCOUNTER* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
