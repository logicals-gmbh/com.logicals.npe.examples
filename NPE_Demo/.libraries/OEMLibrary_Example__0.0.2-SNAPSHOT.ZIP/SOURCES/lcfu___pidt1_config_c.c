#ifndef LC_PROT_LCFU___PIDT1_CONFIG_C__C
#define LC_PROT_LCFU___PIDT1_CONFIG_C__C

#include <lcfu___pidt1_config_c.h>

/*                            FunctionBlocks                   */
void  lcfu___PIDT1_CONFIG_C(LC_TD_FunctionBlock_PIDT1_CONFIG_C* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_PIDT1.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_PIDT1.LC_VD_AUTO = LC_EL_true;
    LC_this->LC_VD_PIDT1.LC_VD_INP = LC_this->LC_VD_INP;
    LC_this->LC_VD_PIDT1.LC_VD_KP = (LC_TD_LREAL)1.0;
    LC_this->LC_VD_PIDT1.LC_VD_KV = (LC_TD_LREAL)1;
    LC_this->LC_VD_PIDT1.LC_VD_LVD = (LC_TD_LREAL)0;
    LC_this->LC_VD_PIDT1.LC_VD_LVU = (LC_TD_LREAL)20.0;
    LC_this->LC_VD_PIDT1.LC_VD_T1 = (LC_TD_LREAL)0.05;
    LC_this->LC_VD_PIDT1.LC_VD_TI = (LC_TD_LREAL)0.2;
    lcfu___CNTRL_PIDT1(&(LC_this->LC_VD_PIDT1), pEPDB);
    LC_this->LC_VD_OUT = LC_this->LC_VD_PIDT1.LC_VD_OUT;
  }
}

#endif
