#ifndef LC_PROT_LCFU___UPDOWNCOUNTER__C
#define LC_PROT_LCFU___UPDOWNCOUNTER__C

#include <lcfu___updowncounter.h>
#include <lcfu_iec61131__AND.h>

/*                            FunctionBlocks                   */
void  lcfu___UPDOWNCOUNTER(LC_TD_FunctionBlock_UPDOWNCOUNTER* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_ERRORCODE = (LC_TD_SINT)0;
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_UP,LC_this->LC_VD_DOWN));
    if (conditionResult)
    {
      LC_this->LC_VD_ERRORCODE = (LC_TD_SINT)-1;
      return;
    }
  }
  if (LC_this->LC_VD_RESET)
  {
    LC_this->LC_VD_VALUE = (LC_TD_SINT)0;
    return;
  }
  if (LC_this->LC_VD_UP)
  {
    if ((LC_TD_BOOL)(LC_this->LC_VD_VALUE <= (LC_TD_SINT)126))
    {
      LC_this->LC_VD_VALUE = (LC_TD_SINT)(LC_this->LC_VD_VALUE + (LC_TD_SINT)1);
    }
    else
    {
      LC_this->LC_VD_ERRORCODE = (LC_TD_SINT)-2;
    }
  }
  else
  {
    if (LC_this->LC_VD_DOWN)
    {
      if ((LC_TD_BOOL)(LC_this->LC_VD_VALUE >= (LC_TD_SINT)-127))
      {
        LC_this->LC_VD_VALUE = (LC_TD_SINT)(LC_this->LC_VD_VALUE - (LC_TD_SINT)1);
      }
      else
      {
        LC_this->LC_VD_ERRORCODE = (LC_TD_SINT)-3;
      }
    }
  }
}

#endif
