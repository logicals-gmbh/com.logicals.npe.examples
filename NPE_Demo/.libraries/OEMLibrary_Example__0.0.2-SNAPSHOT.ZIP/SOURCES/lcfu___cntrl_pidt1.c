#ifndef LC_PROT_LCFU___CNTRL_PIDT1__C
#define LC_PROT_LCFU___CNTRL_PIDT1__C

#include <lcfu___cntrl_pidt1.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__DIV.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_CNTRL_PIDT1(LC_TD_FunctionBlock_CNTRL_PIDT1* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_CNTRL_PIDT1* p = LC_this; \
  LC_INIT_LREAL(&((p)->LC_VD_INP)); \
  LC_INIT_LREAL(&((p)->LC_VD_TI)); \
  LC_INIT_LREAL(&((p)->LC_VD_KV)); \
  LC_INIT_LREAL(&((p)->LC_VD_T1)); \
  LC_INIT_BOOL(&((p)->LC_VD_AUTO)); \
  LC_INIT_LREAL(&((p)->LC_VD_YHAND)); \
  LC_INIT_LREAL(&((p)->LC_VD_LVU)); \
  LC_INIT_LREAL(&((p)->LC_VD_LVD)); \
  LC_INIT_LREAL(&((p)->LC_VD_KP)); \
  LC_INIT_BOOL(&((p)->LC_VD_LU)); \
  LC_INIT_BOOL(&((p)->LC_VD_LD)); \
  LC_INIT_LREAL(&((p)->LC_VD_OUT)); \
  LC_INIT_LREAL(&((p)->LC_VD_P)); \
  LC_INIT_LREAL(&((p)->LC_VD_I)); \
  LC_INIT_LREAL(&((p)->LC_VD_D)); \
  LC_INIT_BOOL(&((p)->LC_VD_CYCLEFLAG)); \
  LC_INIT_LREAL(&((p)->LC_VD_IOLD)); \
}

void LC_WINIT_FUN_FunctionBlock_CNTRL_PIDT1(LC_TD_FunctionBlock_CNTRL_PIDT1* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_CNTRL_PIDT1* p = LC_this; \
  LC_WINIT_LREAL(&((p)->LC_VD_INP),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_TI),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_KV),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_T1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_AUTO),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_YHAND),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_LVU),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_LVD),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_KP),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LU),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LD),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_OUT),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_P),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_I),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_D),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_CYCLEFLAG),RF); \
  LC_WINIT_LREAL(&((p)->LC_VD_IOLD),RF); \
}

void  lcfu___CNTRL_PIDT1(LC_TD_FunctionBlock_CNTRL_PIDT1* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_TD_LREAL LC_VD_DTV;
  LC_TD_LREAL LC_VD_PDT1;
  LC_TD_BOOL LC_VD_CORR_I;
  LC_INIT_LREAL(&(LC_VD_DTV));
  LC_INIT_LREAL(&(LC_VD_PDT1));
  LC_VD_CORR_I = LC_EL_false;
  {
    LC_TD_Function_TO_LREAL lFunction_TO_LREAL;
    LC_INIT_Function_TO_LREAL(&lFunction_TO_LREAL);
    lFunction_TO_LREAL.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_LREAL__TIME(&lFunction_TO_LREAL, LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(20000000)), pEPDB);
    LC_VD_DTV = lFunction_TO_LREAL.LC_VD_TO_LREAL;
  }
  LC_this->LC_VD_P = (LC_TD_LREAL)(LC_this->LC_VD_INP * LC_this->LC_VD_KP);
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_CYCLEFLAG,(LC_TD_BOOL)(LC_this->LC_VD_T1 > (LC_TD_LREAL)0.0)));
    if (conditionResult)
    {
      LC_this->LC_VD_D = (lcfu_iec61131__DIV__LREAL__INL((LC_TD_LREAL)(LC_this->LC_VD_T1 * (LC_TD_LREAL)(LC_this->LC_VD_D + (LC_TD_LREAL)(LC_this->LC_VD_KV * (LC_TD_LREAL)(LC_this->LC_VD_INP - LC_this->LC_VD_IOLD)))),(LC_TD_LREAL)(LC_this->LC_VD_T1 + LC_VD_DTV)));
    }
    else
    {
      LC_this->LC_VD_D = (LC_TD_LREAL)0.0;
    }
  }
  LC_VD_PDT1 = (LC_TD_LREAL)(LC_this->LC_VD_P + LC_this->LC_VD_D);
  if (LC_this->LC_VD_AUTO)
  {
    {
      LC_TD_BOOL conditionResult = LC_EL_false;
      conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_CYCLEFLAG,(LC_TD_BOOL)(LC_this->LC_VD_KP != (LC_TD_LREAL)0.0))),(LC_TD_BOOL)(LC_this->LC_VD_TI > (LC_TD_LREAL)0.0)));
      if (conditionResult)
      {
        LC_this->LC_VD_I = (LC_TD_LREAL)(LC_this->LC_VD_I + (lcfu_iec61131__DIV__LREAL__INL((lcfu_iec61131__DIV__LREAL__INL((LC_TD_LREAL)((LC_TD_LREAL)(LC_this->LC_VD_KP * LC_VD_DTV) * (LC_TD_LREAL)(LC_this->LC_VD_INP + LC_this->LC_VD_IOLD)),(LC_TD_LREAL)2)),LC_this->LC_VD_TI)));
      }
    }
  }
  if (LC_this->LC_VD_AUTO)
  {
    LC_this->LC_VD_OUT = (LC_TD_LREAL)(LC_VD_PDT1 + LC_this->LC_VD_I);
  }
  else
  {
    LC_this->LC_VD_OUT = LC_this->LC_VD_YHAND;
    LC_VD_CORR_I = LC_EL_true;
  }
  LC_this->LC_VD_IOLD = LC_this->LC_VD_INP;
  if ((LC_TD_BOOL)(LC_this->LC_VD_OUT > LC_this->LC_VD_LVU))
  {
    LC_this->LC_VD_OUT = LC_this->LC_VD_LVU;
    LC_this->LC_VD_LU = LC_EL_true;
    LC_this->LC_VD_LD = LC_EL_false;
    LC_VD_CORR_I = LC_EL_true;
  }
  else
  {
    if ((LC_TD_BOOL)(LC_this->LC_VD_OUT <= LC_this->LC_VD_LVD))
    {
      LC_this->LC_VD_OUT = LC_this->LC_VD_LVD;
      LC_this->LC_VD_LU = LC_EL_false;
      LC_this->LC_VD_LD = LC_EL_true;
      LC_VD_CORR_I = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_LU = LC_EL_false;
      LC_this->LC_VD_LD = LC_EL_false;
    }
  }
  if (LC_VD_CORR_I)
  {
    LC_this->LC_VD_I = (LC_TD_LREAL)(LC_this->LC_VD_OUT - LC_VD_PDT1);
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_AUTO == LC_EL_false))
  {
    LC_this->LC_VD_OUT = LC_this->LC_VD_YHAND;
  }
  LC_this->LC_VD_CYCLEFLAG = LC_EL_true;
}

#endif
