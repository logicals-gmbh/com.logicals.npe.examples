#ifndef LC_PROT_LCPU___PIDT1_CONFIG_A__C
#define LC_PROT_LCPU___PIDT1_CONFIG_A__C

#include <lcpu___pidt1_config_a.h>

/*                            Programs                         */
void  lcpu___PIDT1_CONFIG_A(LC_TD_Program_PIDT1_CONFIG_A* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_PIDT1.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_PIDT1.LC_VD_KP = (LC_TD_LREAL)1.0;
    LC_this->LC_VD_PIDT1.LC_VD_TI = (LC_TD_LREAL)0.2;
    LC_this->LC_VD_PIDT1.LC_VD_KV = (LC_TD_LREAL)1.0;
    LC_this->LC_VD_PIDT1.LC_VD_T1 = (LC_TD_LREAL)0.05;
    LC_this->LC_VD_PIDT1.LC_VD_LVU = (LC_TD_LREAL)1000.0;
    LC_this->LC_VD_PIDT1.LC_VD_LVD = (LC_TD_LREAL)-1000.0;
    lcfu___CNTRL_PIDT1(&(LC_this->LC_VD_PIDT1), pEPDB);
  }
}

#endif
