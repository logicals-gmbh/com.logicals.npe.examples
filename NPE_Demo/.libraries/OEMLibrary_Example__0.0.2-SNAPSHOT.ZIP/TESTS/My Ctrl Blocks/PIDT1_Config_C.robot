*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:  | ... Author: |
...  | Date:  | ... Date:  |
...  | Reviewer:  | ... Reviewer:  |
...  | Date:  | ... Date:  |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |  |  |  |  |
...
...  = Excluded Requirements =
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  PIDT1_Config_C   MaxDataRows=48   TestSuitePath=${SUITE SOURCE}
  Set Defaults    &{DEFAULTS}
*** Variables ***
&{DEFAULTS}  Inp=0
*** Test Cases ***
test PIDT1_Config_C
  Head  Time  Inp  Out?  CycleTime=T#20ms
  Tol    /  /  0.0
  Shift  /  /  0
  Data  0  0  0          
  Data  1  0  0          
  Data  2  1  1.76428571428572          
  Data  3  1  1.66020408163265          
  Data  4  1  1.61443148688047          
  Data  5  1  1.61030820491462          
  Data  6  1  1.63593443208187          
  Data  7  1  1.68281030862991          
  Data  8  1  1.74486450616422          
  Data  9  1  1.81776036154587          
  Data  10  1  1.89840025824705          
  Data  11  1  1.98457161303361          
  Data  12  0  0.31040829502401          
  Data  13  0  0.50743449644572          
  Data  14  0  0.64816749746123          
  Data  15  0  0.74869106961516          
  Data  16  0  0.82049362115369          
  Data  17  0  0.87178115796692          
  Data  18  0  0.90841511283351          
  Data  19  0  0.93458222345251          
  Data  20  0  0.95327301675179          
  Data  21  0  0.96662358339414          
  Data  22  0  0.97615970242438          
