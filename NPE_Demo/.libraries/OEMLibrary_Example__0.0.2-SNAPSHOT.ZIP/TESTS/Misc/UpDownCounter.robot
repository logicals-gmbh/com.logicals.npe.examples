*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:  | ... Author:  |
...  | Date:  | ... Date:  |
...  | Reviewer:  | ... Reviewer:  |
...  | Date:  | ... Date:  |
...
...  = Referenced Documents: =
...  | Title  | Revision  | Date  | Remarks  |
...  |  |  |  |  |
...
...  = Change History: =
...  | Revision | Date | Author(s) | Change description/remarks |
...  |  |  |  |  |
...
...  = Excluded Requirements =
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  UpDownCounter   MaxDataRows=8   TestSuitePath=${SUITE SOURCE}
  Set Defaults    &{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Down=FALSE
...  Reset=FALSE
...  Up=FALSE
*** Test Cases ***
test1_Overview
  Head  Time  Down  Reset  Up  ErrorCode?  Value?  CycleTime=T#10ms
  Tol    /  /  /  /  0.0  0.0
  Shift  /  /  /  /  0  0
  Data  0  0  0  0  0  0          
  Data  1  0  0  1  0  1          
  Data  2  0  0  1  0  2          
  Data  3  1  0  0  0  1          
  Data  4  1  0  0  0  0          
  Data  5  1  0  0  0  -1          
  Data  6  1  1  0  0  0          
  Data  7  1  1  0  0  0          
  Finish

test2_InvalidArg
  Head  Time  Down  Reset  Up  ErrorCode?  CycleTime=T#10ms
  Tol    /  /  /  /  0.0
  Shift  /  /  /  /  0
  Data  0  0  0  0  0          
  Data  1  0  0  1  0          
  Data  2  0  1  0  0          
  Data  3  0  1  1  0          
  Data  4  1  0  0  0          
  Data  6  1  0  1  -1          
  Data  7  1  1  1  -1          
  Finish

