/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTUD for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTUD__H
#define LC_PROT_LCFU_IEC61131__CTUD__H

#include <LC3CGBase.h>
#include <LC3CGCounterImpl.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_CTUD
{
  _typedef_FunctionBlock_CTUD_ANY(INT)
} LCCG_StructAttrib LC_TD_FunctionBlock_CTUD;

/*                            Initialization Macro (cold start) */
#define LC_INIT_FunctionBlock_CTUD(p) _INIT_FunctionBlock_CTUD_ANY(INT,p)

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_CTUD(p,RF) { if (RF==0) LC_INIT_FunctionBlock_CTUD(p) }

/*                            Nameserver definition            */
#ifdef LC3_CG_GENERATE_RTS2_NAMESERVER
#define LCNS_EL_INI___CTUD _EL_INI___CTUD(INT)
#define LCNS_EL_CNT___CTUD 11
#endif /* LC3_CG_GENERATE_RTS2_NAMESERVER */

/*                            Prototype                        */
void  lcfu_iec61131__CTUD(LC_TD_FunctionBlock_CTUD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
