#ifndef LC3CGCOUNTERIMPL_H
#define LC3CGCOUNTERIMPL_H

/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK      :: C implementation of function block
** NOTES     :: for RTS compatible Systems.
**              CTU, CTU_INT, CTU_DINT, CTU_LINT, CTU_UINT, CTU_UDINT, CTU_ULINT
**              CTD, CTD_INT, CTD_DINT, CTD_LINT, CTD_UINT, CTD_UDINT, CTD_ULINT
*/

/** \defgroup DocGrpLCStdIECLibMacrosCounter Macros for counter modules
 * \ingroup DocGrpLCStdIECLibMacros
 */

/***************************************************************************
** Global Includes, Defines , Types
****************************************************************************/
#include <LC3CGEdgeDetect.h>

/*                            Typedefs                         */

/** \ingroup DocGrpLCStdIECLibMacrosCounter
 * \brief Define instance data for CDT block
 *
 * Generates a list of variables, which are used by the library block.<br>
 * \param [in] type name of IEC data type
 */
#define _typedef_FunctionBlock_CTD_ANY(type) \
        LC_TD_BOOL LC_VD_CD; \
        LC_TD_BOOL LC_VD_LD; \
        LC_TD_##type LC_VD_PV; \
        LC_TD_BOOL LC_VD_ENO; \
        LC_TD_BOOL LC_VD_Q; \
        LC_TD_##type LC_VD_CV; \
        LC_TD_BOOL LC_VD_CD_M;

/** \ingroup DocGrpLCStdIECLibMacrosCounter
 * \brief Define instance data for CTU block
 *
 * Generates a list of variables, which are used by the library block.<br>
 * \param [in] type name of IEC data type
 */
#define _typedef_FunctionBlock_CTU_ANY(type) \
        LC_TD_BOOL LC_VD_CU; \
        LC_TD_BOOL LC_VD_R; \
        LC_TD_##type LC_VD_PV; \
        LC_TD_BOOL LC_VD_ENO; \
        LC_TD_BOOL LC_VD_Q; \
        LC_TD_##type LC_VD_CV; \
        LC_TD_BOOL LC_VD_CU_M;

/** \ingroup DocGrpLCStdIECLibMacrosCounter
 * \brief Define instance data for CTUD block
 *
 * Generates a list of variables, which are used by the library block.<br>
 * \param [in] type name of IEC data type
 */
#define _typedef_FunctionBlock_CTUD_ANY(type) \
        LC_TD_BOOL LC_VD_CD; \
        LC_TD_BOOL LC_VD_CU; \
        LC_TD_BOOL LC_VD_LD; \
        LC_TD_BOOL LC_VD_R; \
        LC_TD_##type LC_VD_PV; \
        LC_TD_BOOL LC_VD_ENO; \
        LC_TD_BOOL LC_VD_QD; \
        LC_TD_BOOL LC_VD_QU; \
        LC_TD_##type LC_VD_CV; \
        LC_TD_BOOL LC_VD_CD_M; \
        LC_TD_BOOL LC_VD_CU_M;

/** \ingroup DocGrpLCStdIECLibMacrosCounter
 * \brief Initialize instance data for CDT block
 *
 * Initialize variables, which are used by the library block.<br>
 * \param [in] type name of IEC data type
 * \param [out] p pointer to instance data
 */
#define _INIT_FunctionBlock_CTD_ANY(type,p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_CD)); \
  LC_INIT_BOOL(&((p)->LC_VD_LD)); \
  LC_INIT_##type(&((p)->LC_VD_PV)); \
  LC_INIT_BOOL(&((p)->LC_VD_Q)); \
  LC_INIT_##type(&((p)->LC_VD_CV)); \
  LC_INIT_BOOL(&((p)->LC_VD_CD_M)); \
}

/** \ingroup DocGrpLCStdIECLibMacrosCounter
 * \brief Initialize instance data for CTU block
 *
 * Initialize variables, which are used by the library block.<br>
 * \param [in] type name of IEC data type
 * \param [out] p pointer to instance data
 */
#define _INIT_FunctionBlock_CTU_ANY(type,p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_CU)); \
  LC_INIT_BOOL(&((p)->LC_VD_R)); \
  LC_INIT_##type(&((p)->LC_VD_PV)); \
  LC_INIT_BOOL(&((p)->LC_VD_Q)); \
  LC_INIT_##type(&((p)->LC_VD_CV)); \
  LC_INIT_BOOL(&((p)->LC_VD_CU_M)); \
}

/** \ingroup DocGrpLCStdIECLibMacrosCounter
 * \brief Initialize instance data for CTUD block
 *
 * Initialize variables, which are used by the library block.<br>
 * \param [in] type name of IEC data type
 * \param [out] p pointer to instance data
 */
#define _INIT_FunctionBlock_CTUD_ANY(type,p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_CU)); \
  LC_INIT_BOOL(&((p)->LC_VD_CD)); \
  LC_INIT_BOOL(&((p)->LC_VD_R)); \
  LC_INIT_BOOL(&((p)->LC_VD_LD)); \
  LC_INIT_##type(&((p)->LC_VD_PV)); \
  LC_INIT_BOOL(&((p)->LC_VD_QU)); \
  LC_INIT_BOOL(&((p)->LC_VD_QD)); \
  LC_INIT_##type(&((p)->LC_VD_CV)); \
  LC_INIT_BOOL(&((p)->LC_VD_CU_M)); \
  LC_INIT_BOOL(&((p)->LC_VD_CD_M)); \
}

#ifdef LC3_CG_GENERATE_RTS2_NAMESERVER
/*                            Nameserver definition            */
#define _EL_INI___CTD_ANY_intern(type,inst) \
  { \
    {\
      sizeof(RTTypeNS_ElementNode), \
      "CD", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_CD), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_INPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "LD", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_LD), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_INPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "PV", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_PV), \
      sizeof(LC_TD_##type), \
      LCOOS_VAREXP_VAR_INPUT, \
      NULL, \
      LCOOS_VAREXP_##type, \
      LC_STRINGIFY(type), \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "ENO", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_ENO), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_OUTPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "Q", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_Q), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_OUTPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "CV", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_CV), \
      sizeof(LC_TD_##type), \
      LCOOS_VAREXP_VAR_OUTPUT, \
      NULL, \
      LCOOS_VAREXP_##type, \
      LC_STRINGIFY(type), \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "CD_M", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_CD_M), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
  }
#define _EL_INI___CTD(type)     _EL_INI___CTD_ANY_intern(type,CTD)
#define _EL_INI___CTD_ANY(type) _EL_INI___CTD_ANY_intern(type,CTD_##type)

#define _EL_INI___CTU_ANY_intern(type,inst) \
  { \
    {\
      sizeof(RTTypeNS_ElementNode), \
      "CU", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_CU), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_INPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "R", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_R), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_INPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "PV", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_PV), \
      sizeof(LC_TD_##type), \
      LCOOS_VAREXP_VAR_INPUT, \
      NULL, \
      LCOOS_VAREXP_##type, \
      LC_STRINGIFY(type), \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "ENO", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_ENO), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_OUTPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "Q", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_Q), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_OUTPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "CV", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_CV), \
      sizeof(LC_TD_##type), \
      LCOOS_VAREXP_VAR_OUTPUT, \
      NULL, \
      LCOOS_VAREXP_##type, \
      LC_STRINGIFY(type), \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "CU_M", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_CU_M), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
  }
#define _EL_INI___CTU(type)     _EL_INI___CTU_ANY_intern(type,CTU)
#define _EL_INI___CTU_ANY(type) _EL_INI___CTU_ANY_intern(type,CTU_##type)
  
#define _EL_INI___CTUD_ANY_intern(type,inst) \
  { \
    {\
      sizeof(RTTypeNS_ElementNode), \
      "CU", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_CU), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_INPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "CD", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_CD), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_INPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "R", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_R), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_INPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "LD", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_LD), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_INPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "PV", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_PV), \
      sizeof(LC_TD_##type), \
      LCOOS_VAREXP_VAR_INPUT, \
      NULL, \
      LCOOS_VAREXP_##type, \
      LC_STRINGIFY(type), \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "ENO", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_ENO), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_OUTPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "QU", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_QU), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_OUTPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "QD", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_QD), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR_OUTPUT, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "CV", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_CV), \
      sizeof(LC_TD_##type), \
      LCOOS_VAREXP_VAR_OUTPUT, \
      NULL, \
      LCOOS_VAREXP_##type, \
      LC_STRINGIFY(type), \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "CU_M", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_CU_M), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
    ,\
    {\
      sizeof(RTTypeNS_ElementNode), \
      "CD_M", \
      0, \
      offsetof(LC_TD_FunctionBlock_##inst,LC_VD_CD_M), \
      sizeof(LC_TD_BOOL), \
      LCOOS_VAREXP_VAR, \
      NULL, \
      LCOOS_VAREXP_BOOL, \
      "BOOL", \
      NULL, \
      NULL, \
      NULL, \
      NULL, \
      0 \
    }\
  }
#define _EL_INI___CTUD(type)     _EL_INI___CTUD_ANY_intern(type,CTUD)
#define _EL_INI___CTUD_ANY(type) _EL_INI___CTUD_ANY_intern(type,CTUD_##type)

#endif  /* LC3_CG_GENERATE_RTS2_NAMESERVER */

/*                            Implementation                   */
#define _lcfu_iec61131__CTU_ANY(LC_this, type, PVmax) \
  /* Perform Edge Recognition */ \
  LC3_MSI_EDGE(LC_this->LC_VD_CU,LC_this->LC_VD_CU_M) \
  \
  if (LC_this->LC_VD_R) \
  { \
    LC_this->LC_VD_CV = LC_MC_##type(0x0); \
  } else { \
    if (LC_this->LC_VD_CU) \
    { \
      if (LC_this->LC_VD_CV < PVmax) \
      { \
        LC_this->LC_VD_CV = LC_this->LC_VD_CV + LC_MC_##type(0x1); \
      } \
    } \
  } \
  LC_this->LC_VD_Q = LC_this->LC_VD_CV >= LC_this->LC_VD_PV;
 
#define _lcfu_iec61131__CTD_ANY(LC_this, type, PVmin) \
  /* Perform Edge Recognition */ \
  LC3_MSI_EDGE(LC_this->LC_VD_CD,LC_this->LC_VD_CD_M) \
  \
  if (LC_this->LC_VD_LD) \
  { \
    LC_this->LC_VD_CV = LC_this->LC_VD_PV; \
  } else { \
    if (LC_this->LC_VD_CD) \
    { \
      if (LC_this->LC_VD_CV > PVmin) \
      { \
        LC_this->LC_VD_CV = LC_this->LC_VD_CV - LC_MC_##type(0x1); \
      } \
    } \
  } \
  LC_this->LC_VD_Q = LC_this->LC_VD_CV <= LC_MC_##type(0x0);
 
#define _lcfu_iec61131__CTUD_ANY(LC_this, type, PVmax, PVmin) \
  /* Perform Edge Recognition */ \
  LC3_MSI_EDGE(LC_this->LC_VD_CU,LC_this->LC_VD_CU_M) \
  LC3_MSI_EDGE(LC_this->LC_VD_CD,LC_this->LC_VD_CD_M) \
  \
  if (LC_this->LC_VD_R) \
  { \
    LC_this->LC_VD_CV = LC_MC_##type(0x0); \
  } else { \
    if (LC_this->LC_VD_LD) \
    { \
      LC_this->LC_VD_CV = LC_this->LC_VD_PV; \
    } else { \
      if (!(LC_this->LC_VD_CU && LC_this->LC_VD_CD)) \
      { \
        if (LC_this->LC_VD_CU) \
        { \
          if (LC_this->LC_VD_CV < PVmax) \
          { \
            LC_this->LC_VD_CV = LC_this->LC_VD_CV + LC_MC_##type(0x1); \
          } \
        } else { \
          if (LC_this->LC_VD_CD) \
          { \
            if (LC_this->LC_VD_CV > PVmin) \
            { \
              LC_this->LC_VD_CV = LC_this->LC_VD_CV - LC_MC_##type(0x1); \
            } \
          } \
        }  \
      } \
    } \
  } \
  LC_this->LC_VD_QU = LC_this->LC_VD_CV >= LC_this->LC_VD_PV; \
  LC_this->LC_VD_QD = LC_this->LC_VD_CV <= LC_MC_##type(0x0);

#endif /* LC3CGCOUNTERIMPL_H */
