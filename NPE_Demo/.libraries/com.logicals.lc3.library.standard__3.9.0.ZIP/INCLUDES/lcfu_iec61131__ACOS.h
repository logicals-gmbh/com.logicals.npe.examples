/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function ACOS for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__ACOS__H
#define LC_PROT_LCFU_IEC61131__ACOS__H

#include <LC3CGBase.h>
#include <LC3RTLibMath.h>       /* for acos() */

#define DEF_LC_TD_Function_ACOS_ANY_REAL(realtype) \
typedef struct _LC_TD_Function_ACOS__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##realtype LC_VD_ACOS; \
} LCCG_StructAttrib LC_TD_Function_ACOS__##realtype;

DEF_LC_TD_Function_ACOS_ANY_REAL(REAL)
DEF_LC_TD_Function_ACOS_ANY_REAL(LREAL)

/*                            Initialization Macro             */
#define LC_INIT_Function_ACOS_ANY_REAL(p,realtype) \
{ \
  LC_INIT_##realtype(&((p)->LC_VD_ACOS)); \
}

#define LC_INIT_Function_ACOS__REAL(p)    LC_INIT_Function_ACOS_ANY_REAL(p,REAL)
#define LC_INIT_Function_ACOS__LREAL(p)   LC_INIT_Function_ACOS_ANY_REAL(p,LREAL)

/*
**  calculates the principal arc sine of input in radians
**  The output shall be of the same realtype as IN.
*/
#define LC_MF_ACOS_SETERR(Err) ((Err)=LC_EL_false)

#define LC_MF_ACOS_ANY_REAL(realtype,fun,IN,Err)  ((IN)<-1.0f||(IN)>1.0f?LC_MF_ACOS_SETERR(Err),0.0f:(LC_TD_##realtype)fun(IN))
#define LC_MF_ACOS_ANY_LREAL(realtype,fun,IN,Err) ((IN)<-1.0 ||(IN)>1.0 ?LC_MF_ACOS_SETERR(Err),0.0 :(LC_TD_##realtype)fun(IN))

/*  Prototype */
#define lcfu_iec61131__ACOS__REAL(LC_this, IN, pEPDB)  (LC_this)->LC_VD_ACOS = LC_MF_ACOS_ANY_REAL(REAL,LC_ACOSF,IN,(LC_this)->LC_VD_ENO)
#define lcfu_iec61131__ACOS__LREAL(LC_this, IN, pEPDB) (LC_this)->LC_VD_ACOS = LC_MF_ACOS_ANY_LREAL(LREAL,LC_ACOS,IN,(LC_this)->LC_VD_ENO)

#endif
