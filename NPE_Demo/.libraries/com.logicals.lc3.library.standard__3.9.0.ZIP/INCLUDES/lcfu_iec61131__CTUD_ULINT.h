/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTUD_ULINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTUD_ULINT__H
#define LC_PROT_LCFU_IEC61131__CTUD_ULINT__H

#include <LC3CGBase.h>
#include <LC3CGCounterImpl.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_CTUD_ULINT
{
  _typedef_FunctionBlock_CTUD_ANY(ULINT)
} LCCG_StructAttrib LC_TD_FunctionBlock_CTUD_ULINT;

/*                            Initialization Macro (cold start) */
#define LC_INIT_FunctionBlock_CTUD_ULINT(p) _INIT_FunctionBlock_CTUD_ANY(ULINT,p)

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_CTUD_ULINT(p,RF) { if (RF==0) LC_INIT_FunctionBlock_CTUD_ULINT(p) }

/*                            Nameserver definition            */
#ifdef LC3_CG_GENERATE_RTS2_NAMESERVER
#define LCNS_EL_INI___CTUD_ULINT _EL_INI___CTUD_ANY(ULINT)
#define LCNS_EL_CNT___CTUD_ULINT 11
#endif /* LC3_CG_GENERATE_RTS2_NAMESERVER */

/*                            Prototype                        */
void  lcfu_iec61131__CTUD_ULINT(LC_TD_FunctionBlock_CTUD_ULINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
