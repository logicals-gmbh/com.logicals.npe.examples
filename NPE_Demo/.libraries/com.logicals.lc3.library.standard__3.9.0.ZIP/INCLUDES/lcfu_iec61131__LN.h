/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function LN for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__LN__H
#define LC_PROT_LCFU_IEC61131__LN__H

#include <LC3CGBase.h>
#include <LC3RTLibMath.h>       /* for log() */

#define DEF_LC_TD_Function_LN_ANY_REAL(realtype) \
typedef struct _LC_TD_Function_LN__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##realtype LC_VD_LN; \
} LCCG_StructAttrib LC_TD_Function_LN__##realtype;

DEF_LC_TD_Function_LN_ANY_REAL(REAL)
DEF_LC_TD_Function_LN_ANY_REAL(LREAL)

/*                            Initialization Macro             */
#define LC_INIT_Function_LN_ANY_REAL(p,realtype) \
{ \
  LC_INIT_##realtype(&((p)->LC_VD_LN)); \
}

#define LC_INIT_Function_LN__REAL(p)  LC_INIT_Function_LN_ANY_REAL(p,REAL)
#define LC_INIT_Function_LN__LREAL(p) LC_INIT_Function_LN_ANY_REAL(p,LREAL)

/*
**  calculates the natural logarithm of input
**  The output shall be of the same realtype as IN.
*/
#define LC_MF_LN_SETERR(Err) ((Err)=LC_EL_false)

#define LC_MF_LN_ANY_REAL(realtype,fun,IN,Err)  ((IN)<=0.0f?LC_MF_LN_SETERR(Err),0.0f:(LC_TD_##realtype)fun(IN))
#define LC_MF_LN_ANY_LREAL(realtype,fun,IN,Err) ((IN)<=0.0 ?LC_MF_LN_SETERR(Err),0.0 :(LC_TD_##realtype)fun(IN))

/*  Prototype */
#define lcfu_iec61131__LN__REAL(LC_this, IN, pEPDB)  (LC_this)->LC_VD_LN = LC_MF_LN_ANY_REAL(REAL,LC_LOGF,IN,(LC_this)->LC_VD_ENO)
#define lcfu_iec61131__LN__LREAL(LC_this, IN, pEPDB) (LC_this)->LC_VD_LN = LC_MF_LN_ANY_LREAL(LREAL,LC_LOG,IN,(LC_this)->LC_VD_ENO)

#endif
