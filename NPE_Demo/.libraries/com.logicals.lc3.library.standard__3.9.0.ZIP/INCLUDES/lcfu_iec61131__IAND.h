/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function IAND for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__IAND__H
#define LC_PROT_LCFU_IEC61131__IAND__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
#define DEF_LC_TD_Function_IAND_ANY(type) \
typedef struct _LC_TD_Function_IAND__##type \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	LC_TD_##type LC_VD_IAND; \
} LCCG_StructAttrib LC_TD_Function_IAND__##type;

DEF_LC_TD_Function_IAND_ANY(SINT)
DEF_LC_TD_Function_IAND_ANY(USINT)
DEF_LC_TD_Function_IAND_ANY(INT)
DEF_LC_TD_Function_IAND_ANY(UINT)
DEF_LC_TD_Function_IAND_ANY(DINT)
DEF_LC_TD_Function_IAND_ANY(UDINT)
DEF_LC_TD_Function_IAND_ANY(LINT)
DEF_LC_TD_Function_IAND_ANY(ULINT)

/*                            Initialization Macro             */
#define LC_INIT_Function_IAND_ANY(p,type) \
{ \
	LC_INIT_##type(&((p)->LC_VD_IAND)); \
}

#define LC_INIT_Function_IAND__SINT(p)   LC_INIT_Function_IAND_ANY(p,SINT)
#define LC_INIT_Function_IAND__USINT(p)  LC_INIT_Function_IAND_ANY(p,USINT)
#define LC_INIT_Function_IAND__INT(p)    LC_INIT_Function_IAND_ANY(p,INT)
#define LC_INIT_Function_IAND__UINT(p)   LC_INIT_Function_IAND_ANY(p,UINT)
#define LC_INIT_Function_IAND__DINT(p)   LC_INIT_Function_IAND_ANY(p,DINT)
#define LC_INIT_Function_IAND__UDINT(p)  LC_INIT_Function_IAND_ANY(p,UDINT)
#define LC_INIT_Function_IAND__LINT(p)   LC_INIT_Function_IAND_ANY(p,LINT)
#define LC_INIT_Function_IAND__ULINT(p)  LC_INIT_Function_IAND_ANY(p,ULINT)

/* Bitwise and Boolean IAND of arguments                        */
#define LC_MF_IAND_ANY_2(IN1,IN2)                                                                  ((IN1)&(IN2))
#define LC_MF_IAND_ANY_3(IN1,IN2,IN3)                                                              ((IN1)&(IN2)&(IN3))
#define LC_MF_IAND_ANY_4(IN1,IN2,IN3,IN4)                                                          ((IN1)&(IN2)&(IN3)&(IN4))
#define LC_MF_IAND_ANY_5(IN1,IN2,IN3,IN4,IN5)                                                      ((IN1)&(IN2)&(IN3)&(IN4)&(IN5))
#define LC_MF_IAND_ANY_6(IN1,IN2,IN3,IN4,IN5,IN6)                                                  ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6))
#define LC_MF_IAND_ANY_7(IN1,IN2,IN3,IN4,IN5,IN6,IN7)                                              ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7))
#define LC_MF_IAND_ANY_8(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8)                                          ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8))
#define LC_MF_IAND_ANY_9(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9)                                      ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9))
#define LC_MF_IAND_ANY_10(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10)                                ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10))
#define LC_MF_IAND_ANY_11(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11)                           ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10)&(IN11))
#define LC_MF_IAND_ANY_12(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12)                      ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10)&(IN11)&(IN12))
#define LC_MF_IAND_ANY_13(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13)                 ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10)&(IN11)&(IN12)&(IN13))
#define LC_MF_IAND_ANY_14(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14)            ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10)&(IN11)&(IN12)&(IN13)&(IN14))
#define LC_MF_IAND_ANY_15(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15)       ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10)&(IN11)&(IN12)&(IN13)&(IN14)&(IN15))
#define LC_MF_IAND_ANY_16(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,IN16)  ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10)&(IN11)&(IN12)&(IN13)&(IN14)&(IN15)&(IN16))

/*                            Impl (not inlined)                     */
#define lcfu_iec61131__IAND__ANY__2(LC_this, IN1, IN2, pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_2(IN1,IN2)

#define lcfu_iec61131__IAND__ANY__3(LC_this, IN1, IN2, IN3,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_3(IN1,IN2,IN3)

#define lcfu_iec61131__IAND__ANY__4(LC_this, IN1, IN2, IN3,IN4,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_4(IN1,IN2,IN3,IN4)

#define lcfu_iec61131__IAND__ANY__5(LC_this, IN1, IN2, IN3,IN4,IN5,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_5(IN1,IN2,IN3,IN4,IN5)

#define lcfu_iec61131__IAND__ANY__6(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_6(IN1,IN2,IN3,IN4,IN5,IN6)

#define lcfu_iec61131__IAND__ANY__7(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_7(IN1,IN2,IN3,IN4,IN5,IN6,IN7)

#define lcfu_iec61131__IAND__ANY__8(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_8(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8)

#define lcfu_iec61131__IAND__ANY__9(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_9(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9)

#define lcfu_iec61131__IAND__ANY__10(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_10(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10)

#define lcfu_iec61131__IAND__ANY__11(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_11(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11)

#define lcfu_iec61131__IAND__ANY__12(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_12(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12)

#define lcfu_iec61131__IAND__ANY__13(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_13(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13)

#define lcfu_iec61131__IAND__ANY__14(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_14(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14)

#define lcfu_iec61131__IAND__ANY__15(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_15(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15)

#define lcfu_iec61131__IAND__ANY__16(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,IN16,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_16(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,IN16)

#endif
