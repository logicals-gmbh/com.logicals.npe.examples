/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTD for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTD__H
#define LC_PROT_LCFU_IEC61131__CTD__H

#include <LC3CGBase.h>
#include <LC3CGCounterImpl.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_CTD
{
  _typedef_FunctionBlock_CTD_ANY(INT)
} LCCG_StructAttrib LC_TD_FunctionBlock_CTD;

/*                            Initialization Macro (cold start))) */
#define LC_INIT_FunctionBlock_CTD(p) _INIT_FunctionBlock_CTD_ANY(INT,p)

/*                            Initialization Macro (warm start))) */
#define LC_WINIT_FunctionBlock_CTD(p,RF) { if (RF==0) LC_INIT_FunctionBlock_CTD(p) }

/*                            Nameserver definition            */
#ifdef LC3_CG_GENERATE_RTS2_NAMESERVER
#define LCNS_EL_INI___CTD _EL_INI___CTD(INT)
#define LCNS_EL_CNT___CTD 7
#endif /* LC3_CG_GENERATE_RTS2_NAMESERVER */

/*                            Prototype                        */
void  lcfu_iec61131__CTD(LC_TD_FunctionBlock_CTD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
