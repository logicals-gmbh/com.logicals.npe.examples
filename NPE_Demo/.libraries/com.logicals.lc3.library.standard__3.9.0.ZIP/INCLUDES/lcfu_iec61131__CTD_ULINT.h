/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTD_ULINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTD_ULINT__H
#define LC_PROT_LCFU_IEC61131__CTD_ULINT__H

#include <LC3CGBase.h>
#include <LC3CGCounterImpl.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_CTD_ULINT
{
  _typedef_FunctionBlock_CTD_ANY(ULINT)
} LCCG_StructAttrib LC_TD_FunctionBlock_CTD_ULINT;

/*                            Initialization Macro (cold start) */
#define LC_INIT_FunctionBlock_CTD_ULINT(p) _INIT_FunctionBlock_CTD_ANY(ULINT,p)

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_CTD_ULINT(p,RF) { if (RF==0) LC_INIT_FunctionBlock_CTD_ULINT(p) }

/*                            Nameserver definition            */
#ifdef LC3_CG_GENERATE_RTS2_NAMESERVER
#define LCNS_EL_INI___CTD_ULINT _EL_INI___CTD_ANY(ULINT)
#define LCNS_EL_CNT___CTD_ULINT 7
#endif /* LC3_CG_GENERATE_RTS2_NAMESERVER */

/*                            Prototype                        */
void  lcfu_iec61131__CTD_ULINT(LC_TD_FunctionBlock_CTD_ULINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
