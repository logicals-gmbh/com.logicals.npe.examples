/* Copyright (C) logi.cals GmbH. All rights reserved.             */

/*
** TASK :: C implementation of function SUB_DT_DT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__SUB_DT_DT__H
#define LC_PROT_LCFU_IEC61131__SUB_DT_DT__H

#include <LC3CGBase.h>

/*                            Typedefs                            */
typedef struct _LC_TD_Function_SUB_DT_DT \
{                                          \
	LC_TD_BOOL LC_VD_ENO;                  \
	LC_TD_TIME LC_VD_SUB_DT_DT;                \
} LCCG_StructAttrib LC_TD_Function_SUB_DT_DT;


/*                      Initialization Macro                      */
#define LC_INIT_Function_SUB_DT_DT(p)    LC_INIT_TIME(&((p)->LC_VD_SUB_DT_DT));

/*            Implementation of helper macros (inlined)           */
#define LC_MF_SUB_DT_DT(IN1,IN2) ((IN1)-(IN2))

/*                       Impl (not inlined)                       */
#define  lcfu_iec61131__SUB_DT_DT(LC_this, IN1, IN2, pEPDB) \
	(LC_this)->LC_VD_SUB_DT_DT = LC_MF_SUB_DT_DT(IN1,IN2)

#endif
