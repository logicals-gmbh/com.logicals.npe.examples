/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function ROR for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__ROR__H
#define LC_PROT_LCFU_IEC61131__ROR__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
#define DEF_LC_TD_Function_ROR_ANY(type) \
typedef struct _LC_TD_Function_ROR__##type \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	LC_TD_##type LC_VD_ROR; \
} LCCG_StructAttrib LC_TD_Function_ROR__##type;

DEF_LC_TD_Function_ROR_ANY(BOOL)
DEF_LC_TD_Function_ROR_ANY(BYTE)
DEF_LC_TD_Function_ROR_ANY(WORD)
DEF_LC_TD_Function_ROR_ANY(DWORD)
DEF_LC_TD_Function_ROR_ANY(LWORD)

/*                            Initialization Macro             */
#define LC_INIT_Function_ROR_ANY(p,type) \
{ \
	LC_INIT_##type(&((p)->LC_VD_ROR)); \
}

#define LC_INIT_Function_ROR__BOOL(p)   LC_INIT_Function_ROR_ANY(p,BOOL)
#define LC_INIT_Function_ROR__BYTE(p)   LC_INIT_Function_ROR_ANY(p,BYTE)
#define LC_INIT_Function_ROR__WORD(p)   LC_INIT_Function_ROR_ANY(p,WORD)
#define LC_INIT_Function_ROR__DWORD(p)  LC_INIT_Function_ROR_ANY(p,DWORD)
#define LC_INIT_Function_ROR__LWORD(p)  LC_INIT_Function_ROR_ANY(p,LWORD)

/*                            Impl (not inlined)               */
#define LC_MF_ROR_ANY(type,IN,N) /*lint --e{845} */\
        (LC_TD_##type) (((IN) >> ((N) & (sizeof(LC_TD_##type)*8-1))) | ((((N) & (sizeof(LC_TD_##type)*8-1)) == 0) ? 0 : (IN) << ((sizeof(LC_TD_##type)*8 - ((N) & (sizeof(LC_TD_##type)*8-1))))))

#define lcfu_iec61131__ROR__BOOL(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_ROR = (IN)
#define lcfu_iec61131__ROR__BYTE(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_ROR = LC_MF_ROR_ANY(BYTE,IN,N)
#define lcfu_iec61131__ROR__WORD(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_ROR = LC_MF_ROR_ANY(WORD,IN,N)
#define lcfu_iec61131__ROR__DWORD(LC_this, IN, N, pEPDB) (LC_this)->LC_VD_ROR = LC_MF_ROR_ANY(DWORD,IN,N)
#define lcfu_iec61131__ROR__LWORD(LC_this, IN, N, pEPDB) (LC_this)->LC_VD_ROR = LC_MF_ROR_ANY(LWORD,IN,N)

#endif
