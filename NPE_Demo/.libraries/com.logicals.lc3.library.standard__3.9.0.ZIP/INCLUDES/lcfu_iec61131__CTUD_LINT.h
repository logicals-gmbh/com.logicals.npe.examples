/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTUD_LINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTUD_LINT__H
#define LC_PROT_LCFU_IEC61131__CTUD_LINT__H

#include <LC3CGBase.h>
#include <LC3CGCounterImpl.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_CTUD_LINT
{
  _typedef_FunctionBlock_CTUD_ANY(LINT)
} LCCG_StructAttrib LC_TD_FunctionBlock_CTUD_LINT;

/*                            Initialization Macro (cold start) */
#define LC_INIT_FunctionBlock_CTUD_LINT(p) _INIT_FunctionBlock_CTUD_ANY(LINT,p)

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_CTUD_LINT(p,RF) { if (RF==0) LC_INIT_FunctionBlock_CTUD_LINT(p) }

/*                            Nameserver definition            */
#ifdef LC3_CG_GENERATE_RTS2_NAMESERVER
#define LCNS_EL_INI___CTUD_LINT _EL_INI___CTUD_ANY(LINT)
#define LCNS_EL_CNT___CTUD_LINT 11
#endif /* LC3_CG_GENERATE_RTS2_NAMESERVER */

/*                            Prototype                        */
void  lcfu_iec61131__CTUD_LINT(LC_TD_FunctionBlock_CTUD_LINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
