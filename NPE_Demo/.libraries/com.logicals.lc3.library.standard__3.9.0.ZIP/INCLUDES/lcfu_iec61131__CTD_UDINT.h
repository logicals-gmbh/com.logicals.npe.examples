/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTD_UDINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTD_UDINT__H
#define LC_PROT_LCFU_IEC61131__CTD_UDINT__H

#include <LC3CGBase.h>
#include <LC3CGCounterImpl.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_CTD_UDINT
{
  _typedef_FunctionBlock_CTD_ANY(UDINT)
} LCCG_StructAttrib LC_TD_FunctionBlock_CTD_UDINT;

/*                            Initialization Macro (cold start) */
#define LC_INIT_FunctionBlock_CTD_UDINT(p) _INIT_FunctionBlock_CTD_ANY(UDINT,p)

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_CTD_UDINT(p,RF) { if (RF==0) LC_INIT_FunctionBlock_CTD_UDINT(p) }

/*                            Nameserver definition            */
#ifdef LC3_CG_GENERATE_RTS2_NAMESERVER
#define LCNS_EL_INI___CTD_UDINT _EL_INI___CTD_ANY(UDINT)
#define LCNS_EL_CNT___CTD_UDINT 7
#endif /* LC3_CG_GENERATE_RTS2_NAMESERVER */

/*                            Prototype                        */
void  lcfu_iec61131__CTD_UDINT(LC_TD_FunctionBlock_CTD_UDINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
