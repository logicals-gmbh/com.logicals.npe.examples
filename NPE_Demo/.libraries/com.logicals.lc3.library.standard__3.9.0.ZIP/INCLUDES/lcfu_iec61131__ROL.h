/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function ROL for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__ROL__H
#define LC_PROT_LCFU_IEC61131__ROL__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
#define DEF_LC_TD_Function_ROL_ANY(type) \
typedef struct _LC_TD_Function_ROL__##type \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	LC_TD_##type LC_VD_ROL; \
} LCCG_StructAttrib LC_TD_Function_ROL__##type;

DEF_LC_TD_Function_ROL_ANY(BOOL)
DEF_LC_TD_Function_ROL_ANY(BYTE)
DEF_LC_TD_Function_ROL_ANY(WORD)
DEF_LC_TD_Function_ROL_ANY(DWORD)
DEF_LC_TD_Function_ROL_ANY(LWORD)

/*                            Initialization Macro             */
#define LC_INIT_Function_ROL_ANY(p,type) \
{ \
	LC_INIT_##type(&((p)->LC_VD_ROL)); \
}

#define LC_INIT_Function_ROL__BOOL(p)   LC_INIT_Function_ROL_ANY(p,BOOL)
#define LC_INIT_Function_ROL__BYTE(p)   LC_INIT_Function_ROL_ANY(p,BYTE)
#define LC_INIT_Function_ROL__WORD(p)   LC_INIT_Function_ROL_ANY(p,WORD)
#define LC_INIT_Function_ROL__DWORD(p)  LC_INIT_Function_ROL_ANY(p,DWORD)
#define LC_INIT_Function_ROL__LWORD(p)  LC_INIT_Function_ROL_ANY(p,LWORD)

/*                            Impl (not inlined)               */
#define LC_MF_ROL_ANY(type,IN,N) /*lint --e{845} */\
        (LC_TD_##type) (((IN) << ((N) & (sizeof(LC_TD_##type)*8-1))) | ((((N) & (sizeof(LC_TD_##type)*8-1)) == 0) ? 0 : (IN) >> ((sizeof(LC_TD_##type)*8 - ((N) & (sizeof(LC_TD_##type)*8-1))))))

#define lcfu_iec61131__ROL__BOOL(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_ROL = (IN)
#define lcfu_iec61131__ROL__BYTE(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_ROL = LC_MF_ROL_ANY(BYTE,IN,N)
#define lcfu_iec61131__ROL__WORD(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_ROL = LC_MF_ROL_ANY(WORD,IN,N)
#define lcfu_iec61131__ROL__DWORD(LC_this, IN, N, pEPDB) (LC_this)->LC_VD_ROL = LC_MF_ROL_ANY(DWORD,IN,N)
#define lcfu_iec61131__ROL__LWORD(LC_this, IN, N, pEPDB) (LC_this)->LC_VD_ROL = LC_MF_ROL_ANY(LWORD,IN,N)

#endif
