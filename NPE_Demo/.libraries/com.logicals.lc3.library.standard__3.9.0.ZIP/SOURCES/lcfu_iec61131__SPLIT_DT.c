/* Copyright (C) logi.cals GmbH. All rights reserved. */

#ifndef LC_PROT_LCFU_IEC61131__SPLIT_DT_C
#define LC_PROT_LCFU_IEC61131__SPLIT_DT_C

#include <lcfu_iec61131__SPLIT_DT.h>
#include <LC3RTLibStdTypes.h>

#if !defined(_LC_INTERN_TIME_HELPER_DECLARED)
#define _LC_INTERN_TIME_HELPER_DECLARED
/* declared in CONCAT_DT.c and SPLIT_DT.c */
struct _lc_tm {
  lc_int32_t tm_sec;
  lc_int32_t tm_min;
  lc_int32_t tm_hour;
  lc_int32_t tm_mday;
  lc_int32_t tm_mon;
  lc_int32_t tm_year;
  lc_int32_t tm_wday;
  lc_int32_t tm_yday;
  lc_int32_t tm_isdst;
};
#endif  /* _LC_INTERN_TIME_HELPER_DECLARED */

#define _lc_time_t lc_int64_t

static void _lc_gmtime(_lc_time_t time, struct _lc_tm *timep);

void lcfu_iec61131__SplitDateAndTime(LC_TD_DT value, LC_TD_Function_SPLIT_DT* LC_this)
{
  struct _lc_tm tm;
  _lc_time_t t_in_sec;
  lc_uint64_t big_time;

  big_time = (lc_uint64_t)value / (RT_TARGET_TIME_FREQU / 1000);
  LC_this->LC_VD_MILLISECOND = (LC_TD_UINT)(big_time % 1000);
  big_time /= 1000; /* now we have time seconds in ms */

  if (big_time > 0xFFFFFFFEL) {
    /* value is out of range (2106-02-07-06:28:14) */
    LC_this->LC_VD_MILLISECOND = 0;
    LC_this->LC_VD_ENO = LC_EL_false;
    return;
  }

  /* NOTE: time_t ist signed, so at first cast unsigend to signed LongLong and than signed int */
  t_in_sec = (_lc_time_t)(lc_int64_t)big_time;
  _lc_gmtime(t_in_sec,&tm);

  LC_this->LC_VD_YEAR   = (LC_TD_UINT)(tm.tm_year + 1900);
  LC_this->LC_VD_MONTH  = (LC_TD_USINT)(tm.tm_mon + 1);
  LC_this->LC_VD_DAY    = (LC_TD_USINT)tm.tm_mday;
  LC_this->LC_VD_HOUR   = (LC_TD_USINT)tm.tm_hour;
  LC_this->LC_VD_MINUTE = (LC_TD_USINT)tm.tm_min;
  LC_this->LC_VD_SECOND = (LC_TD_USINT)tm.tm_sec;
}

/* the following code for a gmtime is extracted from:
** http://www.cise.ufl.edu/~cop4600/cgi-bin/lxr/http/source.cgi/lib/ansi/gmtime.c
** http://www.cise.ufl.edu/~cop4600/cgi-bin/lxr/http/source.cgi/lib/ansi/loc_time.h
** http://www.cise.ufl.edu/~cop4600/cgi-bin/lxr/http/source.cgi/lib/ansi/misc.c#L82
*/

#define YEAR0             1900            /* the first year */
#define EPOCH_YR          1970            /* EPOCH = Jan 1 1970 00:00:00 */
#define SECS_DAY          (24L * 60L * 60L)
#define LEAPYEAR(year)    (!((year) % 4) && (((year) % 100) || !((year) % 400)))
#define YEARSIZE(year)    (LEAPYEAR(year) ? 366 : 365)

static const lc_uint32_t _ytab[2][12] = {
  { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 },
  { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }
};

static void _lc_gmtime(_lc_time_t time, struct _lc_tm *timep)
{
  lc_uint32_t dayclock, dayno;
  lc_uint32_t year = EPOCH_YR;

  dayclock = (lc_uint32_t)time % SECS_DAY;
  dayno = (lc_uint32_t)time / SECS_DAY;

  timep->tm_sec = dayclock % 60;
  timep->tm_min = (dayclock % 3600) / 60;
  timep->tm_hour = dayclock / 3600;
  timep->tm_wday = (dayno + 4) % 7; /* day 0 was a thursday */
  while (dayno >= YEARSIZE(year)) {
    dayno -= YEARSIZE(year);
    year++;
  }
  timep->tm_year = year - YEAR0;
  timep->tm_yday = dayno;
  timep->tm_mon = 0;
  while (dayno >= _ytab[LEAPYEAR(year)][timep->tm_mon]) {
    dayno -= _ytab[LEAPYEAR(year)][timep->tm_mon];
    timep->tm_mon++;
  }
  timep->tm_mday = dayno + 1;
  timep->tm_isdst = 0;
}

#undef _lc_time_t

#endif
