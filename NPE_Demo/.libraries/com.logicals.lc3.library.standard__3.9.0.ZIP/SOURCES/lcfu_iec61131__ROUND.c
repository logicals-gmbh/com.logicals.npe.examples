/* Copyright (C) logi.cals GmbH. All rights reserved. */

#ifndef LC_PROT_LCFU_IEC61131__ROUND_C
#define LC_PROT_LCFU_IEC61131__ROUND_C

#include <lcfu_iec61131__ROUND.h>
#include <LC3RTLibMath.h>


LC_TD_REAL LCfu_iec61131__ROUND_REAL(float value)
{
  LC_MODFF_PAR ipart;

  if (value >= 0.0f)
  {
    value += 0.5f;
  }
  else
  {
    value -= 0.5f;
  }

  /* ipart is the integer part of value */
  LC_MODFF(value, &ipart);

  return (LC_TD_REAL)ipart;
}

LC_TD_LREAL LCfu_iec61131__ROUND_LREAL(double value)
{
  LC_MODF_PAR ipart;

  if (value >= 0.0)
  {
    value += 0.5;
  }
  else
  {
    value -= 0.5;
  }

  /* ipart is the integer part of value */
  LC_MODF(value, &ipart);

  return (LC_TD_LREAL)ipart;
}
#endif
