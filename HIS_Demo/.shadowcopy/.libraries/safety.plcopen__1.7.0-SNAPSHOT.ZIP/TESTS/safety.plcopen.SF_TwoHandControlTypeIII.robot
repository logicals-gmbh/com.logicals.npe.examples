*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Set Variable Testmodes  &{VARIABLE_TESTMODES}
  Prepare Test Bed  safety.plcopen.SF_TwoHandControlTypeIII		MaxDataRows=200		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  S_Button1=FALSE
...  S_Button2=FALSE
&{VARIABLE_TESTMODES}
...  Timer=useLastValue
*** Test Cases ***
test logicals.safety.plcopen.SF_TwoHandControlTypeIII_Invalid_State
  Head  Time     Activate   S_Button1     S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  ENO?  CycleTime=T#10ms
  Tol    /       /          /             /          0          0       0       0              0              0
  Shift  /       /          /             /          0          0       0       0              0              0
  Init   /       /          /             /          16#9999    FALSE   FALSE   FALSE          FALSE          TRUE 
  Data   0       TRUE       FALSE         FALSE      16#9999    TRUE    TRUE    FALSE          FALSE          FALSE  doc=Invalid State
  Data   1       TRUE       FALSE         FALSE      16#9999    TRUE    TRUE    FALSE          FALSE          FALSE  doc=Invalid State
  Data   2       FALSE      TRUE          FALSE      16#0000    FALSE   FALSE   FALSE          FALSE          TRUE   doc=NOT Activate->Idle
  Data   3       TRUE       FALSE         FALSE      16#8001    FALSE   TRUE    FALSE          FALSE          TRUE   doc=Activate->Init
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_Error_2_B1_and_B2_from_8804
  Head  Time    Activate    S_Button1    S_Button2    DiagCode?    Error?    Ready?    S_TwoHandOut?    SafetyDemand?   CycleTime=T#250ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         FALSE  16#8804    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_1_Actuated
  Data  5        TRUE        TRUE         TRUE   16#C060    TRUE    TRUE    FALSE        FALSE  doc=B1 AND B2 AND Timer elapsed->Error_2_B1_and_B2
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_Error_2_B1_and_B2_from_8806
  Head  Time    Activate    S_Button1    S_Button2    DiagCode?    Error?    Ready?    S_TwoHandOut?    SafetyDemand?   CycleTime=T#250ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        FALSE        TRUE   16#8806    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_2_Actuated
  Data  5        TRUE        TRUE         TRUE   16#C060    TRUE    TRUE    FALSE        FALSE  doc=B1 AND B2 AND Timer elapsed->Error_2_B1_and_B2
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_Error_2_B1_and_B2_to_8000
  Head  Time    Activate    S_Button1    S_Button2    DiagCode?    Error?    Ready?    S_TwoHandOut?    SafetyDemand?   CycleTime=T#250ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        FALSE        TRUE   16#8806    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_2_Actuated
  Data  5        TRUE        TRUE         TRUE   16#C060    TRUE    TRUE    FALSE        FALSE  doc=B1 AND B2 AND Timer elapsed->Error_2_B1_and_B2
  Data  7        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish
#                       DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
#@startuml
#Idle:                  16#0000    FALSE   FALSE   FALSE        FALSE
#Buttons_Actuated:      16#8000    FALSE   TRUE    TRUE         FALSE
#Init:                  16#8001    FALSE   TRUE    FALSE        FALSE
#Buttons_Released:      16#8802    FALSE   TRUE    FALSE        TRUE
#Button_1_Actuated:     16#8804    FALSE   TRUE    FALSE        TRUE
#Button_2_Actuated:     16#8806    FALSE   TRUE    FALSE        TRUE
#Button_1_Released:     16#880A    FALSE   TRUE    FALSE        TRUE
#Button_2_Released:     16#8808    FALSE   TRUE    FALSE        TRUE
#Locked_Off:            16#880C    FALSE   TRUE    FALSE        TRUE
#Locked_On:             16#880E    FALSE   TRUE    FALSE        TRUE
#Error_1_B1:            16#C010    TRUE    TRUE    FALSE        FALSE
#Error_1_B2:            16#C020    TRUE    TRUE    FALSE        FALSE
#Error_1_B1_and_B2:     16#C030    TRUE    TRUE    FALSE        FALSE
#Error_2_B1:            16#C040    TRUE    TRUE    FALSE        FALSE
#Error_2_B2:            16#C050    TRUE    TRUE    FALSE        FALSE
#Error_2_B1_and_B2:     16#C060    TRUE    TRUE    FALSE        FALSE
#T:.                                  Time     Activate    S_Button1    S_Button2
#T:NOT Activate:                      1        FALSE       FALSE        FALSE
#T:Activate:                          1        TRUE        FALSE        FALSE
#T:NOT (B1 OR B2):                    1        TRUE        FALSE        FALSE
#T:B1:                                1        TRUE        TRUE         FALSE
#T:B2:                                1        TRUE        FALSE        TRUE
#T:B1 AND B2:                         1        TRUE        TRUE         TRUE
#T:B1 AND Timer elapsed:              50       TRUE        TRUE         FALSE
#T:B2 AND Timer elapsed:              50       TRUE        FALSE        TRUE
#T:B1 AND B2 AND NOT Timer elapsed:   1        TRUE        TRUE         TRUE
#
#[*]-->Idle: NOT Activate
#Idle-->Init: Activate
#Init-->Error_1_B1: B1
#Init-->Error_1_B2: B2
#Init-->Error_1_B1_and_B2: B1 AND B2
#Error_1_B1-->Error_1_B1: B1
#Error_1_B2-->Error_1_B2: B2
#Error_1_B1_and_B2-->Error_1_B1_and_B2: B1 AND B2
#Init-->Buttons_Released: NOT (B1 OR B2)
#Error_1_B1-->Buttons_Released: NOT (B1 OR B2)
#Error_1_B2-->Buttons_Released: NOT (B1 OR B2)
#Error_1_B1_and_B2-->Buttons_Released: NOT (B1 OR B2)
#Buttons_Released-->Buttons_Actuated: B1 AND B2
#Buttons_Released-->Button_1_Actuated: B1
#Buttons_Released-->Button_2_Actuated: B2
#Buttons_Released-->Buttons_Released: NOT (B1 OR B2)
#Locked_On-->Buttons_Released: NOT (B1 OR B2)
#Locked_On-->Locked_On: B2
#Error_2_B1-->Buttons_Released: NOT (B1 OR B2)
#Error_2_B2-->Buttons_Released: NOT (B1 OR B2)
#Error_2_B1_and_B2-->Buttons_Released: NOT (B1 OR B2)
#Error_2_B1-->Error_2_B1: B2 AND Timer elapsed
#Error_2_B2-->Error_2_B2: B1 AND Timer elapsed
#Button_2_Actuated-->Error_2_B1: B2 AND Timer elapsed
#Button_2_Actuated-->Buttons_Released: NOT (B1 OR B2)
#Button_2_Actuated-->Locked_On: B1
#Button_2_Actuated-->Buttons_Actuated: B1 AND B2 AND NOT Timer elapsed
#Button_1_Actuated-->Error_2_B2: B1 AND Timer elapsed
#Button_1_Actuated-->Buttons_Released: NOT (B1 OR B2)
#Button_1_Actuated-->Locked_On: B2
#Button_1_Actuated-->Buttons_Actuated: B1 AND B2 AND NOT Timer elapsed
#Locked_Off-->Button_1_Released: B2
#Locked_Off-->Button_2_Released: B1
#Locked_Off-->Buttons_Released: NOT (B1 OR B2)
#Locked_Off-->Locked_Off: B1 AND B2
#Button_1_Released-->Locked_Off: B1 AND B2
#Button_1_Released-->Button_2_Released: B1
#Button_1_Released-->Buttons_Released: NOT (B1 OR B2)
#Button_1_Released-->Button_1_Released: B2
#Button_2_Released-->Locked_Off: B1 AND B2
#Button_2_Released-->Button_1_Released: B2
#Button_2_Released-->Buttons_Released: NOT (B1 OR B2)
#Button_2_Released-->Button_2_Released: B1
#Buttons_Actuated-->Button_2_Released: B1
#Buttons_Actuated-->Button_1_Released: B2
#Buttons_Actuated-->Buttons_Released: NOT (B1 OR B2)
#Buttons_Actuated-->Buttons_Actuated: B1 AND B2 AND NOT Timer elapsed
#
#@enduml
#@begin generated
test logicals.safety.plcopen.SF_TwoHandControlTypeIII_0
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        TRUE         FALSE  16#C010    TRUE    TRUE    FALSE        FALSE  doc=B1->Error_1_B1
  Data  3        TRUE        TRUE         FALSE  16#C010    TRUE    TRUE    FALSE        FALSE  doc=B1->Error_1_B1
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_1
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        TRUE         FALSE  16#C010    TRUE    TRUE    FALSE        FALSE  doc=B1->Error_1_B1
  Data  3        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_2
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        TRUE   16#C020    TRUE    TRUE    FALSE        FALSE  doc=B2->Error_1_B2
  Data  3        TRUE        FALSE        TRUE   16#C020    TRUE    TRUE    FALSE        FALSE  doc=B2->Error_1_B2
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_3
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        TRUE   16#C020    TRUE    TRUE    FALSE        FALSE  doc=B2->Error_1_B2
  Data  3        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_4
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        TRUE         TRUE   16#C030    TRUE    TRUE    FALSE        FALSE  doc=B1 AND B2->Error_1_B1_and_B2
  Data  3        TRUE        TRUE         TRUE   16#C030    TRUE    TRUE    FALSE        FALSE  doc=B1 AND B2->Error_1_B1_and_B2
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_5
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        TRUE         TRUE   16#C030    TRUE    TRUE    FALSE        FALSE  doc=B1 AND B2->Error_1_B1_and_B2
  Data  3        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_6
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_7
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_8
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2 AND NOT Timer elapsed->Buttons_Actuated
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_9
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         FALSE  16#8804    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_1_Actuated
  Data  4        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_10
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         FALSE  16#8804    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_1_Actuated
  Data  4        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2 AND NOT Timer elapsed->Buttons_Actuated
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_11
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        FALSE        TRUE   16#8806    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_2_Actuated
  Data  4        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_12
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        FALSE        TRUE   16#8806    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_2_Actuated
  Data  4        TRUE        TRUE         FALSE  16#880E    FALSE   TRUE    FALSE        TRUE   doc=B1->Locked_On
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_13
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        FALSE        TRUE   16#8806    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_2_Actuated
  Data  4        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2 AND NOT Timer elapsed->Buttons_Actuated
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_14
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        TRUE         FALSE  16#8808    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_2_Released
  Data  5        TRUE        FALSE        TRUE   16#880A    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_1_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_15
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        TRUE         FALSE  16#8808    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_2_Released
  Data  5        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_16
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        TRUE         FALSE  16#8808    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_2_Released
  Data  5        TRUE        TRUE         FALSE  16#8808    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_2_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_17
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        FALSE        TRUE   16#880A    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_1_Released
  Data  5        TRUE        TRUE         TRUE   16#880C    FALSE   TRUE    FALSE        TRUE   doc=B1 AND B2->Locked_Off
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_18
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        FALSE        TRUE   16#880A    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_1_Released
  Data  5        TRUE        TRUE         FALSE  16#8808    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_2_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_19
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        FALSE        TRUE   16#880A    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_1_Released
  Data  5        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_20
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        FALSE        TRUE   16#880A    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_1_Released
  Data  5        TRUE        FALSE        TRUE   16#880A    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_1_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_21
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         FALSE  16#8804    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_1_Actuated
  Data  53       TRUE        TRUE         FALSE  16#C050    TRUE    TRUE    FALSE        FALSE  doc=B1 AND Timer elapsed->Error_2_B2
  Data  54       TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_22
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         FALSE  16#8804    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_1_Actuated
  Data  53       TRUE        TRUE         FALSE  16#C050    TRUE    TRUE    FALSE        FALSE  doc=B1 AND Timer elapsed->Error_2_B2
  Data  103      TRUE        TRUE         FALSE  16#C050    TRUE    TRUE    FALSE        FALSE  doc=B1 AND Timer elapsed->Error_2_B2
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_23
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         FALSE  16#8804    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_1_Actuated
  Data  4        TRUE        FALSE        TRUE   16#880E    FALSE   TRUE    FALSE        TRUE   doc=B2->Locked_On
  Data  5        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_24
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         FALSE  16#8804    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_1_Actuated
  Data  4        TRUE        FALSE        TRUE   16#880E    FALSE   TRUE    FALSE        TRUE   doc=B2->Locked_On
  Data  5        TRUE        FALSE        TRUE   16#880E    FALSE   TRUE    FALSE        TRUE   doc=B2->Locked_On
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_25
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        FALSE        TRUE   16#8806    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_2_Actuated
  Data  53       TRUE        FALSE        TRUE   16#C040    TRUE    TRUE    FALSE        FALSE  doc=B2 AND Timer elapsed->Error_2_B1
  Data  54       TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_26
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        FALSE        TRUE   16#8806    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_2_Actuated
  Data  53       TRUE        FALSE        TRUE   16#C040    TRUE    TRUE    FALSE        FALSE  doc=B2 AND Timer elapsed->Error_2_B1
  Data  103      TRUE        FALSE        TRUE   16#C040    TRUE    TRUE    FALSE        FALSE  doc=B2 AND Timer elapsed->Error_2_B1
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_27
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        TRUE         FALSE  16#8808    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_2_Released
  Data  5        TRUE        TRUE         TRUE   16#880C    FALSE   TRUE    FALSE        TRUE   doc=B1 AND B2->Locked_Off
  Data  6        TRUE        FALSE        TRUE   16#880A    FALSE   TRUE    FALSE        TRUE   doc=B2->Button_1_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_28
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        TRUE         FALSE  16#8808    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_2_Released
  Data  5        TRUE        TRUE         TRUE   16#880C    FALSE   TRUE    FALSE        TRUE   doc=B1 AND B2->Locked_Off
  Data  6        TRUE        TRUE         FALSE  16#8808    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_2_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_29
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        TRUE         FALSE  16#8808    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_2_Released
  Data  5        TRUE        TRUE         TRUE   16#880C    FALSE   TRUE    FALSE        TRUE   doc=B1 AND B2->Locked_Off
  Data  6        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Finish

test logicals.safety.plcopen.SF_TwoHandControlTypeIII_30
  Head  Time  Activate  S_Button1  S_Button2  DiagCode?  Error?  Ready?  S_TwoHandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  0  0  0  0  0
  Shift  /  /  /  /  0  0  0  0  0
  Data  0        FALSE       FALSE        FALSE  16#0000    FALSE   FALSE   FALSE        FALSE  doc=NOT Activate->Idle
  Data  1        TRUE        FALSE        FALSE  16#8001    FALSE   TRUE    FALSE        FALSE  doc=Activate->Init
  Data  2        TRUE        FALSE        FALSE  16#8802    FALSE   TRUE    FALSE        TRUE   doc=NOT (B1 OR B2)->Buttons_Released
  Data  3        TRUE        TRUE         TRUE   16#8000    FALSE   TRUE    TRUE         FALSE  doc=B1 AND B2->Buttons_Actuated
  Data  4        TRUE        TRUE         FALSE  16#8808    FALSE   TRUE    FALSE        TRUE   doc=B1->Button_2_Released
  Data  5        TRUE        TRUE         TRUE   16#880C    FALSE   TRUE    FALSE        TRUE   doc=B1 AND B2->Locked_Off
  Data  6        TRUE        TRUE         TRUE   16#880C    FALSE   TRUE    FALSE        TRUE   doc=B1 AND B2->Locked_Off
  Finish

