*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_EnableSwitch		MaxDataRows=100		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  Reset=FALSE
...  S_AutoReset=16#00
...  S_EnableSwitchCh1=16#00
...  S_EnableSwitchCh2=16#00
...  S_SafetyActive=16#00
*** Test Cases ***
test logicals.safety.plcopen.SF_EnableSwitch_Invalid_State
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?   ENO?         CycleTime=T#10ms
  Tol    /     /         /         /        /                  /                  /                0          0        0         0            0                     0             0        
  Shift  /     /         /         /        /                  /                  /                0          0        0         0            0                     0             0       
  Init   /     /         /         /        /                  /                  /                16#9999    FALSE    FALSE     FALSE        FALSE                 FALSE         TRUE        
  Data   0     TRUE      FALSE     FALSE    FALSE              FALSE              FALSE            16#9999    TRUE     TRUE      FALSE        FALSE                 FALSE         FALSE        doc=Activate->Basic_Operation_Mode
  Data   1     TRUE      FALSE     FALSE    FALSE              FALSE              TRUE             16#9999    TRUE     TRUE      FALSE        FALSE                 FALSE         FALSE        doc=S_SafetyActive->Safe_Operation_Mode
  Data   2     FALSE     FALSE     FALSE    FALSE              TRUE               TRUE             16#0000    FALSE    FALSE     FALSE        FALSE                 FALSE         TRUE         doc=S_SafetyActive->Enable siwtch in position1
  Data   3     TRUE      FALSE     FALSE    TRUE               TRUE               FALSE            16#8002    FALSE    TRUE      FALSE        FALSE                 FALSE         TRUE         doc=Safe_Operation_Mode_Prio1_over_prio2(NOT S_SafetyActive)->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_Position1_Priority1_over_2
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     TRUE      FALSE     FALSE              FALSE                    FALSE            FALSE  16#8002    FALSE    TRUE      FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  1     TRUE      FALSE     FALSE              FALSE                    FALSE            TRUE   16#8004    FALSE    TRUE      FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  2     TRUE      FALSE     FALSE              FALSE                    TRUE             TRUE   16#8802    FALSE    TRUE      FALSE        FALSE                 TRUE   doc=S_SafetyActive->Enable siwtch in position1
  Data  3     TRUE      FALSE     FALSE              TRUE                     TRUE             FALSE  16#8002    FALSE    TRUE      FALSE        FALSE                 FALSE  doc=Safe_Operation_Mode_Prio1_over_prio2(NOT S_SafetyActive)->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_Switch_back_to_idle
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     TRUE      FALSE     FALSE              FALSE                    FALSE            FALSE  16#8002    FALSE    TRUE      FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  1     TRUE      FALSE     FALSE              FALSE                    FALSE            TRUE   16#8004    FALSE    TRUE      FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  2     FALSE     FALSE     FALSE              TRUE                     TRUE             FALSE  16#0000    FALSE    FALSE     FALSE        FALSE                 FALSE  doc=Safe_Operation_Mode->Idle
  Data  3     TRUE      FALSE     FALSE              FALSE                    FALSE            FALSE  16#8002    FALSE    TRUE      FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  4     TRUE      FALSE     FALSE              FALSE                    FALSE            TRUE   16#8004    FALSE    TRUE      FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  5     TRUE      FALSE     FALSE              FALSE                    TRUE             TRUE   16#8802    FALSE    TRUE      FALSE        FALSE                 TRUE   doc=S_SafetyActive->Enable siwtch in position1
  Data  7     TRUE      FALSE     FALSE              TRUE                     TRUE             TRUE   16#8000    FALSE    TRUE      FALSE        TRUE                  FALSE  doc=Position1->Position2
  Data  8     FALSE     FALSE     FALSE              TRUE                     TRUE             TRUE   16#0000    FALSE    FALSE     FALSE        FALSE                 FALSE  doc=Position2->Idle
  Finish
  
test logicals.safety.plcopen.SF_EnableSwitch_C011_Stays
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?         CycleTime=T#10ms
  Tol    /     /         /         /        /                  /                  /                0          0        0         0            0                     0             
  Shift  /     /         /         /        /                  /                  /                0          0        0         0            0                     0             
  Init   /     /         /         /        /                  /                  /                16#C011    TRUE    FALSE     FALSE        FALSE                 FALSE         
  Data   0     TRUE      TRUE     TRUE    TRUE                TRUE                TRUE             16#C011    TRUE    TRUE      FALSE        FALSE                 FALSE        doc=Reset->Reset_Error_2
  Data   1     TRUE      TRUE     TRUE    TRUE                TRUE                TRUE             16#C011    TRUE    TRUE      FALSE        FALSE                 FALSE        doc=Reset->Reset_Error_2
  

test logicals.safety.plcopen.SF_EnableSwitch_C001_Stays
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?         CycleTime=T#10ms
  Tol    /     /         /         /        /                  /                  /                0          0        0         0            0                     0             
  Shift  /     /         /         /        /                  /                  /                0          0        0         0            0                     0             
  Init   /     /         /         /        /                  /                  /                16#C001    TRUE    FALSE     FALSE        FALSE                 FALSE         
  Data   0     TRUE      TRUE     TRUE    TRUE                TRUE                TRUE             16#C001    TRUE    TRUE      FALSE        FALSE                 FALSE        doc=Reset->Reset_Error_1
  Data   1     TRUE      TRUE     TRUE    TRUE                TRUE                TRUE             16#C001    TRUE    TRUE      FALSE        FALSE                 FALSE        doc=Reset->Reset_Error_1


#                                           DiagCode?  Error?  Ready?   ResetRequest?   S_EnableSwitchOut?  SafetyDemand?       CycleTime=T#10ms
#@startuml
#skinparam stateFontName Courier
#skinparam stateFontSize 14
#Reset_Error_1:                             16#C001    TRUE     TRUE       FALSE        FALSE                 FALSE
#Reset_Error_2:                             16#C011    TRUE     TRUE       FALSE        FALSE                 FALSE
#Operation_Error_1:                         16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE
#Operation_Error_2_Arriving_RESET_TRUE:     16#C020    TRUE     TRUE       FALSE        FALSE                 FALSE
#Operation_Error_2_Arriving_RESET_FALSE:    16#C020    TRUE     TRUE       TRUE         FALSE                 FALSE
#Operation_Error_3:                         16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE
#Operation_Error_4_RESET_TRUE:              16#C040    TRUE     TRUE       FALSE        FALSE                 FALSE
#Operation_Error_4_RESET_FALSE:             16#C040    TRUE     TRUE       TRUE         FALSE                 FALSE
#Idle:                                      16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE
#Basic_Operation_Mode:                      16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE
#Safe_Operation_Mode:                       16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE
#Position_1:                                16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE 
#Position_2:                                16#8000    FALSE    TRUE       FALSE        TRUE                  FALSE
#Position_3:                                16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE 
#
#T:.                                                                         Time  Activate  Reset            S_AutoReset        S_EnableSwitchCh1        S_EnableSwitchCh2     S_SafetyActive
#T:NOT Activate:                                                             1     FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE
#T:Activate:                                                                 1     TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE
#T:S_SafetyActive:                                                           1     TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE 
#T:NOT S_SafetyActive:                                                       1     TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE
#T:EnableSwitch_in_Position_1:                                               1     TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE 
#T:EnableSwitch_in_Position_1_With_Reset_True:                               1     TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE 
#T:EnableSwitch_in_Position_2:                                               1     TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE 
#T:EnableSwitch_in_Position_3:                                               1     TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE 
#T:EnableSwitch_NOT_in_Position_1_1:                                         1     TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE 
#T:EnableSwitch_NOT_in_Position_1_2:                                         1     TRUE      FALSE            FALSE              TRUE                     FALSE                 TRUE 
#T:EnableSwitch_NOT_in_Position_2_1:                                         1     TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE 
#T:EnableSwitch_NOT_in_Position_2_2:                                         1     TRUE      FALSE            FALSE              TRUE                     FALSE                 TRUE 
#T:EnableSwitch_NOT_in_Position_2_1_RESET_TRUE:                              1     TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE 
#T:EnableSwitch_NOT_in_Position_2_2_RESET_TRUE:                              1     TRUE      TRUE             FALSE              TRUE                     FALSE                 TRUE 

#T:Reset:                                                                    1     TRUE      TRUE             FALSE              FALSE                    FALSE                 TRUE 
#T:NOT Reset:                                                                1     TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE 
#T:R_TRIG_at_Reset:                                                          1     TRUE      R_EDGE           FALSE              FALSE                    TRUE                  TRUE 
#T:S_AutoReset:                                                              1     TRUE      FALSE            TRUE               FALSE                    TRUE                  TRUE 
#T:Reset_+_NOT_R_TRIG_at_Reset:                                              1     TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE 
#T:PRIORITY_CHECK_8000 NOT S_SafetyActive AND EnableSwitch_in_Position_2:    1     TRUE      FALSE            FALSE              TRUE                     TRUE                  FALSE 
#
#[*]-->Idle:NOT Activate
#Idle-->Basic_Operation_Mode: Activate
#Basic_Operation_Mode-->Safe_Operation_Mode: S_SafetyActive
#Basic_Operation_Mode-->Basic_Operation_Mode: Activate
#Safe_Operation_Mode-->Basic_Operation_Mode: NOT S_SafetyActive
#Safe_Operation_Mode-->Operation_Error_1: EnableSwitch_NOT_in_Position_1_1
#Safe_Operation_Mode-->Operation_Error_1: EnableSwitch_NOT_in_Position_1_2
#Safe_Operation_Mode-->Position_1: EnableSwitch_in_Position_1
#Operation_Error_1-->Basic_Operation_Mode: NOT S_SafetyActive
#Operation_Error_1-->Operation_Error_2_Arriving_RESET_FALSE: EnableSwitch_in_Position_1
#Operation_Error_1-->Operation_Error_2_Arriving_RESET_TRUE: EnableSwitch_in_Position_1_With_Reset_True
#Operation_Error_1-->Operation_Error_1: EnableSwitch_NOT_in_Position_1_1
#Operation_Error_2_Arriving_RESET_TRUE-->Reset_Error_1: Reset_+_NOT_R_TRIG_at_Reset
#Reset_Error_1-->Operation_Error_2_Arriving_RESET_FALSE: NOT Reset
#Reset_Error_1-->Basic_Operation_Mode: NOT S_SafetyActive
#Operation_Error_2_Arriving_RESET_TRUE-->Basic_Operation_Mode: NOT S_SafetyActive
#Operation_Error_2_Arriving_RESET_FALSE-->Basic_Operation_Mode: NOT S_SafetyActive
#Operation_Error_2_Arriving_RESET_TRUE-->Operation_Error_1: EnableSwitch_NOT_in_Position_1_1
#Operation_Error_2_Arriving_RESET_FALSE-->Operation_Error_1: EnableSwitch_NOT_in_Position_1_1
#Operation_Error_2_Arriving_RESET_TRUE-->Operation_Error_1: EnableSwitch_NOT_in_Position_1_2
#Operation_Error_2_Arriving_RESET_FALSE-->Operation_Error_1: EnableSwitch_NOT_in_Position_1_2
#Operation_Error_2_Arriving_RESET_FALSE-->Position_1: R_TRIG_at_Reset
#Operation_Error_2_Arriving_RESET_TRUE-->Position_1: S_AutoReset
#Operation_Error_2_Arriving_RESET_FALSE-->Position_1: S_AutoReset
#Operation_Error_2_Arriving_RESET_FALSE-->Operation_Error_2_Arriving_RESET_FALSE: EnableSwitch_in_Position_1
#Operation_Error_2_Arriving_RESET_TRUE-->Operation_Error_2_Arriving_RESET_FALSE: EnableSwitch_in_Position_1
#Position_1-->Basic_Operation_Mode: NOT S_SafetyActive
#Position_1-->Position_2: EnableSwitch_in_Position_2
#Position_1-->Position_3: EnableSwitch_in_Position_3
#Position_3-->Basic_Operation_Mode: NOT S_SafetyActive
#Position_3-->Operation_Error_3: EnableSwitch_in_Position_2
#Position_3-->Position_1: EnableSwitch_in_Position_1
#Position_3-->Position_3: EnableSwitch_in_Position_3
#Operation_Error_3-->Basic_Operation_Mode: NOT S_SafetyActive
#Operation_Error_3-->Operation_Error_4_RESET_FALSE: EnableSwitch_NOT_in_Position_2_1
#Operation_Error_3-->Operation_Error_4_RESET_FALSE: EnableSwitch_NOT_in_Position_2_2
#Operation_Error_3-->Operation_Error_4_RESET_TRUE: EnableSwitch_NOT_in_Position_2_1_RESET_TRUE
#Operation_Error_3-->Operation_Error_4_RESET_TRUE: EnableSwitch_NOT_in_Position_2_2_RESET_TRUE
#Operation_Error_3-->Operation_Error_3: EnableSwitch_in_Position_2
#Operation_Error_4_RESET_TRUE-->Basic_Operation_Mode: NOT S_SafetyActive
#Operation_Error_4_RESET_FALSE-->Basic_Operation_Mode: NOT S_SafetyActive
#Operation_Error_4_RESET_TRUE-->Operation_Error_3: EnableSwitch_in_Position_2
#Operation_Error_4_RESET_FALSE-->Operation_Error_3: EnableSwitch_in_Position_2
#Operation_Error_4_RESET_FALSE-->Position_3: R_TRIG_at_Reset
#Operation_Error_4_RESET_TRUE-->Position_3: S_AutoReset
#Operation_Error_4_RESET_FALSE-->Position_3: S_AutoReset
#Operation_Error_4_RESET_TRUE-->Reset_Error_2: Reset_+_NOT_R_TRIG_at_Reset
#Reset_Error_2-->Operation_Error_4_RESET_FALSE: NOT Reset
#Reset_Error_2-->Basic_Operation_Mode: NOT S_SafetyActive
#Position_2-->Basic_Operation_Mode: NOT S_SafetyActive
#Position_2-->Position_3: EnableSwitch_in_Position_3
#Position_2-->Position_1: EnableSwitch_in_Position_1
#Position_2-->Position_2: EnableSwitch_in_Position_2
#Position_1-->Basic_Operation_Mode: PRIORITY_CHECK_8000 NOT S_SafetyActive AND EnableSwitch_in_Position_2
#@enduml
#@begin generated
test logicals.safety.plcopen.SF_EnableSwitch_0
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_1
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_2
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     FALSE                 TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_2->Operation_Error_1
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_3
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_4
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_5
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_6
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              TRUE                     TRUE                  FALSE   16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=PRIORITY_CHECK_8000 NOT S_SafetyActive AND EnableSwitch_in_Position_2->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_7
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_in_Position_1->Operation_Error_2_Arriving_RESET_FALSE
  Data  5       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_8
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_in_Position_1->Operation_Error_2_Arriving_RESET_FALSE
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_9
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_in_Position_1->Operation_Error_2_Arriving_RESET_FALSE
  Data  5       TRUE      FALSE            FALSE              TRUE                     FALSE                 TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_2->Operation_Error_1
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_10
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_in_Position_1->Operation_Error_2_Arriving_RESET_FALSE
  Data  5       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=R_TRIG_at_Reset->Position_1
  Data  6       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=R_TRIG_at_Reset->Position_1
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_11
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_in_Position_1->Operation_Error_2_Arriving_RESET_FALSE
  Data  5       TRUE      FALSE            TRUE               FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=S_AutoReset->Position_1
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_12
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_in_Position_1->Operation_Error_2_Arriving_RESET_FALSE
  Data  5       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_in_Position_1->Operation_Error_2_Arriving_RESET_FALSE
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_13
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_1_With_Reset_True->Operation_Error_2_Arriving_RESET_TRUE
  Data  5       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_14
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_1_With_Reset_True->Operation_Error_2_Arriving_RESET_TRUE
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_15
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_1_With_Reset_True->Operation_Error_2_Arriving_RESET_TRUE
  Data  5       TRUE      FALSE            FALSE              TRUE                     FALSE                 TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_2->Operation_Error_1
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_16
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_1_With_Reset_True->Operation_Error_2_Arriving_RESET_TRUE
  Data  5       TRUE      FALSE            TRUE               FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=S_AutoReset->Position_1
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_17
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_1_With_Reset_True->Operation_Error_2_Arriving_RESET_TRUE
  Data  5       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_in_Position_1->Operation_Error_2_Arriving_RESET_FALSE
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_18
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#8000    FALSE    TRUE       FALSE        TRUE                  FALSE  doc=EnableSwitch_in_Position_2->Position_2
  Data  5       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_19
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#8000    FALSE    TRUE       FALSE        TRUE                  FALSE  doc=EnableSwitch_in_Position_2->Position_2
  Data  5       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_20
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#8000    FALSE    TRUE       FALSE        TRUE                  FALSE  doc=EnableSwitch_in_Position_2->Position_2
  Data  5       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_21
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#8000    FALSE    TRUE       FALSE        TRUE                  FALSE  doc=EnableSwitch_in_Position_2->Position_2
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#8000    FALSE    TRUE       FALSE        TRUE                  FALSE  doc=EnableSwitch_in_Position_2->Position_2
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_22
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_23
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_24
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_25
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_1_With_Reset_True->Operation_Error_2_Arriving_RESET_TRUE
  Data  5       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C001    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=Reset_+_NOT_R_TRIG_at_Reset->Reset_Error_1
  Data  6       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#C020    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=NOT Reset->Operation_Error_2_Arriving_RESET_FALSE
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_26
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C010    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_1_1->Operation_Error_1
  Data  4       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C020    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_1_With_Reset_True->Operation_Error_2_Arriving_RESET_TRUE
  Data  5       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C001    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=Reset_+_NOT_R_TRIG_at_Reset->Reset_Error_1
  Data  6       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_27
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_28
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      FALSE            FALSE              TRUE                     FALSE                 TRUE   16#C040    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_2_2->Operation_Error_4_RESET_FALSE
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_29
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      TRUE             FALSE              TRUE                     FALSE                 TRUE   16#C040    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_2_2_RESET_TRUE->Operation_Error_4_RESET_TRUE
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_30
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_31
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C040    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_2_1->Operation_Error_4_RESET_FALSE
  Data  7       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_32
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C040    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_2_1->Operation_Error_4_RESET_FALSE
  Data  7       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_33
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C040    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_2_1->Operation_Error_4_RESET_FALSE
  Data  7       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C040    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=R_TRIG_at_Reset->Position_3
  Data  8       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=R_TRIG_at_Reset->Position_3
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_34
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#C040    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_2_1->Operation_Error_4_RESET_FALSE
  Data  7       TRUE      FALSE            TRUE               FALSE                    TRUE                  TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=S_AutoReset->Position_3
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_35
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C040    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_2_1_RESET_TRUE->Operation_Error_4_RESET_TRUE
  Data  7       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_36
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C040    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_2_1_RESET_TRUE->Operation_Error_4_RESET_TRUE
  Data  7       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_37
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C040    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_2_1_RESET_TRUE->Operation_Error_4_RESET_TRUE
  Data  7       TRUE      FALSE            TRUE               FALSE                    TRUE                  TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=S_AutoReset->Position_3
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_38
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C040    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_2_1_RESET_TRUE->Operation_Error_4_RESET_TRUE
  Data  7       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C011    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=Reset_+_NOT_R_TRIG_at_Reset->Reset_Error_2
  Data  8       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#C040    TRUE     TRUE       TRUE         FALSE                 FALSE  doc=NOT Reset->Operation_Error_4_RESET_FALSE
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_39
  Head  Time  Activate  Reset  S_AutoReset  S_EnableSwitchCh1  S_EnableSwitchCh2  S_SafetyActive   DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE            FALSE              FALSE                    FALSE                 FALSE  16#0000    FALSE    FALSE      FALSE        FALSE                 FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8004    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE            FALSE              FALSE                    TRUE                  TRUE   16#8802    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_1->Position_1
  Data  4       TRUE      FALSE            FALSE              FALSE                    FALSE                 TRUE   16#8804    FALSE    TRUE       FALSE        FALSE                 TRUE   doc=EnableSwitch_in_Position_3->Position_3
  Data  5       TRUE      FALSE            FALSE              TRUE                     TRUE                  TRUE   16#C030    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_in_Position_2->Operation_Error_3
  Data  6       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C040    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=EnableSwitch_NOT_in_Position_2_1_RESET_TRUE->Operation_Error_4_RESET_TRUE
  Data  7       TRUE      TRUE             FALSE              FALSE                    TRUE                  TRUE   16#C011    TRUE     TRUE       FALSE        FALSE                 FALSE  doc=Reset_+_NOT_R_TRIG_at_Reset->Reset_Error_2
  Data  8       TRUE      FALSE            FALSE              FALSE                    FALSE                 FALSE  16#8002    FALSE    TRUE       FALSE        FALSE                 FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

