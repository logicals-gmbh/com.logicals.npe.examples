*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_EDM		MaxDataRows=100		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  EDM1=FALSE
...  EDM2=FALSE
...  Reset=FALSE
...  S_OutControl=0
*** Test Cases ***
test logicals.safety.plcopen.plcopen.Invalid_State
  Head  Time  Activate  EDM1    EDM2    MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  ENO?     CycleTime=T#10ms
  Tol    /    /         /       /       /               /       /            0          0       0       0              0           0              0     
  Shift  /    /         /       /       /               /       /            0          0       0       0              0           0              0    
  Init   /    /         /       /       /               /       /            16#9999    FALSE   FALSE   FALSE          FALSE       FALSE          TRUE    
  Data  0     TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE        16#9999    TRUE    TRUE    FALSE          FALSE       FALSE          FALSE       doc=Invalid State
  Data  1     TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE        16#9999    TRUE    TRUE    FALSE          FALSE       FALSE          FALSE       doc=Invalid State
  Data  2     FALSE     FALSE   FALSE   T#20ms          TRUE    FALSE        16#0000    FALSE   FALSE   FALSE          FALSE       FALSE          TRUE        doc=NOT Activate->Idle
  Data  3     TRUE      FALSE   FALSE   T#200ms         FALSE   TRUE         16#8401    FALSE   TRUE    TRUE           FALSE       FALSE          TRUE        doc=Idle->Init
  Finish
  
test logicals.safety.plcopen.plcopen.Stay_in state_for_test_covarage_1
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?    CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Init   /    /         /       /       /               /         /      16#C010    TRUE    TRUE    FALSE          FALSE       FALSE
  Data  0     TRUE      FALSE   TRUE    T#200ms         FALSE     TRUE   16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Stay->EDM_Error_11a
  Finish
  
test logicals.safety.plcopen.plcopen.Stay_in state_for_test_covarage_2
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?    CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Init   /    /         /       /       /               /         /      16#C030    TRUE    TRUE    FALSE          FALSE       FALSE
  Data  0     TRUE      FALSE   FALSE   T#200ms         FALSE    TRUE    16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Stay->EDM_Error_13a
  Finish

test logicals.safety.plcopen.plcopen.Stay_in state_for_test_covarage_3
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?    CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Init   /    /         /       /       /               /         /      16#C060    TRUE    TRUE    FALSE          FALSE       FALSE
  Data  0     TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE    16#C060    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Stay->EDM_Error_23a
  Finish

test logicals.safety.plcopen.plcopen.Stay_in state_for_test_covarage_4
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?    CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Init   /    /         /       /       /               /         /      16#C041    TRUE    TRUE    FALSE          FALSE       FALSE
  Data  0     TRUE      TRUE    FALSE   T#20ms          TRUE    FALSE    16#C041    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Stay->Reset_Error_31
  Finish

test logicals.safety.plcopen.plcopen.Stay_in state_for_test_covarage_5
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?    CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Init   /    /         /       /       /               /         /      16#C051    TRUE    TRUE    FALSE          FALSE       FALSE
  Data  0     TRUE      FALSE   TRUE    T#20ms          TRUE    FALSE    16#C051    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Stay->Reset_Error_32
  Finish

test logicals.safety.plcopen.plcopen.Stay_in state_for_test_covarage_6
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?    CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Init   /    /         /       /       /               /         /      16#C061    TRUE    TRUE    FALSE          FALSE       FALSE
  Data  0     TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE    16#C061    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Stay->Reset_Error_33
  Finish

test logicals.safety.plcopen.SF_EDM_Monitoring_Time_LT_0
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE   T#-100ms          FALSE   FALSE  16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE   T#-100ms          FALSE   FALSE  16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE   FALSE   T#-100ms          TRUE    FALSE  16#8810    FALSE   TRUE    FALSE          FALSE       TRUE  doc=R_TRIG at Reset->Output_Disable
  Data  3     TRUE      FALSE   TRUE    T#-100ms          TRUE    FALSE  16#C040    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed Prio_2_over_3 (3)->EDM_Error_21a
  Finish

test logicals.safety.plcopen.SF_EDM_Monitoring_Time_EQ_0
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE   T#0ms          FALSE   FALSE  16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE   T#0ms          FALSE   FALSE  16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE   FALSE   T#0ms          TRUE    FALSE  16#8810    FALSE   TRUE    FALSE          FALSE       TRUE  doc=R_TRIG at Reset->Output_Disable
  Data  3     TRUE      FALSE   TRUE    T#0ms          TRUE    FALSE  16#C040    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed Prio_2_over_3 (3)->EDM_Error_21a
  Finish

test logicals.safety.plcopen.SF_EDM_Monitoring_Time_LT_Cycle_Time
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE   T#9ms          FALSE   FALSE  16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE   T#9ms          FALSE   FALSE  16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE   FALSE   T#9ms          TRUE    FALSE  16#8810    FALSE   TRUE    FALSE          FALSE       TRUE  doc=R_TRIG at Reset->Output_Disable
  Data  3     TRUE      FALSE   TRUE    T#9ms          TRUE    FALSE  16#C040    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed Prio_2_over_3 (3)->EDM_Error_21a
  Finish

test logicals.safety.plcopen.SF_EDM_Monitoring_Time_EQ_Cycle_Time
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE   T#10ms          FALSE   FALSE  16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE   T#10ms          FALSE   FALSE  16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE   FALSE   T#10ms          TRUE    FALSE  16#8810    FALSE   TRUE    FALSE          FALSE       TRUE  doc=R_TRIG at Reset->Output_Disable
  Data  3     TRUE      FALSE   TRUE    T#10ms          TRUE    FALSE  16#C040    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed Prio_2_over_3 (3)->EDM_Error_21a
  Finish

test logicals.safety.plcopen.8810_1_prio_1_over_3
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE  16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE  16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE  16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3     TRUE      FALSE   FALSE   T#200ms         FALSE    TRUE  16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=PRIORITY_CHECK_8000->EDM_Error_13a (1)
  Finish

test logicals.safety.plcopen.8810_2_prio_1_over_3
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE  16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE  16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE  16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3     TRUE      TRUE    FALSE   T#200ms         FALSE    TRUE  16#C020    TRUE   TRUE     FALSE          FALSE       FALSE  doc=PRIORITY_CHECK_8000->EDM_Error_12a (2)
  Finish

test logicals.safety.plcopen.8810_3_prio_1_over_3
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE  16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE  16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE  16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3     TRUE      FALSE   TRUE    T#200ms         FALSE   TRUE   16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=PRIORITY_CHECK_8000->EDM_Error_11a (3)
  Finish

test logicals.safety.plcopen.8810_4_switch_to_8000
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE  16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE  16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE  16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3     TRUE      TRUE    TRUE     T#20ms         FALSE   FALSE  16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=prio_1_over_3->EDM_Error_13a (4)
  Data  5     TRUE      TRUE    TRUE     T#20ms         FALSE   TRUE   16#8000    FALSE   TRUE    FALSE          TRUE        FALSE  doc=prio_1_over_3->EDM_Error_13a (4)
  Finish

    #                                    DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
#@startuml
#Idle:                               16#0000    FALSE   FALSE   FALSE          FALSE       FALSE
#Init:                               16#8401    FALSE   TRUE    TRUE           FALSE       FALSE
#Init_AND_reset:                     16#8401    FALSE   TRUE    TRUE           FALSE       FALSE
#Init_Error:                         16#C100    TRUE    TRUE    FALSE          FALSE       FALSE
#Output_Disable:                     16#8810    FALSE   TRUE    FALSE          FALSE       TRUE 
#Output_Enable:                      16#8000    FALSE   TRUE    FALSE          TRUE        FALSE
#Reset_Error_1:                      16#C001    TRUE    TRUE    FALSE          FALSE       FALSE
#Reset_Error_21:                     16#C011    TRUE    TRUE    FALSE          FALSE       FALSE
#Reset_Error_22:                     16#C021    TRUE    TRUE    FALSE          FALSE       FALSE
#Reset_Error_23:                     16#C031    TRUE    TRUE    FALSE          FALSE       FALSE
#Reset_Error_31:                     16#C041    TRUE    TRUE    FALSE          FALSE       FALSE
#Reset_Error_32:                     16#C051    TRUE    TRUE    FALSE          FALSE       FALSE
#Reset_Error_33:                     16#C061    TRUE    TRUE    FALSE          FALSE       FALSE
#Reset_Error_41:                     16#C071    TRUE    TRUE    FALSE          FALSE       FALSE
#Reset_Error_42:                     16#C081    TRUE    TRUE    FALSE          FALSE       FALSE
#Reset_Error_43:                     16#C091    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_11a:                      16#C010    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_11a_back:                 16#C010    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_11b:                      16#C410    TRUE    TRUE    TRUE           FALSE       FALSE
#EDM_Error_11b_RESET:                16#C410    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_12a:                      16#C020    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_12a_back:                 16#C020    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_12b:                      16#C420    TRUE    TRUE    TRUE           FALSE       FALSE
#EDM_Error_12b_RESET:                16#C420    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_13a:                      16#C030    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_13a_back:                 16#C030    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_13b:                      16#C430    TRUE    TRUE    TRUE           FALSE       FALSE
#EDM_Error_13b_RESET:                16#C430    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_21a:                      16#C040    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_21a_back:                 16#C040    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_21b:                      16#C440    TRUE    TRUE    TRUE           FALSE       FALSE
#EDM_Error_21b_RESET:                16#C440    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_22a:                      16#C050    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_22a_back:                 16#C050    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_22b:                      16#C450    TRUE    TRUE    TRUE           FALSE       FALSE
#EDM_Error_22b_RESET:                16#C450    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_23a:                      16#C060    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_23a_back:                 16#C060    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_23b:                      16#C460    TRUE    TRUE    TRUE           FALSE       FALSE
#EDM_Error_23b_RESET:                16#C460    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_31:                       16#C070    TRUE    TRUE    TRUE           FALSE       FALSE
#EDM_Error_31_RESET:                 16#C070    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_32:                       16#C080    TRUE    TRUE    TRUE           FALSE       FALSE
#EDM_Error_32_RESET:                 16#C080    TRUE    TRUE    FALSE          FALSE       FALSE
#EDM_Error_33:                       16#C090    TRUE    TRUE    TRUE           FALSE       FALSE
#EDM_Error_33_RESET:                 16#C090    TRUE    TRUE    FALSE          FALSE       FALSE
#
#T:.                                                         Time  Activate  EDM1    EDM2    MonitoringTime  Reset   S_OutControl
#T:NOT Activate:                                             1     FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE 
#T:Activate:                                                 1     TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE 
#T:Activate AND Reset:                                       1     TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE 
#T:R_TRIG at Reset:                                          1     TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE 
#T:S_OutControl AND NOT EDM1 AND NOT EDM2:                   1     TRUE      FALSE   FALSE   T#20ms          FALSE   TRUE  
#T:S_OutControl AND NOT EDM1 AND EDM2:                       1     TRUE      FALSE   TRUE    T#20ms          FALSE   TRUE  
#T:NOT EDM1 AND EDM2:                                        1     TRUE      FALSE   TRUE    T#20ms          FALSE   FALSE 
#T:S_OutControl AND EDM1 AND NOT EDM2:                       1     TRUE      TRUE    FALSE   T#20ms          FALSE   TRUE  
#T:S_OutControl AND EDM1 AND EDM2:                           1     TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE  
#T:R_TRIG at Reset AND EDM1 AND EDM2:                        1     TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE 
#T:R_TRIG at Reset AND EDM1 AND EDM2 EDGE:                   1     TRUE      TRUE    TRUE    T#20ms          R_EDGE  TRUE  
#T:S_OutControl:                                             1     TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE  
#T:NOT S_OutControl:                                         1     TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE 
#T:Reset AND NOT R_TRIG at Reset:                            1     TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE 
#T:R_TRIG at Reset AND S_OutControl:                         1     TRUE      FALSE   FALSE   T#20ms          TRUE    TRUE  
#T:R_TRIG at Reset AND R_TRIG at EDM1:                       1     TRUE      R_EDGE  FALSE   T#20ms          R_EDGE  FALSE 
#/' The Reset is TRUE instead of STAT_TRUE because the Reset was TRUE in previous cycle.'/
#T:STAT_TRUE at Reset AND R_TRIG at EDM1_2:                  1     TRUE      TRUE    FALSE   T#20ms          TRUE    FALSE 
#T:R_TRIG at Reset AND R_TRIG at EDM2:                       1     TRUE      FALSE   R_EDGE  T#20ms          R_EDGE  FALSE 
#T:R_TRIG at Reset AND EDM1 AND NOT EDM2:                    1     TRUE      TRUE    FALSE   T#20ms          R_EDGE  FALSE 
#T:R_TRIG at Reset AND NOT EDM1 AND EDM2:                    1     TRUE      FALSE   TRUE    T#20ms          R_EDGE  FALSE 
#T:R_TRIG at Reset AND R_TRIG at EDM1 and R_TRIG at EDM2:    1     TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE 
#T:NOT Reset:                                                2     TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE 
#T:NOT Reset AND EDM1 AND EDM2:                              1     TRUE      TRUE    TRUE    T#20ms          FALSE   FALSE 
#T:Reset:                                                    1     TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE 
#T:Monitoring_Time_Elapsed AND NOT EDM1 AND NOT EDM2:        2     TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE 
#T:Monitoring_Time_Elapsed AND NOT EDM1 AND EDM2:            2     TRUE      FALSE   TRUE    T#20ms          TRUE    FALSE 
#T:Monitoring_Time_Elapsed AND EDM1 AND NOT EDM2:            2     TRUE      TRUE    FALSE   T#20ms          TRUE    FALSE 
#T:Monitoring_Time_Elapsed AND NOT EDM1 AND EDM2 NOT RESET:  2     TRUE      FALSE   TRUE    T#20ms          FALSE   FALSE 
#T:Monitoring_Time_Elapsed AND EDM1 AND NOT EDM2 NOT RESET:  2     TRUE      TRUE    FALSE   T#20ms          FALSE   FALSE 
#T:Monitoring_Time_Elapsed AND EDM1 AND EDM2:                2     TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE 
#T:R_TRIG Reset AND R_TRIG at S_OutControl:                  1     TRUE      FALSE   FALSE   T#20ms          R_EDGE  R_EDGE
#T:Stay in EDM Error 11 12 21 22:                            1     TRUE      FALSE   FALSE   T#20ms          TRUE    TRUE  
#T:Stay in EDM Error 13 23:                                  1     TRUE      TRUE    FALSE   T#20ms          TRUE    TRUE  
#
#[*]-->Idle: NOT Activate
#Idle-->Init: Activate
#Idle-->Init_AND_reset: Activate AND Reset
#Init-->Init_Error: R_TRIG Reset AND R_TRIG at S_OutControl
#Init-->Output_Disable: R_TRIG at Reset
#Init_AND_reset-->Reset_Error_1: Reset AND NOT R_TRIG at Reset
#Init_Error-->Idle: NOT Activate
#Init_Error-->Init: NOT Reset
#Reset_Error_1-->Init_AND_reset: NOT Reset
#Reset_Error_1-->Idle: NOT Activate
#Output_Disable-->EDM_Error_11a: S_OutControl AND NOT EDM1 AND EDM2
#Output_Disable-->EDM_Error_12a: S_OutControl AND EDM1 AND NOT EDM2
#Output_Disable-->EDM_Error_13a: S_OutControl AND NOT EDM1 AND NOT EDM2
#EDM_Error_11a-->Reset_Error_21: STAT_TRUE at Reset AND R_TRIG at EDM1_2
#EDM_Error_11a-->EDM_Error_11b: S_OutControl AND EDM1 AND EDM2
#EDM_Error_11b-->EDM_Error_11a: NOT EDM1 AND EDM2
#EDM_Error_11b-->Reset_Error_21: R_TRIG at Reset AND R_TRIG at EDM1
#EDM_Error_11b-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2
#EDM_Error_11b-->Idle: NOT Activate
#EDM_Error_12a-->Reset_Error_22: R_TRIG at Reset AND R_TRIG at EDM2
#EDM_Error_12a-->EDM_Error_12b: S_OutControl AND EDM1 AND EDM2
#EDM_Error_12a-->Idle: NOT Activate
#EDM_Error_12b-->EDM_Error_12a: S_OutControl AND EDM1 AND NOT EDM2
#EDM_Error_12b-->Reset_Error_22: R_TRIG at Reset AND R_TRIG at EDM2
#EDM_Error_12b-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2
#EDM_Error_13a-->Reset_Error_23: R_TRIG at Reset AND R_TRIG at EDM1 and R_TRIG at EDM2
#EDM_Error_13a-->EDM_Error_13b: S_OutControl AND EDM1 AND EDM2
#EDM_Error_13a-->Idle: NOT Activate
#EDM_Error_13b-->EDM_Error_13a: S_OutControl AND NOT EDM1 AND NOT EDM2
#EDM_Error_13b-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2
#EDM_Error_13b-->Idle: NOT Activate
#Reset_Error_21-->EDM_Error_11a_back: NOT Reset AND EDM1 AND EDM2
#Reset_Error_22-->EDM_Error_12a_back: NOT Reset AND EDM1 AND EDM2
#Reset_Error_23-->EDM_Error_13a_back: NOT Reset AND EDM1 AND EDM2
#EDM_Error_11a_back-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2
#EDM_Error_12a_back-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2
#EDM_Error_13a_back-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2
#Reset_Error_21-->EDM_Error_11a: NOT Reset
#Reset_Error_22-->EDM_Error_12a: NOT Reset
#Reset_Error_23-->EDM_Error_13a: NOT Reset
#Reset_Error_21-->Idle: NOT Activate
#Reset_Error_22-->Idle: NOT Activate
#Reset_Error_23-->Idle: NOT Activate
#Output_Disable-->EDM_Error_21a: Monitoring_Time_Elapsed AND NOT EDM1 AND EDM2 NOT RESET
#Output_Disable-->EDM_Error_22a: Monitoring_Time_Elapsed AND EDM1 AND NOT EDM2 NOT RESET
#Output_Disable-->EDM_Error_23a: Monitoring_Time_Elapsed AND NOT EDM1 AND NOT EDM2
#EDM_Error_21a-->Reset_Error_31: R_TRIG at Reset AND R_TRIG at EDM1
#EDM_Error_21a-->EDM_Error_21b: S_OutControl AND EDM1 AND EDM2
#EDM_Error_21b-->EDM_Error_21a: NOT EDM1 AND EDM2
#EDM_Error_21b-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2
#EDM_Error_22a-->Reset_Error_32: R_TRIG at Reset AND R_TRIG at EDM2
#EDM_Error_22a-->EDM_Error_22b: S_OutControl AND EDM1 AND EDM2
#EDM_Error_22b-->EDM_Error_22a: S_OutControl AND EDM1 AND NOT EDM2
#EDM_Error_22b-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2
#EDM_Error_23a-->Reset_Error_33: R_TRIG at Reset AND R_TRIG at EDM1 and R_TRIG at EDM2
#EDM_Error_23a-->EDM_Error_23b: S_OutControl AND EDM1 AND EDM2
#EDM_Error_23b-->EDM_Error_23a: S_OutControl AND NOT EDM1 AND NOT EDM2
#EDM_Error_23b-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2
#Reset_Error_31-->EDM_Error_21a_back: NOT Reset AND EDM1 AND EDM2
#Reset_Error_32-->EDM_Error_22a_back: NOT Reset AND EDM1 AND EDM2
#Reset_Error_33-->EDM_Error_23a_back: NOT Reset AND EDM1 AND EDM2
#EDM_Error_21a_back-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2
#EDM_Error_22a_back-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2
#EDM_Error_23a_back-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2
#Output_Disable-->Output_Enable: S_OutControl
#Output_Enable-->Output_Disable: NOT S_OutControl
#Output_Enable-->EDM_Error_31_RESET: Monitoring_Time_Elapsed AND EDM1 AND NOT EDM2
#Output_Enable-->EDM_Error_32_RESET: Monitoring_Time_Elapsed AND NOT EDM1 AND EDM2
#Output_Enable-->EDM_Error_33_RESET: Monitoring_Time_Elapsed AND EDM1 AND EDM2
#EDM_Error_31-->Output_Disable: R_TRIG at Reset AND EDM1 AND NOT EDM2
#EDM_Error_31_RESET-->Reset_Error_41: Reset AND NOT R_TRIG at Reset
#Reset_Error_41-->EDM_Error_31: NOT Reset
#EDM_Error_32_RESET-->Reset_Error_42: Reset AND NOT R_TRIG at Reset
#EDM_Error_32-->Output_Disable: R_TRIG at Reset AND NOT EDM1 AND EDM2
#Reset_Error_42-->EDM_Error_32: NOT Reset
#EDM_Error_33_RESET-->Reset_Error_43: Reset AND NOT R_TRIG at Reset
#EDM_Error_33-->Output_Disable: R_TRIG at Reset AND EDM1 AND EDM2 EDGE
#Reset_Error_43-->EDM_Error_33: NOT Reset
#EDM_Error_11b-->EDM_Error_11b_RESET: Stay in EDM Error 11 12 21 22
#EDM_Error_12b-->EDM_Error_12b_RESET: Stay in EDM Error 11 12 21 22
#EDM_Error_21b-->EDM_Error_21b_RESET: Stay in EDM Error 11 12 21 22
#EDM_Error_22b-->EDM_Error_22b_RESET: Stay in EDM Error 11 12 21 22
#EDM_Error_13b-->EDM_Error_13b_RESET: Stay in EDM Error 13 23
#EDM_Error_23b-->EDM_Error_23b_RESET: Stay in EDM Error 13 23

#@begin generated
test logicals.safety.plcopen.SF_EDM_0
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=R_TRIG Reset AND R_TRIG at S_OutControl->Init_Error
  Data  3       TRUE      FALSE   FALSE   T#20ms          TRUE    TRUE    16#C100    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG Reset AND R_TRIG at S_OutControl->Init_Error
  Data  4       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_EDM_1
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=R_TRIG Reset AND R_TRIG at S_OutControl->Init_Error
  Data  3       TRUE      FALSE   FALSE   T#20ms          TRUE    TRUE    16#C100    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG Reset AND R_TRIG at S_OutControl->Init_Error
  Data  5       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=NOT Reset->Init
  Finish

test logicals.safety.plcopen.SF_EDM_2
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate AND Reset->Init_AND_reset
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#C001    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  4       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=NOT Reset->Init_AND_reset
  Finish

test logicals.safety.plcopen.SF_EDM_3
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate AND Reset->Init_AND_reset
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#C001    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  3       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_EDM_4
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      TRUE    FALSE   T#20ms          FALSE   TRUE    16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND EDM1 AND NOT EDM2->EDM_Error_12a
  Data  4       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_EDM_5
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   FALSE   T#20ms          FALSE   TRUE    16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND NOT EDM2->EDM_Error_13a
  Data  4       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_EDM_6
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#8000    FALSE   TRUE    FALSE          TRUE        FALSE  doc=S_OutControl->Output_Enable
  Data  4       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=NOT S_OutControl->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_7
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   TRUE    T#20ms          FALSE   TRUE    16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND EDM2->EDM_Error_11a
  Data  4       TRUE      TRUE    FALSE   T#20ms          TRUE    FALSE   16#C011    TRUE    TRUE    FALSE          FALSE       FALSE  doc=STAT_TRUE at Reset AND R_TRIG at EDM1_2->Reset_Error_21
  Data  6       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=NOT Reset->EDM_Error_11a
  Finish

test logicals.safety.plcopen.SF_EDM_8
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   TRUE    T#20ms          FALSE   TRUE    16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND EDM2->EDM_Error_11a
  Data  4       TRUE      TRUE    FALSE   T#20ms          TRUE    FALSE   16#C011    TRUE    TRUE    FALSE          FALSE       FALSE  doc=STAT_TRUE at Reset AND R_TRIG at EDM1_2->Reset_Error_21
  Data  5       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_EDM_9
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   TRUE    T#20ms          FALSE   TRUE    16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND EDM2->EDM_Error_11a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C410    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_11b
  Data  5       TRUE      FALSE   TRUE    T#20ms          FALSE   FALSE   16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=NOT EDM1 AND EDM2->EDM_Error_11a
  Finish

test logicals.safety.plcopen.SF_EDM_10
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   TRUE    T#20ms          FALSE   TRUE    16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND EDM2->EDM_Error_11a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C410    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_11b
  Data  5       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C410    TRUE    TRUE    TRUE           FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM1->Reset_Error_21
  Data  6       TRUE      TRUE    FALSE   T#20ms          TRUE    FALSE   16#C011    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM1->Reset_Error_21
  Finish

test logicals.safety.plcopen.SF_EDM_11
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   TRUE    T#20ms          FALSE   TRUE    16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND EDM2->EDM_Error_11a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C410    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_11b
  Data  5       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_12
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   TRUE    T#20ms          FALSE   TRUE    16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND EDM2->EDM_Error_11a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C410    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_11b
  Data  5       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_EDM_13
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   TRUE    T#20ms          FALSE   TRUE    16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND EDM2->EDM_Error_11a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C410    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_11b
  Data  5       TRUE      FALSE   FALSE   T#20ms          TRUE    TRUE    16#C410    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Stay in EDM Error 11 12 21 22->EDM_Error_11b_RESET
  Finish

test logicals.safety.plcopen.SF_EDM_14
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      TRUE    FALSE   T#20ms          FALSE   TRUE    16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND EDM1 AND NOT EDM2->EDM_Error_12a
  Data  4       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM2->Reset_Error_22
  Data  5       TRUE      FALSE   TRUE    T#20ms          TRUE    FALSE   16#C021    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM2->Reset_Error_22
  Data  7       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=NOT Reset->EDM_Error_12a
  Finish

test logicals.safety.plcopen.SF_EDM_15
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      TRUE    FALSE   T#20ms          FALSE   TRUE    16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND EDM1 AND NOT EDM2->EDM_Error_12a
  Data  4       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM2->Reset_Error_22
  Data  5       TRUE      FALSE   TRUE    T#20ms          TRUE    FALSE   16#C021    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM2->Reset_Error_22
  Data  6       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_EDM_16
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      TRUE    FALSE   T#20ms          FALSE   TRUE    16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND EDM1 AND NOT EDM2->EDM_Error_12a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C420    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_12b
  Data  5       TRUE      TRUE    FALSE   T#20ms          FALSE   TRUE    16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND EDM1 AND NOT EDM2->EDM_Error_12a
  Finish

test logicals.safety.plcopen.SF_EDM_17
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      TRUE    FALSE   T#20ms          FALSE   TRUE    16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND EDM1 AND NOT EDM2->EDM_Error_12a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C420    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_12b
  Data  5       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C420    TRUE    TRUE    TRUE           FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM2->Reset_Error_22
  Data  6       TRUE      FALSE   TRUE    T#20ms          TRUE    FALSE   16#C021    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM2->Reset_Error_22
  Finish

test logicals.safety.plcopen.SF_EDM_18
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      TRUE    FALSE   T#20ms          FALSE   TRUE    16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND EDM1 AND NOT EDM2->EDM_Error_12a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C420    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_12b
  Data  5       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_19
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      TRUE    FALSE   T#20ms          FALSE   TRUE    16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND EDM1 AND NOT EDM2->EDM_Error_12a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C420    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_12b
  Data  5       TRUE      FALSE   FALSE   T#20ms          TRUE    TRUE    16#C420    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Stay in EDM Error 11 12 21 22->EDM_Error_12b_RESET
  Finish

test logicals.safety.plcopen.SF_EDM_20
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   FALSE   T#20ms          FALSE   TRUE    16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND NOT EDM2->EDM_Error_13a
  Data  4       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#C031    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM1 and R_TRIG at EDM2->Reset_Error_23
  Data  6       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=NOT Reset->EDM_Error_13a
  Finish

test logicals.safety.plcopen.SF_EDM_21
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   FALSE   T#20ms          FALSE   TRUE    16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND NOT EDM2->EDM_Error_13a
  Data  4       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#C031    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM1 and R_TRIG at EDM2->Reset_Error_23
  Data  5       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_EDM_22
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   FALSE   T#20ms          FALSE   TRUE    16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND NOT EDM2->EDM_Error_13a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C430    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_13b
  Data  5       TRUE      FALSE   FALSE   T#20ms          FALSE   TRUE    16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND NOT EDM2->EDM_Error_13a
  Finish

test logicals.safety.plcopen.SF_EDM_23
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   FALSE   T#20ms          FALSE   TRUE    16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND NOT EDM2->EDM_Error_13a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C430    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_13b
  Data  5       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_24
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   FALSE   T#20ms          FALSE   TRUE    16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND NOT EDM2->EDM_Error_13a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C430    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_13b
  Data  5       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_EDM_25
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   FALSE   T#20ms          FALSE   TRUE    16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND NOT EDM2->EDM_Error_13a
  Data  4       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C430    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_13b
  Data  5       TRUE      TRUE    FALSE   T#20ms          TRUE    TRUE    16#C430    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Stay in EDM Error 13 23->EDM_Error_13b_RESET
  Finish

test logicals.safety.plcopen.SF_EDM_26
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  4       TRUE      FALSE   TRUE    T#20ms          FALSE   FALSE   16#C040    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND NOT EDM1 AND EDM2 NOT RESET->EDM_Error_21a
  Data  5       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C440    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_21b
  Data  6       TRUE      FALSE   TRUE    T#20ms          FALSE   FALSE   16#C040    TRUE    TRUE    FALSE          FALSE       FALSE  doc=NOT EDM1 AND EDM2->EDM_Error_21a
  Finish

test logicals.safety.plcopen.SF_EDM_27
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  4       TRUE      FALSE   TRUE    T#20ms          FALSE   FALSE   16#C040    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND NOT EDM1 AND EDM2 NOT RESET->EDM_Error_21a
  Data  5       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C440    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_21b
  Data  6       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_28
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  4       TRUE      FALSE   TRUE    T#20ms          FALSE   FALSE   16#C040    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND NOT EDM1 AND EDM2 NOT RESET->EDM_Error_21a
  Data  5       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C440    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_21b
  Data  6       TRUE      FALSE   FALSE   T#20ms          TRUE    TRUE    16#C440    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Stay in EDM Error 11 12 21 22->EDM_Error_21b_RESET
  Finish

test logicals.safety.plcopen.SF_EDM_29
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  4       TRUE      TRUE    FALSE   T#20ms          FALSE   FALSE   16#C050    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND EDM1 AND NOT EDM2 NOT RESET->EDM_Error_22a
  Data  5       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C450    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_22b
  Data  6       TRUE      TRUE    FALSE   T#20ms          FALSE   TRUE    16#C050    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND EDM1 AND NOT EDM2->EDM_Error_22a
  Finish

test logicals.safety.plcopen.SF_EDM_30
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  4       TRUE      TRUE    FALSE   T#20ms          FALSE   FALSE   16#C050    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND EDM1 AND NOT EDM2 NOT RESET->EDM_Error_22a
  Data  5       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C450    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_22b
  Data  6       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_31
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  4       TRUE      TRUE    FALSE   T#20ms          FALSE   FALSE   16#C050    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND EDM1 AND NOT EDM2 NOT RESET->EDM_Error_22a
  Data  5       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C450    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_22b
  Data  6       TRUE      FALSE   FALSE   T#20ms          TRUE    TRUE    16#C450    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Stay in EDM Error 11 12 21 22->EDM_Error_22b_RESET
  Finish

test logicals.safety.plcopen.SF_EDM_32
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  4       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C060    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND NOT EDM1 AND NOT EDM2->EDM_Error_23a
  Data  5       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C460    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_23b
  Data  6       TRUE      FALSE   FALSE   T#20ms          FALSE   TRUE    16#C060    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND NOT EDM2->EDM_Error_23a
  Finish

test logicals.safety.plcopen.SF_EDM_33
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  4       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C060    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND NOT EDM1 AND NOT EDM2->EDM_Error_23a
  Data  5       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C460    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_23b
  Data  6       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_34
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  4       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C060    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND NOT EDM1 AND NOT EDM2->EDM_Error_23a
  Data  5       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C460    TRUE    TRUE    TRUE           FALSE       FALSE  doc=S_OutControl AND EDM1 AND EDM2->EDM_Error_23b
  Data  6       TRUE      TRUE    FALSE   T#20ms          TRUE    TRUE    16#C460    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Stay in EDM Error 13 23->EDM_Error_23b_RESET
  Finish

test logicals.safety.plcopen.SF_EDM_35
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   TRUE    T#20ms          FALSE   TRUE    16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND EDM2->EDM_Error_11a
  Data  4       TRUE      TRUE    FALSE   T#20ms          TRUE    FALSE   16#C011    TRUE    TRUE    FALSE          FALSE       FALSE  doc=STAT_TRUE at Reset AND R_TRIG at EDM1_2->Reset_Error_21
  Data  5       TRUE      TRUE    TRUE    T#20ms          FALSE   FALSE   16#C010    TRUE    TRUE    FALSE          FALSE       FALSE  doc=NOT Reset AND EDM1 AND EDM2->EDM_Error_11a_back
  Data  6       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_36
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      TRUE    FALSE   T#20ms          FALSE   TRUE    16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND EDM1 AND NOT EDM2->EDM_Error_12a
  Data  4       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM2->Reset_Error_22
  Data  5       TRUE      FALSE   TRUE    T#20ms          TRUE    FALSE   16#C021    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM2->Reset_Error_22
  Data  6       TRUE      TRUE    TRUE    T#20ms          FALSE   FALSE   16#C020    TRUE    TRUE    FALSE          FALSE       FALSE  doc=NOT Reset AND EDM1 AND EDM2->EDM_Error_12a_back
  Data  7       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_37
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      FALSE   FALSE   T#20ms          FALSE   TRUE    16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=S_OutControl AND NOT EDM1 AND NOT EDM2->EDM_Error_13a
  Data  4       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#C031    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM1 and R_TRIG at EDM2->Reset_Error_23
  Data  5       TRUE      TRUE    TRUE    T#20ms          FALSE   FALSE   16#C030    TRUE    TRUE    FALSE          FALSE       FALSE  doc=NOT Reset AND EDM1 AND EDM2->EDM_Error_13a_back
  Data  6       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_38
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  4       TRUE      FALSE   TRUE    T#20ms          FALSE   FALSE   16#C040    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND NOT EDM1 AND EDM2 NOT RESET->EDM_Error_21a
  Data  5       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C040    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM1->Reset_Error_31
  Data  6       TRUE      TRUE    FALSE   T#20ms          TRUE    FALSE   16#C041    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM1->Reset_Error_31
  Data  7       TRUE      TRUE    TRUE    T#20ms          FALSE   FALSE   16#C040    TRUE    TRUE    FALSE          FALSE       FALSE  doc=NOT Reset AND EDM1 AND EDM2->EDM_Error_21a_back
  Data  8       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_39
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  4       TRUE      TRUE    FALSE   T#20ms          FALSE   FALSE   16#C050    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND EDM1 AND NOT EDM2 NOT RESET->EDM_Error_22a
  Data  5       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C050    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM2->Reset_Error_32
  Data  6       TRUE      FALSE   TRUE    T#20ms          TRUE    FALSE   16#C051    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM2->Reset_Error_32
  Data  7       TRUE      TRUE    TRUE    T#20ms          FALSE   FALSE   16#C050    TRUE    TRUE    FALSE          FALSE       FALSE  doc=NOT Reset AND EDM1 AND EDM2->EDM_Error_22a_back
  Data  8       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_40
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  4       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C060    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND NOT EDM1 AND NOT EDM2->EDM_Error_23a
  Data  5       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#C061    TRUE    TRUE    FALSE          FALSE       FALSE  doc=R_TRIG at Reset AND R_TRIG at EDM1 and R_TRIG at EDM2->Reset_Error_33
  Data  6       TRUE      TRUE    TRUE    T#20ms          FALSE   FALSE   16#C060    TRUE    TRUE    FALSE          FALSE       FALSE  doc=NOT Reset AND EDM1 AND EDM2->EDM_Error_23a_back
  Data  7       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_41
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#8000    FALSE   TRUE    FALSE          TRUE        FALSE  doc=S_OutControl->Output_Enable
  Data  5       TRUE      TRUE    FALSE   T#20ms          TRUE    FALSE   16#C070    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND EDM1 AND NOT EDM2->EDM_Error_31_RESET
  Data  6       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#C071    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_41
  Data  8       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C070    TRUE    TRUE    TRUE           FALSE       FALSE  doc=NOT Reset->EDM_Error_31
  Data  9       TRUE      TRUE    FALSE   T#20ms          FALSE   FALSE   16#C070    TRUE    TRUE    TRUE           FALSE       FALSE  doc=R_TRIG at Reset AND EDM1 AND NOT EDM2->Output_Disable
  Data  10      TRUE      TRUE    FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND NOT EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_42
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#8000    FALSE   TRUE    FALSE          TRUE        FALSE  doc=S_OutControl->Output_Enable
  Data  5       TRUE      FALSE   TRUE    T#20ms          TRUE    FALSE   16#C080    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND NOT EDM1 AND EDM2->EDM_Error_32_RESET
  Data  6       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#C081    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_42
  Data  8       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C080    TRUE    TRUE    TRUE           FALSE       FALSE  doc=NOT Reset->EDM_Error_32
  Data  9       TRUE      FALSE   TRUE    T#20ms          FALSE   FALSE   16#C080    TRUE    TRUE    TRUE           FALSE       FALSE  doc=R_TRIG at Reset AND NOT EDM1 AND EDM2->Output_Disable
  Data  10      TRUE      FALSE   TRUE    T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND NOT EDM1 AND EDM2->Output_Disable
  Finish

test logicals.safety.plcopen.SF_EDM_43
  Head  Time  Activate  EDM1  EDM2  MonitoringTime  Reset  S_OutControl  DiagCode?  Error?  Ready?  ResetRequest?  S_EDM_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE   T#20ms          FALSE   FALSE   16#0000    FALSE   FALSE   FALSE          FALSE       FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#8401    FALSE   TRUE    TRUE           FALSE       FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset->Output_Disable
  Data  3       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#8000    FALSE   TRUE    FALSE          TRUE        FALSE  doc=S_OutControl->Output_Enable
  Data  5       TRUE      TRUE    TRUE    T#20ms          TRUE    FALSE   16#C090    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Monitoring_Time_Elapsed AND EDM1 AND EDM2->EDM_Error_33_RESET
  Data  6       TRUE      FALSE   FALSE   T#20ms          TRUE    FALSE   16#C091    TRUE    TRUE    FALSE          FALSE       FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_43
  Data  8       TRUE      FALSE   FALSE   T#20ms          FALSE   FALSE   16#C090    TRUE    TRUE    TRUE           FALSE       FALSE  doc=NOT Reset->EDM_Error_33
  Data  9       TRUE      TRUE    TRUE    T#20ms          FALSE   TRUE    16#C090    TRUE    TRUE    TRUE           FALSE       FALSE  doc=R_TRIG at Reset AND EDM1 AND EDM2 EDGE->Output_Disable
  Data  10      TRUE      TRUE    TRUE    T#20ms          TRUE    TRUE    16#8810    FALSE   TRUE    FALSE          FALSE       TRUE   doc=R_TRIG at Reset AND EDM1 AND EDM2 EDGE->Output_Disable
  Finish

