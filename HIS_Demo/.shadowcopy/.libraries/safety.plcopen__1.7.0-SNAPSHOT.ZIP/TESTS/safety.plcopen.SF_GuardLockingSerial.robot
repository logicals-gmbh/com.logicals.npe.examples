*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_GuardLockingSerial		MaxDataRows=300		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  Reset=FALSE
...  S_AutoReset=0
...  S_Guard=0
...  S_SafetyActive=0
...  S_StartReset=0
...  UnlockRequest=FALSE
*** Test Cases ***
test logicals.safety.plcopen.SF_GLS_Invalid_State
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?   ENO?     CycleTime=T#10ms
  Tol    /    /         /      /            /        /               /             /              0          0       0       0              0               0               0               0     
  Shift  /    /         /      /            /        /               /             /              0          0       0       0              0               0               0               0
  Init   /    /         /      /            /        /               /             /              16#9999    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE           TRUE     
  Data   0    TRUE      FALSE  FALSE        FALSE    FALSE           FALSE         FALSE          16#9999    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE           FALSE    doc=Invalid State
  Data   1    TRUE      FALSE  FALSE        FALSE    FALSE           FALSE         FALSE          16#9999    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE           FALSE    doc=Invalid State
  Data   2    FALSE     FALSE  FALSE        FALSE    FALSE           FALSE         FALSE          16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE           TRUE     doc=NOT Activate->Idle
  Data   3    TRUE      TRUE   FALSE        TRUE     FALSE           FALSE         FALSE          16#8401    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE           TRUE     doc=Activate AND S_Guard->Init_S_Guard_True
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_C410_Reset_Request
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?   CycleTime=T#10ms
  Tol    /    /         /      /            /        /               /             /              0          0       0       0              0               0               0                   
  Shift  /    /         /      /            /        /               /             /              0          0       0       0              0               0               0               
  Init   /    /         /      /            /        /               /             /              16#C010    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     
  Data  0     TRUE      TRUE   FALSE        TRUE     TRUE           FALSE          FALSE          16#C410    TRUE    TRUE    FALSE          FALSE           FALSE            FALSE           doc=ResetRequest False when reset is True
  Data  1     TRUE      TRUE   FALSE        TRUE     TRUE           FALSE          FALSE          16#C011    TRUE    TRUE    FALSE          FALSE           FALSE            FALSE           doc=Just passing by
  Data  2     TRUE      FALSE  FALSE        TRUE     TRUE           FALSE          FALSE          16#C410    TRUE    TRUE    TRUE           FALSE           FALSE            FALSE           doc=ResetRequest True when reset is False

test logicals.safety.plcopen.SF_GuardLockingSerial_C420_Reset_Request
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?   CycleTime=T#10ms
  Tol    /    /         /      /            /        /               /             /              0          0       0       0              0               0               0                   
  Shift  /    /         /      /            /        /               /             /              0          0       0       0              0               0               0               
  Init   /    /         /      /            /        /               /             /              16#C050    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     
  Data  0     TRUE      TRUE   FALSE        FALSE    TRUE           FALSE          FALSE          16#C420    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE           doc=ResetRequest False when reset is True
  Data  1     TRUE      TRUE   FALSE        FALSE    TRUE           FALSE          FALSE          16#C021    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE           doc=Just passing by
  Data  2     TRUE      FALSE  FALSE        FALSE    TRUE           FALSE          FALSE          16#C420    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE           doc=ResetRequest True when reset is False

test logicals.safety.plcopen.SF_GuardLockingSerial_CX40_Reset_Request
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?   CycleTime=T#10ms
  Tol    /    /         /      /            /        /               /             /              0          0       0       0              0               0               0                   
  Shift  /    /         /      /            /        /               /             /              0          0       0       0              0               0               0               
  Init   /    /         /      /            /        /               /             /              16#C040    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     
  Data  0     TRUE      TRUE   FALSE        FALSE    TRUE           FALSE          FALSE          16#C040    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE           doc=ResetRequest False when reset is True
  Data  1     TRUE      TRUE   FALSE        FALSE    TRUE           FALSE          FALSE          16#C041    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE           doc=Just passing by
  Data  2     TRUE      FALSE  FALSE        FALSE    TRUE           FALSE          FALSE          16#C040    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE           doc=ResetRequest True when reset is False

test logicals.safety.plcopen.SF_GuardLockingSerial_8430_Reset_Request
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?   CycleTime=T#10ms
  Tol    /    /         /      /            /        /               /             /              0          0       0       0              0               0               0                   
  Shift  /    /         /      /            /        /               /             /              0          0       0       0              0               0               0               
  Init   /    /         /      /            /        /               /             /              16#8812    TRUE    FALSE   FALSE          FALSE           TRUE            FALSE     
  Data  0     TRUE      TRUE   FALSE        TRUE     TRUE           FALSE          FALSE          16#8430    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE           doc=ResetRequest False when reset is True
  Data  1     TRUE      TRUE   FALSE        TRUE     TRUE           FALSE          FALSE          16#C031    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE           doc=Just passing by
  Data  2     TRUE      FALSE  FALSE        TRUE     TRUE           FALSE          FALSE          16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE           doc=ResetRequest True when reset is False

test logicals.safety.plcopen.SF_GuardLockingSerial_8410_Reset_Request
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?   CycleTime=T#10ms
  Tol    /    /         /      /            /        /               /             /              0          0       0       0              0               0               0                   
  Shift  /    /         /      /            /        /               /             /              0          0       0       0              0               0               0               
  Init   /    /         /      /            /        /               /             /              16#8000    TRUE    FALSE   FALSE          TRUE            TRUE            FALSE     
  Data  0     TRUE      TRUE   FALSE        TRUE     TRUE           FALSE          TRUE           16#8410    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE           doc=ResetRequest False when reset is True
  Data  1     TRUE      FALSE  FALSE        TRUE     TRUE           FALSE          FALSE          16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE           doc=ResetRequest True when reset is False

test logicals.safety.plcopen.SF_GuardLockingSerial_CX50_Reset_Request
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?   CycleTime=T#10ms
  Tol    /    /         /      /            /        /               /             /              0          0       0       0              0               0               0                   
  Shift  /    /         /      /            /        /               /             /              0          0       0       0              0               0               0               
  Init   /    /         /      /            /        /               /             /              16#C050    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     
  Data  0     TRUE      TRUE   FALSE        FALSE    FALSE          FALSE          FALSE          16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE           doc=ResetRequest False when reset is True
  Data  1     TRUE      FALSE  FALSE        FALSE    FALSE          FALSE          FALSE          16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE           doc=ResetRequest True when reset is False

test logicals.safety.plcopen.SF_GuardLockingSerial_8X01_Reset_Request
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?   CycleTime=T#10ms
  Tol    /    /         /      /            /        /               /             /              0          0       0       0              0               0               0                   
  Shift  /    /         /      /            /        /               /             /              0          0       0       0              0               0               0               
  Init   /    /         /      /            /        /               /             /              16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     
  Data  0     TRUE      TRUE   FALSE        FALSE    FALSE          FALSE          FALSE          16#8801    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE            doc=ResetRequest False when reset is True
  Data  1     TRUE      TRUE   FALSE        FALSE    FALSE          FALSE          FALSE          16#C001    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE           doc=ResetRequest True when reset is False
  Data  2     TRUE      FALSE  FALSE        FALSE    FALSE          FALSE          FALSE          16#8801    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE            doc=ResetRequest True when reset is False


test logicals.safety.plcopen.SF_GuardLockingSerial_8401_C001_C001
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    FALSE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C001    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE     doc=Reset AND NOT R_TRIG at Reset AND NOT S_StartReset->Reset_Error_0
  Data  3     TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C001    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE     doc=Reset->Reset_Error_0
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_8401_C001_8401
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C001    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE     doc=Reset AND NOT R_TRIG at Reset AND NOT S_StartReset->Reset_Error_0
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=NOT Reset->Init_S_Guard_True
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_8401_C001_8801
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    FALSE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C001    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE     doc=Reset AND NOT R_TRIG at Reset AND NOT S_StartReset->Reset_Error_0
  Data  3     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE            FALSE           FALSE           TRUE      doc=NOT Reset->Init_S_Guard_False
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_8401_8000_var1
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_1
  Data  2     TRUE      FALSE   FALSE        TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=NOT Reset AND S_Guard AND S_StartReset->Guard_Closed_And_Locked
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_8401_8000_var2
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_1
  Data  2     TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=Reset AND R_TRIG at Reset AND S_Guard AND NOT S_StartReset->Guard_Closed_And_Locked
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_8401_8000_var3
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_1
  Data  2     TRUE      TRUE    FALSE        TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=Reset AND R_TRIG at Reset AND S_Guard AND S_StartReset->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_8801_8000_var1
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE           FALSE            FALSE           TRUE      doc=Activate AND NOT S_Guard->Init_2
  Data  2     TRUE      FALSE   FALSE        TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=NOT Reset AND S_Guard AND S_StartReset->Guard_Closed_And_Locked
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_8801_8000_var2
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE      doc=Activate AND NOT S_Guard->Init_2
  Data  2     TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=Reset AND R_TRIG at Reset AND S_Guard AND NOT S_StartReset->Guard_Closed_And_Locked
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_8801_8000_var3
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE      doc=Activate AND NOT S_Guard->Init_2
  Data  2     TRUE      TRUE    FALSE        TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=Reset AND R_TRIG at Reset AND S_Guard AND S_StartReset->Guard_Closed_And_Locked
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_8801_C001
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      TRUE    FALSE        FALSE    FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE      doc=Activate AND NOT S_Guard->Init_2
  Data  2     TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C001    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE     doc=Reset AND R_TRIG at Reset AND S_Guard AND S_StartReset->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_C410_C011_C011
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE     doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3     TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#C410    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE     doc=S_Guard->Guard_Return
  Data  4     TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#C011    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE     doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#C011    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE     doc=Reset->Reset_Error_1
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_C410_C011_C410
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE     doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3     TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#C410    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE     doc=S_Guard->Guard_Return
  Data  4     TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#C011    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE     doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  5     TRUE      FALSE   FALSE        TRUE     TRUE            FALSE         FALSE  16#C410    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE     doc=NOT Reset->Guard_Return
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_C420_prio2over4
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE    doc=NOT S_SafetyActive AND NOT S_Guard->Safety_Lost_S_Guard_False
  Data  4     TRUE      TRUE    FALSE        FALSE    TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=S_SafetyActive->Safety_Return
  Data  5     TRUE      FALSE   FALSE        FALSE    TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE    doc=S_SafetyActive->Safety_Return
  Data  6     TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=PRIORITY_CHECK_8000_Reset AND NOT R_TRIG at Reset->Reset_Error_2
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_C450_prio1over2
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE    doc=NOT S_SafetyActive AND S_Guard->Safety_Lost_1
  Data  4     TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=PRIORITY_CHECK_8000_Reset AND R_TRIG at Reset AND S_Guard AND S_SafetyActive->Safety_Return
  Finish
    
test logicals.safety.plcopen.SF_GuardLockingSerial_C050_prio1over2
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE    doc=NOT S_SafetyActive AND NOT S_Guard->Safety_Lost_2
  Data  4     TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=PRIORITY_CHECK_8000_Reset AND R_TRIG at Reset AND S_Guard AND S_SafetyActive->Safety_Return
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_C420_C021_C021
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE    doc=NOT S_SafetyActive AND NOT S_Guard->Safety_Lost_S_Guard_False
  Data  4     TRUE      TRUE    FALSE        FALSE    TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=S_SafetyActive->Safety_Return
  Data  5     TRUE      TRUE    FALSE        FALSE    TRUE            FALSE         FALSE  16#C021    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=Reset AND NOT R_TRIG at Reset->Reset_Error_2
  Data  6     TRUE      TRUE    FALSE        FALSE    TRUE            FALSE         FALSE  16#C021    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=Reset->Reset_Error_2
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_C420_C021_C420
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND NOT S_Guard->Safety_Lost_S_Guard_False
  Data  4     TRUE      TRUE    FALSE        FALSE    TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=S_SafetyActive->Safety_Return
  Data  5     TRUE      TRUE    FALSE        FALSE    TRUE            FALSE         FALSE  16#C021    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_2
  Data  6     TRUE      FALSE   FALSE        FALSE    TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT Reset->Safety_Return
  Finish
    
test logicals.safety.plcopen.SF_GuardLockingSerial_8822_8822
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE      doc=Activate AND NOT S_Guard->Init_S_Guard_False
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE      doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    TRUE            FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE      doc=S_SafetyActive UnlockRequest->Guard_Open_And_Or_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_8812_8812
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE      doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE      doc=NOT UnlockRequest->Wait_For_Operator
  Data  4     TRUE      FALSE   FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE      doc=S_SafetyActive AND NOT S_Guard->Wait_For_Operator
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_8812_prio1over3
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE      doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE      doc=NOT UnlockRequest->Wait_For_Operator
  Data  4     TRUE      FALSE   FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE      doc=S_SafetyActive AND NOT S_Guard->Wait_For_Operator
  Data  5     TRUE      FALSE   TRUE         TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE     doc=PRIORITY_CHECK_8000_S_AutoReset AND NOT S_SafetyActive AND S_Guard->Safety_Lost_1
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_8430_C031_C031
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE   doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE    doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE    doc=NOT UnlockRequest->Wait_For_Operator
  Data  4     TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE   doc=S_Guard->Wait_For_Reset
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#C031    TRUE   TRUE    FALSE           FALSE           FALSE           FALSE   doc=Reset AND NOT R_TRIG at Reset AND NOT S_AutoReset->Reset_Error_3
  Data  6     TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#C031    TRUE   TRUE    FALSE           FALSE           FALSE           FALSE   doc=Reset->Reset_Error_3
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_8430_C031_8430
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE            FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE            FALSE   doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE             TRUE    doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE            TRUE    doc=NOT UnlockRequest->Wait_For_Operator
  Data  4     TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    FALSE          FALSE           FALSE            FALSE   doc=S_Guard->Wait_For_Reset
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#C031    TRUE    TRUE    FALSE          FALSE           FALSE            FALSE   doc=Reset AND NOT R_TRIG at Reset AND NOT S_AutoReset->Reset_Error_3
  Data  6     TRUE      FALSE   FALSE        TRUE     TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE            FALSE   doc=Reset->Wait_For_Reset
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_C440_C041_C041
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0      FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1      TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2      TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3      TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE    doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  4      TRUE      FALSE   FALSE        TRUE     TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE    doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5      TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         TRUE   16#8410    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE    doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  205    TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C440    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=Unlock_Waiting_Timer_Elapsed AND S_Guard->Unlock_Request_Error_S_Guard_True
  Data  206    TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C041    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=Reset AND NOT R_TRIG at Reset AND NOT S-AutoReset->Reset_Error_4
  Data  207    TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C041    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=Reset->Reset_Error_4
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_C440_C041_C440
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0      FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1      TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2      TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3      TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE    doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  4      TRUE      FALSE   FALSE        TRUE     TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE    doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5      TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         TRUE   16#8410    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE    doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  205    TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C440    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=Unlock_Waiting_Timer_Elapsed AND S_Guard->Unlock_Request_Error_S_Guard_True
  Data  206    TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C041    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=Reset AND NOT R_TRIG at Reset AND NOT S-AutoReset->Reset_Error_4
  Data  207    TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE    doc=NOT Reset AND S_Guard->Unlock_Request_Error_S_Guard_True
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_C440_C041_C040
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0      FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1      TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2      TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3      TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE    doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  4      TRUE      FALSE   FALSE        TRUE     TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE    doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5      TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         TRUE   16#8410    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE    doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  205    TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C440    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=Unlock_Waiting_Timer_Elapsed AND S_Guard->Unlock_Request_Error_S_Guard_True
  Data  206    TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#C041    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=Reset AND NOT R_TRIG at Reset AND NOT S-AutoReset->Reset_Error_4
  Data  207    TRUE      FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#C040    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE    doc=NOT Reset AND NOT S_Guard->Unlock_Request_Error_S_Guard_False
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_8410_prio2over3
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE   FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3     TRUE      TRUE    FALSE        TRUE     FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  4     TRUE      FALSE   FALSE        TRUE     TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5     TRUE      FALSE   FALSE        TRUE     TRUE            FALSE         TRUE   16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE     doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  6     TRUE      FALSE   FALSE        TRUE     TRUE            FALSE         FALSE  16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE     doc=S_Guard AND S_SafetyActive-Wait_For_Unlocked
  Data  205   TRUE      TRUE    FALSE        TRUE     TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=PRIORITY_CHECK_C040_R_TRIG at Reset AND S_Guard AND S_SafetyActive->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_C440_8000
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE    FALSE       FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE    FALSE       TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE    FALSE       TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3     TRUE      FALSE    FALSE       TRUE     TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  4     TRUE      FALSE    FALSE       TRUE     TRUE            FALSE         TRUE   16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE     doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  204   TRUE      FALSE    FALSE       TRUE     FALSE           FALSE         FALSE  16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE     doc=Unlock_Waiting_Timer_Elapsed AND S_Guard->Unlock_Request_Error_S_Guard_True
  Data  205   TRUE      TRUE     FALSE       TRUE     FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=R_TRIG at Reset AND S_Guard->Guard_Closed_And_Locked
  Finish
  
test logicals.safety.plcopen.SF_GuardLockingSerial_C440_C040_C041
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE    FALSE       FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE    FALSE       TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE    FALSE       TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3     TRUE      FALSE    FALSE       TRUE     TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  4     TRUE      FALSE    FALSE       TRUE     TRUE            FALSE         TRUE   16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE     doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  204   TRUE      FALSE    FALSE       TRUE     FALSE           FALSE         FALSE  16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE     doc=Unlock_Waiting_Timer_Elapsed AND S_Guard->Unlock_Request_Error_S_Guard_True
  Data  205   TRUE      FALSE    FALSE       FALSE    FALSE           FALSE         FALSE  16#C040    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE     doc=NOT S_Guard->Unlock_Request_Error_S_Guard_False
  Data  206   TRUE      TRUE     FALSE       FALSE    FALSE           FALSE         FALSE  16#C040    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE     doc=NOT S_Guard AND Reset->Unlock_Request_Error_S_Guard_False
  Data  207   TRUE      TRUE     FALSE       FALSE    FALSE           FALSE         FALSE  16#C041    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE     doc=Reset AND NOT R_TRIG at Reset AND NOT S-AutoReset->Reset_Error_4
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_C440_C040_8000
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE    FALSE       FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE    FALSE       TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE    FALSE       TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3     TRUE      FALSE    FALSE       TRUE     TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  4     TRUE      FALSE    FALSE       TRUE     TRUE            FALSE         TRUE   16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE     doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  204   TRUE      FALSE    FALSE       TRUE     FALSE           FALSE         FALSE  16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE     doc=Unlock_Waiting_Timer_Elapsed AND S_Guard->Unlock_Request_Error_S_Guard_True
  Data  205   TRUE      FALSE    FALSE       FALSE    FALSE           FALSE         FALSE  16#C040    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE     doc=NOT S_Guard->Unlock_Request_Error_S_Guard_False
  Data  206   TRUE      TRUE     FALSE       TRUE     FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=R_TRIG at Reset AND S_Guard->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_C440_C040_C440
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE    FALSE       FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE    FALSE       TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2     TRUE      FALSE    FALSE       TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3     TRUE      FALSE    FALSE       TRUE     TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE     doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  4     TRUE      FALSE    FALSE       TRUE     TRUE            FALSE         TRUE   16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE     doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  204   TRUE      FALSE    FALSE       TRUE     FALSE           FALSE         FALSE  16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE     doc=Unlock_Waiting_Timer_Elapsed AND S_Guard->Unlock_Request_Error_S_Guard_True
  Data  205   TRUE      FALSE    FALSE       FALSE    FALSE           FALSE         FALSE  16#C040    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE     doc=NOT S_Guard->Unlock_Request_Error_S_Guard_False
  Data  206   TRUE      FALSE    FALSE       TRUE     FALSE           FALSE         FALSE  16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE     doc=NOT Reset AND S_Guard->Unlock_Request_Error_S_Guard_True
  Finish


test logicals.safety.plcopen.SF_GuardLockingSerial_8430_prio2over3
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?   CycleTime=T#10ms
  Tol    /    /         /      /            /        /               /             /              0          0       0       0              0               0               0                   
  Shift  /    /         /      /            /        /               /             /              0          0       0       0              0               0               0               
  Init   /    /         /      /            /        /               /             /              16#8430    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     
  Data  0     TRUE      TRUE   FALSE        FALSE    TRUE           FALSE          FALSE          16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE           doc=PRIORITY_CHECK_8000


test logicals.safety.plcopen.SF_GuardLockingSerial_8430_prio3over4
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?   CycleTime=T#10ms
  Tol    /    /         /      /            /        /               /             /              0          0       0       0              0               0               0                   
  Shift  /    /         /      /            /        /               /             /              0          0       0       0              0               0               0               
  Init   /    /         /      /            /        /               /             /              16#8430    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     
  Data  0     TRUE      TRUE   FALSE        TRUE     TRUE           FALSE          TRUE           16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE           doc=PRIORITY_CHECK_8410
  

    #                                      DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
#@startuml
#Idle:                                 16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE
#Guard_Closed_And_Locked:              16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE
#Init_S_Guard_True:                    16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE
#Init_S_Guard_False:                   16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE
#Wait_For_Reset:                       16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE
#Wait_For_Operator:                    16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE
#Guard_Open_And_Or_Unlocked:           16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE
#Wait_For_Unlocked:                    16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE
#Guard_Error:                          16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE
#Guard_Return:                         16#C410    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE
#Safety_Lost_S_Guard_True:             16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE
#Safety_Lost_S_Guard_False:            16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE
#Safety_Return:                        16#C420    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE
#Unlock_Request_Error_S_Guard_True:    16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE
#Unlock_Request_Error_S_Guard_False:   16#C040    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE
#Reset_Error_4:                        16#C041    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE
#
#T:.                                                                     Time  Activate  Reset      S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest
#T:NOT Activate:                                                         1     FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE
#T:Activate AND S_Guard:                                                 1     TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE
#T:Activate AND NOT S_Guard:                                             1     TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE
#T:NOT S_Guard AND UnlockRequest:                                        1     TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE
#T:NOT S_Guard AND NOT UnlockRequest:                                    1     TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE
#T:(R_TRIG at Reset OR S_StartReset) AND S_Guard 1:                      1     TRUE      FALSE      FALSE        TRUE     FALSE           TRUE          FALSE
#T:(R_TRIG at Reset OR S_StartReset) AND S_Guard 2:                      1     TRUE      FALSE      FALSE        TRUE     FALSE           TRUE          FALSE
#T:NOT S_SafetyActive AND S_Guard:                                       1     TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE
#T:NOT S_SafetyActive AND NOT S_Guard:                                   1     TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE
#T:S_SafetyActive:                                                       1     TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE
#T:NOT UnlockRequest:                                                    1     TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE
#T:NOT S_Guard:                                                          1     TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE
#T:S_Guard:                                                              1     TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE
#T:S_SafetyActive AND S_Guard:                                           1     TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         FALSE
#T:R_TRIG at UnlockRequest:                                              1     TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         R_EDGE
#T:R_TRIG at UnlockRequest AND S_SafetyActive:                           1     TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         R_EDGE
#T:R_TRIG at Reset AND S_Guard AND NOT S_SafetyActive:                   1     TRUE      R_EDGE     FALSE        TRUE     FALSE           FALSE         FALSE
#T:R_TRIG at Reset AND R_TRIG at S_Guard AND NOT S_SafetyActive:         1     TRUE      R_EDGE     FALSE        R_EDGE   FALSE           FALSE         FALSE
#T:R_TRIG at Reset AND S_Guard AND S_SafetyActive:                       1     TRUE      R_EDGE     FALSE        TRUE     TRUE            FALSE         FALSE
#T:R_TRIG at Reset AND NOT S_Guard:                                      1     TRUE      R_EDGE     FALSE        FALSE    TRUE            FALSE         FALSE
#T:R_TRIG at Reset:                                                      1     TRUE      R_EDGE     FALSE        TRUE     FALSE           FALSE         FALSE
#T:S_Guard AND S_AutoReset:                                              1     TRUE      FALSE      TRUE         TRUE     TRUE            FALSE         FALSE
#T:Unlock_Waiting_Timer_Elapsed AND S_Guard:                             200   TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE
#T:R_TRIG at Reset AND S_Guard:                                          1     TRUE      R_EDGE     FALSE        TRUE     FALSE           FALSE         FALSE
#T:Reset AND NOT R_TRIG at Reset AND NOT S_AutoReset AND NOT S_Guard:    1     TRUE      STAT_TRUE  FALSE        FALSE    FALSE           FALSE         FALSE
#T:NOT Reset AND NOT S_Guard:                                            1     TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE
#T:NOT Reset AND S_Guard:                                                1     TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE
#
#[*]-->Idle:NOT Activate
#Idle-->Init_S_Guard_True: Activate AND S_Guard
#Idle-->Init_S_Guard_False: Activate AND NOT S_Guard
#Init_S_Guard_True-->Guard_Open_And_Or_Unlocked: NOT S_Guard AND UnlockRequest
#Init_S_Guard_True-->Guard_Error: NOT S_Guard AND NOT UnlockRequest
#Init_S_Guard_True-->Guard_Closed_And_Locked:(R_TRIG at Reset OR S_StartReset) AND S_Guard 1
#Init_S_Guard_True-->Guard_Closed_And_Locked:(R_TRIG at Reset OR S_StartReset) AND S_Guard 2
#Init_S_Guard_True-->Init_S_Guard_True: S_Guard
#Init_S_Guard_False-->Guard_Open_And_Or_Unlocked: NOT S_Guard AND UnlockRequest
#Init_S_Guard_False-->Guard_Error: NOT S_Guard AND NOT UnlockRequest
#Init_S_Guard_False-->Guard_Closed_And_Locked:(R_TRIG at Reset OR S_StartReset) AND S_Guard 1
#Init_S_Guard_False-->Guard_Closed_And_Locked:(R_TRIG at Reset OR S_StartReset) AND S_Guard 2
#Init_S_Guard_False-->Init_S_Guard_True: S_Guard
#Guard_Open_And_Or_Unlocked-->Safety_Lost_S_Guard_True: NOT S_SafetyActive AND S_Guard
#Guard_Open_And_Or_Unlocked-->Safety_Lost_S_Guard_False: NOT S_SafetyActive AND NOT S_Guard
#Guard_Open_And_Or_Unlocked-->Wait_For_Operator: NOT UnlockRequest
#Safety_Lost_S_Guard_True-->Safety_Return: S_SafetyActive
#Safety_Lost_S_Guard_True-->Guard_Closed_And_Locked: R_TRIG at Reset AND S_Guard AND NOT S_SafetyActive
#Safety_Lost_S_Guard_True-->Safety_Lost_S_Guard_False: NOT S_Guard
#Safety_Lost_S_Guard_False-->Safety_Return: S_SafetyActive
#Safety_Lost_S_Guard_False-->Guard_Closed_And_Locked: R_TRIG at Reset AND R_TRIG at S_Guard AND NOT S_SafetyActive
#Safety_Lost_S_Guard_False-->Safety_Lost_S_Guard_True: S_Guard
#Safety_Return-->Safety_Lost_S_Guard_True: NOT S_SafetyActive AND S_Guard
#Safety_Return-->Safety_Lost_S_Guard_False: NOT S_SafetyActive AND NOT S_Guard
#Safety_Return-->Wait_For_Operator: R_TRIG at Reset AND NOT S_Guard
#Safety_Return-->Guard_Closed_And_Locked: R_TRIG at Reset AND S_Guard AND S_SafetyActive
#Wait_For_Operator-->Safety_Lost_S_Guard_True: NOT S_SafetyActive AND S_Guard
#Wait_For_Operator-->Safety_Lost_S_Guard_False: NOT S_SafetyActive AND NOT S_Guard
#Wait_For_Operator-->Wait_For_Reset: S_SafetyActive AND S_Guard
#Wait_For_Operator-->Guard_Closed_And_Locked: S_Guard AND S_AutoReset
#Wait_For_Reset-->Guard_Error: NOT S_Guard
#Wait_For_Reset-->Guard_Closed_And_Locked: R_TRIG at Reset
#Wait_For_Reset-->Wait_For_Unlocked: R_TRIG at UnlockRequest
#Wait_For_Unlocked-->Guard_Open_And_Or_Unlocked: NOT S_Guard
#Wait_For_Unlocked-->Guard_Closed_And_Locked: R_TRIG at Reset AND S_Guard AND S_SafetyActive
#Wait_For_Unlocked-->Unlock_Request_Error_S_Guard_True: Unlock_Waiting_Timer_Elapsed AND S_Guard
#Guard_Closed_And_Locked-->Guard_Error: NOT S_Guard
#Guard_Closed_And_Locked-->Wait_For_Unlocked: R_TRIG at UnlockRequest AND S_SafetyActive
#Guard_Closed_And_Locked-->Idle: NOT Activate
#Guard_Error-->Guard_Return: S_Guard
#Guard_Return-->Guard_Error: NOT S_Guard
#Guard_Return-->Guard_Closed_And_Locked: R_TRIG at Reset AND S_Guard
#Guard_Error-->Guard_Error: NOT S_Guard
#Unlock_Request_Error_S_Guard_True-->Unlock_Request_Error_S_Guard_True: NOT Reset AND S_Guard
#@enduml
#@begin generated
test logicals.safety.plcopen.SF_GuardLockingSerial_0
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 2->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_1
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_Guard->Init_S_Guard_True
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_2
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE  doc=Activate AND NOT S_Guard->Init_S_Guard_False
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_3
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE  doc=Activate AND NOT S_Guard->Init_S_Guard_False
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_4
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE  doc=Activate AND NOT S_Guard->Init_S_Guard_False
  Data  2       TRUE      FALSE      FALSE        TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_5
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE  doc=Activate AND NOT S_Guard->Init_S_Guard_False
  Data  2       TRUE      FALSE      FALSE        TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 2->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_6
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE  doc=Activate AND NOT S_Guard->Init_S_Guard_False
  Data  2       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_Guard->Init_S_Guard_True
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_7
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_8
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_9
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_10
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard->Safety_Lost_S_Guard_True
  Data  4       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=R_TRIG at Reset AND S_Guard AND NOT S_SafetyActive->Guard_Closed_And_Locked
  Data  5       TRUE      TRUE       FALSE        TRUE     FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND NOT S_SafetyActive->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_11
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard->Safety_Lost_S_Guard_True
  Data  4       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_Guard->Safety_Lost_S_Guard_False
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_12
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND NOT S_Guard->Safety_Lost_S_Guard_False
  Data  4       TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=S_SafetyActive->Safety_Return
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_13
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND NOT S_Guard->Safety_Lost_S_Guard_False
  Data  4       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=R_TRIG at Reset AND R_TRIG at S_Guard AND NOT S_SafetyActive->Guard_Closed_And_Locked
  Data  5       TRUE      TRUE       FALSE        TRUE     FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND R_TRIG at S_Guard AND NOT S_SafetyActive->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_14
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND NOT S_Guard->Safety_Lost_S_Guard_False
  Data  4       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=S_Guard->Safety_Lost_S_Guard_True
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_15
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE  doc=NOT UnlockRequest->Wait_For_Operator
  Data  4       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard->Safety_Lost_S_Guard_True
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_16
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE  doc=NOT UnlockRequest->Wait_For_Operator
  Data  4       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND NOT S_Guard->Safety_Lost_S_Guard_False
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_17
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE  doc=NOT UnlockRequest->Wait_For_Operator
  Data  4       TRUE      FALSE      TRUE         TRUE     TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=S_Guard AND S_AutoReset->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_18
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C410    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_Guard->Guard_Return
  Data  4       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_19
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C410    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_Guard->Guard_Return
  Data  4       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C410    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard->Guard_Closed_And_Locked
  Data  5       TRUE      TRUE       FALSE        TRUE     FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_20
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3       TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  4       TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         TRUE    16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard->Guard_Open_And_Or_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_21
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3       TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  4       TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         TRUE    16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5       TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         FALSE  16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE  doc=R_TRIG at Reset AND S_Guard AND S_SafetyActive->Guard_Closed_And_Locked
  Data  6       TRUE      TRUE       FALSE        TRUE     TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_SafetyActive->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_22
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard->Safety_Lost_S_Guard_True
  Data  4       TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=S_SafetyActive->Safety_Return
  Data  5       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard->Safety_Lost_S_Guard_True
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_23
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard->Safety_Lost_S_Guard_True
  Data  4       TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=S_SafetyActive->Safety_Return
  Data  5       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND NOT S_Guard->Safety_Lost_S_Guard_False
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_24
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard->Safety_Lost_S_Guard_True
  Data  4       TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=S_SafetyActive->Safety_Return
  Data  5       TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=R_TRIG at Reset AND NOT S_Guard->Wait_For_Operator
  Data  6       TRUE      TRUE       FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE  doc=R_TRIG at Reset AND NOT S_Guard->Wait_For_Operator
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_25
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard->Safety_Lost_S_Guard_True
  Data  4       TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=S_SafetyActive->Safety_Return
  Data  5       TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=R_TRIG at Reset AND S_Guard AND S_SafetyActive->Guard_Closed_And_Locked
  Data  6       TRUE      TRUE       FALSE        TRUE     TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_SafetyActive->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_26
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE  doc=NOT UnlockRequest->Wait_For_Operator
  Data  4       TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_SafetyActive AND S_Guard->Wait_For_Reset
  Data  5       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_27
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE  doc=NOT UnlockRequest->Wait_For_Operator
  Data  4       TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_SafetyActive AND S_Guard->Wait_For_Reset
  Data  5       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset->Guard_Closed_And_Locked
  Data  6       TRUE      TRUE       FALSE        TRUE     FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_28
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        FALSE    FALSE           FALSE         TRUE  16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE  doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Or_Unlocked
  Data  3       TRUE      FALSE      FALSE        FALSE    TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE  doc=NOT UnlockRequest->Wait_For_Operator
  Data  4       TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_SafetyActive AND S_Guard->Wait_For_Reset
  Data  5       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE   16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at UnlockRequest->Wait_For_Unlocked
  Data  6       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         TRUE    16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE  doc=R_TRIG at UnlockRequest->Wait_For_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLockingSerial_29
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE        FALSE    FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard->Init_S_Guard_True
  Data  2       TRUE      FALSE      FALSE        TRUE     FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard 1->Guard_Closed_And_Locked
  Data  3       TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  4       TRUE      FALSE      FALSE        TRUE     TRUE            FALSE         TRUE    16#8410    FALSE   TRUE    TRUE           FALSE           TRUE            FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  204   TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=Unlock_Waiting_Timer_Elapsed AND S_Guard->Unlock_Request_Error_S_Guard_True
  Data  205     TRUE      FALSE      FALSE        TRUE     FALSE           FALSE         FALSE  16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT Reset AND S_Guard->Unlock_Request_Error_S_Guard_True
  Finish

