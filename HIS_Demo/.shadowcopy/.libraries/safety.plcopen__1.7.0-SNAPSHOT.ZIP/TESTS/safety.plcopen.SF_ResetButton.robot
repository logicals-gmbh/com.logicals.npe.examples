*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_ResetButton		MaxDataRows=200		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  ResetIn=FALSE
...  ResetRequested=FALSE
...  TrailingMaximum=T#2s
...  TrailingMinimum=0
*** Test Cases ***
test logicals.safety.plcopen.SF_ResetButton_Invalid_State
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  ENO?  CycleTime=T#10ms
  Tol    /    /        /               /                /                0          0       0       0          0
  Shift  /    /        /               /                /                0          0       0       0          0
  Init   /    /        /               /                /                16#9999    FALSE   FALSE   FALSE      TRUE
  Data   0    FALSE    TRUE            T#1s             T#350ms          16#9999    TRUE    TRUE    FALSE      FALSE  doc=Invalid State
  Data   1    FALSE    TRUE            T#1s             T#350ms          16#9999    TRUE    TRUE    FALSE      FALSE  doc=Invalid State
  Data   2    FALSE    FALSE           T#1s             T#350ms          16#0000    FALSE   FALSE   FALSE      TRUE   doc=NOT ResetRequested->Idle
  Finish

test logicals.safety.plcopen.SF_ResetButton_TMinimum_EQ_100
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#1s             T#100ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     FALSE    TRUE            T#1s             T#100ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     FALSE    TRUE            T#80ms           T#100ms  16#C000    TRUE    TRUE    FALSE  doc=TrailingMinimum > TrailingMaximum->Parameter_Error
  Finish
  
test logicals.safety.plcopen.SF_ResetButton_TMaximum_LT_Minimum
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#50ms           T#100ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     FALSE    TRUE            T#50ms           T#100ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     FALSE    TRUE            T#50ms           T#100ms  16#C000    TRUE    TRUE    FALSE  doc=TrailingMinimum > TrailingMaximum->Parameter_Error
  Finish
  
test logicals.safety.plcopen.SF_ResetButton_TMaximum_EQ_Minimum
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#100ms           T#100ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     FALSE    TRUE            T#100ms           T#100ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     FALSE    TRUE            T#100ms           T#100ms  16#83E2    FALSE   TRUE    FALSE  doc=TrailingMinimum > TrailingMaximum->Parameter_Error
  Finish

test logicals.safety.plcopen.SF_ResetButton_83E2_C001_83E2
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#1s             T#350ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     TRUE     TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     TRUE     TRUE            T#1s             T#350ms  16#C001    TRUE    TRUE    FALSE  doc=ResetIn AND NOT R_TRIG at ResetIn->Reset_Error
  Data  4     FALSE    TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=NOT ResetIn->Wait_for_R_TRIG
  Finish
#                              DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
#@startuml
#Idle:                          16#0000    FALSE   FALSE   FALSE
#Wait_for_R_TRIG:               16#83E2    FALSE   TRUE    FALSE
#Wait_for_F_TRIG:               16#83F2    FALSE   TRUE    FALSE
#Reset_Detected:                16#8000    FALSE   TRUE    TRUE
#Parameter_Error:               16#C000    TRUE    TRUE    FALSE
#Reset_Error:                   16#C001    TRUE    TRUE    FALSE
#Error_Trailing_Maximum:        16#C3E0    TRUE    TRUE    FALSE
#Error_Trailing_Maximum_1:      16#C3E0    TRUE    TRUE    FALSE
#Error_Trailing_Minimum:        16#C3F0    TRUE    TRUE    FALSE
#T:.                                                 Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum
#T:NOT ResetRequested:                               1     FALSE    FALSE           T#1s             T#350ms
#T:ResetRequested:                                   1     FALSE    TRUE            T#1s             T#350ms
#T:NOT ResetIn:                                      1     FALSE    TRUE            T#1s             T#350ms
#T:ResetIn:                                          1     TRUE     TRUE            T#1s             T#350ms
#T:ResetIn AND ResetRequested:                       1     TRUE     TRUE            T#1s             T#350ms
#T:TrailingMinimum > TrailingMaximum:                1     FALSE    TRUE            T#1s             T#3s
#T:TrailingMinimum < 100ms:                          1     FALSE    TRUE            T#1s             T#10ms
#T:TrailingMaximum Elapsed:                          100   TRUE     TRUE            T#1s             T#350ms
#T:TrailingMaximum Elapsed_1:                        100   FALSE    TRUE            T#1s             T#350ms
#T:NOT ResetIn AND NOT TrailingMinimum Elapsed:      1     FALSE    TRUE            T#1s             T#350ms
#T:NOT ResetIn AND TrailingMinimum Elapsed:          35    FALSE    TRUE            T#1s             T#350ms
#T:ResetIn AND TrailingMinimum > TrailingMaximum:    1     TRUE     TRUE            T#1s             T#3s
#T:ResetIn AND TrailingMinimum < 100ms:              1     TRUE     TRUE            T#1s             T#10ms
#T:ResetIn AND Next Cycle:                           1     TRUE     TRUE            T#1s             T#350ms
#T:Next Cycle:                                       1     FALSE    TRUE            T#1s             T#350ms
#[*]-->Idle:NOT ResetRequested
#Idle-->Wait_for_R_TRIG: ResetRequested
#Wait_for_R_TRIG-->Parameter_Error: TrailingMinimum > TrailingMaximum
#Wait_for_R_TRIG-->Parameter_Error: ResetIn AND TrailingMinimum > TrailingMaximum
#Wait_for_R_TRIG-->Wait_for_R_TRIG: ResetRequested
#Wait_for_R_TRIG-->Parameter_Error: TrailingMinimum < 100ms
#Wait_for_R_TRIG-->Parameter_Error: ResetIn AND TrailingMinimum < 100ms
#Wait_for_R_TRIG-->Wait_for_F_TRIG: ResetIn
#Reset_Error-->Wait_for_R_TRIG: NOT ResetIn
#Reset_Error-->Reset_Error: ResetIn AND ResetRequested
#Wait_for_F_TRIG-->Error_Trailing_Minimum: NOT ResetIn AND NOT TrailingMinimum Elapsed
#Wait_for_F_TRIG-->Error_Trailing_Maximum_1: TrailingMaximum Elapsed_1
#Wait_for_F_TRIG-->Reset_Detected: NOT ResetIn AND TrailingMinimum Elapsed
#Error_Trailing_Minimum-->Wait_for_F_TRIG: ResetIn
#Error_Trailing_Minimum-->Error_Trailing_Minimum: NOT ResetIn AND NOT TrailingMinimum Elapsed
#Error_Trailing_Maximum-->Error_Trailing_Maximum_1: TrailingMaximum Elapsed_1
#Error_Trailing_Maximum_1-->Wait_for_F_TRIG: ResetIn
#Reset_Detected-->Wait_for_R_TRIG: Next Cycle
#
#@enduml
#@begin generated
test logicals.safety.plcopen.SF_ResetButton_0
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#1s             T#350ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     FALSE    TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     FALSE    TRUE            T#1s             T#3s  16#C000    TRUE    TRUE    FALSE  doc=TrailingMinimum > TrailingMaximum->Parameter_Error
  Finish

test logicals.safety.plcopen.SF_ResetButton_1
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#1s             T#350ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     FALSE    TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     TRUE     TRUE            T#1s             T#3s  16#C000    TRUE    TRUE    FALSE  doc=ResetIn AND TrailingMinimum > TrailingMaximum->Parameter_Error
  Finish

test logicals.safety.plcopen.SF_ResetButton_2
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#1s             T#350ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     FALSE    TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     FALSE    TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Finish

test logicals.safety.plcopen.SF_ResetButton_3
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#1s             T#350ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     FALSE    TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     FALSE    TRUE            T#1s             T#10ms  16#C000    TRUE    TRUE    FALSE  doc=TrailingMinimum < 100ms->Parameter_Error
  Finish

test logicals.safety.plcopen.SF_ResetButton_4
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#1s             T#350ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     FALSE    TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     TRUE     TRUE            T#1s             T#10ms  16#C000    TRUE    TRUE    FALSE  doc=ResetIn AND TrailingMinimum < 100ms->Parameter_Error
  Finish

test logicals.safety.plcopen.SF_ResetButton_5
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#1s             T#350ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     FALSE    TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     TRUE     TRUE            T#1s             T#350ms  16#83F2    FALSE   TRUE    FALSE  doc=ResetIn->Wait_for_F_TRIG
  Data  3     FALSE    TRUE            T#1s             T#350ms  16#C3F0    TRUE    TRUE    FALSE  doc=NOT ResetIn AND NOT TrailingMinimum Elapsed->Error_Trailing_Minimum
  Data  4     TRUE     TRUE            T#1s             T#350ms  16#83F2    FALSE   TRUE    FALSE  doc=ResetIn->Wait_for_F_TRIG
  Finish

test logicals.safety.plcopen.SF_ResetButton_6
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#1s             T#350ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     FALSE    TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     TRUE     TRUE            T#1s             T#350ms  16#83F2    FALSE   TRUE    FALSE  doc=ResetIn->Wait_for_F_TRIG
  Data  3     FALSE    TRUE            T#1s             T#350ms  16#C3F0    TRUE    TRUE    FALSE  doc=NOT ResetIn AND NOT TrailingMinimum Elapsed->Error_Trailing_Minimum
  Data  4     FALSE    TRUE            T#1s             T#350ms  16#C3F0    TRUE    TRUE    FALSE  doc=NOT ResetIn AND NOT TrailingMinimum Elapsed->Error_Trailing_Minimum
  Finish

test logicals.safety.plcopen.SF_ResetButton_7
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#1s             T#350ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     FALSE    TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     TRUE     TRUE            T#1s             T#350ms  16#83F2    FALSE   TRUE    FALSE  doc=ResetIn->Wait_for_F_TRIG
  Data  102   FALSE    TRUE            T#1s             T#350ms  16#C3E0    TRUE    TRUE    FALSE  doc=TrailingMaximum Elapsed_1->Error_Trailing_Maximum_1
  Data  104   TRUE     TRUE            T#1s             T#350ms  16#83F2    FALSE   TRUE    FALSE  doc=ResetIn->Wait_for_F_TRIG
  Finish

test logicals.safety.plcopen.SF_ResetButton_8
  Head  Time  ResetIn  ResetRequested  TrailingMaximum  TrailingMinimum  DiagCode?  Error?  Ready?  ResetOut?  CycleTime=T#10ms
  Tol  /  /  /  /  /   0  0  0  0
  Shift  /  /  /  /  /   0  0  0  0
  Data  0     FALSE    FALSE           T#1s             T#350ms  16#0000    FALSE   FALSE   FALSE  doc=NOT ResetRequested->Idle
  Data  1     FALSE    TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=ResetRequested->Wait_for_R_TRIG
  Data  2     TRUE     TRUE            T#1s             T#350ms  16#83F2    FALSE   TRUE    FALSE  doc=ResetIn->Wait_for_F_TRIG
  Data  37    FALSE    TRUE            T#1s             T#350ms  16#8000    FALSE   TRUE    TRUE  doc=NOT ResetIn AND TrailingMinimum Elapsed->Reset_Detected
  Data  38     FALSE    TRUE            T#1s             T#350ms  16#83E2    FALSE   TRUE    FALSE  doc=Next Cycle->Wait_for_R_TRIG
  Finish

