*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_ESPE		MaxDataRows=100		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  Reset=FALSE
...  S_AutoReset=16#00
...  S_ESPE_In=16#00
...  S_StartReset=16#00
*** Test Cases ***
#
# Note: The SF_EmergencyStop uses the SFB_GenericSafetyDemand block.
#       Therefore only one test is needed that includes all IOs
#

test test_all_IOs
  Head  Time  Activate  Reset  S_AutoReset  S_ESPE_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_ESPE_Out?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE       FALSE       FALSE         16#0000   FALSE   FALSE   FALSE          FALSE        FALSE         doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE       FALSE       FALSE         16#8001   FALSE   TRUE    FALSE          FALSE        FALSE         doc=Activate->Init
  Data  2     TRUE      TRUE    FALSE       TRUE        FALSE         16#8802   FALSE   TRUE    FALSE          FALSE        TRUE          doc=NOT S_StartReset->Wait_for_EstopIn 1
  Data  3     TRUE      TRUE    FALSE       TRUE        FALSE         16#8402   FALSE   TRUE    FALSE          FALSE        FALSE         doc=S_EStopIn>Wait_for_Reset_1
  Data  4     TRUE      TRUE    TRUE        FALSE       FALSE         16#C001   TRUE    TRUE    FALSE          FALSE        FALSE         doc=NOT R_TRIG at Reset AND Reset AND S_AutoReset->Reset_Error_1
  Data  5     TRUE      FALSE   FALSE       TRUE        FALSE         16#8402   FALSE   TRUE    TRUE           FALSE        FALSE         doc=NOT Reset->Wait_for_Reset_1
  Data  6     TRUE      TRUE    FALSE       TRUE        TRUE          16#8000   FALSE   TRUE    FALSE          TRUE         FALSE         doc=Reset->Safety_Output_Enabled
  Finish
