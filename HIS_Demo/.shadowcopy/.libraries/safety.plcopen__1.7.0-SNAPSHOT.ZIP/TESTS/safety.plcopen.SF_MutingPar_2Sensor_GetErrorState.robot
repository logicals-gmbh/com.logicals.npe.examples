*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_MutingPar_2Sensor_GetErrorState	MaxDataRows=100		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  MS_11=FALSE
...  MS_12=FALSE
*** Test Cases ***

test ErrorStateOfMutingSensors
  Head  Time  MS_12  MS_11  SF_MutingPar_2Sensor_GetErrorState?
  Tol  /  /  /  0
  Shift  /  /  /  0
  Data  0  FALSE  FALSE     16#0000
  Data  1  FALSE  TRUE      16#0010
  Data  2  TRUE   FALSE     16#0020
  Data  3  TRUE   TRUE      16#0030
  Finish

