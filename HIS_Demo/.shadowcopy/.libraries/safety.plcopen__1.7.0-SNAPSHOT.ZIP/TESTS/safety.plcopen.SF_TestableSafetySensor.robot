*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_TestableSafetySensor         MaxDataRows=100         TestSuitePath=${SUITE SOURCE}
  Set Defaults          &{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  NoExternalTest=FALSE
...  Reset=FALSE
...  S_AutoReset=16#00
...  S_OSSD_In=16#00
...  S_StartReset=16#00
...  StartTest=FALSE
...  TestTime=0
*** Test Cases ***

test logicals.safety.plcopen.SF_TestableSafetySensor_Invalid_State
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  ENO?  CycleTime=T#10ms
  Tol    /    /         /               /      /            /          /             /          /         0          0       0       0              0            0           0              0              0              0
  Shift  /    /         /               /      /            /          /             /          /         0          0       0       0              0            0           0              0              0              0
  Init   /    /         /               /      /            /          /             /          /         16#9999    FALSE   FALSE   FALSE          FALSE        FALSE       FALSE          FALSE          FALSE          TRUE
  Data   0    TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#10ms    16#9999    TRUE    TRUE    FALSE          FALSE        FALSE       FALSE          FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data   1    TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#10ms    16#9999    TRUE    TRUE    FALSE          FALSE        FALSE       FALSE          FALSE          FALSE          FALSE  doc=Activate->Init
  Data   2    FALSE     FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#10ms    16#0000    FALSE   FALSE   FALSE          FALSE        TRUE        FALSE          FALSE          FALSE          TRUE   doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data   3    TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#10ms    16#8401    FALSE   TRUE    TRUE           FALSE        TRUE        FALSE          FALSE          FALSE          TRUE   doc=S_OSSD_In->Wait_for_Reset_1
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_Wait_for_Reset_1_TO_ESPE_Free_No_Test_Reset_RESET
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0        FALSE      FALSE              FALSE     FALSE         FALSE        FALSE                  FALSE        T#10ms  16#0000    FALSE    FALSE       FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=NOT Activate->Idle
  Data  1        TRUE       FALSE              FALSE     FALSE         FALSE        FALSE                  FALSE        T#10ms  16#8401    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=Activate->Init
  Data  2        TRUE       FALSE              FALSE     FALSE         FALSE        FALSE                  FALSE        T#10ms  16#8802    FALSE    TRUE        FALSE            FALSE        TRUE         TRUE             FALSE            FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3        TRUE       FALSE              FALSE     FALSE         TRUE         FALSE                  FALSE        T#10ms  16#8402    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  4        TRUE       FALSE              TRUE      FALSE         TRUE         FALSE                  FALSE        T#10ms  16#8010    FALSE    TRUE        FALSE            TRUE         TRUE         FALSE            FALSE            TRUE   doc=S_OSSD_In AND NOT R_TRIG at S_OSSD_In AND (R_TRIG at Reset OR S_AutoReset)->ESPE_Free_No_Test
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_Wait_for_Reset_1_TO_ESPE_Free_No_Test_S_AUTORESET
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0        FALSE      FALSE              FALSE     FALSE         FALSE        FALSE                  FALSE        T#10ms  16#0000    FALSE    FALSE       FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=NOT Activate->Idle
  Data  1        TRUE       FALSE              FALSE     FALSE         FALSE        FALSE                  FALSE        T#10ms  16#8401    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=Activate->Init
  Data  2        TRUE       FALSE              FALSE     FALSE         FALSE        FALSE                  FALSE        T#10ms  16#8802    FALSE    TRUE        FALSE            FALSE        TRUE         TRUE             FALSE            FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3        TRUE       FALSE              FALSE     FALSE         TRUE         FALSE                  FALSE        T#10ms  16#8402    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  4        TRUE       FALSE              FALSE     TRUE          TRUE         FALSE                  FALSE        T#10ms  16#8010    FALSE    TRUE        FALSE            TRUE         TRUE         FALSE            FALSE            TRUE   doc=S_OSSD_In AND NOT R_TRIG at S_OSSD_In AND (R_TRIG at Reset OR S_AutoReset)->ESPE_Free_No_Test
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_8401_8010_var1
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?     CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0    FALSE      FALSE          FALSE   FALSE        FALSE      FALSE         FALSE      T#10ms    16#0000    FALSE   FALSE   FALSE    FALSE    TRUE     FALSE    FALSE    FALSE      doc=NOT Activate->Idle
  Data  2    TRUE       FALSE          FALSE   FALSE        TRUE       FALSE         FALSE      T#10ms    16#8401    FALSE   TRUE    TRUE     FALSE    TRUE     FALSE    FALSE    FALSE      doc=Activate->Init
  Data  4    TRUE       FALSE          FALSE   FALSE        TRUE       TRUE          FALSE      T#10ms    16#8010    FALSE   TRUE    FALSE    TRUE     TRUE     FALSE    FALSE    TRUE       doc=S_OSSD_In AND NOT R_TRIG at S_OSSD_In AND (R_TRIG at Reset OR S_AutoReset)->ESPE_Free_No_Test (var 3)
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_8401_8010_var2
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?    CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#10ms    16#0000    FALSE   FALSE    FALSE    FALSE    TRUE     FALSE    FALSE    FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#10ms    16#8401    FALSE   TRUE     TRUE     FALSE    TRUE     FALSE    FALSE    FALSE      doc=Activate->Init
  Data  2     TRUE      FALSE           TRUE   TRUE         TRUE       FALSE         FALSE      T#10ms    16#8010    FALSE   TRUE     FALSE    TRUE     TRUE     FALSE    FALSE    TRUE       doc=S_OSSD_In AND NOT R_TRIG at S_OSSD_In AND (R_TRIG at Reset OR S_AutoReset)->ESPE_Free_No_Test (var 2)
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_8401_8010_var3
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?     CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0    FALSE      FALSE          FALSE   FALSE        FALSE      FALSE         FALSE      T#10ms    16#0000    FALSE   FALSE   FALSE    FALSE    TRUE     FALSE    FALSE    FALSE      doc=NOT Activate->Idle
  Data  2    TRUE       FALSE          FALSE   FALSE        TRUE       FALSE         FALSE      T#10ms    16#8401    FALSE   TRUE    TRUE     FALSE    TRUE     FALSE    FALSE    FALSE      doc=Activate->Init
  Data  4    TRUE       FALSE          TRUE    FALSE        TRUE       TRUE          FALSE      T#10ms    16#8010    FALSE   TRUE    FALSE    TRUE     TRUE     FALSE    FALSE    TRUE       doc=S_OSSD_In AND NOT R_TRIG at S_OSSD_In AND (R_TRIG at Reset OR S_AutoReset)->ESPE_Free_No_Test (var 3)
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_End_External_Test_TO_ESPE_Free_No_Test
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#19ms    16#0000    FALSE    FALSE  FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#19ms    16#8401    FALSE    TRUE   TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#19ms    16#8802    FALSE    TRUE   FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#19ms    16#8402    FALSE    TRUE   TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  4     TRUE      FALSE           TRUE   FALSE        TRUE       FALSE         FALSE      T#19ms    16#8010    FALSE    TRUE   FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND Reset->ESPE_Free_No_Test
  Data  5     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         TRUE       T#19ms    16#8020    FALSE    TRUE   FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=StartTest->Test_Request
  Data  7     TRUE      TRUE            FALSE  FALSE        TRUE       FALSE         FALSE      T#19ms    16#C410    TRUE     TRUE   TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer1 elapsed Test_Error_1->Test_Error_1
  Data  8     TRUE      FALSE           TRUE   FALSE        FALSE      FALSE         FALSE      T#19ms    16#8002    FALSE    TRUE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=Reset AND NOT NoExternalTest->External_Function_Test
  Data  9     TRUE      TRUE            TRUE   FALSE        TRUE       FALSE         FALSE      T#19ms    16#8002    FALSE    TRUE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=F_Trig at S_OSSD_In->ESPE_Interrupted_External_Test
  Data  10    TRUE      TRUE            TRUE   FALSE        FALSE      FALSE         TRUE       T#19ms    16#8804    FALSE    TRUE   FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=F_Trig at S_OSSD_In->ESPE_Interrupted_External_Test
  Data  11    TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#19ms    16#8404    FALSE    TRUE   TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->End_External_Test
  Data  12    TRUE      FALSE           TRUE   FALSE        TRUE       FALSE         FALSE      T#19ms    16#8010    FALSE    TRUE   FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=R_TRIG at Reset AND S_OSSD_In AND NOT R_TRIG at S_OSSD_In->ESPE_Free_No_Test
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_Test_Error_1_TO_ESPE_Free_No_Test
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE  FALSE        FALSE      FALSE          FALSE     T#11ms    16#0000    FALSE    FALSE       FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE          FALSE     T#11ms    16#8401    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE          FALSE     T#11ms    16#8802    FALSE    TRUE        FALSE            FALSE        TRUE         TRUE             FALSE            FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE          FALSE     T#11ms    16#8402    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  4     TRUE      FALSE           TRUE   FALSE        TRUE       FALSE          FALSE     T#11ms    16#8010    FALSE    TRUE        FALSE            TRUE         TRUE         FALSE            FALSE            TRUE   doc=S_OSSD_In AND Reset->ESPE_Free_No_Test
  Data  5     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE          TRUE      T#11ms    16#8020    FALSE    TRUE        FALSE            TRUE         FALSE        FALSE            FALSE            FALSE  doc=StartTest->Test_Request
  Data  7     TRUE      TRUE            FALSE  FALSE        TRUE       FALSE          FALSE     T#11ms    16#C410    TRUE     TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=Timer1 elapsed Test_Error_1->Test_Error_1
  Data  8     TRUE      TRUE            TRUE   FALSE        TRUE       FALSE          FALSE     T#11ms    16#8010    FALSE    TRUE        FALSE            TRUE         TRUE         FALSE            FALSE            TRUE   doc=S_OSSD_In AND NOT R_TRIG at S_OSSD_In AND R_TRIG at Reset AND NoExternalTest->ESPE_Free_No_Test
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_Test_Error_2_TO_ESPE_Free_No_Test
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#11ms    16#0000    FALSE    FALSE       FALSE     FALSE        TRUE        FALSE            FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#11ms    16#8401    FALSE    TRUE        TRUE      FALSE        TRUE        FALSE            FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#11ms    16#8802    FALSE    TRUE        FALSE     FALSE        TRUE        TRUE             FALSE            FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#11ms    16#8402    FALSE    TRUE        TRUE      FALSE        TRUE        FALSE            FALSE            FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  4     TRUE      FALSE           FALSE  TRUE         TRUE       FALSE         FALSE      T#11ms    16#8010    FALSE    TRUE        FALSE     TRUE         TRUE        FALSE            FALSE            TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5     TRUE      TRUE            TRUE   FALSE        TRUE       FALSE         FALSE      T#11ms    16#8010    FALSE    TRUE        FALSE     TRUE         TRUE        FALSE            FALSE            TRUE   doc=R_TRIG at StartTest->Test_Request
  Data  6     TRUE      TRUE            TRUE   FALSE        TRUE       FALSE         TRUE       T#11ms    16#8020    FALSE    TRUE        FALSE     TRUE         FALSE       FALSE            FALSE            FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  7     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#11ms    16#8030    FALSE    TRUE        FALSE     TRUE         TRUE        FALSE            FALSE            FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  9     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#11ms    16#C010    TRUE     TRUE        FALSE     FALSE        TRUE        FALSE            FALSE            FALSE  doc=Timer2 elapsed Test_Error_2->Test_Error_2
  Data  10    TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#11ms    16#C010    TRUE     TRUE        FALSE     FALSE        TRUE        FALSE            FALSE            FALSE  doc=S_OSSD_In
  Data  11    TRUE      TRUE            TRUE   FALSE        TRUE       FALSE         FALSE      T#11ms    16#8010    FALSE    TRUE        FALSE     TRUE         TRUE        FALSE            FALSE            TRUE   doc=S_OSSD_In AND NOT R_TRIG at S_OSSD_In AND R_TRIG at Reset AND NoExternalTest->ESPE_Free_No_Test
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_Reset_Error_1
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0        FALSE      FALSE       FALSE  FALSE        FALSE      FALSE         FALSE      T#10ms  16#0000    FALSE    FALSE       FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=NOT Activate->Idle
  Data  1        TRUE       FALSE       TRUE   FALSE        TRUE       FALSE         FALSE      T#10ms  16#8401    FALSE    TRUE        FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=Activate->Init
  Data  2        TRUE       FALSE       TRUE   FALSE        TRUE       TRUE          FALSE      T#10ms  16#C001    TRUE     TRUE        FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=PRIORITY_CHECK_8010->Reset_Error_1 (4: prio 2 over 4)
  Data  3        TRUE       FALSE       TRUE   FALSE        FALSE      FALSE         FALSE      T#10ms  16#C001    TRUE     TRUE        FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  4        TRUE       FALSE       FALSE  FALSE        FALSE      FALSE         FALSE      T#10ms  16#8401    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=NOT Reset->Init
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_Reset_Error_2
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0        FALSE      FALSE       FALSE     FALSE     FALSE       FALSE         FALSE      T#10ms  16#0000    FALSE    FALSE       FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=NOT Activate->Idle
  Data  1        TRUE       FALSE       FALSE     FALSE     FALSE       FALSE         FALSE      T#10ms  16#8401    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=Activate->Init
  Data  2        TRUE       FALSE       FALSE     FALSE     FALSE       FALSE         FALSE      T#10ms  16#8802    FALSE    TRUE        FALSE            FALSE        TRUE         TRUE             FALSE            FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3        TRUE       FALSE       TRUE      FALSE     TRUE        FALSE         FALSE      T#10ms  16#8402    FALSE    TRUE        FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  4        TRUE       FALSE       TRUE      TRUE      TRUE        FALSE         FALSE      T#10ms  16#C011    TRUE     TRUE        FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=PRIORITY_CHECK_8010->Reset_Error_2 (prio 1 over 3)
  Data  5        TRUE       FALSE       TRUE      FALSE     TRUE        FALSE         FALSE      T#10ms  16#C011    TRUE     TRUE        FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_2
  Data  6        TRUE       FALSE       FALSE     FALSE     TRUE        FALSE         FALSE      T#10ms  16#8402    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=NOT Reset->Wait_for_Reset_1
  Finish

# This test covers that ResetRequest is NOT Reset in C410 
test logicals.safety.plcopen.SF_TestableSafetySensor_Reset_Error_3_1
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#20ms    16#0000    FALSE   FALSE   FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#20ms    16#8401    FALSE   TRUE    TRUE           FALSE        TRUE        FALSE          FALSE          FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#20ms    16#8802    FALSE   TRUE    FALSE          FALSE        TRUE        TRUE           FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#20ms    16#8402    FALSE   TRUE    TRUE           FALSE        TRUE        FALSE          FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  4     TRUE      FALSE           TRUE   FALSE        TRUE       FALSE         FALSE      T#20ms    16#8010    FALSE   TRUE    FALSE          TRUE         TRUE        FALSE          FALSE          TRUE   doc=S_OSSD_In AND Reset->ESPE_Free_No_Test
  Data  5     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         TRUE       T#20ms    16#8020    FALSE   TRUE    FALSE          TRUE         FALSE       FALSE          FALSE          FALSE  doc=StartTest->Test_Request
  Data  7     TRUE      TRUE            TRUE   FALSE        TRUE       FALSE         FALSE      T#20ms    16#C410    TRUE    TRUE    FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=Timer1 elapsed Test_Error_1->Test_Error_1
  Data  8     TRUE      TRUE            TRUE   FALSE        TRUE       FALSE         FALSE      T#20ms    16#C021    TRUE    TRUE    FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_3
  Data  9     TRUE      TRUE            TRUE   FALSE        TRUE       FALSE         FALSE      T#20ms    16#C021    TRUE    TRUE    FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_3
  Data  10    TRUE      TRUE            FALSE  FALSE        TRUE       FALSE         FALSE      T#20ms    16#C410    TRUE    TRUE    TRUE           FALSE        TRUE        FALSE          FALSE          FALSE  doc=NOT Reset->Test_Error_1
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_Reset_Error_3_2a
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE  FALSE        FALSE      FALSE          FALSE     T#15ms     16#0000    FALSE  FALSE   FALSE          FALSE        TRUE         FALSE            FALSE            FALSE       doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE          FALSE     T#15ms     16#8401    FALSE  TRUE    TRUE           FALSE        TRUE         FALSE            FALSE            FALSE       doc=Activate->Init
  Data  2     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE          FALSE     T#15ms     16#8802    FALSE  TRUE    FALSE          FALSE        TRUE         TRUE             FALSE            FALSE       doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE          FALSE     T#15ms     16#8402    FALSE  TRUE    TRUE           FALSE        TRUE         FALSE            FALSE            FALSE       doc=S_OSSD_In->Wait_for_Reset_1
  Data  4     TRUE      FALSE           TRUE   FALSE        TRUE       FALSE          FALSE     T#15ms     16#8010    FALSE  TRUE    FALSE          TRUE         TRUE         FALSE            FALSE            TRUE        doc=S_OSSD_In AND Reset->ESPE_Free_No_Test
  Data  5     TRUE      FALSE           TRUE   FALSE        TRUE       FALSE          TRUE      T#15ms     16#8020    FALSE  TRUE    FALSE          TRUE         FALSE        FALSE            FALSE            FALSE       doc=StartTest->Test_Request
  Data  7     TRUE      FALSE           TRUE   FALSE        FALSE      FALSE          FALSE     T#15ms     16#C010    TRUE   TRUE    FALSE          FALSE        TRUE         FALSE            FALSE            FALSE       doc=Timer1 elapsed AND NOT S_OSSD_In->Test_Error_2 (3: prio 1 over 2)
  Data  8     TRUE      FALSE           TRUE   FALSE        FALSE      FALSE          FALSE     T#15ms     16#C021    TRUE   TRUE    FALSE          FALSE        TRUE         FALSE            FALSE            FALSE       doc=Reset AND NOT R_TRIG at Reset->Reset_Error_3
  Data  9     TRUE      FALSE           TRUE   FALSE        FALSE      FALSE          FALSE     T#15ms     16#C021    TRUE   TRUE    FALSE          FALSE        TRUE         FALSE            FALSE            FALSE       doc=Reset AND NOT R_TRIG at Reset->Reset_Error_3
  Data  10    TRUE      FALSE           FALSE  FALSE        FALSE      FALSE          FALSE     T#15ms     16#C010    TRUE   TRUE    FALSE          FALSE        TRUE         FALSE            FALSE            FALSE       doc=NOT Reset->Test_Error_2
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_Reset_Error_3_2b
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#19ms  16#0000    FALSE    FALSE       FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#19ms  16#8401    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#19ms  16#8802    FALSE    TRUE        FALSE            FALSE        TRUE         TRUE             FALSE            FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#19ms  16#8402    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  4     TRUE      FALSE           TRUE   FALSE        TRUE       FALSE         FALSE      T#19ms  16#8010    FALSE    TRUE        FALSE            TRUE         TRUE         FALSE            FALSE            TRUE   doc=S_OSSD_In AND Reset->ESPE_Free_No_Test
  Data  5     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         TRUE       T#19ms  16#8020    FALSE    TRUE        FALSE            TRUE         FALSE        FALSE            FALSE            FALSE  doc=StartTest->Test_Request
  Data  7     TRUE      TRUE            TRUE   FALSE        FALSE      FALSE         FALSE      T#19ms  16#C010    TRUE     TRUE        FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=Timer1 elapsed Test_Error_1->Test_Error_1 (4: prio 1 over 2)
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_Reset_Error_4
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE   FALSE       FALSE      FALSE         FALSE      T#20ms    16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE          FALSE         FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE   FALSE       FALSE      FALSE         FALSE      T#20ms    16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE          FALSE         FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE           FALSE   FALSE       FALSE      FALSE         FALSE      T#20ms    16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE           FALSE         FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3     TRUE      FALSE           FALSE   FALSE       TRUE       FALSE         FALSE      T#20ms    16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE          FALSE         FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  4     TRUE      FALSE           TRUE    FALSE       TRUE       FALSE         FALSE      T#20ms    16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE          FALSE         TRUE   doc=S_OSSD_In AND Reset->ESPE_Free_No_Test
  Data  5     TRUE      FALSE           FALSE   FALSE       TRUE       FALSE         TRUE       T#20ms    16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE          FALSE         FALSE  doc=StartTest->Test_Request
  Data  7     TRUE      TRUE            FALSE   FALSE       TRUE       FALSE         FALSE      T#20ms    16#C410    TRUE    TRUE    TRUE           FALSE        TRUE         FALSE          FALSE         FALSE  doc=Timer1 elapsed Test_Error_1->Test_Error_1
  Data  8     TRUE      FALSE           TRUE    FALSE       FALSE      FALSE         FALSE      T#20ms    16#8002    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE          FALSE         FALSE  doc=Reset AND NOT NoExternalTest->External_Function_Test
  Data  9     TRUE      TRUE            TRUE    FALSE       TRUE       FALSE         FALSE      T#20ms    16#8002    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE          FALSE         FALSE  doc=F_Trig at S_OSSD_In->ESPE_Interrupted_External_Test
  Data  10    TRUE      TRUE            TRUE    FALSE       FALSE      FALSE         TRUE       T#20ms    16#8804    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE           FALSE         FALSE  doc=F_Trig at S_OSSD_In->ESPE_Interrupted_External_Test
  Data  11    TRUE      FALSE           TRUE    FALSE       TRUE       FALSE         FALSE      T#20ms    16#8404    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE          FALSE         FALSE  doc=S_OSSD_In->End_External_Test
  Data  12    TRUE      FALSE           TRUE    FALSE       TRUE       FALSE         FALSE      T#20ms    16#C031    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE          FALSE         FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_4
  Data  13    TRUE      FALSE           TRUE    FALSE       TRUE       FALSE         FALSE      T#20ms    16#C031    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE          FALSE         FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_4
  Data  14    TRUE      FALSE           FALSE   FALSE       TRUE       FALSE         FALSE      T#20ms    16#8404    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE          FALSE         FALSE  doc=NOT Reset->End_External_Test
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_Reset_Error_5
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0        FALSE  FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#10ms    16#0000     FALSE    FALSE       FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=NOT Activate->Idle
  Data  1        TRUE   FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#10ms    16#8401     FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=Activate->Init
  Data  2        TRUE   FALSE           TRUE   FALSE        TRUE       FALSE         FALSE      T#160ms   16#C000     TRUE     TRUE        FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=COMBO_CHECK_8010_A TestTime > 150ms->Parameter_Error (11: prio 1 over 4)
  Data  3        TRUE   FALSE           TRUE   FALSE        FALSE      FALSE         FALSE      T#160ms   16#C041     TRUE     TRUE        FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_5
  Data  4        TRUE   FALSE           TRUE   FALSE        FALSE      FALSE         FALSE      T#160ms   16#C041     TRUE     TRUE        FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_5
  Data  5        TRUE   FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#160ms   16#C000     TRUE     TRUE        FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=NOT Reset->Parameter_Error
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_Reset_Error_6
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#15ms    16#0000    FALSE    FALSE       FALSE            FALSE        TRUE         FALSE            FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#15ms    16#8401    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#15ms    16#8802    FALSE    TRUE        FALSE            FALSE        TRUE         TRUE             FALSE            FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#15ms    16#8402    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            FALSE            FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  4     TRUE      FALSE           FALSE  TRUE         TRUE       FALSE         FALSE      T#15ms    16#8010    FALSE    TRUE        FALSE            TRUE         TRUE         FALSE            FALSE            TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5     TRUE      TRUE            TRUE   FALSE        TRUE       FALSE         FALSE      T#15ms    16#8010    FALSE    TRUE        FALSE            TRUE         TRUE         FALSE            FALSE            TRUE   doc=R_TRIG at StartTest->Test_Request
  Data  6     TRUE      TRUE            TRUE   FALSE        TRUE       FALSE         TRUE       T#15ms    16#8020    FALSE    TRUE        FALSE            TRUE         FALSE        FALSE            FALSE            FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  7     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#15ms    16#8030    FALSE    TRUE        FALSE            TRUE         TRUE         FALSE            FALSE            FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  8     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#15ms    16#8000    FALSE    TRUE        FALSE            TRUE         TRUE         FALSE            TRUE             TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok
  Data  9     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         TRUE       T#15ms    16#8806    FALSE    TRUE        FALSE            FALSE        TRUE         TRUE             TRUE             FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_2 (prio 1 over 2)
  Data  10    TRUE      FALSE           TRUE   FALSE        TRUE       FALSE         FALSE      T#15ms    16#8406    FALSE    TRUE        FALSE            FALSE        TRUE         FALSE            TRUE             FALSE  doc=S_OSSD_In->Wait_for_Reset_2
  Data  11    TRUE      FALSE           TRUE   TRUE         TRUE       FALSE         FALSE      T#15ms    16#C051    TRUE     TRUE        FALSE            FALSE        TRUE         FALSE            TRUE             FALSE  doc=PRIORITY_CHECK_8000_Reset AND NOT R_TRIG at Reset->Reset_Error_6 (prio 1 over 3)
  Data  12    TRUE      FALSE           TRUE   FALSE        TRUE       FALSE         FALSE      T#15ms    16#C051    TRUE     TRUE        FALSE            FALSE        TRUE         FALSE            TRUE             FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_6
  Data  13    TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#15ms    16#8406    FALSE    TRUE        TRUE             FALSE        TRUE         FALSE            TRUE             FALSE  doc=NOT Reset->Wait_for_Reset_2
  Data  14    TRUE      FALSE           TRUE   TRUE         TRUE       FALSE         FALSE      T#15ms    16#8000    FALSE    TRUE        FALSE            TRUE         TRUE         FALSE            TRUE             TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok (var 3)
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_8401_prio_1_over_4
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#10ms    16#0000    FALSE   FALSE   FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#10ms    16#8401    FALSE   TRUE    TRUE           FALSE        TRUE        FALSE          FALSE          FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE           FALSE  FALSE        TRUE       TRUE          FALSE      T#160ms   16#C000    TRUE    TRUE    FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=COMBO_CHECK_8010_B TestTime > 150ms AND NOT Reset->Parameter_Error (7: prio 1 over 4)
  Data  3     TRUE      FALSE           TRUE   FALSE        TRUE       FALSE         FALSE      T#10ms    16#8401    FALSE   TRUE    FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=Activate->Init
  Data  4     TRUE      FALSE           TRUE   FALSE        TRUE       TRUE          TRUE       T#-1ms    16#C000    TRUE    TRUE    FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=TestTime > 150ms->Parameter_Error (10: prio 2 over 4)
  Data  5     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         TRUE       T#10ms    16#C000    TRUE    TRUE    FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=set Reset to FALSE
  Data  6     TRUE      FALSE           TRUE   FALSE        TRUE       FALSE         FALSE      T#10ms    16#8401    FALSE   TRUE    FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=Activate->Init
  Data  7     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#10ms    16#8401    FALSE   TRUE    TRUE           FALSE        TRUE        FALSE          FALSE          FALSE  doc=set Reset to FALSE
  Data  8     TRUE      FALSE           TRUE   FALSE        TRUE       FALSE         FALSE      T#151ms   16#C000    TRUE    TRUE    FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=TestTime > 150ms->Parameter_Error (11: prio 2 over 4)
  Data  9     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         TRUE       T#10ms    16#C000    TRUE    TRUE    FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=set Reset to FALSE
  Data  10    TRUE      FALSE           TRUE   FALSE        TRUE       FALSE         FALSE      T#10ms    16#8401    FALSE   TRUE    FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=R_TRIG at Reset
  Data  11    TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#10ms    16#8401    FALSE   TRUE    TRUE           FALSE        TRUE        FALSE          FALSE          FALSE  doc=set Reset to FALSE
  Data  12    TRUE      FALSE           TRUE   FALSE        TRUE       TRUE          FALSE      T#-10ms   16#C000    TRUE    TRUE    FALSE          FALSE        TRUE        FALSE          FALSE          FALSE  doc=TestTime > 150ms->Parameter_Error (12: prio 2 over 4)
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_8402_8010_variants
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#11ms    16#0000    FALSE    FALSE       FALSE     FALSE        TRUE        FALSE            FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#11ms    16#8401    FALSE    TRUE        TRUE      FALSE        TRUE        FALSE            FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#150ms   16#8802    FALSE    TRUE        FALSE     FALSE        TRUE        TRUE             FALSE            FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#11ms    16#8402    FALSE    TRUE        TRUE      FALSE        TRUE        FALSE            FALSE            FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  4     TRUE      FALSE           TRUE   TRUE         TRUE       FALSE         FALSE      T#11ms    16#8010    FALSE    TRUE        FALSE     TRUE         TRUE        FALSE            FALSE            TRUE   doc=Variant 3
  Data  5     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#0ms     16#8802    FALSE    TRUE        FALSE     FALSE        TRUE        TRUE             FALSE            FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  6     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#11ms    16#8402    FALSE    TRUE        TRUE      FALSE        TRUE        FALSE            FALSE            FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  7     TRUE      FALSE           TRUE   FALSE        TRUE       FALSE         FALSE      T#11ms    16#8010    FALSE    TRUE        FALSE     TRUE         TRUE        FALSE            FALSE            TRUE   doc=Variant 2
  Data  8     TRUE      FALSE           FALSE  FALSE        FALSE      FALSE         TRUE       T#11ms    16#8802    FALSE    TRUE        FALSE     FALSE        TRUE        TRUE             FALSE            FALSE  doc=8010->8802 (Prio 1 over 2)
  Data  9     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#11ms    16#8402    FALSE    TRUE        TRUE      FALSE        TRUE        FALSE            FALSE            FALSE  doc=S_OSSD_In->Wait_for_Reset_1
  Data  10    TRUE      FALSE           FALSE  TRUE         TRUE       FALSE         FALSE      T#11ms    16#8010    FALSE    TRUE        FALSE     TRUE         TRUE        FALSE            FALSE            TRUE   doc=Variant 2
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_C410_C010_C410
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE  FALSE        FALSE      FALSE         FALSE      T#20ms    16#0000    FALSE    FALSE       FALSE     FALSE        TRUE        FALSE            FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE  FALSE        TRUE       FALSE         FALSE      T#20ms    16#8401    FALSE    TRUE        TRUE      FALSE        TRUE        FALSE            FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE           TRUE   TRUE         TRUE       FALSE         FALSE      T#20ms    16#8010    FALSE    TRUE        FALSE     TRUE         TRUE        FALSE            FALSE            TRUE   doc=S_OSSD_In AND NOT R_TRIG at S_OSSD_In AND (R_TRIG at Reset OR S_AutoReset)->ESPE_Free_No_Test (var 2)
  Data  3     TRUE      TRUE            TRUE   FALSE        TRUE       FALSE         TRUE       T#20ms    16#8020    FALSE    TRUE        FALSE     TRUE         FALSE       FALSE            FALSE            FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  5     TRUE      TRUE            FALSE  FALSE        TRUE       FALSE         FALSE      T#20ms    16#C410    TRUE     TRUE        TRUE      FALSE        TRUE        FALSE            FALSE            FALSE  doc=Timer1 elapsed AND S_OSSD_In AND NoExternalTest->Test_Error_1
  Data  6     TRUE      TRUE            FALSE  FALSE        FALSE      FALSE         FALSE      T#20ms    16#C010    TRUE     TRUE        FALSE     FALSE        TRUE        FALSE            FALSE            FALSE  doc=NOT S_OSSD_In->Test_Error_2
  Data  7     TRUE      TRUE            FALSE  FALSE        TRUE       FALSE         FALSE      T#20ms    16#C410    TRUE     TRUE        TRUE      FALSE        TRUE        FALSE            FALSE            FALSE  doc=S_OSSD_In->Test_Error_1
  Finish

#                                   DiagCode?  Error?   Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut    SafetyDemand? TestExecuted?  TestPossible? CycleTime=T#10ms
#@startuml
#Idle:                               16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE
#Init_Reset_False:                   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE
#Init_Reset_True:                    16#8401    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE
#ESPE_Interrupted_1:                 16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE
#Wait_for_Reset_1_Reset_False:       16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE
#Wait_for_Reset_1_Reset_True:        16#8402    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE
#External_Function_Test:             16#8002    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE
#ESPE_Interrupted_External_Test:     16#8804    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE
#End_External_Test_Reset_False:      16#8404    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE
#End_External_Test_Reset_True:       16#8404    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE
#ESPE_Free_No_Test:                  16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE 
#ESPE_Interrupted_2:                 16#8806    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          TRUE           FALSE
#Wait_for_Reset_2_Reset_False:       16#8406    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         TRUE           FALSE
#Wait_for_Reset_2_Reset_True:        16#8406    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         TRUE           FALSE
#Test_Request:                       16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE
#Test_Active:                        16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE
#ESPE_Free_Test_ok:                  16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE 
#Parameter_Error:                    16#C000    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE
#Test_Error_1:                       16#C410    TRUE    TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE
#Test_Error_2:                       16#C010    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE
#T:                                             Time     Activate   NoExternalTest Reset S_AutoReset S_OSSD_In   S_StartReset   StartTest    TestTime
#T: NOT Activate:                                1        FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms 
#T: Activate:                                    1        TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms 
#T: Activate+Reset:                              1        TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#10ms 
#T: TestTime > 150ms:                            1        TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#160ms
#T: R_TRIG at Reset AND TestTime <= 150ms:       1        TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#100ms
#T: R_TRIG at Reset AND NOT S_OSSD_In:           1        TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#10ms 
#T: NOT S_OSSD_In:                               1        TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms 
#T: NOT S_OSSD_In AND R_TRIG at StartTest:       1        TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    TRUE        T#10ms 
#T: S_OSSD_In:                                   1        TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms 
#T: StartTest:                                   1        TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    TRUE        T#10ms 
#T: Timer1 elapsed Test_Error_1:                 2        TRUE       TRUE        FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms 
#T: Timer1 elapsed Test_Error_2:                 2        TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms 
#T: Timer1 elapsed Test_Error_2_2:               2        TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms 
#T: Timer2 elapsed Test_Error_1:                 2        TRUE       TRUE        FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms 
#T: Timer2 elapsed Test_Error_1 AND Reset:       2        TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms 
#T: Timer2 elapsed Test_Error_2:                 2        TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms 
#T: Timer2 elapsed Test_Error_2_2:               2        TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms 
#T: StartReset:                                  1        TRUE       FALSE       FALSE   FALSE       FALSE           TRUE     FALSE       T#10ms 
#T: R_TRIG at Reset AND NOT NoExternalTest:      1        TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms 
#T: S_OSSD_In AND R_TRIG at Reset:               1        TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms 
#T: S_OSSD_In AND S_AutoReset:                   1        TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms 
#T: R_TRIG at StartTest:                         1        TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms 
#T: F_TRIG at S_OSSD_In:                         1        TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#10ms 
#T: Invalid Test Time:                           1        TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#-10ms
#
#[*]-->Idle:NOT Activate
#Idle-->Init_Reset_False: Activate
#Idle-->Init_Reset_True: Activate+Reset
#Init_Reset_False-->Parameter_Error: TestTime > 150ms
#Init_Reset_False-->Parameter_Error: Invalid Test Time
#Init_Reset_False-->ESPE_Interrupted_1: NOT S_OSSD_In
#Init_Reset_True-->Parameter_Error: TestTime > 150ms
#Init_Reset_True-->Parameter_Error: Invalid Test Time
#Init_Reset_True-->ESPE_Interrupted_1: NOT S_OSSD_In
#Parameter_Error-->Init_Reset_True: R_TRIG at Reset AND TestTime <= 150ms
#Parameter_Error-->Parameter_Error: TestTime > 150ms
#ESPE_Interrupted_1-->ESPE_Interrupted_1: NOT S_OSSD_In
#ESPE_Interrupted_1-->Wait_for_Reset_1_Reset_False: S_OSSD_In
#ESPE_Interrupted_1-->Wait_for_Reset_1_Reset_True: S_OSSD_In AND R_TRIG at Reset
#Wait_for_Reset_1_Reset_False-->ESPE_Interrupted_1: NOT S_OSSD_In
#Wait_for_Reset_1_Reset_False-->ESPE_Free_No_Test: S_OSSD_In AND S_AutoReset
#Wait_for_Reset_1_Reset_False-->Wait_for_Reset_1_Reset_False: S_OSSD_In
#Wait_for_Reset_1_Reset_True-->ESPE_Interrupted_1: NOT S_OSSD_In
#Wait_for_Reset_1_Reset_True-->ESPE_Free_No_Test: S_OSSD_In AND S_AutoReset
#Wait_for_Reset_1_Reset_True-->Wait_for_Reset_1_Reset_False: S_OSSD_In
#ESPE_Free_No_Test-->ESPE_Interrupted_1: NOT S_OSSD_In
#ESPE_Free_No_Test-->ESPE_Interrupted_1: NOT S_OSSD_In AND R_TRIG at StartTest
#ESPE_Free_No_Test-->Test_Request: R_TRIG at StartTest
#ESPE_Free_No_Test-->ESPE_Free_No_Test: S_OSSD_In AND S_AutoReset
#Test_Request-->Test_Error_1: Timer1 elapsed Test_Error_1
#Test_Request-->Test_Error_2: Timer1 elapsed Test_Error_2
#Test_Request-->Test_Error_2: Timer1 elapsed Test_Error_2_2
#Test_Request-->Test_Active: NOT S_OSSD_In
#Test_Active-->Test_Error_1: Timer2 elapsed Test_Error_1
#Test_Active-->Test_Error_2: Timer2 elapsed Test_Error_2
#Test_Active-->Test_Error_2: Timer2 elapsed Test_Error_2_2
#Test_Active-->ESPE_Free_Test_ok: S_OSSD_In
#Test_Error_1-->External_Function_Test: R_TRIG at Reset AND NOT NoExternalTest
#Test_Error_1-->Test_Error_1: Timer1 elapsed Test_Error_1
#Test_Error_2-->External_Function_Test: R_TRIG at Reset AND NOT NoExternalTest
#External_Function_Test-->ESPE_Interrupted_External_Test: F_TRIG at S_OSSD_In
#External_Function_Test-->External_Function_Test: R_TRIG at Reset AND NOT NoExternalTest
#ESPE_Interrupted_External_Test-->ESPE_Interrupted_External_Test: F_TRIG at S_OSSD_In
#ESPE_Interrupted_External_Test-->End_External_Test_Reset_False: S_OSSD_In
#End_External_Test_Reset_False-->ESPE_Interrupted_1: R_TRIG at Reset AND NOT S_OSSD_In
#End_External_Test_Reset_False-->End_External_Test_Reset_False: S_OSSD_In
#ESPE_Interrupted_External_Test-->End_External_Test_Reset_True: S_OSSD_In AND R_TRIG at Reset
#ESPE_Free_Test_ok-->ESPE_Interrupted_2: NOT S_OSSD_In
#ESPE_Free_Test_ok-->Test_Request: R_TRIG at StartTest
#ESPE_Free_Test_ok-->ESPE_Free_Test_ok: S_OSSD_In
#ESPE_Interrupted_2-->ESPE_Interrupted_2: NOT S_OSSD_In
#ESPE_Interrupted_2-->Wait_for_Reset_2_Reset_False: S_OSSD_In
#Wait_for_Reset_2_Reset_False-->ESPE_Interrupted_2: NOT S_OSSD_In
#Wait_for_Reset_2_Reset_False-->ESPE_Free_Test_ok: S_OSSD_In AND R_TRIG at Reset
#Wait_for_Reset_2_Reset_False-->ESPE_Free_Test_ok: S_OSSD_In AND S_AutoReset
#Wait_for_Reset_2_Reset_False-->Wait_for_Reset_2_Reset_False: S_OSSD_In
#ESPE_Interrupted_2-->Wait_for_Reset_2_Reset_True: S_OSSD_In AND R_TRIG at Reset
#Wait_for_Reset_2_Reset_True-->ESPE_Interrupted_2: NOT S_OSSD_In
#Wait_for_Reset_2_Reset_True-->ESPE_Free_Test_ok: S_OSSD_In AND S_AutoReset
#Wait_for_Reset_2_Reset_True-->Wait_for_Reset_2_Reset_False: S_OSSD_In
#@enduml
#@begin generated
test logicals.safety.plcopen.SF_TestableSafetySensor_0
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#-10ms  16#C000    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=Invalid Test Time->Parameter_Error
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_1
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate+Reset->Init_Reset_True
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#160ms  16#C000    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=TestTime > 150ms->Parameter_Error
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_2
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate+Reset->Init_Reset_True
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#-10ms  16#C000    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=Invalid Test Time->Parameter_Error
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_3
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate+Reset->Init_Reset_True
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_4
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#160ms  16#C000    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=TestTime > 150ms->Parameter_Error
  Data  3          TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#100ms  16#8401    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=R_TRIG at Reset AND TestTime <= 150ms->Init_Reset_True
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_5
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#160ms  16#C000    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=TestTime > 150ms->Parameter_Error
  Data  3          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#160ms  16#C000    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=TestTime > 150ms->Parameter_Error
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_6
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_7
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_8
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_9
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In AND R_TRIG at Reset->Wait_for_Reset_1_Reset_True
  Data  4          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_10
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In AND R_TRIG at Reset->Wait_for_Reset_1_Reset_True
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_11
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In AND R_TRIG at Reset->Wait_for_Reset_1_Reset_True
  Data  4          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_12
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_13
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    TRUE        T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In AND R_TRIG at StartTest->ESPE_Interrupted_1
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_14
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_15
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  7          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#C010    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer1 elapsed Test_Error_2_2->Test_Error_2
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_16
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  7          TRUE       TRUE        FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#C410    TRUE    TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer1 elapsed Test_Error_1->Test_Error_1
  Data  9          TRUE       TRUE        FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#C410    TRUE    TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer1 elapsed Test_Error_1->Test_Error_1
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_17
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  7          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#C010    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer1 elapsed Test_Error_2->Test_Error_2
  Data  8          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8002    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=R_TRIG at Reset AND NOT NoExternalTest->External_Function_Test
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_18
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  8          TRUE       TRUE        FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#C410    TRUE    TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer2 elapsed Test_Error_1->Test_Error_1
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_19
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  8          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#C010    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer2 elapsed Test_Error_2->Test_Error_2
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_20
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  8          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#C010    TRUE    TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer2 elapsed Test_Error_2_2->Test_Error_2
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_21
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  7          TRUE       TRUE        FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#C410    TRUE    TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer1 elapsed Test_Error_1->Test_Error_1
  Data  8          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8002    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=R_TRIG at Reset AND NOT NoExternalTest->External_Function_Test
  Data  9          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8002    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=R_TRIG at Reset AND NOT NoExternalTest->External_Function_Test
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_22
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  7          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok
  Data  8          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_23
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  7          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok
  Data  8          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_24
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  7          TRUE       TRUE        FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#C410    TRUE    TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer1 elapsed Test_Error_1->Test_Error_1
  Data  8          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8002    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=R_TRIG at Reset AND NOT NoExternalTest->External_Function_Test
  Data  9          TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#10ms   16#8804    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=F_TRIG at S_OSSD_In->ESPE_Interrupted_External_Test
  Data  10         TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#10ms   16#8804    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=F_TRIG at S_OSSD_In->ESPE_Interrupted_External_Test
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_25
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  7          TRUE       TRUE        FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#C410    TRUE    TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer1 elapsed Test_Error_1->Test_Error_1
  Data  8          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8002    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=R_TRIG at Reset AND NOT NoExternalTest->External_Function_Test
  Data  9          TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#10ms   16#8804    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=F_TRIG at S_OSSD_In->ESPE_Interrupted_External_Test
  Data  10         TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8404    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In AND R_TRIG at Reset->End_External_Test_Reset_True
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_26
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  7          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok
  Data  8          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8806    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          TRUE           FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_2
  Data  9          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8806    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          TRUE           FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_2
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_27
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  7          TRUE       TRUE        FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#C410    TRUE    TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer1 elapsed Test_Error_1->Test_Error_1
  Data  8          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8002    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=R_TRIG at Reset AND NOT NoExternalTest->External_Function_Test
  Data  9          TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#10ms   16#8804    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=F_TRIG at S_OSSD_In->ESPE_Interrupted_External_Test
  Data  10         TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8404    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->End_External_Test_Reset_False
  Data  11         TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=R_TRIG at Reset AND NOT S_OSSD_In->ESPE_Interrupted_1
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_28
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  7          TRUE       TRUE        FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#C410    TRUE    TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Timer1 elapsed Test_Error_1->Test_Error_1
  Data  8          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8002    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=R_TRIG at Reset AND NOT NoExternalTest->External_Function_Test
  Data  9          TRUE       FALSE       TRUE    FALSE       FALSE           FALSE    FALSE       T#10ms   16#8804    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=F_TRIG at S_OSSD_In->ESPE_Interrupted_External_Test
  Data  10         TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8404    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->End_External_Test_Reset_False
  Data  11         TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8404    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->End_External_Test_Reset_False
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_29
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  7          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok
  Data  8          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8806    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          TRUE           FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_2
  Data  9          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8406    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         TRUE           FALSE  doc=S_OSSD_In->Wait_for_Reset_2_Reset_False
  Data  10         TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8806    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          TRUE           FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_2
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_30
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  7          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok
  Data  8          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8806    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          TRUE           FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_2
  Data  9          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8406    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         TRUE           FALSE  doc=S_OSSD_In->Wait_for_Reset_2_Reset_False
  Data  10         TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In AND R_TRIG at Reset->ESPE_Free_Test_ok
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_31
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  7          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok
  Data  8          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8806    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          TRUE           FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_2
  Data  9          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8406    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         TRUE           FALSE  doc=S_OSSD_In->Wait_for_Reset_2_Reset_False
  Data  10         TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_Test_ok
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_32
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  7          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok
  Data  8          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8806    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          TRUE           FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_2
  Data  9          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8406    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         TRUE           FALSE  doc=S_OSSD_In->Wait_for_Reset_2_Reset_False
  Data  10         TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8406    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         TRUE           FALSE  doc=S_OSSD_In->Wait_for_Reset_2_Reset_False
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_33
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  7          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok
  Data  8          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8806    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          TRUE           FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_2
  Data  9          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8406    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         TRUE           FALSE  doc=S_OSSD_In AND R_TRIG at Reset->Wait_for_Reset_2_Reset_True
  Data  10         TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8806    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          TRUE           FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_2
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_34
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  7          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok
  Data  8          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8806    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          TRUE           FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_2
  Data  9          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8406    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         TRUE           FALSE  doc=S_OSSD_In AND R_TRIG at Reset->Wait_for_Reset_2_Reset_True
  Data  10         TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_Test_ok
  Finish

test logicals.safety.plcopen.SF_TestableSafetySensor_35
  Head  Time  Activate  NoExternalTest  Reset  S_AutoReset  S_OSSD_In  S_StartReset  StartTest  TestTime  DiagCode?  Error?  Ready?  ResetRequest?  S_OSSD_Out?  S_TestOut?  SafetyDemand?  TestExecuted?  TestPossible?  CycleTime=T#9ms
  Tol  /  /  /  /  /  /  /  /  /    0  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /   0  0  0  0  0  0  0  0  0
  Data  0          FALSE      FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#0000    FALSE   FALSE   FALSE          FALSE        TRUE         FALSE         FALSE          FALSE  doc=NOT Activate->Idle
  Data  1          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8401    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=Activate->Init_Reset_False
  Data  2          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8802    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          FALSE          FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_1
  Data  3          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8402    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         FALSE          FALSE  doc=S_OSSD_In->Wait_for_Reset_1_Reset_False
  Data  4          TRUE       FALSE       FALSE   TRUE        TRUE            FALSE    FALSE       T#10ms   16#8010    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          TRUE   doc=S_OSSD_In AND S_AutoReset->ESPE_Free_No_Test
  Data  5          TRUE       TRUE        TRUE    FALSE       TRUE            FALSE    TRUE        T#10ms   16#8020    FALSE   TRUE    FALSE          TRUE         FALSE        FALSE         FALSE          FALSE  doc=R_TRIG at StartTest->Test_Request
  Data  6          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8030    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         FALSE          FALSE  doc=NOT S_OSSD_In->Test_Active
  Data  7          TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8000    FALSE   TRUE    FALSE          TRUE         TRUE         FALSE         TRUE           TRUE   doc=S_OSSD_In->ESPE_Free_Test_ok
  Data  8          TRUE       FALSE       FALSE   FALSE       FALSE           FALSE    FALSE       T#10ms   16#8806    FALSE   TRUE    FALSE          FALSE        TRUE         TRUE          TRUE           FALSE  doc=NOT S_OSSD_In->ESPE_Interrupted_2
  Data  9          TRUE       FALSE       TRUE    FALSE       TRUE            FALSE    FALSE       T#10ms   16#8406    FALSE   TRUE    FALSE          FALSE        TRUE         FALSE         TRUE           FALSE  doc=S_OSSD_In AND R_TRIG at Reset->Wait_for_Reset_2_Reset_True
  Data  10         TRUE       FALSE       FALSE   FALSE       TRUE            FALSE    FALSE       T#10ms   16#8406    FALSE   TRUE    TRUE           FALSE        TRUE         FALSE         TRUE           FALSE  doc=S_OSSD_In->Wait_for_Reset_2_Reset_False
  Finish

