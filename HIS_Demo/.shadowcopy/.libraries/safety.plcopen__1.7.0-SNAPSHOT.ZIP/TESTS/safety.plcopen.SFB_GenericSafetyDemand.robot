*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SFB_GenericSafetyDemand		MaxDataRows=100		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  Reset=FALSE
...  S_AutoReset=16#00
...  S_SafetyDemandIn=16#00
...  S_StartReset=16#00
*** Test Cases ***
test logicals.safety.plcopen.SFB_GenericSafetyDemand_Invalid_State
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  ENO?  CycleTime=T#10ms
  Tol    /    /         /      /            /                 /             0          0       0       0              0                   0              0
  Shift  /    /         /      /            /                 /             0          0       0       0              0                   0              0
  Init   /    /         /      /            /                 /             16#9999    FALSE   FALSE   FALSE          FALSE               FALSE          TRUE
  Data   0    TRUE      FALSE  FALSE        FALSE             FALSE         16#9999    TRUE    TRUE    FALSE          FALSE               FALSE          FALSE        doc=Invalid State
  Data   1    TRUE      FALSE  FALSE        FALSE             FALSE         16#9999    TRUE    TRUE    FALSE          FALSE               FALSE          FALSE        doc=Invalid State
  Data   2    FALSE     FALSE  FALSE        FALSE             FALSE         16#0000    FALSE   FALSE   FALSE          FALSE               FALSE          TRUE         doc=NOT Activate->Idle
  Data   3    TRUE      FALSE  FALSE        FALSE             FALSE         16#8001    FALSE   TRUE    FALSE          FALSE               FALSE          TRUE         doc=Activate->Init
  Finish

test state8804resetRequestIsInverseOfReset
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /    /         /      /            /                 /             0          0       0       0              0                   0              
  Shift  /    /         /      /            /                 /             0          0       0       0              0                   0              
  Init   /    /         /      /            /                 /             16#8804    FALSE   TRUE    TRUE           FALSE               TRUE  
  Data   0     TRUE     FALSE   FALSE       FALSE             TRUE          16#8804    FALSE   TRUE    TRUE           FALSE               TRUE
  Data   1     TRUE     TRUE    FALSE       FALSE             TRUE          16#8804    FALSE   TRUE    FALSE          FALSE               TRUE  
  
test state8404resetRequestIsInverseOfReset
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /    /         /      /            /                 /             0          0       0       0              0                   0              
  Shift  /    /         /      /            /                 /             0          0       0       0              0                   0  
  Init   /    /         /      /            /                 /             16#8804    FALSE   TRUE    FALSE          FALSE               TRUE
  Data   0     TRUE      TRUE    TRUE        FALSE            FALSE         16#8804    FALSE   TRUE    FALSE          FALSE               TRUE          doc=R_TRIG at Reset AND S_AutoReset AND NOT S_SafetyDemandIn->Wait_for_S_SafetyDemandIn_2 (15 prio2 over 3)
  Data   1     TRUE      TRUE    FALSE       TRUE             TRUE          16#8404    FALSE   TRUE    FALSE          FALSE               FALSE         doc=S_SafetyDemandIn_2 AND NOT S_AutoReset->Wait_for_Reset_2
  Data   2     TRUE      FALSE   FALSE       TRUE             TRUE          16#8404    FALSE   TRUE    TRUE           FALSE               FALSE         doc=S_SafetyDemandIn_2 AND NOT S_AutoReset->Wait_for_Reset_2


test logicals.safety.plcopen.8402_prio2_over_3
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE       FALSE              FALSE         16#0000   FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE       FALSE              FALSE         16#8001   FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2     TRUE      FALSE   FALSE       FALSE              FALSE         16#8802   FALSE   TRUE    FALSE          FALSE               TRUE   doc=NOT S_StartReset->Wait_for_S_SafetyDemandIn_1
  Data  3     TRUE      FALSE   FALSE       TRUE               FALSE         16#8402   FALSE   TRUE    TRUE           FALSE               FALSE  doc=S_SafetyDemandIn_1->Wait_for_Reset_1
  Data  4     TRUE      TRUE    FALSE       FALSE              FALSE         16#8802   FALSE   TRUE    FALSE          FALSE               TRUE   doc=PRIORITY_CHECK_8000->Wait_for_S_SafetyDemandIn_1:
  Finish

test logicals.safety.plcopen.8404_prio_tests
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE       FALSE              FALSE         16#0000   FALSE   FALSE   FALSE          FALSE                FALSE         doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE       FALSE              FALSE         16#8001   FALSE   TRUE    FALSE          FALSE                FALSE         doc=Activate->Init
  Data  2     TRUE      FALSE   FALSE       FALSE              TRUE          16#8804   FALSE   TRUE    TRUE           FALSE                TRUE          doc=S_StartReset AND NOT S_SafetyDemandIn->Wait_for_S_SafetyDemandIn_2
  Data  3     TRUE      FALSE   FALSE       TRUE               TRUE          16#8404   FALSE   TRUE    TRUE           FALSE                FALSE         doc=S_SafetyDemandIn_2 AND NOT S_AutoReset->Wait_for_Reset_2
  Data  4     TRUE      FALSE   FALSE       TRUE               TRUE          16#8404   FALSE   TRUE    TRUE           FALSE                FALSE         doc=S_SafetyDemandIn_2 AND NOT S_AutoReset->Wait_for_Reset_2
  Data  5     TRUE      FALSE   TRUE        FALSE              FALSE         16#8804   FALSE   TRUE    TRUE           FALSE                TRUE          doc=COMBO_CHECK_8000_S_AutoReset->Wait_for_S_SafetyDemandIn_2 (3 prio2 over 3)
  Data  6     TRUE      FALSE   FALSE       TRUE               TRUE          16#8404   FALSE   TRUE    TRUE           FALSE                FALSE         doc=S_SafetyDemandIn_2 AND NOT S_AutoReset->Wait_for_Reset_2
  Data  7     TRUE      TRUE    FALSE       FALSE              FALSE         16#8804   FALSE   TRUE    FALSE          FALSE                TRUE          doc=COMBO_CHECK_8000_RTRIG_RESET->Wait_for_S_SafetyDemandIn_2
  Data  8     TRUE      FALSE   FALSE       TRUE               TRUE          16#8404   FALSE   TRUE    TRUE           FALSE                FALSE         doc=S_SafetyDemandIn_2 AND NOT S_AutoReset->Wait_for_Reset_2
  Data  9     TRUE      TRUE    TRUE        FALSE              FALSE         16#8804   FALSE   TRUE    FALSE          FALSE                TRUE          doc=R_TRIG at Reset AND S_AutoReset AND NOT S_SafetyDemandIn->Wait_for_S_SafetyDemandIn_2 (15 prio2 over 3)
  Data  10    TRUE      TRUE    FALSE       TRUE               TRUE          16#8404   FALSE   TRUE    FALSE          FALSE                FALSE         doc=S_SafetyDemandIn_2 AND NOT S_AutoReset->Wait_for_Reset_2
  Data  11    TRUE      TRUE    TRUE        FALSE              FALSE         16#C011   TRUE    TRUE    FALSE          FALSE                FALSE         doc=COMBO_CHECK_8000_C011->Reset_Error_2
  Data  12    TRUE      FALSE   FALSE       FALSE              FALSE         16#8404   FALSE   TRUE    TRUE           FALSE                FALSE         doc=NOT Reset->Wait_for_Reset_2
  Data  13    TRUE      TRUE    TRUE        FALSE              FALSE         16#8804   FALSE   TRUE    FALSE          FALSE                TRUE          doc=preparation for 12
  Data  14    TRUE      TRUE    FALSE       TRUE               TRUE          16#8404   FALSE   TRUE    FALSE          FALSE                FALSE         doc=preparation for 12
  Data  15    TRUE      TRUE    TRUE        TRUE               FALSE         16#C011   TRUE    TRUE    FALSE          FALSE                FALSE         doc=COMBO_CHECK_8000_C011->Reset_Error_2
  Finish
#                                  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
#@startuml
#Idle:                             16#0000    FALSE   FALSE   FALSE          FALSE               FALSE
#Init:                             16#8001    FALSE   TRUE    FALSE          FALSE               FALSE
#Wait_for_S_SafetyDemandIn_1:      16#8802    FALSE   TRUE    FALSE          FALSE               TRUE
#Wait_for_Reset_1:                 16#8402    FALSE   TRUE    TRUE           FALSE               FALSE
#Wait_for_Reset_1_AND_Reset:       16#8402    FALSE   TRUE    FALSE          FALSE               FALSE
#Wait_for_Reset_1_AND_NOT_Reset:   16#8402    FALSE   TRUE    TRUE           FALSE               FALSE
#Wait_for_S_SafetyDemandIn_2:      16#8804    FALSE   TRUE    TRUE           FALSE               TRUE
#Wait_for_Reset_2:                 16#8404    FALSE   TRUE    TRUE           FALSE               FALSE
#Wait_for_Reset_2_AND_Reset:       16#8404    FALSE   TRUE    FALSE          FALSE               FALSE
#Safety_Output_Enabled:            16#8000    FALSE   TRUE    FALSE          TRUE                FALSE
#Reset_Error_1:                    16#C001    TRUE    TRUE    FALSE          FALSE               FALSE
#Reset_Error_2:                    16#C011    TRUE    TRUE    FALSE          FALSE               FALSE
#T:                                                    Time  Activate  Reset   S_AutoReset  S_SafetyDemandIn  S_StartReset
#T:NOT Activate:                                       1     FALSE     FALSE   FALSE        FALSE             FALSE
#T:Activate:                                           1     TRUE      FALSE   FALSE        FALSE             FALSE
#T:NOT S_StartReset:                                   1     TRUE      FALSE   FALSE        FALSE             FALSE
#T:S_StartReset AND NOT S_SafetyDemandIn:              1     TRUE      FALSE   FALSE        FALSE             TRUE
#T:S_SafetyDemandIn AND S_StartReset:                  1     TRUE      FALSE   FALSE        TRUE              TRUE
#T:S_SafetyDemandIn_1:                                 1     TRUE      FALSE   FALSE        TRUE              FALSE
#T:S_SafetyDemandIn_1 AND Reset:                       1     TRUE      TRUE    FALSE        TRUE              FALSE
#T:S_SafetyDemandIn_1 AND NOT Reset:                   1     TRUE      FALSE   FALSE        TRUE              FALSE
#T:NOT S_SafetyDemandIn_1:                             1     TRUE      FALSE   FALSE        FALSE             FALSE
#T:NOT S_SafetyDemandIn_2:                             1     TRUE      FALSE   FALSE        FALSE             TRUE
#T:Reset:                                              1     TRUE      R_EDGE  FALSE        TRUE              FALSE
#T:S_SafetyDemandIn_2 AND S_AutoReset:                 1     TRUE      FALSE   TRUE         TRUE              TRUE
#T:S_SafetyDemandIn_2 AND NOT S_AutoReset:             1     TRUE      FALSE   FALSE        TRUE              TRUE
#T:S_SafetyDemandIn_2 AND NOT S_AutoReset AND Reset:   1     TRUE      TRUE    FALSE        TRUE              TRUE
#T:Reset OR S_AutoReset:                               1     TRUE      FALSE   TRUE         TRUE              FALSE
#T:NOT Reset:                                          1     TRUE      FALSE   FALSE        FALSE             FALSE
#T:Reset AND NOT R_TRIG at Reset:                      1     TRUE      TRUE    FALSE        FALSE             FALSE
#T:NOT Reset AND NOT R_TRIG at Reset:                  1     TRUE      FALSE   TRUE         FALSE             FALSE
#
#[*]-->Idle:NOT Activate
#Idle-->Init: Activate
#Init-->Wait_for_S_SafetyDemandIn_1: NOT S_StartReset
#Init-->Wait_for_S_SafetyDemandIn_2: S_StartReset AND NOT S_SafetyDemandIn
#Init-->Safety_Output_Enabled: S_SafetyDemandIn AND S_StartReset
#Wait_for_S_SafetyDemandIn_1-->Wait_for_Reset_1: S_SafetyDemandIn_1
#Wait_for_S_SafetyDemandIn_1-->Wait_for_Reset_1_AND_Reset: S_SafetyDemandIn_1 AND Reset
#Wait_for_S_SafetyDemandIn_1-->Wait_for_Reset_1_AND_NOT_Reset: S_SafetyDemandIn_1 AND NOT Reset
#Wait_for_S_SafetyDemandIn_1-->Wait_for_S_SafetyDemandIn_1: NOT S_StartReset
#Wait_for_Reset_1-->Wait_for_S_SafetyDemandIn_1: NOT S_SafetyDemandIn_1
#Wait_for_Reset_1_AND_Reset-->Reset_Error_1: Reset AND NOT R_TRIG at Reset
#Wait_for_Reset_1-->Safety_Output_Enabled: Reset
#Wait_for_Reset_1-->Wait_for_Reset_1: S_SafetyDemandIn_1
#Reset_Error_1-->Wait_for_Reset_1: NOT Reset
#Reset_Error_1-->Reset_Error_1: S_SafetyDemandIn_1 AND Reset
#Wait_for_S_SafetyDemandIn_2-->Wait_for_Reset_2: S_SafetyDemandIn_2 AND NOT S_AutoReset
#Wait_for_S_SafetyDemandIn_2-->Wait_for_Reset_2_AND_Reset: S_SafetyDemandIn_2 AND NOT S_AutoReset AND Reset
#Wait_for_S_SafetyDemandIn_2-->Safety_Output_Enabled: S_SafetyDemandIn_2 AND S_AutoReset
#Wait_for_S_SafetyDemandIn_2-->Wait_for_S_SafetyDemandIn_2: S_StartReset AND NOT S_SafetyDemandIn
#Wait_for_Reset_2-->Wait_for_S_SafetyDemandIn_2: NOT S_SafetyDemandIn_2
#Wait_for_Reset_2-->Safety_Output_Enabled: Reset OR S_AutoReset
#Wait_for_Reset_2_AND_Reset-->Reset_Error_2: Reset AND NOT R_TRIG at Reset
#Reset_Error_2-->Wait_for_Reset_2: NOT Reset
#Reset_Error_2-->Reset_Error_2: S_SafetyDemandIn_2 AND NOT S_AutoReset AND Reset
#Safety_Output_Enabled-->Wait_for_S_SafetyDemandIn_2: NOT S_SafetyDemandIn_2
#Safety_Output_Enabled-->Safety_Output_Enabled: S_SafetyDemandIn_2 AND S_AutoReset
#
#@enduml
#@begin generated
test logicals.safety.plcopen.SFB_GenericSafetyDemand_0
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             FALSE  16#8802    FALSE   TRUE    FALSE          FALSE               TRUE  doc=NOT S_StartReset->Wait_for_S_SafetyDemandIn_1
  Data  3       TRUE      FALSE   FALSE        TRUE              FALSE  16#8402    FALSE   TRUE    TRUE           FALSE               FALSE  doc=S_SafetyDemandIn_1 AND NOT Reset->Wait_for_Reset_1_AND_NOT_Reset
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_1
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             FALSE  16#8802    FALSE   TRUE    FALSE          FALSE               TRUE  doc=NOT S_StartReset->Wait_for_S_SafetyDemandIn_1
  Data  3       TRUE      FALSE   FALSE        FALSE             FALSE  16#8802    FALSE   TRUE    FALSE          FALSE               TRUE  doc=NOT S_StartReset->Wait_for_S_SafetyDemandIn_1
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_2
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             TRUE  16#8804    FALSE   TRUE    TRUE           FALSE               TRUE  doc=S_StartReset AND NOT S_SafetyDemandIn->Wait_for_S_SafetyDemandIn_2
  Data  3       TRUE      FALSE   TRUE         TRUE              TRUE  16#8000    FALSE   TRUE    FALSE          TRUE                FALSE  doc=S_SafetyDemandIn_2 AND S_AutoReset->Safety_Output_Enabled
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_3
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             TRUE  16#8804    FALSE   TRUE    TRUE           FALSE               TRUE  doc=S_StartReset AND NOT S_SafetyDemandIn->Wait_for_S_SafetyDemandIn_2
  Data  3       TRUE      FALSE   FALSE        FALSE             TRUE  16#8804    FALSE   TRUE    TRUE           FALSE               TRUE  doc=S_StartReset AND NOT S_SafetyDemandIn->Wait_for_S_SafetyDemandIn_2
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_4
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        TRUE              TRUE  16#8000    FALSE   TRUE    FALSE          TRUE                FALSE  doc=S_SafetyDemandIn AND S_StartReset->Safety_Output_Enabled
  Data  3       TRUE      FALSE   FALSE        FALSE             TRUE  16#8804    FALSE   TRUE    TRUE           FALSE               TRUE  doc=NOT S_SafetyDemandIn_2->Wait_for_S_SafetyDemandIn_2
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_5
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        TRUE              TRUE  16#8000    FALSE   TRUE    FALSE          TRUE                FALSE  doc=S_SafetyDemandIn AND S_StartReset->Safety_Output_Enabled
  Data  3       TRUE      FALSE   TRUE         TRUE              TRUE  16#8000    FALSE   TRUE    FALSE          TRUE                FALSE  doc=S_SafetyDemandIn_2 AND S_AutoReset->Safety_Output_Enabled
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_6
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             FALSE  16#8802    FALSE   TRUE    FALSE          FALSE               TRUE  doc=NOT S_StartReset->Wait_for_S_SafetyDemandIn_1
  Data  3       TRUE      FALSE   FALSE        TRUE              FALSE  16#8402    FALSE   TRUE    TRUE           FALSE               FALSE  doc=S_SafetyDemandIn_1->Wait_for_Reset_1
  Data  4       TRUE      FALSE   FALSE        FALSE             FALSE  16#8802    FALSE   TRUE    FALSE          FALSE               TRUE  doc=NOT S_SafetyDemandIn_1->Wait_for_S_SafetyDemandIn_1
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_7
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             FALSE  16#8802    FALSE   TRUE    FALSE          FALSE               TRUE  doc=NOT S_StartReset->Wait_for_S_SafetyDemandIn_1
  Data  3       TRUE      FALSE   FALSE        TRUE              FALSE  16#8402    FALSE   TRUE    TRUE           FALSE               FALSE  doc=S_SafetyDemandIn_1->Wait_for_Reset_1
  Data  4       TRUE      FALSE   FALSE        TRUE              FALSE  16#8402    FALSE   TRUE    TRUE           FALSE               FALSE  doc=Reset->Safety_Output_Enabled
  Data  5       TRUE      TRUE    FALSE        TRUE              FALSE  16#8000    FALSE   TRUE    FALSE          TRUE                FALSE  doc=Reset->Safety_Output_Enabled
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_8
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             FALSE  16#8802    FALSE   TRUE    FALSE          FALSE               TRUE  doc=NOT S_StartReset->Wait_for_S_SafetyDemandIn_1
  Data  3       TRUE      FALSE   FALSE        TRUE              FALSE  16#8402    FALSE   TRUE    TRUE           FALSE               FALSE  doc=S_SafetyDemandIn_1->Wait_for_Reset_1
  Data  4       TRUE      FALSE   FALSE        TRUE              FALSE  16#8402    FALSE   TRUE    TRUE           FALSE               FALSE  doc=S_SafetyDemandIn_1->Wait_for_Reset_1
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_9
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             TRUE  16#8804    FALSE   TRUE    TRUE           FALSE               TRUE  doc=S_StartReset AND NOT S_SafetyDemandIn->Wait_for_S_SafetyDemandIn_2
  Data  3       TRUE      FALSE   FALSE        TRUE              TRUE  16#8404    FALSE   TRUE    TRUE           FALSE               FALSE  doc=S_SafetyDemandIn_2 AND NOT S_AutoReset->Wait_for_Reset_2
  Data  4       TRUE      FALSE   FALSE        FALSE             TRUE  16#8804    FALSE   TRUE    TRUE           FALSE               TRUE  doc=NOT S_SafetyDemandIn_2->Wait_for_S_SafetyDemandIn_2
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_10
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             TRUE  16#8804    FALSE   TRUE    TRUE           FALSE               TRUE  doc=S_StartReset AND NOT S_SafetyDemandIn->Wait_for_S_SafetyDemandIn_2
  Data  3       TRUE      FALSE   FALSE        TRUE              TRUE  16#8404    FALSE   TRUE    TRUE           FALSE               FALSE  doc=S_SafetyDemandIn_2 AND NOT S_AutoReset->Wait_for_Reset_2
  Data  4       TRUE      FALSE   TRUE         TRUE              FALSE  16#8000    FALSE   TRUE    FALSE          TRUE                FALSE  doc=Reset OR S_AutoReset->Safety_Output_Enabled
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_11
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             FALSE  16#8802    FALSE   TRUE    FALSE          FALSE               TRUE  doc=NOT S_StartReset->Wait_for_S_SafetyDemandIn_1
  Data  3       TRUE      TRUE    FALSE        TRUE              FALSE  16#8402    FALSE   TRUE    FALSE          FALSE               FALSE  doc=S_SafetyDemandIn_1 AND Reset->Wait_for_Reset_1_AND_Reset
  Data  4       TRUE      TRUE    FALSE        FALSE             FALSE  16#C001    TRUE    TRUE    FALSE          FALSE               FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  5       TRUE      FALSE   FALSE        FALSE             FALSE  16#8402    FALSE   TRUE    TRUE           FALSE               FALSE  doc=NOT Reset->Wait_for_Reset_1
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_12
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             FALSE  16#8802    FALSE   TRUE    FALSE          FALSE               TRUE  doc=NOT S_StartReset->Wait_for_S_SafetyDemandIn_1
  Data  3       TRUE      TRUE    FALSE        TRUE              FALSE  16#8402    FALSE   TRUE    FALSE          FALSE               FALSE  doc=S_SafetyDemandIn_1 AND Reset->Wait_for_Reset_1_AND_Reset
  Data  4       TRUE      TRUE    FALSE        FALSE             FALSE  16#C001    TRUE    TRUE    FALSE          FALSE               FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  5       TRUE      TRUE    FALSE        TRUE              FALSE  16#C001    TRUE    TRUE    FALSE          FALSE               FALSE  doc=S_SafetyDemandIn_1 AND Reset->Reset_Error_1
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_13
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             TRUE  16#8804    FALSE   TRUE    TRUE           FALSE               TRUE  doc=S_StartReset AND NOT S_SafetyDemandIn->Wait_for_S_SafetyDemandIn_2
  Data  3       TRUE      TRUE    FALSE        TRUE              TRUE  16#8404    FALSE   TRUE    FALSE          FALSE               FALSE  doc=S_SafetyDemandIn_2 AND NOT S_AutoReset AND Reset->Wait_for_Reset_2_AND_Reset
  Data  4       TRUE      TRUE    FALSE        FALSE             FALSE  16#C011    TRUE    TRUE    FALSE          FALSE               FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_2
  Data  5       TRUE      FALSE   FALSE        FALSE             FALSE  16#8404    FALSE   TRUE    TRUE           FALSE               FALSE  doc=NOT Reset->Wait_for_Reset_2
  Finish

test logicals.safety.plcopen.SFB_GenericSafetyDemand_14
  Head  Time  Activate  Reset  S_AutoReset  S_SafetyDemandIn  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyDemandOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE             FALSE  16#0000    FALSE   FALSE   FALSE          FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE             FALSE  16#8001    FALSE   TRUE    FALSE          FALSE               FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE   FALSE        FALSE             TRUE  16#8804    FALSE   TRUE    TRUE           FALSE               TRUE  doc=S_StartReset AND NOT S_SafetyDemandIn->Wait_for_S_SafetyDemandIn_2
  Data  3       TRUE      TRUE    FALSE        TRUE              TRUE  16#8404    FALSE   TRUE    FALSE          FALSE               FALSE  doc=S_SafetyDemandIn_2 AND NOT S_AutoReset AND Reset->Wait_for_Reset_2_AND_Reset
  Data  4       TRUE      TRUE    FALSE        FALSE             FALSE  16#C011    TRUE    TRUE    FALSE          FALSE               FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_2
  Data  5       TRUE      TRUE    FALSE        TRUE              TRUE  16#C011    TRUE    TRUE    FALSE          FALSE               FALSE  doc=S_SafetyDemandIn_2 AND NOT S_AutoReset AND Reset->Reset_Error_2
  Finish

