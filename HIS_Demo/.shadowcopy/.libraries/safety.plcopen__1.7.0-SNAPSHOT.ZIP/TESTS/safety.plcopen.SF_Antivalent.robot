*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_Antivalent       MaxDataRows=10     TestSuitePath=${SUITE SOURCE}
  Set Defaults    &{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  DiscrepancyTime=T#10ms
...  S_ChannelNC=FALSE
...  S_ChannelNO=FALSE
*** Test Cases ***
test SF_Antivalent_Invalid_State
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?  ENO?   CycleTime=T#10ms
  Shift  /      /           /                 /              /               0            0         0         0                   0              0
  Tol    /      /           /                 /              /               0            0         0         0                   0              0
  Init   /      /           /                 /              /               16#9999      FALSE     FALSE     FALSE               FALSE          TRUE
  Data  0       TRUE        T#0ms             FALSE          FALSE           16#9999      TRUE      TRUE      FALSE               FALSE          FALSE  doc=Invalid state
  Data  1       TRUE        T#0ms             FALSE          FALSE           16#9999      TRUE      TRUE      FALSE               FALSE          FALSE  doc=Invalid state
  Data  2       FALSE       T#0ms             FALSE          FALSE           16#0000      FALSE     FALSE     FALSE               FALSE          TRUE   doc=NOT Activate -> Idle
  Data  3       TRUE        T#0ms             FALSE          FALSE           16#8801      FALSE     TRUE      FALSE               TRUE           TRUE   doc=Idle->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_DiscrTime_LT_0
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#-100ms             FALSE          TRUE   16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#-100ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=Activate->Init
  Data  2       TRUE        T#-100ms             TRUE           TRUE   16#8802      FALSE     TRUE      FALSE               TRUE   doc=S_ChannelNC AND S_ChannelNO->Wait_for_NO
  Data  3       TRUE        T#-100ms             FALSE          FALSE  16#C010      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_1
  Data  4       TRUE        T#-100ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC AND S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_DiscrTime_EQ_0_C010
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#0ms             FALSE          TRUE   16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#0ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=Activate->Init
  Data  2       TRUE        T#0ms             TRUE           TRUE   16#8802      FALSE     TRUE      FALSE               TRUE   doc=S_ChannelNC AND S_ChannelNO->Wait_for_NO
  Data  3       TRUE        T#0ms             FALSE          FALSE  16#C010      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_1
  Data  4       TRUE        T#0ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC AND S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_DiscrTime_EQ_0_C020
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#0ms             FALSE          TRUE   16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#0ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=Activate->Init
  Data  2       TRUE        T#0ms             FALSE          FALSE  16#8804      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC AND NOT S_ChannelNO->Wait_for_NC
  Data  3       TRUE        T#0ms             FALSE          FALSE  16#C020      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_2
  Data  4       TRUE        T#0ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC AND S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_DiscrTime_EQ_0_C030
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#0ms             FALSE          TRUE   16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#0ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=Activate->Init
  Data  2       TRUE        T#0ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=S_ChannelNC AND NOT S_ChannelNO->Safety_Output_Enabled
  Data  3       TRUE        T#0ms             FALSE          FALSE  16#8806      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC OR S_ChannelNO->From_Active_Wait
  Data  4       TRUE        T#0ms             FALSE          FALSE  16#C030      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_3
  Data  5       TRUE        T#0ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC AND S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_DiscrTime_LT_CycleTime
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#9ms             FALSE          TRUE   16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#9ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=Activate->Init
  Data  2       TRUE        T#9ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=S_ChannelNC AND NOT S_ChannelNO->Safety_Output_Enabled
  Data  3       TRUE        T#9ms             FALSE          FALSE  16#8806      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC OR S_ChannelNO->From_Active_Wait
  Data  4       TRUE        T#9ms             FALSE          FALSE  16#C030      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_3
  Data  5       TRUE        T#9ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC AND S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_DiscrTime_EQ_CycleTime
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#10ms             FALSE          TRUE   16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#10ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=Activate->Init
  Data  2       TRUE        T#10ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=S_ChannelNC AND NOT S_ChannelNO->Safety_Output_Enabled
  Data  3       TRUE        T#10ms             FALSE          FALSE  16#8806      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC OR S_ChannelNO->From_Active_Wait
  Data  4       TRUE        T#10ms             FALSE          FALSE  16#C030      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_3
  Data  5       TRUE        T#10ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC AND S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_DiscrTime_GT_CycleTime
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#11ms             FALSE          TRUE   16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#11ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=Activate->Init
  Data  2       TRUE        T#11ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=S_ChannelNC AND NOT S_ChannelNO->Safety_Output_Enabled
  Data  3       TRUE        T#11ms             FALSE          FALSE  16#8806      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC OR S_ChannelNO->From_Active_Wait
  Data  5       TRUE        T#11ms             FALSE          FALSE  16#C030      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_3
  Data  6       TRUE        T#11ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC AND S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_8802_prio1over3
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE   16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             TRUE           TRUE   16#8802      FALSE     TRUE      FALSE               TRUE  doc=S_ChannelNC AND S_ChannelNO->Wait_for_NO
  Data  4       TRUE        T#20ms             FALSE          FALSE  16#C010      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_1
  Finish

test logicals.safety.plcopen.SF_Antivalent_8802_prio2over3
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE   16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             TRUE           TRUE   16#8802      FALSE     TRUE      FALSE               TRUE  doc=S_ChannelNC AND S_ChannelNO->Wait_for_NO
  Data  3       TRUE        T#20ms             FALSE          FALSE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_8804_prio1over3
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE   16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             FALSE          FALSE  16#8804      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC AND NOT S_ChannelNO->Wait_for_NC
  Data  4       TRUE        T#20ms             TRUE           FALSE  16#C020      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_2

test logicals.safety.plcopen.SF_Antivalent_8804_prio2over3
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE   16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             FALSE          FALSE  16#8804      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC AND NOT S_ChannelNO->Wait_for_NC
  Data  3       TRUE        T#20ms             TRUE           TRUE   16#8801      FALSE     TRUE      FALSE               TRUE  doc=S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_8000_8806_var2
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#11ms             FALSE          TRUE   16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  2       TRUE        T#11ms             FALSE          TRUE   16#8801      FALSE     TRUE      FALSE               TRUE   doc=Activate->Init
  Data  4       TRUE        T#11ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=S_ChannelNC AND NOT S_ChannelNO->Safety_Output_Enabled
  Data  5       TRUE        T#11ms             TRUE           TRUE   16#8806      FALSE     TRUE      FALSE               TRUE   doc=NOT S_ChannelNC OR S_ChannelNO->From_Active_Wait
  Finish

#                            DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
#@startuml
#Idle:                       16#0000      FALSE     FALSE     FALSE               FALSE
#Init:                       16#8801      FALSE     TRUE      FALSE               TRUE
#Wait_for_NO:                16#8802      FALSE     TRUE      FALSE               TRUE
#Wait_for_NC:                16#8804      FALSE     TRUE      FALSE               TRUE
#Safety_Output_Enabled:      16#8000      FALSE     TRUE      TRUE                FALSE
#From_Active_Wait:           16#8806      FALSE     TRUE      FALSE               TRUE
#Error_1:                    16#C010      TRUE      TRUE      FALSE               FALSE
#Error_2:                    16#C020      TRUE      TRUE      FALSE               FALSE
#Error_3:                    16#C030      TRUE      TRUE      FALSE               FALSE
#
#T:.                                     Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO
#T:NOT Activate:                         1       FALSE       T#20ms             FALSE          TRUE
#T:Activate:                             1       TRUE        T#20ms             FALSE          TRUE
#T:S_ChannelNC AND S_ChannelNO:          1       TRUE        T#20ms             TRUE           TRUE
#T:NOT S_ChannelNC AND NOT S_ChannelNO:  1       TRUE        T#20ms             FALSE          FALSE
#T:NOT S_ChannelNC:                      1       TRUE        T#20ms             FALSE          TRUE
#T:S_ChannelNC AND NOT S_ChannelNO:      1       TRUE        T#20ms             TRUE           FALSE
#T:Discrepancy_Time_Elapsed:             2       TRUE        T#20ms             FALSE          FALSE
#T:NOT S_ChannelNC AND S_ChannelNO:      1       TRUE        T#20ms             FALSE          TRUE
#T:S_ChannelNO:                          1       TRUE        T#20ms             FALSE          TRUE
#T:NOT S_ChannelNO:                      1       TRUE        T#20ms             TRUE           FALSE
#T:NOT S_ChannelNC OR S_ChannelNO:       1       TRUE        T#20ms             FALSE          FALSE
#T:S_ChannelNC:                          1       TRUE        T#20ms             TRUE           FALSE
#
#[*]-->Idle: NOT Activate
#Idle-->Init: Activate
#Init-->Wait_for_NO: S_ChannelNC AND S_ChannelNO
#Init-->Wait_for_NC: NOT S_ChannelNC AND NOT S_ChannelNO
#Init-->Safety_Output_Enabled: S_ChannelNC AND NOT S_ChannelNO
#Wait_for_NO-->Error_1: Discrepancy_Time_Elapsed
#Wait_for_NO-->Init: NOT S_ChannelNC
#Wait_for_NO-->Safety_Output_Enabled: NOT S_ChannelNO
#Wait_for_NO-->Wait_for_NO: S_ChannelNC AND S_ChannelNO
#Wait_for_NC-->Error_2: Discrepancy_Time_Elapsed
#Wait_for_NC-->Init: S_ChannelNO
#Wait_for_NC-->Safety_Output_Enabled: S_ChannelNC
#Error_1-->Error_1: S_ChannelNC AND NOT S_ChannelNO
#Error_1-->Init: NOT S_ChannelNC AND S_ChannelNO
#Error_2-->Init: NOT S_ChannelNC AND S_ChannelNO
#Safety_Output_Enabled-->Idle: NOT Activate
#Safety_Output_Enabled-->Safety_Output_Enabled: S_ChannelNC AND NOT S_ChannelNO
#Safety_Output_Enabled-->Init: NOT S_ChannelNC AND S_ChannelNO
#Safety_Output_Enabled-->From_Active_Wait: NOT S_ChannelNC OR S_ChannelNO
#From_Active_Wait-->Error_3: Discrepancy_Time_Elapsed
#From_Active_Wait-->Init: NOT S_ChannelNC AND S_ChannelNO
#Error_3-->Init: NOT S_ChannelNC AND S_ChannelNO
#@enduml
#@begin generated
test logicals.safety.plcopen.SF_Antivalent_0
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             TRUE           TRUE  16#8802      FALSE     TRUE      FALSE               TRUE  doc=S_ChannelNC AND S_ChannelNO->Wait_for_NO
  Data  3       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_1
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             TRUE           TRUE  16#8802      FALSE     TRUE      FALSE               TRUE  doc=S_ChannelNC AND S_ChannelNO->Wait_for_NO
  Data  3       TRUE        T#20ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=NOT S_ChannelNO->Safety_Output_Enabled
  Finish

test logicals.safety.plcopen.SF_Antivalent_2
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             TRUE           TRUE  16#8802      FALSE     TRUE      FALSE               TRUE  doc=S_ChannelNC AND S_ChannelNO->Wait_for_NO
  Data  3       TRUE        T#20ms             TRUE           TRUE  16#8802      FALSE     TRUE      FALSE               TRUE  doc=S_ChannelNC AND S_ChannelNO->Wait_for_NO
  Finish

test logicals.safety.plcopen.SF_Antivalent_3
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             FALSE          FALSE  16#8804      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC AND NOT S_ChannelNO->Wait_for_NC
  Data  3       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_4
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             FALSE          FALSE  16#8804      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC AND NOT S_ChannelNO->Wait_for_NC
  Data  3       TRUE        T#20ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=S_ChannelNC->Safety_Output_Enabled
  Finish

test logicals.safety.plcopen.SF_Antivalent_5
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=S_ChannelNC AND NOT S_ChannelNO->Safety_Output_Enabled
  Data  3       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_Antivalent_6
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=S_ChannelNC AND NOT S_ChannelNO->Safety_Output_Enabled
  Data  3       TRUE        T#20ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=S_ChannelNC AND NOT S_ChannelNO->Safety_Output_Enabled
  Finish

test logicals.safety.plcopen.SF_Antivalent_7
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=S_ChannelNC AND NOT S_ChannelNO->Safety_Output_Enabled
  Data  3       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC AND S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_8
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             TRUE           TRUE  16#8802      FALSE     TRUE      FALSE               TRUE  doc=S_ChannelNC AND S_ChannelNO->Wait_for_NO
  Data  4       TRUE        T#20ms             FALSE          FALSE  16#C010      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_1
  Data  5       TRUE        T#20ms             TRUE           FALSE  16#C010      TRUE      TRUE      FALSE               FALSE  doc=S_ChannelNC AND NOT S_ChannelNO->Error_1
  Finish

test logicals.safety.plcopen.SF_Antivalent_9
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             TRUE           TRUE  16#8802      FALSE     TRUE      FALSE               TRUE  doc=S_ChannelNC AND S_ChannelNO->Wait_for_NO
  Data  4       TRUE        T#20ms             FALSE          FALSE  16#C010      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_1
  Data  5       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC AND S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_10
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             FALSE          FALSE  16#8804      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC AND NOT S_ChannelNO->Wait_for_NC
  Data  4       TRUE        T#20ms             FALSE          FALSE  16#C020      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_2
  Data  5       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC AND S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_11
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=S_ChannelNC AND NOT S_ChannelNO->Safety_Output_Enabled
  Data  3       TRUE        T#20ms             FALSE          FALSE  16#8806      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC OR S_ChannelNO->From_Active_Wait
  Data  4       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC AND S_ChannelNO->Init
  Finish

test logicals.safety.plcopen.SF_Antivalent_12
  Head  Time    Activate    DiscrepancyTime    S_ChannelNC    S_ChannelNO    DiagCode?    Error?    Ready?    S_AntivalentOut?    SafetyDemand?    CycleTime=T#10ms
  Tol  /    /    /    /    /    0    0    0    0    0
  Shift  /    /    /    /    /    0    0    0    0    0
  Data  0       FALSE       T#20ms             FALSE          TRUE  16#0000      FALSE     FALSE     FALSE               FALSE  doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=Activate->Init
  Data  2       TRUE        T#20ms             TRUE           FALSE  16#8000      FALSE     TRUE      TRUE                FALSE  doc=S_ChannelNC AND NOT S_ChannelNO->Safety_Output_Enabled
  Data  3       TRUE        T#20ms             FALSE          FALSE  16#8806      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC OR S_ChannelNO->From_Active_Wait
  Data  5       TRUE        T#20ms             FALSE          FALSE  16#C030      TRUE      TRUE      FALSE               FALSE  doc=Discrepancy_Time_Elapsed->Error_3
  Data  6       TRUE        T#20ms             FALSE          TRUE  16#8801      FALSE     TRUE      FALSE               TRUE  doc=NOT S_ChannelNC AND S_ChannelNO->Init
  Finish

