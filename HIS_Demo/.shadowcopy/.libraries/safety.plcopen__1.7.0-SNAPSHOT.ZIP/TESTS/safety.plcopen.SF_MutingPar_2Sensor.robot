*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_MutingPar_2Sensor		MaxDataRows=100		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  DiscTimeEntry=0
...  MaxMutingTime=0
...  MutingEnable=FALSE
...  MutingSwitch11=FALSE
...  MutingSwitch12=FALSE
...  Reset=FALSE
...  S_AOPD_In=0
...  S_StartReset=0
&{VARIABLE_TESTMODES}
...  ControlCode=useLastValue
*** Test Cases ***

test logicals.safety.plcopen.SF_MutingPar_2Sensor_Invalid_State
  Head   Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  ENO?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0  0
  Init   /       /           /           /             /             /               /               /       /          /      16#9999    TRUE    TRUE    FALSE          FALSE        FALSE            TRUE   FALSE  doc=Invalid State
  Data   0     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#9999    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  FALSE  doc=Invalid State
  Data   1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#9999    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  FALSE  doc=Invalid State
  Data   2     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  TRUE   doc=NOT Activate->Idle
  Data   3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  TRUE   doc=Activate->Init
  Finish

test logicals.safety.plcopen.NOT_Activate_From_AOPD_Free
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  6     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  7     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  8     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  9     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free

#SAFE-26576 test logicals.safety.plcopen.Check_SafeInputs
#  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  ENO?  CycleTime=T#10ms
#  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0  0
#  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0  0
#  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   16#F0      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  FALSE  doc=NOT Activate->Idle
#  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      16#20  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  FALSE  doc=Activate->Init
#  Finish

test logicals.safety.plcopen.Init_To_Reset_Error_1_And_Stay_In_Reset_Error_1
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE           FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8401    FALSE   TRUE    FALSE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#C001    TRUE    TRUE    FALSE           FALSE        FALSE            FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#C001    TRUE    TRUE    FALSE           FALSE        FALSE            FALSE  doc=Reset->Reset_Error_1
  Finish

test logicals.safety.plcopen.Init_To_Reset_Error_1_And_Back
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8401    FALSE   TRUE    FALSE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#C001    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=NOT Reset->Init
  Finish

test logicals.safety.plcopen.Wait_For_Reset_To_Reset_Error_2_And_Stay_In_Reset_Error_2
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE   doc=NOT S_AOPD_In->Safety_Demand_AOPD
  Data  5     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    TRUE       FALSE  16#8402    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=S_AOPD_In->Wait_For_Reset
  Data  6     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    TRUE       FALSE  16#C011    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_2
  Data  7     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    TRUE       FALSE  16#C011    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Reset->Reset_Error_2
 
test logicals.safety.plcopen.Wait_For_Reset_To_Reset_Error_2_And_Back
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE   doc=NOT S_AOPD_In->Safety_Demand_AOPD
  Data  5     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    TRUE       FALSE  16#8402    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=S_AOPD_In->Wait_For_Reset
  Data  6     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    TRUE       FALSE  16#C011    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_2
  Data  7     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=NOT Reset->Wait_For_Reset

test logicals.safety.plcopen.Error_Timer_Max_Muting_From_Muting_Start_1
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#20ms         T#1m           TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6     TRUE      T#30ms         T#20ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  8     TRUE      T#30ms         T#20ms         TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=MutingTimer_Expired->Error_Timer_Max_Muting
  Finish

test logicals.safety.plcopen.Error_Timer_DiscTime_From_Muting_Start_1
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#20ms         T#1m           TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6     TRUE      T#20ms         T#30ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  8     TRUE      T#20ms         T#30ms         TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#C030    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=DiscTimeEntry_Timer_Expired->Error_Timer_DiscTime
  Finish

test logicals.safety.plcopen.Error_Timer_Max_Muting_From_Muting_Start_1_To_Wait_For_Reset
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#20ms         T#1m           TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6     TRUE      T#30ms         T#20ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  8     TRUE      T#30ms         T#20ms         TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=MutingTimer_Expired->Error_Timer_Max_Muting
  Data  9     TRUE      T#1s           T#1m           TRUE          FALSE           FALSE           FALSE   FALSE      FALSE  16#8402    FALSE    TRUE    TRUE          FALSE        FALSE            FALSE  doc=NOT (MS_11 OR MS_12)->Wait_For_Reset
  Finish

test logicals.safety.plcopen.Error_Timer_DiscTime_From_Muting_Start_1_And_Stay_In_Error_State_1
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#20ms         T#1m           TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6     TRUE      T#20ms         T#30ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  8     TRUE      T#20ms         T#30ms         TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#C030    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=DiscTimeEntry_Timer_Expired->Error_Timer_DiscTime
  Data  9     TRUE      T#1ms          T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#C030    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=DiscTimeEntry_Timer_Expired->Error_Timer_DiscTime
  Finish

test logicals.safety.plcopen.Error_Timer_DiscTime_From_Muting_Start_1_And_Stay_In_Error_State_2
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#20ms         T#1m           TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6     TRUE      T#20ms         T#30ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  8     TRUE      T#20ms         T#30ms         TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#C030    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=DiscTimeEntry_Timer_Expired->Error_Timer_DiscTime
  Data  9     TRUE      T#1ms          T#1m           TRUE          FALSE           TRUE            FALSE   FALSE      FALSE  16#C030    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=DiscTimeEntry_Timer_Expired->Error_Timer_DiscTime
  Finish

test logicals.safety.plcopen.Error_Timer_DiscTime_From_Muting_Start_1_And_Stay_In_Error_State_3
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#20ms         T#1m           TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6     TRUE      T#20ms         T#30ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  8     TRUE      T#20ms         T#30ms         TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#C030    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=DiscTimeEntry_Timer_Expired->Error_Timer_DiscTime
  Data  9     TRUE      T#1ms          T#1m           TRUE          TRUE            FALSE           FALSE   FALSE      FALSE  16#C030    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=DiscTimeEntry_Timer_Expired->Error_Timer_DiscTime
  Finish

test logicals.safety.plcopen.Error_Timer_Max_Muting_From_Muting_Start_2
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#50ms         T#1m           TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  6     TRUE      T#50ms         T#20ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#8310    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  8     TRUE      T#50ms         T#20ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=MutingTimer_Expired->Error_Timer_Max_Muting
  Finish

test logicals.safety.plcopen.Error_Timer_DiscTime_From_Muting_Start_2
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#50ms         T#1m           TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  6     TRUE      T#20ms         T#30ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#8310    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  8     TRUE      T#20ms         T#30ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#C030    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=DiscTimeEntry_Timer_Expired->Error_Timer_DiscTime
  Finish

test logicals.safety.plcopen.Muting_Start_1_To_Safety_Demand_AOPD
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#50ms         T#1m           TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6     TRUE      T#50ms         T#1m           TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  7     TRUE      T#50ms         T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE   doc=NOT S_AOPD_In->Safety_Demand_AOPD
  Finish

test logicals.safety.plcopen.Muting_Start_2_To_Safety_Demand_AOPD
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#50ms         T#1m           TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  6     TRUE      T#50ms         T#1m           TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#8310    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  7     TRUE      T#50ms         T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE   doc=NOT S_AOPD_In->Safety_Demand_AOPD
  Finish
  
test logicals.safety.plcopen.Error_Timer_MaxMuting_From_Muting_Active
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#50ms         T#1m           TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6     TRUE      T#50ms         T#1m           TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  7     TRUE      T#50ms         T#1m           TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND MS_11 AND R_TRIG at MS_12->Muting_Active
  Data  8     TRUE      T#50ms         T#20ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=MutingEnable AND MS_11 AND R_TRIG at MS_12->Muting_Active
  Data  9     TRUE      T#50ms         T#20ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=MutingTimer_Expired->Error_Timer_Max_Muting
  Finish

test logicals.safety.plcopen.AOPD_Free_To_Error_Muting_Sequence_Via_First_Condition
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#10ms         T#10ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#C034    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at MS_11 AND MS_12 AND NOT R_TRIG at MS_12->Error_Muting_Sequence
  Finish

test logicals.safety.plcopen.AOPD_Free_To_Error_Muting_Sequence_Via_Second_Condition
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#10ms         T#10ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#C034    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at MS_12 AND MS_11 AND NOT R_TRIG at MS_11-->Error_Muting_Sequence
  Finish

test logicals.safety.plcopen.AOPD_Free_To_Error_Muting_Sequence_Via_Third_Condition
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#10ms         T#10ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#C034    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=(MS_11 AND NOT R_TRIG at MS11) AND (MS_12 AND NOT R_TRIG at MS12)-->Error_Muting_Sequence
  Finish
  
test logicals.safety.plcopen.AOPD_Free_To_Error_Muting_Sequence_Via_Fourth_Condition
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#10ms         T#10ms         FALSE          TRUE           FALSE           FALSE   TRUE       FALSE  16#CF14    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=NOT MutingEnable AND R_TRIG at MS_11-->Error_Muting_Sequence
  Finish

test logicals.safety.plcopen.AOPD_Free_To_Error_Muting_Sequence_Via_Fifth_Condition
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#10ms         T#10ms         FALSE         FALSE           TRUE            FALSE   TRUE       FALSE  16#CF24    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=NOT MutingEnable AND R_TRIG at MS_12-->Error_Muting_Sequence
  Finish

test logicals.safety.plcopen.Error_Muting_Sequnece_To_Wait_For_Reset
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#10ms         T#10ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#C034    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at MS_12 AND MS_11 AND NOT R_TRIG at MS_11-->Error_Muting_Sequence
  Data  6     TRUE      T#10ms         T#10ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=NOT (MS_11 OR MS_12)-->Wait_For_Reset
  Finish

test logicals.safety.plcopen.Error_Muting_Sequence_And_Stay_There_For_One_Cycle_1
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#10ms         T#10ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#C034    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at MS_12 AND MS_11 AND NOT R_TRIG at MS_11-->Error_Muting_Sequence
  Data  6     TRUE      T#10ms         T#10ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#C034    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=MS_11-->Error_Muting_Sequence
  Finish

test logicals.safety.plcopen.Error_Muting_Sequence_And_Stay_There_For_One_Cycle_2
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#10ms         T#10ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#C034    TRUE   TRUE    FALSE           FALSE        FALSE            FALSE  doc=R_TRIG at MS_12 AND MS_11 AND NOT R_TRIG at MS_11-->Error_Muting_Sequence
  Data  6     TRUE      T#10ms         T#10ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#C034    TRUE   TRUE    FALSE           FALSE        FALSE            FALSE  doc=MS_12-->Error_Muting_Sequence
  Finish

test SUBCONDITION_CHECK_A_SF_MutingPar_2Sensor_Manual
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE  FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         TRUE         TRUE           TRUE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#50ms         T#1m           TRUE        FALSE          TRUE            FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=SUBCONDITION_CHECK_A FROM 8000 R_TRIG at MS_11 AND MS_12->Error_Muting_Sequence_8000_MS_11_True_MS_12_True
  Data  6     TRUE      T#50ms         T#1m           FALSE        TRUE          TRUE            FALSE   TRUE       FALSE  16#CF34    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=SUBCONDITION_CHECK_A FROM 8000 R_TRIG at MS_11 AND MS_12->Error_Muting_Sequence_8000_MS_11_True_MS_12_True
  Finish

test SUBCONDITION_CHECK_B_SF_MutingPar_2Sensor_Manual
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         TRUE            TRUE            TRUE    TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#50ms         T#1m           TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=SUBCONDITION_CHECK_B FROM 8000 R_TRIG at MS_12 AND MS_11->Error_Muting_Sequence_8000_MS_11_True_MS_12_True
  Data  6     TRUE      T#50ms         T#1m           FALSE         TRUE            TRUE            FALSE   TRUE       FALSE  16#CF34    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=SUBCONDITION_CHECK_B FROM 8000 R_TRIG at MS_12 AND MS_11->Error_Muting_Sequence_8000_MS_11_True_MS_12_True
  Finish

test SUBCONDITION_CHECK_C_SF_MutingPar_2Sensor_Manual
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4     TRUE      T#10ms         T#10ms         FALSE         TRUE            TRUE            FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5     TRUE      T#50ms         T#1m           FALSE         TRUE            TRUE            FALSE   TRUE       FALSE  16#CF34    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=SUBCONDITION_CHECK_C FROM 8000 MS_11 AND MS_12->Error_Muting_Sequence_8000_MS_11_True_MS_12_True
  Finish


#                                                       DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
#@startuml                                              
#skinparam stateFontName Courier
#skinparam stateFontSize 14
#Idle:                                                  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE
#AOPD_Free:                                             16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE
#Init:                                                  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE
#Safety_Demand_AOPD:                                    16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE
#Wait_For_Reset:                                        16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE
#Safe:                                                  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE
#Muting_Start_1:                                        16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE
#Muting_Start_2:                                        16#8310    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE
#Muting_Active:                                         16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Parameter_Error:                                       16#C010    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Error_Timer_Max_Muting:                                16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Error_Timer_Entry:                                     16#C030    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Error_Muting_Sequence_8000_MS_11_True_MS_12_False:     16#CF14    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Error_Muting_Sequence_8000_MS_11_False_MS_12_True:     16#CF24    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Error_Muting_Sequence_8000_MS_11_True_MS_12_True:      16#CF34    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Error_Muting_Sequence_8010_MS_11_True_MS_12_False:     16#CF14    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Error_Muting_Sequence_8010_MS_11_False_MS_12_False:    16#C104    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Error_Muting_Sequence_8310_MS_11_False_MS_12_False:    16#C204    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Error_Muting_Sequence_8310_MS_11_False_MS_12_True:     16#CF24    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#
#T:.                                                                                             Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset   S_AOPD_In  S_StartReset
#T: NOT Activate:                                                                               1     FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE
#T: Activate:                                                                                   1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE
#T: R_TRIG at Reset OR S_StartReset (condition 1):                                              1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           R_EDGE  FALSE      FALSE
#T: R_TRIG at Reset OR S_StartReset (condition 2):                                              1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      TRUE 
#T: R_TRIG at Reset:                                                                            1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           R_EDGE  FALSE      FALSE
#T: DiscTimeEntry out of range_1:                                                               1     TRUE      T#4s1ms        T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE
#T: DiscTimeEntry out of range_2:                                                               1     TRUE      T#-1ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE
#T: MaxMutingTime out of range_1:                                                               1     TRUE      T#10ms         T#120m1ms      FALSE         FALSE           FALSE           FALSE   FALSE      FALSE
#T: MaxMutingTime out of range_2:                                                               1     TRUE      T#10ms         T#-1ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE
#T: DiscTimeEntry exceeds limit:                                                                4     TRUE      T#4s1ms        T#10ms         TRUE          TRUE            TRUE            FALSE   FALSE      FALSE
#T: MaxMutingTime exceeds limit:                                                                5     TRUE      T#10ms         T#120m1ms      FALSE         FALSE           FALSE           FALSE   FALSE      FALSE
#T: NOT S_AOPD_In:                                                                              1     TRUE      T#1s           T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE
#T: S_AOPD_In:                                                                                  1     TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE
#T: NOT MutingEnable AND R_TRIG at MS_11:                                                       1     TRUE      T#35ms         T#45ms         FALSE         R_EDGE          FALSE           FALSE   TRUE       FALSE
#T: MutingEnable AND R_TRIG at MS_11 AND NOT MS_12:                                             1     TRUE      T#35ms         T#45ms         TRUE          R_EDGE          FALSE           FALSE   TRUE       FALSE
#T: MutingEnable AND NOT MS_11 AND R_TRIG at MS_12:                                             1     TRUE      T#35ms         T#45ms         TRUE          FALSE           R_EDGE          FALSE   TRUE       FALSE
#T: MutingEnable AND R_TRIG at MS_11 AND R_TRIG at MS_12:                                       1     TRUE      T#35ms         T#45ms         TRUE          R_EDGE          R_EDGE          FALSE   TRUE       FALSE
#T: MutingEnable AND MS_11 AND R_TRIG at MS_12:                                                 1     TRUE      T#35ms         T#45ms         TRUE          TRUE            R_EDGE          FALSE   TRUE       FALSE
#T: MutingEnable AND R_TRIG at MS_11 AND MS_12:                                                 1     TRUE      T#35ms         T#45ms         TRUE          R_EDGE          TRUE            FALSE   TRUE       FALSE
#T: MS_11 AND MS_12:                                                                            1     TRUE      T#35ms         T#45ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE
#T: NOT_MS_11_AND_NOT_MS_12:                                                                    1     TRUE      T#50ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE
#/'FROM 8000 TO C004'/

#/'The following 3 transitions can't be use with the python script (used for manually written robot tests), but in order to have everything consistently in one place, therefore I leave it here in a comment.'/
#/'T: SUBCONDITION_CHECK_A FROM 8000 R_TRIG at MS_11 AND MS_12:                                   1     TRUE      T#50ms         T#1m           F_EDGE        R_EDGE          TRUE            FALSE   TRUE       FALSE'/
#/'T: SUBCONDITION_CHECK_B FROM 8000 R_TRIG at MS_12 AND MS_11:                                   1     TRUE      T#50ms         T#1m           F_EDGE        TRUE            R_EDGE          FALSE   TRUE       FALSE'/
#/'T: SUBCONDITION_CHECK_C FROM 8000 MS_11 AND MS_12:                                             1     TRUE      T#50ms         T#1m           F_EDGE        STAT_TRUE       STAT_TRUE       FALSE   TRUE       FALSE'/


#T: SUBCONDITION_CHECK_D FROM 8000 NOT MutingEnable AND R_TRIG at MS_11:                        1     TRUE      T#50ms         T#1m           FALSE         R_EDGE          FALSE           FALSE   TRUE       FALSE
#T: SUBCONDITION_CHECK_E FROM 8000 NOT MutingEnable AND R_TRIG at MS_12:                        1     TRUE      T#50ms         T#1m           FALSE         FALSE           R_EDGE          FALSE   TRUE       FALSE


#/'FROM 8010 TO C104'/
#T: SUBCONDITION_CHECK_A FROM 8010 NOT MutingEnable:                                            1     TRUE      T#50ms         T#1m           FALSE         TRUE            FALSE           FALSE   FALSE      FALSE
#T: SUBCONDITION_CHECK_B FROM 8010 NOT MS_11:                                                   1     TRUE      T#50ms         T#1m           TRUE          FALSE           FALSE           FALSE   FALSE      FALSE
#/'FROM 8310 TO C204'/
#T: SUBCONDITION_CHECK_A FROM 8310 NOT MutingEnable:                                            1     TRUE      T#50ms         T#1m           FALSE         FALSE           TRUE            FALSE   FALSE      FALSE
#T: SUBCONDITION_CHECK_B FROM 8310 NOT MS_12:                                                   1     TRUE      T#50ms         T#1m           TRUE          FALSE           FALSE           FALSE   FALSE      FALSE
#/'FROM 8020 TO 8000'/
#T: SUBCONDITION_CHECK_A FROM 8020 NOT MS_11:                                                   1     TRUE      T#50ms         T#1m           FALSE         FALSE           TRUE            FALSE   TRUE       FALSE
#T: SUBCONDITION_CHECK_B FROM 8020 NOT MS_12:                                                   1     TRUE      T#50ms         T#1m           FALSE         TRUE            FALSE           FALSE   TRUE       FALSE
#/'FROM 8000 TO 8802'/
#T: PRIORITY_CHECK_8010 FROM 8000 NOT S_AOPD_In MutingEnable MS_11 NOT MS_12:                   1     TRUE      T#1s           T#1m           TRUE          TRUE            FALSE           FALSE   FALSE      FALSE
#T: PRIORITY_CHECK_8310 FROM 8000 NOT S_AOPD_In MutingEnable NOT MS_11 MS_12:                   1     TRUE      T#1s           T#1m           TRUE          FALSE           TRUE            FALSE   FALSE      FALSE
#T: PRIORITY_CHECK_8020 FROM 8000 NOT S_AOPD_In MutingEnable MS_11 MS_12:                       1     TRUE      T#1s           T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE
#/'FROM 8010, 8310 TO 8802'/
#T: PRIORITY_CHECK_8020 FROM 8010-8310 NOT S_AOPD_In MutingEnable MS_11 MS_12:                  1     TRUE      T#1s           T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE
#/'FROM 8010, 8310 TO C030'/
#T: PRIORITY_CHECK_8020 FROM 8010-8310 DiscTimeEntry exceeds limit MutingEnable MS_11 MS_12:    4     TRUE      T#5ms          T#1m           TRUE          TRUE            TRUE            FALSE   TRUE       FALSE
#/'FROM 8020 TO C020'/
#T: PRIORITY_CHECK_8000 FROM 8020 MaxMutingTime exceeds limit MutingEnable MS_11 MS_12:         5     TRUE      T#5ms          T#1m           TRUE          TRUE            TRUE            FALSE   TRUE       FALSE
#
#[*]-->Idle: NOT Activate
#Idle-->Init: Activate
#Init-->Init: Activate 
#Init-->Parameter_Error: DiscTimeEntry out of range_1
#Init-->Parameter_Error: DiscTimeEntry out of range_2
#Init-->Parameter_Error: MaxMutingTime out of range_1
#Init-->Parameter_Error: MaxMutingTime out of range_2
#Init-->Safe: R_TRIG at Reset OR S_StartReset (condition 1)
#Init-->Safe: R_TRIG at Reset OR S_StartReset (condition 2)
#Safe-->Safety_Demand_AOPD: NOT S_AOPD_In
#Safe-->AOPD_Free: S_AOPD_In
#Safety_Demand_AOPD-->Wait_For_Reset: S_AOPD_In
#Wait_For_Reset-->Safe: R_TRIG at Reset
#Safety_Demand_AOPD-->Safety_Demand_AOPD: NOT S_AOPD_In
#AOPD_Free-->Safety_Demand_AOPD: NOT S_AOPD_In
#AOPD_Free-->Muting_Start_1: MutingEnable AND R_TRIG at MS_11 AND NOT MS_12
#AOPD_Free-->Muting_Start_2: MutingEnable AND NOT MS_11 AND R_TRIG at MS_12
#AOPD_Free-->Muting_Active: MutingEnable AND R_TRIG at MS_11 AND R_TRIG at MS_12
#/'AOPD_Free->Error_Muting_Sequence_8000_MS_11_True_MS_12_True: SUBCONDITION_CHECK_A FROM 8000 R_TRIG at MS_11 AND MS_12'/
#/'AOPD_Free->Error_Muting_Sequence_8000_MS_11_True_MS_12_True: SUBCONDITION_CHECK_B FROM 8000 R_TRIG at MS_12 AND MS_11'/
#/'AOPD_Free->Error_Muting_Sequence_8000_MS_11_True_MS_12_True: SUBCONDITION_CHECK_C FROM 8000 MS_11 AND MS_12'/
#AOPD_Free-->Error_Muting_Sequence_8000_MS_11_True_MS_12_False: SUBCONDITION_CHECK_D FROM 8000 NOT MutingEnable AND R_TRIG at MS_11
#AOPD_Free-->Error_Muting_Sequence_8000_MS_11_False_MS_12_True: SUBCONDITION_CHECK_E FROM 8000 NOT MutingEnable AND R_TRIG at MS_12
#Muting_Active-->AOPD_Free: SUBCONDITION_CHECK_A FROM 8020 NOT MS_11
#Muting_Active-->AOPD_Free: SUBCONDITION_CHECK_B FROM 8020 NOT MS_12
#Muting_Active-->Muting_Active: MS_11 AND MS_12
#Muting_Start_1-->Muting_Active: MutingEnable AND MS_11 AND R_TRIG at MS_12
#Muting_Start_1-->Error_Muting_Sequence_8010_MS_11_True_MS_12_False: SUBCONDITION_CHECK_A FROM 8010 NOT MutingEnable
#Muting_Start_1-->Error_Muting_Sequence_8010_MS_11_False_MS_12_False: SUBCONDITION_CHECK_B FROM 8010 NOT MS_11
#Muting_Start_2-->Muting_Active: MutingEnable AND R_TRIG at MS_11 AND MS_12
#Muting_Start_2-->Error_Muting_Sequence_8310_MS_11_False_MS_12_True: SUBCONDITION_CHECK_A FROM 8310 NOT MutingEnable
#Muting_Start_2-->Error_Muting_Sequence_8310_MS_11_False_MS_12_False: SUBCONDITION_CHECK_B FROM 8310 NOT MS_12


#Error_Muting_Sequence_8310_MS_11_False_MS_12_True-->Wait_For_Reset: NOT_MS_11_AND_NOT_MS_12
#Error_Timer_Max_Muting-->Wait_For_Reset: NOT_MS_11_AND_NOT_MS_12
#Error_Timer_Entry-->Wait_For_Reset: NOT_MS_11_AND_NOT_MS_12
#Muting_Start_1-->Error_Timer_Entry: DiscTimeEntry exceeds limit

#/'FROM 8000 TO 8802'/
#AOPD_Free-->Safety_Demand_AOPD: PRIORITY_CHECK_8010 FROM 8000 NOT S_AOPD_In MutingEnable MS_11 NOT MS_12
#AOPD_Free-->Safety_Demand_AOPD: PRIORITY_CHECK_8310 FROM 8000 NOT S_AOPD_In MutingEnable NOT MS_11 MS_12
#AOPD_Free-->Safety_Demand_AOPD: PRIORITY_CHECK_8020 FROM 8000 NOT S_AOPD_In MutingEnable MS_11 MS_12

#/'FROM 8010, 8310 TO 8802'/
#Muting_Start_1-->Safety_Demand_AOPD: PRIORITY_CHECK_8020 FROM 8010-8310 NOT S_AOPD_In MutingEnable MS_11 MS_12
#Muting_Start_2-->Safety_Demand_AOPD: PRIORITY_CHECK_8020 FROM 8010-8310 NOT S_AOPD_In MutingEnable MS_11 MS_12


#/'FROM 8010, 8310 TO C030'/
#Muting_Start_1-->Error_Timer_Entry: PRIORITY_CHECK_8020 FROM 8010-8310 DiscTimeEntry exceeds limit MutingEnable MS_11 MS_12
#Muting_Start_2-->Error_Timer_Entry: PRIORITY_CHECK_8020 FROM 8010-8310 DiscTimeEntry exceeds limit MutingEnable MS_11 MS_12

#/'FROM 8020 TO C020'/
#Muting_Active-->Error_Timer_Max_Muting: PRIORITY_CHECK_8000 FROM 8020 MaxMutingTime exceeds limit MutingEnable MS_11 MS_12

#@enduml

#@begin generated
test SF_MutingPar_2Sensor_0
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Finish

test SF_MutingPar_2Sensor_1
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#4s1ms        T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#C010    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=DiscTimeEntry out of range_1->Parameter_Error
  Finish

test SF_MutingPar_2Sensor_2
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#-1ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#C010    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=DiscTimeEntry out of range_2->Parameter_Error
  Finish

test SF_MutingPar_2Sensor_3
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#120m1ms      FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#C010    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=MaxMutingTime out of range_1->Parameter_Error
  Finish

test SF_MutingPar_2Sensor_4
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#-1ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#C010    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=MaxMutingTime out of range_2->Parameter_Error
  Finish

test SF_MutingPar_2Sensor_5
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      TRUE   16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 2)->Safe
  Finish

test SF_MutingPar_2Sensor_6
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#1s           T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=NOT S_AOPD_In->Safety_Demand_AOPD
  Data  5       TRUE      T#1s           T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=NOT S_AOPD_In->Safety_Demand_AOPD
  Finish

test SF_MutingPar_2Sensor_7
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#1s           T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=NOT S_AOPD_In->Safety_Demand_AOPD
  Finish

test SF_MutingPar_2Sensor_8
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#50ms         T#1m           FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=SUBCONDITION_CHECK_D FROM 8000 NOT MutingEnable AND R_TRIG at MS_11->Error_Muting_Sequence_8000_MS_11_True_MS_12_False
  Data  6       TRUE      T#50ms         T#1m           FALSE         TRUE            FALSE           FALSE   TRUE       FALSE  16#CF14    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=SUBCONDITION_CHECK_D FROM 8000 NOT MutingEnable AND R_TRIG at MS_11->Error_Muting_Sequence_8000_MS_11_True_MS_12_False
  Finish

test SF_MutingPar_2Sensor_9
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#50ms         T#1m           FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=SUBCONDITION_CHECK_E FROM 8000 NOT MutingEnable AND R_TRIG at MS_12->Error_Muting_Sequence_8000_MS_11_False_MS_12_True
  Data  6       TRUE      T#50ms         T#1m           FALSE         FALSE           TRUE            FALSE   TRUE       FALSE  16#CF24    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=SUBCONDITION_CHECK_E FROM 8000 NOT MutingEnable AND R_TRIG at MS_12->Error_Muting_Sequence_8000_MS_11_False_MS_12_True
  Finish

test SF_MutingPar_2Sensor_10
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#1s           T#1m           TRUE          TRUE            FALSE           FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=PRIORITY_CHECK_8010 FROM 8000 NOT S_AOPD_In MutingEnable MS_11 NOT MS_12->Safety_Demand_AOPD
  Finish

test SF_MutingPar_2Sensor_11
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#1s           T#1m           TRUE          FALSE           TRUE            FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=PRIORITY_CHECK_8310 FROM 8000 NOT S_AOPD_In MutingEnable NOT MS_11 MS_12->Safety_Demand_AOPD
  Finish

test SF_MutingPar_2Sensor_12
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#1s           T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=PRIORITY_CHECK_8020 FROM 8000 NOT S_AOPD_In MutingEnable MS_11 MS_12->Safety_Demand_AOPD
  Finish

test SF_MutingPar_2Sensor_13
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#1s           T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=NOT S_AOPD_In->Safety_Demand_AOPD
  Data  5       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=S_AOPD_In->Wait_For_Reset
  Data  6       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset->Safe
  Data  7       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset->Safe
  Finish

test SF_MutingPar_2Sensor_14
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6       TRUE      T#35ms         T#45ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  7       TRUE      T#35ms         T#45ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND MS_11 AND R_TRIG at MS_12->Muting_Active
  Data  8       TRUE      T#35ms         T#45ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=MutingEnable AND MS_11 AND R_TRIG at MS_12->Muting_Active
  Finish

test SF_MutingPar_2Sensor_15
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6       TRUE      T#35ms         T#45ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  7       TRUE      T#50ms         T#1m           FALSE         TRUE            FALSE           FALSE   FALSE      FALSE  16#CF14    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=SUBCONDITION_CHECK_A FROM 8010 NOT MutingEnable->Error_Muting_Sequence_8010_MS_11_True_MS_12_False
  Finish

test SF_MutingPar_2Sensor_16
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6       TRUE      T#35ms         T#45ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  7       TRUE      T#50ms         T#1m           TRUE          FALSE           FALSE           FALSE   FALSE      FALSE  16#C104    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=SUBCONDITION_CHECK_B FROM 8010 NOT MS_11->Error_Muting_Sequence_8010_MS_11_False_MS_12_False
  Finish

test SF_MutingPar_2Sensor_17
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6       TRUE      T#35ms         T#45ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  7       TRUE      T#1s           T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=PRIORITY_CHECK_8020 FROM 8010-8310 NOT S_AOPD_In MutingEnable MS_11 MS_12->Safety_Demand_AOPD
  Finish

test SF_MutingPar_2Sensor_18
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6       TRUE      T#35ms         T#45ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  10      TRUE      T#5ms          T#1m           TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#C030    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=PRIORITY_CHECK_8020 FROM 8010-8310 DiscTimeEntry exceeds limit MutingEnable MS_11 MS_12->Error_Timer_Entry
  Finish

test SF_MutingPar_2Sensor_19
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  6       TRUE      T#35ms         T#45ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#8310    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  7       TRUE      T#35ms         T#45ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#8310    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND MS_12->Muting_Active
  Data  8       TRUE      T#35ms         T#45ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND MS_12->Muting_Active
  Finish

test SF_MutingPar_2Sensor_20
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  6       TRUE      T#35ms         T#45ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#8310    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  7       TRUE      T#50ms         T#1m           TRUE          FALSE           FALSE           FALSE   FALSE      FALSE  16#C204    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=SUBCONDITION_CHECK_B FROM 8310 NOT MS_12->Error_Muting_Sequence_8310_MS_11_False_MS_12_False
  Finish

test SF_MutingPar_2Sensor_21
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  6       TRUE      T#35ms         T#45ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#8310    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  7       TRUE      T#1s           T#1m           TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=PRIORITY_CHECK_8020 FROM 8010-8310 NOT S_AOPD_In MutingEnable MS_11 MS_12->Safety_Demand_AOPD
  Finish

test SF_MutingPar_2Sensor_22
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  6       TRUE      T#35ms         T#45ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#8310    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  10      TRUE      T#5ms          T#1m           TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#C030    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=PRIORITY_CHECK_8020 FROM 8010-8310 DiscTimeEntry exceeds limit MutingEnable MS_11 MS_12->Error_Timer_Entry
  Finish

test SF_MutingPar_2Sensor_23
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND R_TRIG at MS_12->Muting_Active
  Data  6       TRUE      T#35ms         T#45ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND R_TRIG at MS_12->Muting_Active
  Data  7       TRUE      T#50ms         T#1m           FALSE         FALSE           TRUE            FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=SUBCONDITION_CHECK_A FROM 8020 NOT MS_11->AOPD_Free
  Finish

test SF_MutingPar_2Sensor_24
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND R_TRIG at MS_12->Muting_Active
  Data  6       TRUE      T#35ms         T#45ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND R_TRIG at MS_12->Muting_Active
  Data  7       TRUE      T#50ms         T#1m           FALSE         TRUE            FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=SUBCONDITION_CHECK_B FROM 8020 NOT MS_12->AOPD_Free
  Finish

test SF_MutingPar_2Sensor_25
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND R_TRIG at MS_12->Muting_Active
  Data  6       TRUE      T#35ms         T#45ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND R_TRIG at MS_12->Muting_Active
  Data  7       TRUE      T#35ms         T#45ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=MS_11 AND MS_12->Muting_Active
  Finish

test SF_MutingPar_2Sensor_26
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  6       TRUE      T#35ms         T#45ms         TRUE          TRUE            FALSE           FALSE   TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND NOT MS_12->Muting_Start_1
  Data  10      TRUE      T#4s1ms        T#10ms         TRUE          TRUE            TRUE            FALSE   FALSE      FALSE  16#C030    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=DiscTimeEntry exceeds limit->Error_Timer_Entry
  Data  11      TRUE      T#50ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=NOT_MS_11_AND_NOT_MS_12->Wait_For_Reset
  Finish

test SF_MutingPar_2Sensor_27
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  6       TRUE      T#35ms         T#45ms         TRUE          FALSE           TRUE            FALSE   TRUE       FALSE  16#8310    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND NOT MS_11 AND R_TRIG at MS_12->Muting_Start_2
  Data  7       TRUE      T#50ms         T#1m           FALSE         FALSE           TRUE            FALSE   FALSE      FALSE  16#CF24    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=SUBCONDITION_CHECK_A FROM 8310 NOT MutingEnable->Error_Muting_Sequence_8310_MS_11_False_MS_12_True
  Data  8       TRUE      T#50ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=NOT_MS_11_AND_NOT_MS_12->Wait_For_Reset
  Finish

test SF_MutingPar_2Sensor_28
  Head  Time  Activate  DiscTimeEntry  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_Out?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  3       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           TRUE    FALSE      FALSE  16#8804    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_TRIG at Reset OR S_StartReset (condition 1)->Safe
  Data  4       TRUE      T#10ms         T#10ms         FALSE         FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_In->AOPD_Free
  Data  5       TRUE      T#35ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND R_TRIG at MS_12->Muting_Active
  Data  6       TRUE      T#35ms         T#45ms         TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=MutingEnable AND R_TRIG at MS_11 AND R_TRIG at MS_12->Muting_Active
  Data  11      TRUE      T#5ms          T#1m           TRUE          TRUE            TRUE            FALSE   TRUE       FALSE  16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=PRIORITY_CHECK_8000 FROM 8020 MaxMutingTime exceeds limit MutingEnable MS_11 MS_12->Error_Timer_Max_Muting
  Data  12      TRUE      T#50ms         T#45ms         TRUE          FALSE           FALSE           FALSE   TRUE       FALSE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=NOT_MS_11_AND_NOT_MS_12->Wait_For_Reset
  Finish

