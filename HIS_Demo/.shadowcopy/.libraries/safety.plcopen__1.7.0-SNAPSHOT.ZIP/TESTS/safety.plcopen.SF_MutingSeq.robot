*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_MutingSeq		MaxDataRows=100		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  MaxMutingTime=T#10m
...  MutingEnable=FALSE
...  MutingSwitch11=FALSE
...  MutingSwitch12=FALSE
...  MutingSwitch21=FALSE
...  MutingSwitch22=FALSE
...  Reset=FALSE
...  S_AOPD_In=16#00
...  S_StartReset=16#00
*** Test Cases ***
test logicals.safety.plcopen.NOT_Activate_From_AOPD_Free
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0     FALSE     T#10m         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE          16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      T#10m         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE          16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE     doc=Activate->Init
  Data  2     TRUE      T#10m         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE           16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE     doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3     TRUE      T#10m         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE           16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE     doc=S_AOPD_IN->AOPD_Free
  Data  4     FALSE     T#10m         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE          16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE     doc=NOT Activate->Idle
  Data  5     TRUE      T#10m         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE          16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE     doc=Activate->Init
  Data  6     TRUE      T#10m         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE           16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE     doc=R_Trig at Reset OR S_StartReset->Safe
  Data  7     TRUE      T#10m         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE           16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE     doc=S_AOPD_IN->AOPD_Free

test logicals.safety.plcopen.SF_MutingSeq_
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data    0     FALSE     T#20ms         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE         16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE            doc=NOT Activate->Idle
  Data    1     TRUE      T#20ms         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE         16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE            doc=Activate->Init
  Data    2     FALSE     T#20ms         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE         16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE            doc=NOT Activate->Idle
  Finish
  
test logicals.safety.plcopen.SF_MutingSeq_Invalid_State
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  ENO?             CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0              0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0              0
  Init    /     /         /              /             /               /               /               /               /      /          /             16#9999    TRUE    FALSE   TRUE           FALSE        FALSE            FALSE          FALSE
  Data    0     TRUE      T#20ms         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE         16#9999    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE          FALSE            doc=NOT Activate->Idle
  Data    1     TRUE      T#20ms         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE         16#9999    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE          FALSE            doc=NOT Activate->Idle
  Data    2     FALSE     T#20ms         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE         16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE          FALSE            doc=NOT Activate->Idle
  Data    3     TRUE      T#20ms         FALSE         FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE         16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE          FALSE            doc=NOT Activate->Idle
  Finish


# Some states have a Suffix _x, e.g. Muting_Forward_Active_1. This indicates that the State in the state diagram change actually consists of multiples
# substates that need to be traversed before the condition for one of the exits can be reached (e.g. Muting sequences, see spec).
# Wrong_Muting_Sequence_8XXX_Y means that the Muting Sequence error occurred in state 8XXX, for the condition (index in OR sequence in spec) Y.
# Wrong_Muting_Sequence_8XXX_F means that the Muting Enable variable was FALSE in one of the muting states.
#
#                                     DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand? CycleTime=T#10ms
#@startuml
#skinparam stateFontName Courier
#skinparam stateFontSize 14
#Idle:                                16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE
#Init:                                16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE
#Init_AND_Reset:                      16#8401    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE
#Reset_Error_1:                       16#C001    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Parameter_Error:                     16#C010    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Safe:                                16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE
#Safety_Demand_AOPD:                  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE
#Wait_for_Reset:                      16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE
#Wait_for_Reset_AND_Reset:            16#8402    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE
#Reset_Error_2:                       16#C011    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#AOPD_Free:                           16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE
#Error_Muting_Sequence_Base:          16#C004    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Muting_Forward_Start:                16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE
#Muting_Forward_Active:               16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Muting_Forward_Active_short_timer:   16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Muting_Forward_Active_1:             16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Muting_Forward_Active_2:             16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Muting_Forward_Active_3:             16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Muting_Forward_Active_4:             16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Wrong_Muting_Sequence_8000:          16#C034    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8000_F:        16#CF14    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8010:          16#C154    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8010_F:        16#CF14    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8020_F:        16#CF74    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8020_1:        16#C274    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8020_2:        16#C254    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8020_3:        16#C234    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8020_4:        16#C264    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8020_5:        16#C2D4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8020_7:        16#C2F4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8020_8:        16#C234    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8020_9:        16#C284    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Muting_Backward_Start:               16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE
#Wrong_Muting_Sequence_8120_F:        16#CF84    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8120_1:        16#C394    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Muting_Backward_Active_short_timer:  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Muting_Backward_Active:              16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Wrong_Muting_Sequence_8110_F:        16#CFC4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8110_1:        16#C4E4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8110_2:        16#C484    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8110_3:        16#C4D4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8110_4:        16#C404    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8110_5:        16#C4D4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8110_7:        16#C4F4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8110_8:        16#C434    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Wrong_Muting_Sequence_8110_9:        16#C414    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#Muting_Backward_Active_1:            16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Muting_Backward_Active_2:            16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Muting_Backward_Active_3:            16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Muting_Backward_Active_4:            16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Muting_Backward_Active_5:            16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE
#Error_Timer_MaxMuting:               16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE
#
#T:.                                                       Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset
#T:NOT Activate:                                           1     FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE
#T:Activate:                                               1     TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE
#T:Activate AND Reset:                                     1     TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   FALSE      FALSE
#T:NOT Reset:                                              1     TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE
#T:Time parameter out of range1:                           1     TRUE      T#121m        FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE
#T:Time parameter out of range2:                           1     TRUE      T#-1m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE
#T:R_Trig at Reset OR S_StartReset:                        1     TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE
#T:NOT S_AOPD_IN:                                          1     TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE
#T:S_AOPD_IN:                                              1     TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE
#T:S_AOPD_IN AND Reset:                                    1     TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   TRUE       TRUE
#T:R_Trig at Reset:                                        1     TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   TRUE       TRUE
#T:Wrong Muting Sequence 8000:                             1     TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       TRUE
#T:NOT (MS11 OR MS12 OR MS21 OR MS22):                     1     TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE
#T:Wrong Muting Sequence 8000 F:                           1     TRUE      T#10m         FALSE          TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       TRUE
#T:Muting condition 1:                                     1     TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE
#T:Wrong Muting Sequence 8010:                             1     TRUE      T#10m         TRUE           TRUE            FALSE           TRUE            FALSE           FALSE  TRUE       FALSE
#T:Wrong Muting Sequence 8010 F:                           1     TRUE      T#10m         FALSE          TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE
#T:Muting condition 2:                                     1     TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE
#T:Muting forward NOT S_AOPD_IN:                           1     TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  FALSE      FALSE
#T:Muting condition 2 short timer:                         1     TRUE      T#20ms        TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE
#T:Muting forward timer expired:                           3     TRUE      T#20ms        TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE
#T:Wrong Muting Sequence 8020 F:                           1     TRUE      T#10m         FALSE          TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE
#T:Wrong Muting Sequence 8020 2:                           1     TRUE      T#10m         TRUE           TRUE            FALSE           TRUE            FALSE           FALSE  TRUE       FALSE
#T:Wrong Muting Sequence 8020 3:                           1     TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE
#T:Wrong Muting Sequence 8020 4:                           1     TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            FALSE           FALSE  TRUE       FALSE
#T:Wrong Muting Sequence 8020 5:                           1     TRUE      T#10m         TRUE           TRUE            FALSE           TRUE            TRUE            FALSE  TRUE       FALSE
#T:Wrong Muting Sequence 8020 7:                           1     TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       FALSE
#T:Muting forward 1:                                       1     TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE
#T:Muting forward 2:                                       1     TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       FALSE
#T:Muting forward 3:                                       1     TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       FALSE
#T:Muting forward 4:                                       1     TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       FALSE
#T:Wrong Muting Sequence 8020 1:                           1     TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE
#T:Wrong Muting Sequence 8020 8:                           1     TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE
#T:Wrong Muting Sequence 8020 9:                           1     TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       FALSE
#T:Muting condition 3:                                     1     TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       FALSE
#T:Muting condition 11:                                    1     TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE
#T:Muting backward start NOT S_AOPD_In:                    1     TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  FALSE      TRUE
#T:Wrong Muting Sequence 8110 F:                           1     TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE
#T:Wrong Muting Sequence 8110 1:                           1     TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           TRUE            FALSE  TRUE       TRUE
#T:Muting condition 12:                                    1     TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE
#T:Wrong Muting Sequence 8120 F:                           1     TRUE      T#10m         FALSE          FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE
#T:Wrong Muting Sequence 8120 5:                           1     TRUE      T#10m         TRUE           TRUE            FALSE           TRUE            TRUE            FALSE  TRUE       TRUE
#T:Wrong Muting Sequence 8120 2:                           1     TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE
#T:Wrong Muting Sequence 8120 4:                           1     TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE
#T:Muting condition 12 short timer:                        1     TRUE      T#20ms        TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE
#T:Muting backward timer expired:                          3     TRUE      T#20ms        TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE
#T:Muting backward 1:                                      1     TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE
#T:Muting backward 2:                                      1     TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       TRUE
#T:Muting backward 3:                                      1     TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       TRUE
#T:Muting backward 4:                                      1     TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       TRUE
#T:Wrong Muting Sequence 8120 1:                           1     TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE
#T:Wrong Muting Sequence 8120 3:                           1     TRUE      T#10m         TRUE           TRUE            FALSE           TRUE            TRUE            FALSE  TRUE       TRUE
#T:Wrong Muting Sequence 8120 8:                           1     TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       TRUE
#T:Wrong Muting Sequence 8120 9:                           1     TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       TRUE
#T:Wrong Muting Sequence 8120 7:                           1     TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       TRUE
#T:Muting condition 13:                                    1     TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       TRUE
#
#T:PRIORITY_CHECK_8020 FROM 8010 TO 8802:                  1     TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  FALSE      FALSE
#T:PRIORITY_CHECK_8110 FROM 8120 TO 8802:                  1     TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  FALSE      TRUE
#
#T:PRIORITY_CHECK_8000 FROM 8020 TO C020:                  3     TRUE      T#20ms        TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE
#T:PRIORITY_CHECK_8000 FROM 8110 TO C020:                  3     TRUE      T#20ms        TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE
#
#/'                                                        Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset '/
#T:COMBO_CHECK_8000_5 FROM 8020 TO CXY4:                   1     TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       FALSE
#T:COMBO_CHECK_8000_8 FROM 8020 TO CXY4:                   1     TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       FALSE
#T:COMBO_CHECK_8000_9 FROM 8020 TO CXY4:                   1     TRUE      T#10m         TRUE           FALSE           F_EDGE          F_EDGE          TRUE            FALSE  TRUE       FALSE
#
#T:PRIORITY_CHECK_8010 FROM 8000 TO 8802:                  1     TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  FALSE      FALSE
#T:PRIORITY_CHECK_8120 FROM 8000 TO 8802:                  1     TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  FALSE      TRUE
#
#T:COMBO_CHECK_8000_5 FROM 8110 TO CXY4:                   1     TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE
#T:COMBO_CHECK_8000_8 FROM 8110 TO CXY4:                   1     TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE
#T:COMBO_CHECK_8000_9 FROM 8110 TO CXY4:                   1     TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE
#
#[*]-->Idle:NOT Activate
#AOPD_Free-->Safety_Demand_AOPD:PRIORITY_CHECK_8010 FROM 8000 TO 8802
#AOPD_Free-->Safety_Demand_AOPD:PRIORITY_CHECK_8120 FROM 8000 TO 8802
#Muting_Backward_Active_1-->Wrong_Muting_Sequence_8110_9:COMBO_CHECK_8000_5 FROM 8110 TO CXY4
#Muting_Backward_Active_2-->Wrong_Muting_Sequence_8110_9:COMBO_CHECK_8000_8 FROM 8110 TO CXY4
#Muting_Backward_Active_3-->Wrong_Muting_Sequence_8110_9:COMBO_CHECK_8000_9 FROM 8110 TO CXY4
#Idle-->Idle:NOT Activate
#Idle-->Init:Activate
#Init-->Init:Activate
#Init-->Idle:NOT Activate
#Idle-->Init_AND_Reset:Activate AND Reset
#Init_AND_Reset-->Reset_Error_1:Activate AND Reset
#Reset_Error_1-->Reset_Error_1:Activate AND Reset
#Init-->Parameter_Error:Time parameter out of range1
#Init-->Parameter_Error:Time parameter out of range2
#Reset_Error_1-->Init:NOT Reset
#Init-->Safe:R_Trig at Reset OR S_StartReset
#Safe-->Idle:NOT Activate
#Safe-->Safety_Demand_AOPD:NOT S_AOPD_IN
#Safety_Demand_AOPD-->Safety_Demand_AOPD:NOT S_AOPD_IN
#Safe-->AOPD_Free:S_AOPD_IN
#Safety_Demand_AOPD-->Wait_for_Reset:S_AOPD_IN
#Wait_for_Reset-->Wait_for_Reset:S_AOPD_IN
#Safety_Demand_AOPD-->Wait_for_Reset_AND_Reset:S_AOPD_IN AND Reset
#Wait_for_Reset-->Safe:R_Trig at Reset
#Wait_for_Reset_AND_Reset-->Reset_Error_2:S_AOPD_IN AND Reset
#Reset_Error_2-->Reset_Error_2:S_AOPD_IN AND Reset
#Reset_Error_2-->Wait_for_Reset:NOT Reset
#AOPD_Free-->AOPD_Free:S_AOPD_IN
#AOPD_Free-->Wrong_Muting_Sequence_8000:Wrong Muting Sequence 8000
#AOPD_Free-->Wrong_Muting_Sequence_8000_F:Wrong Muting Sequence 8000 F
#AOPD_Free-->Safety_Demand_AOPD:NOT S_AOPD_IN
#AOPD_Free-->Muting_Forward_Start:Muting condition 1
#Muting_Forward_Start-->Muting_Forward_Start:Muting condition 1
#Muting_Forward_Start-->Muting_Forward_Active:Muting condition 2
#Muting_Forward_Start-->Safety_Demand_AOPD:Muting forward NOT S_AOPD_IN
#Muting_Forward_Start-->Muting_Forward_Active_short_timer:Muting condition 2 short timer
#Muting_Forward_Start-->Wrong_Muting_Sequence_8010:Wrong Muting Sequence 8010
#Muting_Forward_Start-->Safety_Demand_AOPD: PRIORITY_CHECK_8020 FROM 8010 TO 8802
#Wrong_Muting_Sequence_8010-->Wrong_Muting_Sequence_8010:Wrong Muting Sequence 8010
#Muting_Forward_Start-->Wrong_Muting_Sequence_8010_F:Wrong Muting Sequence 8010 F
#Muting_Forward_Active_short_timer-->Error_Timer_MaxMuting:Muting forward timer expired
#Muting_Forward_Active_short_timer-->Error_Timer_MaxMuting:PRIORITY_CHECK_8000 FROM 8020 TO C020
#Error_Timer_MaxMuting-->Error_Timer_MaxMuting:Muting forward timer expired
#Error_Timer_MaxMuting-->Wait_for_Reset:NOT (MS11 OR MS12 OR MS21 OR MS22)
#Muting_Forward_Active-->Muting_Forward_Active:Muting condition 2
#Muting_Forward_Active-->Muting_Forward_Active_1:Muting forward 1
#Muting_Forward_Active-->Wrong_Muting_Sequence_8020_F:Wrong Muting Sequence 8020 F
#Wrong_Muting_Sequence_8020_F-->Wait_for_Reset:NOT (MS11 OR MS12 OR MS21 OR MS22)
#Muting_Forward_Active-->Wrong_Muting_Sequence_8020_5:Wrong Muting Sequence 8020 5
#Muting_Forward_Active_1-->Wrong_Muting_Sequence_8020_9:COMBO_CHECK_8000_5 FROM 8020 TO CXY4
#Muting_Forward_Active-->Wrong_Muting_Sequence_8020_7:Wrong Muting Sequence 8020 7
#Muting_Forward_Active_2-->Wrong_Muting_Sequence_8020_9:COMBO_CHECK_8000_8 FROM 8020 TO CXY4
#Muting_Forward_Active_1-->Wrong_Muting_Sequence_8020_2:Wrong Muting Sequence 8020 2
#Muting_Forward_Active_1-->Wrong_Muting_Sequence_8020_3:Wrong Muting Sequence 8020 3
#Muting_Forward_Active_1-->Wrong_Muting_Sequence_8020_4:Wrong Muting Sequence 8020 4
#Muting_Forward_Active_1-->Muting_Forward_Active_2:Muting forward 2
#Muting_Forward_Active_2-->Wrong_Muting_Sequence_8020_1:Wrong Muting Sequence 8020 1
#Muting_Forward_Active_2-->Muting_Forward_Active_3:Muting forward 3
#Muting_Forward_Active_2-->Wrong_Muting_Sequence_8020_8:Wrong Muting Sequence 8020 8
#Muting_Forward_Active_3-->Muting_Forward_Active_4:Muting forward 4
#Muting_Forward_Active_3-->Wrong_Muting_Sequence_8020_9:Wrong Muting Sequence 8020 9
#Muting_Forward_Active_3-->Wrong_Muting_Sequence_8020_9:COMBO_CHECK_8000_9 FROM 8020 TO CXY4
#Muting_Forward_Active_4-->AOPD_Free:Muting condition 3
#AOPD_Free-->Muting_Backward_Start:Muting condition 11
#Muting_Backward_Start-->Muting_Backward_Start:Muting condition 11
#Muting_Backward_Start-->Safety_Demand_AOPD:Muting backward start NOT S_AOPD_In
#Muting_Backward_Start-->Wrong_Muting_Sequence_8120_F:Wrong Muting Sequence 8110 F
#Muting_Backward_Start-->Wrong_Muting_Sequence_8120_1:Wrong Muting Sequence 8110 1
#Muting_Backward_Start-->Muting_Backward_Active:Muting condition 12
#Muting_Backward_Start-->Safety_Demand_AOPD:PRIORITY_CHECK_8110 FROM 8120 TO 8802
#Muting_Backward_Active-->Muting_Backward_Active:Muting condition 12
#Muting_Backward_Active-->Wrong_Muting_Sequence_8110_F:Wrong Muting Sequence 8120 F
#Muting_Backward_Active-->Muting_Backward_Active:Muting condition 12
#Muting_Backward_Active-->Muting_Backward_Active_1:Muting backward 1
#Muting_Backward_Active-->Wrong_Muting_Sequence_8110_2:Wrong Muting Sequence 8120 2
#Muting_Backward_Active-->Wrong_Muting_Sequence_8110_4:Wrong Muting Sequence 8120 4
#Muting_Backward_Active-->Wrong_Muting_Sequence_8110_5:Wrong Muting Sequence 8120 5
#Muting_Backward_Active_1-->Muting_Backward_Active_2:Muting backward 2
#Muting_Backward_Active_2-->Muting_Backward_Active_3:Muting backward 3
#Muting_Backward_Active_2-->Wrong_Muting_Sequence_8110_1:Wrong Muting Sequence 8120 1
#Muting_Backward_Active_2-->Wrong_Muting_Sequence_8110_3:Wrong Muting Sequence 8120 3
#Muting_Backward_Active_2-->Wrong_Muting_Sequence_8110_8:Wrong Muting Sequence 8120 8
#Muting_Backward_Active_3-->Muting_Backward_Active_4:Muting backward 4
#Muting_Backward_Active_3-->Wrong_Muting_Sequence_8110_9:Wrong Muting Sequence 8120 9
#Muting_Backward_Active_4-->AOPD_Free:Muting condition 13
#Muting_Backward_Active_4-->Wrong_Muting_Sequence_8110_7:Wrong Muting Sequence 8120 7
#Muting_Backward_Start-->Muting_Backward_Active_short_timer:Muting condition 12 short timer
#Muting_Backward_Active_short_timer-->Error_Timer_MaxMuting:Muting backward timer expired
#Muting_Backward_Active_short_timer-->Error_Timer_MaxMuting:PRIORITY_CHECK_8000 FROM 8110 TO C020
#@enduml
#@begin generated
test logicals.safety.plcopen.SF_MutingSeq_0
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_MutingSeq_1
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Finish

test logicals.safety.plcopen.SF_MutingSeq_2
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_MutingSeq_3
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#121m        FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#C010    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Time parameter out of range1->Parameter_Error
  Finish

test logicals.safety.plcopen.SF_MutingSeq_4
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#-1m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#C010    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Time parameter out of range2->Parameter_Error
  Finish

test logicals.safety.plcopen.SF_MutingSeq_5
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_MutingSeq_6
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   FALSE      FALSE  16#8401    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=Activate AND Reset->Init_AND_Reset
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   FALSE      FALSE  16#C001    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Activate AND Reset->Reset_Error_1
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   FALSE      FALSE  16#C001    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Activate AND Reset->Reset_Error_1
  Finish

test logicals.safety.plcopen.SF_MutingSeq_7
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   FALSE      FALSE  16#8401    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=Activate AND Reset->Init_AND_Reset
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   FALSE      FALSE  16#C001    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Activate AND Reset->Reset_Error_1
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=NOT Reset->Init
  Finish

test logicals.safety.plcopen.SF_MutingSeq_8
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=NOT S_AOPD_IN->Safety_Demand_AOPD
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=NOT S_AOPD_IN->Safety_Demand_AOPD
  Finish

test logicals.safety.plcopen.SF_MutingSeq_9
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=PRIORITY_CHECK_8010 FROM 8000 TO 8802->Safety_Demand_AOPD
  Finish

test logicals.safety.plcopen.SF_MutingSeq_10
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  FALSE      TRUE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=PRIORITY_CHECK_8120 FROM 8000 TO 8802->Safety_Demand_AOPD
  Finish

test logicals.safety.plcopen.SF_MutingSeq_11
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Finish

test logicals.safety.plcopen.SF_MutingSeq_12
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       TRUE  16#C034    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8000->Wrong_Muting_Sequence_8000
  Finish

test logicals.safety.plcopen.SF_MutingSeq_13
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         FALSE          TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#CF14    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8000 F->Wrong_Muting_Sequence_8000_F
  Finish

test logicals.safety.plcopen.SF_MutingSeq_14
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=NOT S_AOPD_IN->Safety_Demand_AOPD
  Finish

test logicals.safety.plcopen.SF_MutingSeq_15
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=NOT S_AOPD_IN->Safety_Demand_AOPD
  Data  4       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=S_AOPD_IN->Wait_for_Reset
  Data  5       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=S_AOPD_IN->Wait_for_Reset
  Finish

test logicals.safety.plcopen.SF_MutingSeq_16
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=NOT S_AOPD_IN->Safety_Demand_AOPD
  Data  4       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=S_AOPD_IN->Wait_for_Reset
  Data  5       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   TRUE       TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset->Safe
  Finish

test logicals.safety.plcopen.SF_MutingSeq_17
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Finish

test logicals.safety.plcopen.SF_MutingSeq_18
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=Muting forward NOT S_AOPD_IN->Safety_Demand_AOPD
  Finish

test logicals.safety.plcopen.SF_MutingSeq_19
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  FALSE      FALSE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=PRIORITY_CHECK_8020 FROM 8010 TO 8802->Safety_Demand_AOPD
  Finish

test logicals.safety.plcopen.SF_MutingSeq_20
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         FALSE          TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#CF14    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8010 F->Wrong_Muting_Sequence_8010_F
  Finish

test logicals.safety.plcopen.SF_MutingSeq_21
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Finish

test logicals.safety.plcopen.SF_MutingSeq_22
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  FALSE      TRUE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=Muting backward start NOT S_AOPD_In->Safety_Demand_AOPD
  Finish

test logicals.safety.plcopen.SF_MutingSeq_23
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#CF84    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8110 F->Wrong_Muting_Sequence_8120_F
  Finish

test logicals.safety.plcopen.SF_MutingSeq_24
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#C394    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8110 1->Wrong_Muting_Sequence_8120_1
  Finish

test logicals.safety.plcopen.SF_MutingSeq_25
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  FALSE      TRUE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=PRIORITY_CHECK_8110 FROM 8120 TO 8802->Safety_Demand_AOPD
  Finish

test logicals.safety.plcopen.SF_MutingSeq_26
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=NOT S_AOPD_IN->Safety_Demand_AOPD
  Data  4       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   TRUE       TRUE  16#8402    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=S_AOPD_IN AND Reset->Wait_for_Reset_AND_Reset
  Data  5       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   TRUE       TRUE  16#C011    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=S_AOPD_IN AND Reset->Reset_Error_2
  Data  6       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   TRUE       TRUE  16#C011    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=S_AOPD_IN AND Reset->Reset_Error_2
  Finish

test logicals.safety.plcopen.SF_MutingSeq_27
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8802    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE  doc=NOT S_AOPD_IN->Safety_Demand_AOPD
  Data  4       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   TRUE       TRUE  16#8402    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=S_AOPD_IN AND Reset->Wait_for_Reset_AND_Reset
  Data  5       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           TRUE   TRUE       TRUE  16#C011    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=S_AOPD_IN AND Reset->Reset_Error_2
  Data  6       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=NOT Reset->Wait_for_Reset
  Finish

test logicals.safety.plcopen.SF_MutingSeq_28
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Finish

test logicals.safety.plcopen.SF_MutingSeq_29
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            FALSE           TRUE            TRUE            FALSE  TRUE       FALSE  16#C2D4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8020 5->Wrong_Muting_Sequence_8020_5
  Finish

test logicals.safety.plcopen.SF_MutingSeq_30
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       FALSE  16#C2F4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8020 7->Wrong_Muting_Sequence_8020_7
  Finish

test logicals.safety.plcopen.SF_MutingSeq_31
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#20ms        TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2 short timer->Muting_Forward_Active_short_timer
  Data  8       TRUE      T#20ms        TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=PRIORITY_CHECK_8000 FROM 8020 TO C020->Error_Timer_MaxMuting
  Finish

test logicals.safety.plcopen.SF_MutingSeq_32
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            FALSE           TRUE            FALSE           FALSE  TRUE       FALSE  16#C154    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8010->Wrong_Muting_Sequence_8010
  Data  6       TRUE      T#10m         TRUE           TRUE            FALSE           TRUE            FALSE           FALSE  TRUE       FALSE  16#C154    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8010->Wrong_Muting_Sequence_8010
  Finish

test logicals.safety.plcopen.SF_MutingSeq_33
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Finish

test logicals.safety.plcopen.SF_MutingSeq_34
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         FALSE          FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#CFC4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8120 F->Wrong_Muting_Sequence_8110_F
  Finish

test logicals.safety.plcopen.SF_MutingSeq_35
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Finish

test logicals.safety.plcopen.SF_MutingSeq_36
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#C484    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8120 2->Wrong_Muting_Sequence_8110_2
  Finish

test logicals.safety.plcopen.SF_MutingSeq_37
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#C404    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8120 4->Wrong_Muting_Sequence_8110_4
  Finish

test logicals.safety.plcopen.SF_MutingSeq_38
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#C4D4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8120 5->Wrong_Muting_Sequence_8110_5
  Finish

test logicals.safety.plcopen.SF_MutingSeq_39
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#20ms        TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12 short timer->Muting_Backward_Active_short_timer
  Data  8       TRUE      T#20ms        TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Muting backward timer expired->Error_Timer_MaxMuting
  Finish

test logicals.safety.plcopen.SF_MutingSeq_40
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#20ms        TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12 short timer->Muting_Backward_Active_short_timer
  Data  8       TRUE      T#20ms        TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=PRIORITY_CHECK_8000 FROM 8110 TO C020->Error_Timer_MaxMuting
  Finish

test logicals.safety.plcopen.SF_MutingSeq_41
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 1->Muting_Forward_Active_1
  Data  7       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       FALSE  16#C284    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=COMBO_CHECK_8000_5 FROM 8020 TO CXY4->Wrong_Muting_Sequence_8020_9
  Finish

test logicals.safety.plcopen.SF_MutingSeq_42
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 1->Muting_Forward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            FALSE           TRUE            FALSE           FALSE  TRUE       FALSE  16#C254    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8020 2->Wrong_Muting_Sequence_8020_2
  Finish

test logicals.safety.plcopen.SF_MutingSeq_43
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 1->Muting_Forward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#C234    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8020 3->Wrong_Muting_Sequence_8020_3
  Finish

test logicals.safety.plcopen.SF_MutingSeq_44
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 1->Muting_Forward_Active_1
  Data  7       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#C264    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8020 4->Wrong_Muting_Sequence_8020_4
  Finish

test logicals.safety.plcopen.SF_MutingSeq_45
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         FALSE          TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#CF74    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8020 F->Wrong_Muting_Sequence_8020_F
  Data  7       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=NOT (MS11 OR MS12 OR MS21 OR MS22)->Wait_for_Reset
  Finish

test logicals.safety.plcopen.SF_MutingSeq_46
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#20ms        TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2 short timer->Muting_Forward_Active_short_timer
  Data  8       TRUE      T#20ms        TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Muting forward timer expired->Error_Timer_MaxMuting
  Data  11      TRUE      T#20ms        TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Muting forward timer expired->Error_Timer_MaxMuting
  Finish

test logicals.safety.plcopen.SF_MutingSeq_47
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#20ms        TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2 short timer->Muting_Forward_Active_short_timer
  Data  8       TRUE      T#20ms        TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#C020    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Muting forward timer expired->Error_Timer_MaxMuting
  Data  9       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8402    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=NOT (MS11 OR MS12 OR MS21 OR MS22)->Wait_for_Reset
  Finish

test logicals.safety.plcopen.SF_MutingSeq_48
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 1->Muting_Backward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#C414    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=COMBO_CHECK_8000_5 FROM 8110 TO CXY4->Wrong_Muting_Sequence_8110_9
  Finish

test logicals.safety.plcopen.SF_MutingSeq_49
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 1->Muting_Forward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 2->Muting_Forward_Active_2
  Data  8       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       FALSE  16#C284    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=COMBO_CHECK_8000_8 FROM 8020 TO CXY4->Wrong_Muting_Sequence_8020_9
  Finish

test logicals.safety.plcopen.SF_MutingSeq_50
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 1->Muting_Forward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 2->Muting_Forward_Active_2
  Data  8       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#C274    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8020 1->Wrong_Muting_Sequence_8020_1
  Finish

test logicals.safety.plcopen.SF_MutingSeq_51
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 1->Muting_Forward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 2->Muting_Forward_Active_2
  Data  8       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#C234    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8020 8->Wrong_Muting_Sequence_8020_8
  Finish

test logicals.safety.plcopen.SF_MutingSeq_52
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 1->Muting_Backward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 2->Muting_Backward_Active_2
  Data  8       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#C414    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=COMBO_CHECK_8000_8 FROM 8110 TO CXY4->Wrong_Muting_Sequence_8110_9
  Finish

test logicals.safety.plcopen.SF_MutingSeq_53
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 1->Muting_Backward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 2->Muting_Backward_Active_2
  Data  8       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#C4E4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8120 1->Wrong_Muting_Sequence_8110_1
  Finish

test logicals.safety.plcopen.SF_MutingSeq_54
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 1->Muting_Backward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 2->Muting_Backward_Active_2
  Data  8       TRUE      T#10m         TRUE           TRUE            FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#C4D4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8120 3->Wrong_Muting_Sequence_8110_3
  Finish

test logicals.safety.plcopen.SF_MutingSeq_55
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 1->Muting_Backward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 2->Muting_Backward_Active_2
  Data  8       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       TRUE  16#C434    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8120 8->Wrong_Muting_Sequence_8110_8
  Finish

test logicals.safety.plcopen.SF_MutingSeq_56
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 1->Muting_Forward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 2->Muting_Forward_Active_2
  Data  8       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 3->Muting_Forward_Active_3
  Data  9       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       FALSE  16#C284    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8020 9->Wrong_Muting_Sequence_8020_9
  Finish

test logicals.safety.plcopen.SF_MutingSeq_57
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 1->Muting_Forward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 2->Muting_Forward_Active_2
  Data  8       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 3->Muting_Forward_Active_3
  Data  9       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=COMBO_CHECK_8000_9 FROM 8020 TO CXY4->Wrong_Muting_Sequence_8020_9
  Data  10      TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       FALSE  16#C284    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=COMBO_CHECK_8000_9 FROM 8020 TO CXY4->Wrong_Muting_Sequence_8020_9
  Finish

test logicals.safety.plcopen.SF_MutingSeq_58
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 1->Muting_Backward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 2->Muting_Backward_Active_2
  Data  8       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 3->Muting_Backward_Active_3
  Data  9       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#C414    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=COMBO_CHECK_8000_9 FROM 8110 TO CXY4->Wrong_Muting_Sequence_8110_9
  Finish

test logicals.safety.plcopen.SF_MutingSeq_59
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 1->Muting_Backward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 2->Muting_Backward_Active_2
  Data  8       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 3->Muting_Backward_Active_3
  Data  9       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#C414    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8120 9->Wrong_Muting_Sequence_8110_9
  Finish

test logicals.safety.plcopen.SF_MutingSeq_60
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       FALSE  16#8010    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 1->Muting_Forward_Start
  Data  5       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 2->Muting_Forward_Active
  Data  6       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 1->Muting_Forward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 2->Muting_Forward_Active_2
  Data  8       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 3->Muting_Forward_Active_3
  Data  9       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       FALSE  16#8020    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting forward 4->Muting_Forward_Active_4
  Data  10      TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       FALSE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 3->AOPD_Free
  Finish

test logicals.safety.plcopen.SF_MutingSeq_61
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 1->Muting_Backward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 2->Muting_Backward_Active_2
  Data  8       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 3->Muting_Backward_Active_3
  Data  9       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 4->Muting_Backward_Active_4
  Data  10      TRUE      T#10m         TRUE           TRUE            FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 13->AOPD_Free
  Finish

test logicals.safety.plcopen.SF_MutingSeq_62
  Head    Time  Activate  MaxMutingTime  MutingEnable  MutingSwitch11  MutingSwitch12  MutingSwitch21  MutingSwitch22  Reset  S_AOPD_In  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_AOPD_OUT?  S_MutingActive?  SafetyDemand?  CycleTime=T#10ms
  Tol     /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Shift   /     /         /              /             /               /               /               /               /      /          /             0          0       0       0              0            0                0
  Data  0       FALSE     T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      FALSE  16#8401    FALSE   TRUE    TRUE           FALSE        FALSE            FALSE  doc=Activate->Init
  Data  2       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  FALSE      TRUE  16#8002    FALSE   TRUE    FALSE          FALSE        FALSE            FALSE  doc=R_Trig at Reset OR S_StartReset->Safe
  Data  3       TRUE      T#10m         FALSE          FALSE           FALSE           FALSE           FALSE           FALSE  TRUE       TRUE  16#8000    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=S_AOPD_IN->AOPD_Free
  Data  4       TRUE      T#10m         TRUE           FALSE           FALSE           FALSE           TRUE            FALSE  TRUE       TRUE  16#8120    FALSE   TRUE    FALSE          TRUE         FALSE            FALSE  doc=Muting condition 11->Muting_Backward_Start
  Data  5       TRUE      T#10m         TRUE           FALSE           FALSE           TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting condition 12->Muting_Backward_Active
  Data  6       TRUE      T#10m         TRUE           FALSE           TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 1->Muting_Backward_Active_1
  Data  7       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 2->Muting_Backward_Active_2
  Data  8       TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            FALSE           FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 3->Muting_Backward_Active_3
  Data  9       TRUE      T#10m         TRUE           TRUE            TRUE            FALSE           FALSE           FALSE  TRUE       TRUE  16#8110    FALSE   TRUE    FALSE          TRUE         TRUE             FALSE  doc=Muting backward 4->Muting_Backward_Active_4
  Data  10      TRUE      T#10m         TRUE           TRUE            TRUE            TRUE            TRUE            FALSE  TRUE       TRUE  16#C4F4    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE  doc=Wrong Muting Sequence 8120 7->Wrong_Muting_Sequence_8110_7
  Finish

