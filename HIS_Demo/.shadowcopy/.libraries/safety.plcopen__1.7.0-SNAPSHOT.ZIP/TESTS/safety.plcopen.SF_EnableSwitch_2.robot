*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_EnableSwitch_2		MaxDataRows=100		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  Reset=FALSE
...  S_EnableIn=16#00
...  S_SafetyActive=16#00
*** Test Cases ***

#SAFE-26576 test logicals.safety.plcopen.SF_SafeInputs_Invalid
#  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  ENO?  CycleTime=T#10ms
#  Tol  /  /  /  /  /  0  0  0  0  0  0  0
#  Shift  /  /  /  /  /  0  0  0  0  0  0  0
#  Data  0     FALSE     FALSE   FALSE       FALSE              16#0000    FALSE   FALSE   FALSE          FALSE                FALSE     TRUE        doc=NOT Activate->Idle
#  Data  1     TRUE      FALSE   16#0        16#01              16#8002    FALSE   TRUE    FALSE          FALSE                FALSE     FALSE       doc=Activate->Basic_Operation_Mode
#  Data  2     TRUE      FALSE   FALSE       TRUE               16#8004    FALSE   TRUE    FALSE          FALSE                FALSE     TRUE        doc=S_SafetyActive->Safe_Operation_Mode
#  Data  3     TRUE      FALSE   16#0F       FALSE              16#8002    FALSE   TRUE    FALSE          FALSE                FALSE     FALSE       doc=NOT S_SafetyActive->Basic_Operation_Mode
#  Finish

test logicals.safety.plcopen.SF_EnableSwitch_2_Invalid_State
  Head  Time  Activate  Reset      S_EnableIn  S_SafetyActive  DiagCode?          Error?           Ready?     ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  ENO?     CycleTime=T#10ms
  Tol    /     /         /         /           /               0                  0                0          0              0                   0              0
  Shift  /     /         /         /           /               0                  0                0          0              0                   0              0
  Init   /     /         /         /           /               16#9999            TRUE            TRUE        FALSE          FALSE               FALSE          TRUE
  Data   0     TRUE      FALSE     FALSE       FALSE           16#9999            TRUE            TRUE        FALSE          FALSE               FALSE          FALSE    doc=Activate->Basic_Operation_Mode
  Data   1     TRUE      FALSE     FALSE       FALSE           16#9999            TRUE            TRUE        FALSE          FALSE               FALSE          FALSE    doc=S_SafetyActive->Safe_Operation_Mode
  Data   2     FALSE     FALSE     FALSE       FALSE           16#0000            FALSE           FALSE       FALSE          FALSE               FALSE          TRUE     doc=S_SafetyActive->Enable siwtch in position1
  Data   3     TRUE      FALSE     FALSE       FALSE           16#8002            FALSE           TRUE        FALSE          FALSE               FALSE          TRUE     doc=Safe_Operation_Mode_Prio1_over_prio2(NOT S_SafetyActive)->Basic_Operation_Mode
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_2_Reset_Error_1_Then_Basic_Operation_Mode
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE       FALSE              16#0000    FALSE   FALSE   FALSE          FALSE                FALSE             doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE       FALSE              16#8002    FALSE   TRUE    FALSE          FALSE                FALSE             doc=Activate->Basic_Operation_Mode
  Data  2     TRUE      FALSE   FALSE       TRUE               16#8004    FALSE   TRUE    FALSE          FALSE                FALSE             doc=S_SafetyActive->Safe_Operation_Mode
  Data  3     TRUE      TRUE    TRUE        TRUE               16#C010    TRUE    TRUE    FALSE          FALSE                FALSE             doc=S_EnableIn->Operation_Error_1_EnableIn
  Data  4     TRUE      TRUE    TRUE        TRUE               16#C001    TRUE    TRUE    FALSE          FALSE                FALSE             doc=RESET AND NOT R_TRIG at Reset->Reset_Error_1
  Data  5     TRUE      TRUE    TRUE        FALSE              16#8002    FALSE   TRUE    FALSE          FALSE                FALSE             doc=NOT S_SafetyActive->Basic_Operation_Mode 
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_2_Reset_Error_1_Then_Operation_Error_Position_2
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE    FALSE       FALSE              16#0000    FALSE   FALSE   FALSE          FALSE                FALSE             doc=NOT Activate->Idle
  Data  1     TRUE      FALSE    FALSE       FALSE              16#8002    FALSE   TRUE    FALSE          FALSE                FALSE             doc=Activate->Basic_Operation_Mode
  Data  2     TRUE      FALSE    FALSE       TRUE               16#8004    FALSE   TRUE    FALSE          FALSE                FALSE             doc=S_SafetyActive->Safe_Operation_Mode
  Data  3     TRUE      TRUE     TRUE        TRUE               16#C010    TRUE    TRUE    FALSE          FALSE                FALSE             doc=S_EnableIn->Operation_Error_1_EnableIn
  Data  4     TRUE      TRUE     TRUE        TRUE               16#C001    TRUE    TRUE    FALSE          FALSE                FALSE             doc=RESET AND NOT R_TRIG at Reset->Reset_Error_1
  Data  5     TRUE      FALSE    TRUE        TRUE               16#C010    TRUE    TRUE    FALSE          FALSE                FALSE             doc=NOT Reset->Operation_Error_1_EnableIn            
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_2_Reset_Error_1_Then_Operation_Error_Position_1_Or_3
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE    FALSE       FALSE              16#0000    FALSE   FALSE   FALSE          FALSE                FALSE             doc=NOT Activate->Idle
  Data  1     TRUE      FALSE    FALSE       FALSE              16#8002    FALSE   TRUE    FALSE          FALSE                FALSE             doc=Activate->Basic_Operation_Mode
  Data  2     TRUE      FALSE    FALSE       TRUE               16#8004    FALSE   TRUE    FALSE          FALSE                FALSE             doc=S_SafetyActive->Safe_Operation_Mode
  Data  3     TRUE      TRUE     TRUE        TRUE               16#C010    TRUE    TRUE    FALSE          FALSE                FALSE             doc=S_EnableIn->Operation_Error_1_EnableIn
  Data  4     TRUE      TRUE     TRUE        TRUE               16#C001    TRUE    TRUE    FALSE          FALSE                FALSE             doc=RESET AND NOT R_TRIG at Reset->Reset_Error_1
  Data  5     TRUE      FALSE    FALSE       TRUE               16#C410    TRUE    TRUE    TRUE           FALSE                FALSE             doc=NOT Reset->Operation_Error_1_Not_EnableIn 
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_2_Reset_Error_1_Then_Operation_Error_Not_Enabled
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE    FALSE       FALSE              16#0000    FALSE   FALSE   FALSE          FALSE                FALSE             doc=NOT Activate->Idle
  Data  1     TRUE      FALSE    FALSE       FALSE              16#8002    FALSE   TRUE    FALSE          FALSE                FALSE             doc=Activate->Basic_Operation_Mode
  Data  2     TRUE      FALSE    FALSE       TRUE               16#8004    FALSE   TRUE    FALSE          FALSE                FALSE             doc=S_SafetyActive->Safe_Operation_Mode
  Data  3     TRUE      TRUE     TRUE        TRUE               16#C010    TRUE    TRUE    FALSE          FALSE                FALSE             doc=S_EnableIn->Operation_Error_1_EnableIn
  Data  4     TRUE      TRUE     TRUE        TRUE               16#C001    TRUE    TRUE    FALSE          FALSE                FALSE             doc=RESET AND NOT R_TRIG at Reset->Reset_Error_1
  Data  6     TRUE      FALSE    FALSE       TRUE               16#C410    TRUE    TRUE    TRUE           FALSE                FALSE             doc=NOT Reset->Operation_Error_1_Not_EnableIn
  Finish

test logicals.safety.plcopen.SF_EnableSwitch_2_Not_Activate
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE    FALSE       FALSE              16#0000    FALSE   FALSE   FALSE          FALSE                FALSE             doc=NOT Activate->Idle
  Data  1     TRUE      FALSE    FALSE       FALSE              16#8002    FALSE   TRUE    FALSE          FALSE                FALSE             doc=Activate->Basic_Operation_Mode
  Data  2     FALSE     FALSE    FALSE       FALSE              16#0000    FALSE   FALSE   FALSE          FALSE                FALSE             doc=NOT Activate->Idle    
  Finish

#                                    DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?    CycleTime=T#10ms
#@startuml
#skinparam stateFontName Courier
#skinparam stateFontSize 14
#Idle:                               16#0000    FALSE   FALSE   FALSE          FALSE                FALSE
#Basic_Operation_Mode:               16#8002    FALSE   TRUE    FALSE          FALSE                FALSE
#Safe_Operation_Mode:                16#8004    FALSE   TRUE    FALSE          FALSE                FALSE
#Operation_Error_1_EnableIn:         16#C010    TRUE    TRUE    FALSE          FALSE                FALSE
#Operation_Error_1_Not_EnableIn:     16#C410    TRUE    TRUE    TRUE           FALSE                FALSE
#Reset_Error_1:                      16#C001    TRUE    TRUE    FALSE          FALSE                FALSE
#Not_Enabled:                        16#8802    FALSE   TRUE    FALSE          FALSE                TRUE
#Enabled:                            16#8000    FALSE   TRUE    FALSE          TRUE                 FALSE
#
#T:.                                                            Time  Activate  Reset   S_EnableIn  S_SafetyActive
#T:NOT Activate:                                                1     FALSE     FALSE      FALSE       FALSE
#T:Activate:                                                    1     TRUE      FALSE      FALSE       FALSE
#T:S_SafetyActive:                                              1     TRUE      FALSE      FALSE       TRUE
#T:NOT S_SafetyActive:                                          1     TRUE      FALSE      FALSE       FALSE
#T:S_EnableIn:                                                  1     TRUE      FALSE      TRUE        TRUE
#T:NOT S_EnableIn:                                              1     TRUE      FALSE      FALSE       TRUE
#T:NOT S_EnableIn AND R_TRIG at Reset:                          1     TRUE      R_EDGE     FALSE       TRUE
#T:F_TRIG S_EnableIn AND R_TRIG at Reset:                       1     TRUE      R_EDGE     F_EDGE      TRUE 
#T:NOT Reset AND S_EnableIn:                                    1     TRUE      FALSE      TRUE        TRUE
#T:NOT Reset AND NOT S_EnableIn:                                1     TRUE      FALSE      FALSE       TRUE
#T:PRIORITY_CHECK_8000 S_EnableIn AND NOT S_SafetyActive:       1     TRUE      FALSE      TRUE        FALSE  
#T:Reset AND NOT R_TRIG at Reset:                               1     TRUE      STAT_TRUE  TRUE        TRUE
#
#[*]-->Idle:NOT Activate
#Idle-->Basic_Operation_Mode: Activate
#Basic_Operation_Mode-->Basic_Operation_Mode: Activate
#Basic_Operation_Mode-->Safe_Operation_Mode: S_SafetyActive
#Safe_Operation_Mode-->Basic_Operation_Mode: NOT S_SafetyActive
#Safe_Operation_Mode-->Operation_Error_1_EnableIn: S_EnableIn
#Safe_Operation_Mode-->Not_Enabled: NOT S_EnableIn
#Operation_Error_1_EnableIn-->Basic_Operation_Mode: NOT S_SafetyActive
#Operation_Error_1_EnableIn-->Not_Enabled: F_TRIG S_EnableIn AND R_TRIG at Reset
#Operation_Error_1_EnableIn-->Operation_Error_1_Not_EnableIn: NOT S_EnableIn
#Operation_Error_1_Not_EnableIn-->Basic_Operation_Mode: NOT S_SafetyActive
#Operation_Error_1_Not_EnableIn-->Not_Enabled: NOT S_EnableIn AND R_TRIG at Reset
#Operation_Error_1_Not_EnableIn-->Operation_Error_1_EnableIn: S_EnableIn
#Reset_Error_1-->Basic_Operation_Mode: NOT S_SafetyActive
#Reset_Error_1-->Operation_Error_1_EnableIn: NOT Reset AND S_EnableIn
#Reset_Error_1-->Operation_Error_1_Not_EnableIn: NOT Reset AND NOT S_EnableIn
#Not_Enabled-->Basic_Operation_Mode: NOT S_SafetyActive
#Not_Enabled-->Enabled: S_EnableIn
#Not_Enabled-->Not_Enabled: NOT S_EnableIn
#Enabled-->Basic_Operation_Mode: NOT S_SafetyActive
#Enabled-->Not_Enabled: NOT S_EnableIn
#Enabled-->Enabled: S_EnableIn
#Not_Enabled-->Basic_Operation_Mode: PRIORITY_CHECK_8000 S_EnableIn AND NOT S_SafetyActive
#Operation_Error_1_EnableIn-->Reset_Error_1:Reset AND NOT R_TRIG at Reset
#
#@enduml


#@begin generated
test SF_EnableSwitch_2_0
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Finish

test SF_EnableSwitch_2_1
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test SF_EnableSwitch_2_2
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=S_EnableIn->Operation_Error_1_EnableIn
  Data  4       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test SF_EnableSwitch_2_3
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=S_EnableIn->Operation_Error_1_EnableIn
  Data  4       TRUE      FALSE      TRUE        TRUE   16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=F_TRIG S_EnableIn AND R_TRIG at Reset->Not_Enabled
  Data  5       TRUE      TRUE       FALSE       TRUE   16#8802    FALSE   TRUE    FALSE          FALSE                TRUE  doc=F_TRIG S_EnableIn AND R_TRIG at Reset->Not_Enabled
  Finish

test SF_EnableSwitch_2_4
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      FALSE       TRUE  16#8802    FALSE   TRUE    FALSE          FALSE                TRUE  doc=NOT S_EnableIn->Not_Enabled
  Data  4       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test SF_EnableSwitch_2_5
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      FALSE       TRUE  16#8802    FALSE   TRUE    FALSE          FALSE                TRUE  doc=NOT S_EnableIn->Not_Enabled
  Data  4       TRUE      FALSE      FALSE       TRUE  16#8802    FALSE   TRUE    FALSE          FALSE                TRUE  doc=NOT S_EnableIn->Not_Enabled
  Finish

test SF_EnableSwitch_2_6
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      FALSE       TRUE  16#8802    FALSE   TRUE    FALSE          FALSE                TRUE  doc=NOT S_EnableIn->Not_Enabled
  Data  4       TRUE      FALSE      TRUE        FALSE    16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=PRIORITY_CHECK_8000 S_EnableIn AND NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test SF_EnableSwitch_2_7
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=S_EnableIn->Operation_Error_1_EnableIn
  Data  4       TRUE      FALSE      FALSE       TRUE  16#C410    TRUE    TRUE    TRUE           FALSE                FALSE  doc=NOT S_EnableIn->Operation_Error_1_Not_EnableIn
  Data  5       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test SF_EnableSwitch_2_8
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=S_EnableIn->Operation_Error_1_EnableIn
  Data  4       TRUE      FALSE      FALSE       TRUE  16#C410    TRUE    TRUE    TRUE           FALSE                FALSE  doc=NOT S_EnableIn->Operation_Error_1_Not_EnableIn
  Data  5       TRUE      FALSE      FALSE       TRUE  16#C410    TRUE    TRUE    TRUE           FALSE                FALSE  doc=NOT S_EnableIn AND R_TRIG at Reset->Not_Enabled
  Data  6       TRUE      TRUE       FALSE       TRUE  16#8802    FALSE   TRUE    FALSE          FALSE                TRUE  doc=NOT S_EnableIn AND R_TRIG at Reset->Not_Enabled
  Finish

test SF_EnableSwitch_2_9
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=S_EnableIn->Operation_Error_1_EnableIn
  Data  4       TRUE      FALSE      FALSE       TRUE  16#C410    TRUE    TRUE    TRUE           FALSE                FALSE  doc=NOT S_EnableIn->Operation_Error_1_Not_EnableIn
  Data  5       TRUE      FALSE      TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=S_EnableIn->Operation_Error_1_EnableIn
  Finish

test SF_EnableSwitch_2_10
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=S_EnableIn->Operation_Error_1_EnableIn
  Data  4       TRUE      TRUE       TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  5       TRUE      TRUE       TRUE        TRUE  16#C001    TRUE    TRUE    FALSE          FALSE                FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  6       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test SF_EnableSwitch_2_11
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=S_EnableIn->Operation_Error_1_EnableIn
  Data  4       TRUE      TRUE       TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  5       TRUE      TRUE       TRUE        TRUE  16#C001    TRUE    TRUE    FALSE          FALSE                FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  6       TRUE      FALSE      TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=NOT Reset AND S_EnableIn->Operation_Error_1_EnableIn
  Finish

test SF_EnableSwitch_2_12
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=S_EnableIn->Operation_Error_1_EnableIn
  Data  4       TRUE      TRUE       TRUE        TRUE  16#C010    TRUE    TRUE    FALSE          FALSE                FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  5       TRUE      TRUE       TRUE        TRUE  16#C001    TRUE    TRUE    FALSE          FALSE                FALSE  doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  6       TRUE      FALSE      FALSE       TRUE  16#C410    TRUE    TRUE    TRUE           FALSE                FALSE  doc=NOT Reset AND NOT S_EnableIn->Operation_Error_1_Not_EnableIn
  Finish

test SF_EnableSwitch_2_13
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      FALSE       TRUE  16#8802    FALSE   TRUE    FALSE          FALSE                TRUE  doc=NOT S_EnableIn->Not_Enabled
  Data  4       TRUE      FALSE      TRUE        TRUE  16#8000    FALSE   TRUE    FALSE          TRUE                 FALSE  doc=S_EnableIn->Enabled
  Data  5       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=NOT S_SafetyActive->Basic_Operation_Mode
  Finish

test SF_EnableSwitch_2_14
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      FALSE       TRUE  16#8802    FALSE   TRUE    FALSE          FALSE                TRUE  doc=NOT S_EnableIn->Not_Enabled
  Data  4       TRUE      FALSE      TRUE        TRUE  16#8000    FALSE   TRUE    FALSE          TRUE                 FALSE  doc=S_EnableIn->Enabled
  Data  5       TRUE      FALSE      FALSE       TRUE  16#8802    FALSE   TRUE    FALSE          FALSE                TRUE  doc=NOT S_EnableIn->Not_Enabled
  Finish

test SF_EnableSwitch_2_15
  Head  Time  Activate  Reset  S_EnableIn  S_SafetyActive  DiagCode?  Error?  Ready?  ResetRequest?  S_EnableSwitchOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE      FALSE       FALSE  16#0000    FALSE   FALSE   FALSE          FALSE                FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE      FALSE       FALSE  16#8002    FALSE   TRUE    FALSE          FALSE                FALSE  doc=Activate->Basic_Operation_Mode
  Data  2       TRUE      FALSE      FALSE       TRUE  16#8004    FALSE   TRUE    FALSE          FALSE                FALSE  doc=S_SafetyActive->Safe_Operation_Mode
  Data  3       TRUE      FALSE      FALSE       TRUE  16#8802    FALSE   TRUE    FALSE          FALSE                TRUE  doc=NOT S_EnableIn->Not_Enabled
  Data  4       TRUE      FALSE      TRUE        TRUE  16#8000    FALSE   TRUE    FALSE          TRUE                 FALSE  doc=S_EnableIn->Enabled
  Data  5       TRUE      FALSE      TRUE        TRUE  16#8000    FALSE   TRUE    FALSE          TRUE                 FALSE  doc=S_EnableIn->Enabled
  Finish

