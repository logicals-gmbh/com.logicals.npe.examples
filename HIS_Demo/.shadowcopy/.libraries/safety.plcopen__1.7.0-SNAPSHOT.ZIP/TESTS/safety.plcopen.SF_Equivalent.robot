*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_Equivalent   MaxDataRows=10   TestSuitePath=${SUITE SOURCE}
  Set Defaults    &{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  DiscrepancyTime=T#10ms
...  S_ChannelA=FALSE
...  S_ChannelB=FALSE
*** Test Cases ***
test logicals.safety.plcopen.SF_Equivalent_Invalid_State
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?   ENO?     CycleTime=T#10ms
  Tol    /     /         /               /           /           0.0        0.0     0.0     0.0               0.0             0.0     
  Shift  /     /         /               /           /           0          0       0       0                 0               0
  Init   /     /         /               /           /           16#9999    FALSE   FALSE   FALSE             FALSE           TRUE           
  Data   0     TRUE      T#20ms        FALSE       FALSE         16#9999    TRUE    TRUE    FALSE             FALSE           FALSE     doc=Invalid State
  Data   1     TRUE      T#20ms        FALSE       FALSE         16#9999    TRUE    TRUE    FALSE             FALSE           FALSE     doc=Invalid State
  Data   2     FALSE     T#20ms        FALSE       FALSE         16#0000    FALSE   FALSE   FALSE             FALSE           TRUE      doc=NOT Activate->Idle
  Data   3     TRUE      T#20ms        FALSE       FALSE         16#8801    FALSE   TRUE    FALSE             TRUE            TRUE      doc=Activate->init
  Finish

test logicals.safety.plcopen.SF_Equivalent_DiscrTime_LT_0
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#-100ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#-100ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE   doc=Activate->Init
  Data  2     TRUE      T#-100ms           TRUE        FALSE  16#8802    FALSE   TRUE    FALSE             TRUE   doc=S_ChannelA AND NOT S_ChannelB->Wait_for_channel_B
  Data  3     TRUE      T#-100ms           FALSE       FALSE  16#C010    TRUE    TRUE    FALSE             FALSE  doc=Discrepancy Time Elapsed->Error1
  Data  4     TRUE      T#-100ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE   doc=NOT S_ChannelA AND NOT S_ChannelB->Init
  Finish

test logicals.safety.plcopen.SF_Equivalent_DiscrTime_EQ_0_C010
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#0ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#0ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE   doc=Activate->Init
  Data  2     TRUE      T#0ms           TRUE        FALSE  16#8802    FALSE   TRUE    FALSE             TRUE   doc=S_ChannelA AND NOT S_ChannelB->Wait_for_channel_B
  Data  3     TRUE      T#0ms           FALSE       FALSE  16#C010    TRUE    TRUE    FALSE             FALSE  doc=Discrepancy Time Elapsed->Error1
  Data  4     TRUE      T#0ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE   doc=NOT S_ChannelA AND NOT S_ChannelB->Init
  Finish

test logicals.safety.plcopen.SF_Equivalent_DiscrTime_EQ_0_C020
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#0ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      T#0ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE    doc=Activate->Init
  Data  2     TRUE      T#0ms           FALSE       TRUE   16#8804    FALSE   TRUE    FALSE             TRUE    doc=S_ChannelB AND NOT S_ChannelA->Wait_for_channel_A
  Data  3     TRUE      T#0ms           FALSE       FALSE  16#C020    TRUE    TRUE    FALSE             FALSE   doc=Discrepancy Time Elapsed->Error2
  Data  4     TRUE      T#0ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE    doc=NOT S_ChannelA AND NOT S_ChannelB->Init
  Finish

test logicals.safety.plcopen.SF_Equivalent_DiscrTime_EQ_0_C030
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#0ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      T#0ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE    doc=Activate->Init
  Data  2     TRUE      T#0ms           TRUE        TRUE   16#8000    FALSE   TRUE    TRUE              FALSE   doc=S_ChannelA AND S_ChannelB->Safety_Output_Enabled
  Data  3     TRUE      T#0ms           TRUE        FALSE  16#8806    FALSE   TRUE    FALSE             TRUE    doc=S_ChannelA XOR S_ChannelB->From_Active_Wait
  Data  4     TRUE      T#0ms           FALSE       FALSE  16#C030    TRUE    TRUE    FALSE             FALSE   doc=Discrepancy Time Elapsed->Error3
  Finish

test logicals.safety.plcopen.SF_Equivalent_DiscrTime_LT_CycleTime
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#9ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      T#9ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE    doc=Activate->Init
  Data  2     TRUE      T#9ms           TRUE        TRUE   16#8000    FALSE   TRUE    TRUE              FALSE   doc=S_ChannelA AND S_ChannelB->Safety_Output_Enabled
  Data  3     TRUE      T#9ms           TRUE        FALSE  16#8806    FALSE   TRUE    FALSE             TRUE    doc=S_ChannelA XOR S_ChannelB->From_Active_Wait
  Data  4     TRUE      T#9ms           FALSE       FALSE  16#C030    TRUE    TRUE    FALSE             FALSE   doc=Discrepancy Time Elapsed->Error3
  Finish

test logicals.safety.plcopen.SF_Equivalent_DiscrTime_EQ_CycleTime
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#10ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      T#10ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE    doc=Activate->Init
  Data  2     TRUE      T#10ms           TRUE        TRUE   16#8000    FALSE   TRUE    TRUE              FALSE   doc=S_ChannelA AND S_ChannelB->Safety_Output_Enabled
  Data  3     TRUE      T#10ms           TRUE        FALSE  16#8806    FALSE   TRUE    FALSE             TRUE    doc=S_ChannelA XOR S_ChannelB->From_Active_Wait
  Data  4     TRUE      T#10ms           FALSE       FALSE  16#C030    TRUE    TRUE    FALSE             FALSE   doc=Discrepancy Time Elapsed->Error3
  Finish

test logicals.safety.plcopen.SF_Equivalent_DiscrTime_GT_CycleTime
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#11ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      T#11ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE    doc=Activate->Init
  Data  2     TRUE      T#11ms           TRUE        TRUE   16#8000    FALSE   TRUE    TRUE              FALSE   doc=S_ChannelA AND S_ChannelB->Safety_Output_Enabled
  Data  3     TRUE      T#11ms           TRUE        FALSE  16#8806    FALSE   TRUE    FALSE             TRUE    doc=S_ChannelA XOR S_ChannelB->From_Active_Wait
  Data  5     TRUE      T#11ms           FALSE       FALSE  16#C030    TRUE    TRUE    FALSE             FALSE   doc=Discrepancy Time Elapsed->Error3
  Finish

test logicals.safety.plcopen.SF_Equivalent_8802_prio1over3
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE   doc=Activate->Init
  Data  2     TRUE      T#20ms           TRUE        FALSE  16#8802    FALSE   TRUE    FALSE             TRUE   doc=S_ChannelA AND NOT S_ChannelB->Wait_for_channel_B
  Data  4     TRUE      T#20ms           FALSE       TRUE  16#C010     TRUE    TRUE    FALSE             FALSE  doc=Discrepancy Time Elapsed->Error1
  Finish

test logicals.safety.plcopen.SF_Equivalent_8802_prio2over3
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           TRUE        FALSE  16#8802    FALSE   TRUE    FALSE             TRUE  doc=S_ChannelA AND NOT S_ChannelB->Wait_for_channel_B
  Data  3     TRUE      T#20ms           FALSE       TRUE   16#8801    FALSE   TRUE    FALSE             TRUE  doc=NOT S_ChannelA->Init
  Finish

test logicals.safety.plcopen.SF_Equivalent_8804_prio1over3
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE   doc=Activate->Init
  Data  2     TRUE      T#20ms           FALSE       TRUE   16#8804    FALSE   TRUE    FALSE             TRUE   doc=S_ChannelB AND NOT S_ChannelA->Wait_for_channel_A
  Data  4     TRUE      T#20ms           TRUE        FALSE  16#C020    TRUE    TRUE    FALSE             FALSE  doc=Discrepancy Time Elapsed->Error2
  Finish

test logicals.safety.plcopen.SF_Equivalent_8804_prio2over3
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           FALSE       TRUE   16#8804    FALSE   TRUE    FALSE             TRUE  doc=S_ChannelB AND NOT S_ChannelA->Wait_for_channel_A
  Data  3     TRUE      T#20ms           TRUE       FALSE  16#8801    FALSE   TRUE    FALSE              TRUE  doc=NOT S_ChannelB->Init
  Finish

test logicals.safety.plcopen.SF_Equivalent_8000_8806_var2
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           TRUE        TRUE   16#8000    FALSE   TRUE    TRUE              FALSE  doc=S_ChannelA AND S_ChannelB->Safety_Output_Enabled
  Data  3     TRUE      T#20ms           FALSE       TRUE   16#8806    FALSE   TRUE    FALSE             TRUE  doc=S_ChannelA XOR S_ChannelB->From_Active_Wait
  Finish

#                       DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
#@startuml
#
#skinparam stateFontName Courier
#skinparam stateFontSize 14
#
#Idle:                  16#0000    FALSE   FALSE   FALSE             FALSE
#Init:                  16#8801    FALSE   TRUE    FALSE             TRUE
#Wait_for_channel_A:    16#8804    FALSE   TRUE    FALSE             TRUE
#Wait_for_channel_B:    16#8802    FALSE   TRUE    FALSE             TRUE
#Safety_Output_Enabled: 16#8000    FALSE   TRUE    TRUE              FALSE
#From_Active_Wait:      16#8806    FALSE   TRUE    FALSE             TRUE
#Error1:                16#C010    TRUE    TRUE    FALSE             FALSE
#Error2:                16#C020    TRUE    TRUE    FALSE             FALSE
#Error3:                16#C030    TRUE    TRUE    FALSE             FALSE
#
#T:.                                       Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB
#T:NOT Activate:                           1     FALSE     T#20ms           FALSE       FALSE
#T:Activate:                               1     TRUE      T#20ms           FALSE       FALSE
#T:S_ChannelB AND NOT S_ChannelA:          1     TRUE      T#20ms           FALSE       TRUE
#T:S_ChannelA:                             1     TRUE      T#20ms           TRUE        TRUE
#T:NOT S_ChannelB:                         1     TRUE      T#20ms           FALSE       FALSE
#T:S_ChannelA AND NOT S_ChannelB:          1     TRUE      T#20ms           TRUE        FALSE
#T:S_ChannelB:                             1     TRUE      T#20ms           TRUE        TRUE
#T:NOT S_ChannelA:                         1     TRUE      T#20ms           FALSE       FALSE
#T:Discrepancy Time Elapsed:               2     TRUE      T#20ms           FALSE       FALSE
#T:S_ChannelA AND S_ChannelB:              1     TRUE      T#20ms           TRUE        TRUE
#T:NOT S_ChannelA AND NOT S_ChannelB:      1     TRUE      T#20ms           FALSE       FALSE
#T:S_ChannelA XOR S_ChannelB:              1     TRUE      T#20ms           TRUE        FALSE
#
#[*]-->Idle: NOT Activate
#Idle-->Init: Activate
#Init-->Init: Activate
#Init-->Wait_for_channel_B: S_ChannelA AND NOT S_ChannelB
#Init-->Wait_for_channel_A: S_ChannelB AND NOT S_ChannelA
#Init-->Safety_Output_Enabled: S_ChannelA AND S_ChannelB
#Safety_Output_Enabled-->Safety_Output_Enabled: S_ChannelA AND S_ChannelB
#Wait_for_channel_B-->Error1 : Discrepancy Time Elapsed
#Wait_for_channel_B-->Init : NOT S_ChannelA
#Wait_for_channel_B-->Safety_Output_Enabled: S_ChannelB
#Wait_for_channel_A-->Error2 : Discrepancy Time Elapsed
#Wait_for_channel_A-->Init : NOT S_ChannelB
#Wait_for_channel_A-->Safety_Output_Enabled: S_ChannelA
#Error1-->Init: NOT S_ChannelA AND NOT S_ChannelB
#Error2-->Init: NOT S_ChannelA AND NOT S_ChannelB
#Safety_Output_Enabled-->Idle: NOT Activate
#Safety_Output_Enabled-->From_Active_Wait: S_ChannelA XOR S_ChannelB
#Safety_Output_Enabled-->Init: NOT S_ChannelA AND NOT S_ChannelB
#From_Active_Wait-->Error3: Discrepancy Time Elapsed
#From_Active_Wait-->Init: NOT S_ChannelA AND NOT S_ChannelB
#Error3-->Error3: S_ChannelA AND NOT S_ChannelB
#Error3-->Init: NOT S_ChannelA AND NOT S_ChannelB
#
#@enduml
#@begin generated
test logicals.safety.plcopen.SF_Equivalent_0
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Finish

test logicals.safety.plcopen.SF_Equivalent_1
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           TRUE        FALSE  16#8802    FALSE   TRUE    FALSE             TRUE  doc=S_ChannelA AND NOT S_ChannelB->Wait_for_channel_B
  Data  3     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=NOT S_ChannelA->Init
  Finish

test logicals.safety.plcopen.SF_Equivalent_2
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           TRUE        FALSE  16#8802    FALSE   TRUE    FALSE             TRUE  doc=S_ChannelA AND NOT S_ChannelB->Wait_for_channel_B
  Data  3     TRUE      T#20ms           TRUE        TRUE  16#8000    FALSE   TRUE    TRUE              FALSE  doc=S_ChannelB->Safety_Output_Enabled
  Finish

test logicals.safety.plcopen.SF_Equivalent_3
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           FALSE       TRUE  16#8804    FALSE   TRUE    FALSE             TRUE  doc=S_ChannelB AND NOT S_ChannelA->Wait_for_channel_A
  Data  3     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=NOT S_ChannelB->Init
  Finish

test logicals.safety.plcopen.SF_Equivalent_4
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           FALSE       TRUE  16#8804    FALSE   TRUE    FALSE             TRUE  doc=S_ChannelB AND NOT S_ChannelA->Wait_for_channel_A
  Data  3     TRUE      T#20ms           TRUE        TRUE  16#8000    FALSE   TRUE    TRUE              FALSE  doc=S_ChannelA->Safety_Output_Enabled
  Finish

test logicals.safety.plcopen.SF_Equivalent_5
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           TRUE        TRUE  16#8000    FALSE   TRUE    TRUE              FALSE  doc=S_ChannelA AND S_ChannelB->Safety_Output_Enabled
  Data  3     TRUE      T#20ms           TRUE        TRUE  16#8000    FALSE   TRUE    TRUE              FALSE  doc=S_ChannelA AND S_ChannelB->Safety_Output_Enabled
  Finish

test logicals.safety.plcopen.SF_Equivalent_6
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           TRUE        TRUE  16#8000    FALSE   TRUE    TRUE              FALSE  doc=S_ChannelA AND S_ChannelB->Safety_Output_Enabled
  Data  3     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_Equivalent_7
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           TRUE        TRUE  16#8000    FALSE   TRUE    TRUE              FALSE  doc=S_ChannelA AND S_ChannelB->Safety_Output_Enabled
  Data  3     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=NOT S_ChannelA AND NOT S_ChannelB->Init
  Finish

test logicals.safety.plcopen.SF_Equivalent_8
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           TRUE        FALSE  16#8802    FALSE   TRUE    FALSE             TRUE  doc=S_ChannelA AND NOT S_ChannelB->Wait_for_channel_B
  Data  4     TRUE      T#20ms           FALSE       FALSE  16#C010    TRUE    TRUE    FALSE             FALSE  doc=Discrepancy Time Elapsed->Error1
  Data  5     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=NOT S_ChannelA AND NOT S_ChannelB->Init
  Finish

test logicals.safety.plcopen.SF_Equivalent_9
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           FALSE       TRUE  16#8804    FALSE   TRUE    FALSE             TRUE  doc=S_ChannelB AND NOT S_ChannelA->Wait_for_channel_A
  Data  4     TRUE      T#20ms           FALSE       FALSE  16#C020    TRUE    TRUE    FALSE             FALSE  doc=Discrepancy Time Elapsed->Error2
  Data  5     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=NOT S_ChannelA AND NOT S_ChannelB->Init
  Finish

test logicals.safety.plcopen.SF_Equivalent_10
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           TRUE        TRUE  16#8000    FALSE   TRUE    TRUE              FALSE  doc=S_ChannelA AND S_ChannelB->Safety_Output_Enabled
  Data  3     TRUE      T#20ms           TRUE        FALSE  16#8806    FALSE   TRUE    FALSE             TRUE  doc=S_ChannelA XOR S_ChannelB->From_Active_Wait
  Data  4     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=NOT S_ChannelA AND NOT S_ChannelB->Init
  Finish

test logicals.safety.plcopen.SF_Equivalent_11
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           TRUE        TRUE  16#8000    FALSE   TRUE    TRUE              FALSE  doc=S_ChannelA AND S_ChannelB->Safety_Output_Enabled
  Data  3     TRUE      T#20ms           TRUE        FALSE  16#8806    FALSE   TRUE    FALSE             TRUE  doc=S_ChannelA XOR S_ChannelB->From_Active_Wait
  Data  5     TRUE      T#20ms           FALSE       FALSE  16#C030    TRUE    TRUE    FALSE             FALSE  doc=Discrepancy Time Elapsed->Error3
  Data  6     TRUE      T#20ms           TRUE        FALSE  16#C030    TRUE    TRUE    FALSE             FALSE  doc=S_ChannelA AND NOT S_ChannelB->Error3
  Finish

test logicals.safety.plcopen.SF_Equivalent_12
  Head  Time  Activate  DiscrepancyTime  S_ChannelA  S_ChannelB  DiagCode?  Error?  Ready?  S_EquivalentOut?  SafetyDemand?  CycleTime=T#10ms
  Tol    /  /  /  /  /  0.0  0.0  0.0  0.0  0.0
  Shift  /  /  /  /  /  0  0  0  0  0
  Data  0     FALSE     T#20ms           FALSE       FALSE  16#0000    FALSE   FALSE   FALSE             FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=Activate->Init
  Data  2     TRUE      T#20ms           TRUE        TRUE  16#8000    FALSE   TRUE    TRUE              FALSE  doc=S_ChannelA AND S_ChannelB->Safety_Output_Enabled
  Data  3     TRUE      T#20ms           TRUE        FALSE  16#8806    FALSE   TRUE    FALSE             TRUE  doc=S_ChannelA XOR S_ChannelB->From_Active_Wait
  Data  5     TRUE      T#20ms           FALSE       FALSE  16#C030    TRUE    TRUE    FALSE             FALSE  doc=Discrepancy Time Elapsed->Error3
  Data  6     TRUE      T#20ms           FALSE       FALSE  16#8801    FALSE   TRUE    FALSE             TRUE  doc=NOT S_ChannelA AND NOT S_ChannelB->Init
  Finish

