*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_Guard		MaxDataRows=100		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  DiscrepancyTime=T#10ms
...  Reset=FALSE
...  S_AutoReset=FALSE
...  S_GuardSwitch1=FALSE
...  S_GuardSwitch2=FALSE
...  S_StartReset=FALSE
*** Test Cases ***
test logicals.safety.plcopen.SF_Guard_Invalid_State
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?    ENO?    CycleTime=T#10ms
  Tol    /       /           /           /       /            /               /               /            0          0       0       0              0            0                0        
  Shift  /       /           /           /       /            /               /               /            0          0       0       0              0            0                0        
  Init   /       /           /           /       /            /               /               /            16#9999    FALSE   FALSE   FALSE          FALSE        FALSE            TRUE        
  Data   0       TRUE        T#20ms      FALSE   FALSE        FALSE           FALSE           FALSE        16#9999    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE        doc=Invalid State
  Data   1       TRUE        T#20ms      FALSE   FALSE        FALSE           FALSE           FALSE        16#9999    TRUE    TRUE    FALSE          FALSE        FALSE            FALSE        doc=Invalid State
  Data   2       FALSE       T#20ms      FALSE   FALSE        FALSE           FALSE           FALSE        16#0000    FALSE   FALSE   FALSE          FALSE        FALSE            TRUE         doc=NOT Activate -> Idle
  Data   3       TRUE        T#20ms      FALSE   FALSE        FALSE           FALSE           FALSE        16#8001    FALSE   TRUE    FALSE          FALSE        FALSE            TRUE         doc=Activate->Init
  Finish

test logicals.safety.plcopen.SF_Guard_Invalid_Discrepancy_Error
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#-100ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#-100ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#-100ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#-100ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#-100ms          FALSE   FALSE        TRUE            FALSE           FALSE               16#8806      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  5       TRUE        T#-100ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#C010      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Discrepancy_Time_Elapsed->Discrepancytime_Error_1
  Data  6       TRUE        T#-100ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch2->Guard_Opened
  Finish

test logicals.safety.plcopen.SF_Guard_Zero_Discrepancy_Error_1
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#0ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#0ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#0ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#0ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#0ms          FALSE   FALSE        TRUE            FALSE           FALSE               16#8806      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  5       TRUE        T#0ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#C010      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Discrepancy_Time_Elapsed->Discrepancytime_Error_1
  Data  6       TRUE        T#0ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE              doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch2->Guard_Opened
  Finish

test logicals.safety.plcopen.SF_Guard_Zero_Discrepancy_Error_2
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#0ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#0ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#0ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#0ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#0ms          FALSE   FALSE        FALSE           TRUE            FALSE               16#8808      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch2->Wait_For_GuardSwitch_1
  Data  5       TRUE        T#0ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#C020      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Discrepancy_Time_Elapsed->Discrepancytime_Error_2
  Data  6       TRUE        T#0ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE      TRUE    FALSE          FALSE        TRUE              doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch2->Guard_Opened
  Finish

test logicals.safety.plcopen.SF_Guard_Discrepancy_LT_Cycle_Time
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#9ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#9ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#9ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#9ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#9ms          FALSE   FALSE        FALSE           TRUE            FALSE               16#8808      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch2->Wait_For_GuardSwitch_1
  Data  5       TRUE        T#9ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#C020      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Discrepancy_Time_Elapsed->Discrepancytime_Error_2
  Data  6       TRUE        T#9ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE      TRUE    FALSE          FALSE        TRUE              doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch2->Guard_Opened
  Finish

test logicals.safety.plcopen.SF_Guard_Discrepancy_GT_Cycle_Time
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#11ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#11ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#11ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#11ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#11ms          FALSE   FALSE        FALSE           TRUE            FALSE               16#8808      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch2->Wait_For_GuardSwitch_1
  Data  6       TRUE        T#11ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#C020      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Discrepancy_Time_Elapsed->Discrepancytime_Error_2
  Data  7       TRUE        T#11ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE      TRUE    FALSE          FALSE        TRUE              doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch2->Guard_Opened
  Finish

test logicals.safety.plcopen.SF_Guard_Discrepancy_EQ_Cycle_Time
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#10ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#10ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#10ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#10ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#10ms          FALSE   FALSE        FALSE           TRUE            FALSE               16#8808      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch2->Wait_For_GuardSwitch_1
  Data  5       TRUE        T#10ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#C020      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Discrepancy_Time_Elapsed->Discrepancytime_Error_2
  Data  6       TRUE        T#10ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE      TRUE    FALSE          FALSE        TRUE              doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch2->Guard_Opened
  Finish

test logicals.safety.plcopen.SF_Guard_C001_8402
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          TRUE    FALSE        TRUE            TRUE            FALSE               16#8402      FALSE     TRUE    FALSE          FALSE        FALSE              doc=S_GuardSwitch1 AND S_GuardSwitch2 AND NOT S_StartReset->Wait_For_Reset
  Data  3       TRUE        T#20ms          TRUE    FALSE        FALSE           FALSE           FALSE               16#C001      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Reset AND NOT R_TRIG at Reset->Reset_Error
  Data  4       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8402      FALSE     TRUE    TRUE           FALSE        FALSE              doc=NOT Reset->Wait_For_Reset
  Finish

test logicals.safety.plcopen.SF_Guard_C001_C001
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          TRUE    FALSE        TRUE            TRUE            FALSE               16#8402      FALSE     TRUE    FALSE          FALSE        FALSE              doc=S_GuardSwitch1 AND S_GuardSwitch2 AND NOT S_StartReset->Wait_For_Reset
  Data  3       TRUE        T#20ms          TRUE    FALSE        FALSE           FALSE           FALSE               16#C001      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Reset AND NOT R_TRIG at Reset->Reset_Error
  Data  4       TRUE        T#20ms          TRUE    FALSE        FALSE           FALSE           FALSE               16#C001      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Reset->Reset_Error
  Finish

test logicals.safety.plcopen.SF_Guard_C010_8804
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE               16#8806      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  6       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#C010      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Discrepancy_Time_Elapsed->Discrepancytime_Error_1
  Data  7       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE      TRUE    FALSE          FALSE        TRUE              doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch2->Guard_Opened
  Finish

test logicals.safety.plcopen.SF_Guard_C010_C010
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE               16#8806      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  6       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#C010      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Discrepancy_Time_Elapsed->Discrepancytime_Error_1
  Data  7       TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE               16#C010      TRUE      TRUE    FALSE          FALSE        FALSE              doc=S_GuardSwitch1 AND NOT S_GuardSwitch2->Discrepancytime_Error_1
  Finish

test logicals.safety.plcopen.SF_Guard_C020_8804
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#20ms          FALSE   FALSE        FALSE           TRUE            FALSE               16#8808      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  6       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#C020      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Discrepancy_Time_Elapsed->Discrepancytime_Error_2
  Data  7       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE      TRUE    FALSE          FALSE        TRUE              doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch2->Guard_Opened
  Finish

test logicals.safety.plcopen.SF_Guard_C020_C020
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#20ms          FALSE   FALSE        FALSE           TRUE            FALSE               16#8808      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch2->Wait_For_GuardSwitch_1
  Data  6       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#C020      TRUE      TRUE    FALSE          FALSE        FALSE              doc=Discrepancy_Time_Elapsed->Discrepancytime_Error_2
  Data  7       TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE               16#C020      TRUE      TRUE    FALSE          FALSE        FALSE              doc=S_GuardSwitch1 AND NOT S_GuardSwitch2->Discrepancytime_Error_2
  Finish

test logicals.safety.plcopen.SF_Guard_Not_S_GuardSw1_From_Init
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        FALSE           TRUE            FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch1 AND S_GuardSwitch2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_Not_S_GuardSw2_From_Init
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch1 AND S_GuardSwitch2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_8402_prio2over3_A
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#8402      FALSE     TRUE    TRUE           FALSE        FALSE              doc=Reset AND R_TRIG at Reset AND S_GuardSwitch1 AND S_GuardSwitch2 AND NOT S_StartReset->Wait_For_Reset
  Data  4       TRUE        T#20ms          TRUE    FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=COMBO_CHECK_8000_A Reset AND R_TRIG at Reset AND NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_8402_prio2over3_B
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#8402      FALSE     TRUE    TRUE           FALSE        FALSE              doc=S_GuardSwitch1 AND S_GuardSwitch2 AND NOT S_StartReset->Wait_For_Reset
  Data  3       TRUE        T#20ms          TRUE    FALSE        FALSE           TRUE            FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=COMBO_CHECK_8000_B Reset AND R_TRIG at Reset AND NOT S_GuardSwitch1 OR S_GuardSwitch_2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_8402_prio2over3_C
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#8402      FALSE     TRUE    TRUE           FALSE        FALSE              doc=S_GuardSwitch1 AND S_GuardSwitch2 AND NOT S_StartReset->Wait_For_Reset
  Data  3       TRUE        T#20ms          TRUE    FALSE        TRUE            FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=COMBO_CHECK_8000_C Reset AND R_TRIG at Reset AND S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_8002_prio1over3_A
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE               16#8806      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  5       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#8002      FALSE     TRUE    FALSE          FALSE        FALSE              doc=S_GuardSwitch1 AND S_GuardSwitch2->Guard_Closed
  Data  6       TRUE        T#20ms          FALSE   TRUE         FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=COMBO_CHECK_8000_A S_AutoReset AND NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_8002_prio1over3_B
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE               16#8806      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  5       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#8002      FALSE     TRUE    FALSE          FALSE        FALSE              doc=S_GuardSwitch1 AND S_GuardSwitch2->Guard_Closed
  Data  6       TRUE        T#20ms          FALSE   TRUE         FALSE           TRUE            FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=COMBO_CHECK_8000_B S_AutoReset AND NOT S_GuardSwitch1 AND S_GuardSwitch_2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_8002_prio1over3_C
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8804      FALSE     TRUE    FALSE          FALSE        TRUE               doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4       TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE               16#8806      FALSE     TRUE    FALSE          FALSE        TRUE               doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  5       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE               16#8002      FALSE     TRUE    FALSE          FALSE        FALSE              doc=S_GuardSwitch1 AND S_GuardSwitch2->Guard_Closed
  Data  6       TRUE        T#20ms          FALSE   TRUE         TRUE            FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=COMBO_CHECK_8000_C S_AutoReset AND S_GuardSwitch1 AND NOT S_GuardSwitch_2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_8000_8802_var1
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            TRUE                16#8000      FALSE     TRUE    FALSE          TRUE         FALSE              doc=S_GuardSwitch1 AND S_GuardSwitch2 AND S_StartReset->Normal
  Data  3       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=SUBCONDITION_CHECK_A NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_8000_8802_var2
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            TRUE                16#8000      FALSE     TRUE    FALSE          TRUE         FALSE              doc=S_GuardSwitch1 AND S_GuardSwitch2 AND S_StartReset->Normal
  Data  3       TRUE        T#20ms          FALSE   FALSE        FALSE           TRUE            FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=SUBCONDITION_CHECK_B NOT S_GuardSwitch1 AND S_GuardSwitch_2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_8000_8802_var3
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#0000      FALSE     FALSE   FALSE          FALSE        FALSE              doc=NOT Activate->Idle
  Data  1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE               16#8001      FALSE     TRUE    FALSE          FALSE        FALSE              doc=Activate->Init
  Data  2       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            TRUE                16#8000      FALSE     TRUE    FALSE          TRUE         FALSE              doc=S_GuardSwitch1 AND S_GuardSwitch2 AND S_StartReset->Normal
  Data  3       TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE               16#8802      FALSE     TRUE    FALSE          FALSE        TRUE               doc=SUBCONDITION_CHECK_C S_GuardSwitch1 AND NOT S_GuardSwitch_2->Open_Guard_Request
  Finish

#                              DiagCode?    Error?    Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
#@startuml
#Idle:                         16#0000      FALSE     FALSE   FALSE          FALSE        FALSE
#Init:                         16#8001      FALSE     TRUE    FALSE          FALSE        FALSE
#Open_Guard_Request:           16#8802      FALSE     TRUE    FALSE          FALSE        TRUE
#Guard_Opened:                 16#8804      FALSE     TRUE    FALSE          FALSE        TRUE
#Wait_For_GuardSwitch_2:       16#8806      FALSE     TRUE    FALSE          FALSE        TRUE
#Wait_For_GuardSwitch_1:       16#8808      FALSE     TRUE    FALSE          FALSE        TRUE
#Discrepancytime_Error_1:      16#C010      TRUE      TRUE    FALSE          FALSE        FALSE
#Discrepancytime_Error_2:      16#C020      TRUE      TRUE    FALSE          FALSE        FALSE
#Guard_Closed:                 16#8002      FALSE     TRUE    FALSE          FALSE        FALSE
#Wait_For_Reset:               16#8402      FALSE     TRUE    TRUE           FALSE        FALSE
#Reset_Error:                  16#C001      TRUE      TRUE    FALSE          FALSE        FALSE
#Normal:                       16#8000      FALSE     TRUE    FALSE          TRUE         FALSE
#
#T:.                                                                     Time    Activate    DiscrepancyTime  Reset   S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset
#T:NOT Activate:                                                          1       FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE
#T:Activate:                                                              1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE
#T:NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2:                             1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE
#T:NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2:                            1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE
#T:S_GuardSwitch1 AND S_GuardSwitch2 AND NOT S_StartReset:                1       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE
#T:S_GuardSwitch1 AND S_GuardSwitch2 AND S_StartReset:                    1       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            TRUE
#T:S_GuardSwitch1:                                                        1       TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE
#T:S_GuardSwitch2:                                                        1       TRUE        T#20ms          FALSE   FALSE        FALSE           TRUE            FALSE
#T:Discrepancy_Time_Elapsed:                                              2       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE
#T:NOT S_GuardSwitch1:                                                    1       TRUE        T#20ms          FALSE   FALSE        FALSE           TRUE            FALSE
#T:NOT S_GuardSwitch2:                                                    1       TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE
#T:S_GuardSwitch1 AND S_GuardSwitch2:                                     1       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE
#T:NOT S_AutoReset:                                                       1       TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE
#T:S_AutoReset:                                                           1       TRUE        T#20ms          FALSE   TRUE         TRUE            TRUE            FALSE
#T:R_TRIG at Reset:                                                       1       TRUE        T#20ms          TRUE    FALSE        TRUE            TRUE            FALSE
#T:NOT Reset:                                                             1       TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE
#
#[*]-->Idle: NOT Activate
#Idle-->Init: Activate
#Init-->Open_Guard_Request: NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2
#Init-->Wait_For_Reset: S_GuardSwitch1 AND S_GuardSwitch2 AND NOT S_StartReset
#Init-->Normal: S_GuardSwitch1 AND S_GuardSwitch2 AND S_StartReset
#Open_Guard_Request-->Guard_Opened: NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2
#Open_Guard_Request-->Open_Guard_Request: S_GuardSwitch1 AND S_GuardSwitch2
#Guard_Opened-->Wait_For_GuardSwitch_2: S_GuardSwitch1
#Guard_Opened-->Wait_For_GuardSwitch_1: S_GuardSwitch2
#Guard_Opened-->Guard_Opened: NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2
#Wait_For_GuardSwitch_2-->Discrepancytime_Error_1: Discrepancy_Time_Elapsed
#Wait_For_GuardSwitch_2-->Open_Guard_Request: NOT S_GuardSwitch1
#Wait_For_GuardSwitch_2-->Guard_Closed: S_GuardSwitch1 AND S_GuardSwitch2
#Wait_For_GuardSwitch_1-->Discrepancytime_Error_2: Discrepancy_Time_Elapsed
#Wait_For_GuardSwitch_1-->Open_Guard_Request:NOT S_GuardSwitch2
#Wait_For_GuardSwitch_1-->Guard_Closed: S_GuardSwitch1 AND S_GuardSwitch2
#Guard_Closed-->Open_Guard_Request: NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2
#Guard_Closed-->Wait_For_Reset: NOT S_AutoReset
#Guard_Closed-->Normal: S_AutoReset
#Wait_For_Reset-->Open_Guard_Request: NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2
#Wait_For_Reset-->Normal: R_TRIG at Reset
#Normal-->Open_Guard_Request: NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2
#Normal-->Normal: S_GuardSwitch1 AND S_GuardSwitch2
#Normal-->Idle: NOT Activate
#Reset_Error-->Wait_For_Reset: NOT Reset
#@enduml
#@begin generated
test logicals.safety.plcopen.SF_Guard_0
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=S_GuardSwitch1 AND S_GuardSwitch2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_1
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE  16#8402      FALSE     TRUE    TRUE           FALSE        FALSE  doc=S_GuardSwitch1 AND S_GuardSwitch2 AND NOT S_StartReset->Wait_For_Reset
  Data  3         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_2
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE  16#8402      FALSE     TRUE    TRUE           FALSE        FALSE  doc=S_GuardSwitch1 AND S_GuardSwitch2 AND NOT S_StartReset->Wait_For_Reset
  Data  3         TRUE        T#20ms          TRUE    FALSE        TRUE            TRUE            FALSE  16#8000      FALSE     TRUE    FALSE          TRUE         FALSE  doc=R_TRIG at Reset->Normal
  Finish

test logicals.safety.plcopen.SF_Guard_3
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            TRUE  16#8000      FALSE     TRUE    FALSE          TRUE         FALSE  doc=S_GuardSwitch1 AND S_GuardSwitch2 AND S_StartReset->Normal
  Data  3         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_4
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            TRUE  16#8000      FALSE     TRUE    FALSE          TRUE         FALSE  doc=S_GuardSwitch1 AND S_GuardSwitch2 AND S_StartReset->Normal
  Data  3         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE  16#8000      FALSE     TRUE    FALSE          TRUE         FALSE  doc=S_GuardSwitch1 AND S_GuardSwitch2->Normal
  Finish

test logicals.safety.plcopen.SF_Guard_5
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            TRUE  16#8000      FALSE     TRUE    FALSE          TRUE         FALSE  doc=S_GuardSwitch1 AND S_GuardSwitch2 AND S_StartReset->Normal
  Data  3         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_Guard_6
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8804      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8804      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Finish

test logicals.safety.plcopen.SF_Guard_7
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8804      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4         TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE  16#8806      FALSE     TRUE    FALSE          FALSE        TRUE  doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  6         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE  16#C010      TRUE      TRUE    FALSE          FALSE        FALSE  doc=Discrepancy_Time_Elapsed->Discrepancytime_Error_1
  Finish

test logicals.safety.plcopen.SF_Guard_8
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8804      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4         TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE  16#8806      FALSE     TRUE    FALSE          FALSE        TRUE  doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  5         TRUE        T#20ms          FALSE   FALSE        FALSE           TRUE            FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_9
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8804      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4         TRUE        T#20ms          FALSE   FALSE        FALSE           TRUE            FALSE  16#8808      FALSE     TRUE    FALSE          FALSE        TRUE  doc=S_GuardSwitch2->Wait_For_GuardSwitch_1
  Data  6         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE  16#C020      TRUE      TRUE    FALSE          FALSE        FALSE  doc=Discrepancy_Time_Elapsed->Discrepancytime_Error_2
  Finish

test logicals.safety.plcopen.SF_Guard_10
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8804      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4         TRUE        T#20ms          FALSE   FALSE        FALSE           TRUE            FALSE  16#8808      FALSE     TRUE    FALSE          FALSE        TRUE  doc=S_GuardSwitch2->Wait_For_GuardSwitch_1
  Data  5         TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_11
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8804      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4         TRUE        T#20ms          FALSE   FALSE        FALSE           TRUE            FALSE  16#8808      FALSE     TRUE    FALSE          FALSE        TRUE  doc=S_GuardSwitch2->Wait_For_GuardSwitch_1
  Data  5         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE  16#8002      FALSE     TRUE    FALSE          FALSE        FALSE  doc=S_GuardSwitch1 AND S_GuardSwitch2->Guard_Closed
  Finish

test logicals.safety.plcopen.SF_Guard_12
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8804      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4         TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE  16#8806      FALSE     TRUE    FALSE          FALSE        TRUE  doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  5         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE  16#8002      FALSE     TRUE    FALSE          FALSE        FALSE  doc=S_GuardSwitch1 AND S_GuardSwitch2->Guard_Closed
  Data  6         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Finish

test logicals.safety.plcopen.SF_Guard_13
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8804      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4         TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE  16#8806      FALSE     TRUE    FALSE          FALSE        TRUE  doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  5         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE  16#8002      FALSE     TRUE    FALSE          FALSE        FALSE  doc=S_GuardSwitch1 AND S_GuardSwitch2->Guard_Closed
  Data  6         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE  16#8402      FALSE     TRUE    TRUE           FALSE        FALSE  doc=NOT S_AutoReset->Wait_For_Reset
  Finish

test logicals.safety.plcopen.SF_Guard_14
  Head  Time  Activate  DiscrepancyTime  Reset  S_AutoReset  S_GuardSwitch1  S_GuardSwitch2  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardOut?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0         FALSE       T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#0000      FALSE     FALSE   FALSE          FALSE        FALSE  doc=NOT Activate->Idle
  Data  1         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8001      FALSE     TRUE    FALSE          FALSE        FALSE  doc=Activate->Init
  Data  2         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8802      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 OR NOT S_GuardSwitch_2->Open_Guard_Request
  Data  3         TRUE        T#20ms          FALSE   FALSE        FALSE           FALSE           FALSE  16#8804      FALSE     TRUE    FALSE          FALSE        TRUE  doc=NOT S_GuardSwitch1 AND NOT S_GuardSwitch_2->Guard_Opened
  Data  4         TRUE        T#20ms          FALSE   FALSE        TRUE            FALSE           FALSE  16#8806      FALSE     TRUE    FALSE          FALSE        TRUE  doc=S_GuardSwitch1->Wait_For_GuardSwitch_2
  Data  5         TRUE        T#20ms          FALSE   FALSE        TRUE            TRUE            FALSE  16#8002      FALSE     TRUE    FALSE          FALSE        FALSE  doc=S_GuardSwitch1 AND S_GuardSwitch2->Guard_Closed
  Data  6         TRUE        T#20ms          FALSE   TRUE         TRUE            TRUE            FALSE  16#8000      FALSE     TRUE    FALSE          TRUE         FALSE  doc=S_AutoReset->Normal
  Finish

