*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_OutControl		MaxDataRows=100		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  ProcessControl=FALSE
...  Reset=FALSE
...  S_AutoReset=16#00
...  S_SafeControl=16#00
...  S_StartReset=16#00
...  StaticControl=FALSE
*** Test Cases ***
test SF_OutControl_Invalid_State
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  ENO?  CycleTime=T#10ms
  Tol    /    /         /               /      /            /              /             /              0          0       0       0              0              0              0      
  Shift  /    /         /               /      /            /              /             /              0          0       0       0              0              0              0
  Init   /    /         /               /      /            /              /             /              16#9999    FALSE   FALSE   FALSE          FALSE          FALSE          TRUE         
  Data   0    TRUE      FALSE           FALSE  FALSE        FALSE          FALSE         FALSE          16#9999    TRUE    TRUE    FALSE          FALSE          FALSE          FALSE      doc=Invalid State
  Data   1    TRUE      FALSE           FALSE  FALSE        FALSE          FALSE         FALSE          16#9999    TRUE    TRUE    FALSE          FALSE          FALSE          FALSE      doc=Invalid State
  Data   2    FALSE     FALSE           FALSE  FALSE        FALSE          FALSE         FALSE          16#0000    FALSE   FALSE   FALSE          FALSE          FALSE          TRUE       doc=NOT Activate->Idle
  Data   3    TRUE      FALSE           TRUE   FALSE        FALSE          FALSE         FALSE          16#8401    FALSE   TRUE    FALSE          FALSE          FALSE          TRUE       doc=Activate->Idle
  Finish

test 2RE1
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE  FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           TRUE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    FALSE          FALSE          FALSE   doc=Activate->Init
  Data  2     TRUE      FALSE           TRUE   FALSE        FALSE          FALSE         FALSE  16#C001    TRUE    TRUE    FALSE          FALSE          FALSE   doc=Activate->Reset_Error_1
  Data  3     TRUE      FALSE           TRUE   FALSE        FALSE          FALSE         FALSE  16#C001    TRUE   TRUE    FALSE           FALSE          FALSE   doc=Reset->Reset_Error_1
  Finish

test RE1_Init
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#0000    FALSE   FALSE   FALSE          FALSE          FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE    16#8401    FALSE   TRUE    FALSE          FALSE          FALSE   doc=Activate->Init
  Data  2     TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE    16#C001    TRUE    TRUE    FALSE          FALSE          FALSE   doc=Activate->Reset_Error_1
  Data  3     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#8401    FALSE   TRUE    TRUE           FALSE          FALSE   doc=NOT Reset->Init
  Finish

test OutDis_CE_OutDis
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#0000    FALSE   FALSE   FALSE          FALSE          FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#8401    FALSE   TRUE    TRUE           FALSE          FALSE   doc=Activate->Init
  Data  2     TRUE      TRUE            FALSE   FALSE        FALSE          TRUE          FALSE    16#8006    FALSE   TRUE    FALSE          FALSE          FALSE   doc=R_TRIG at Reset OR S_StartReset->Output_Disable
  Data  3     TRUE      TRUE            FALSE   FALSE        TRUE           TRUE          FALSE    16#C010    TRUE    TRUE    FALSE          FALSE          FALSE   doc=NOT R_TRIG at ProcessControl AND ProcessControl AND NOT StaticControl->Control_Error
  Data  4     TRUE      FALSE           FALSE   FALSE        FALSE          TRUE          FALSE    16#8006    FALSE   TRUE    FALSE          FALSE          FALSE   doc=NOT ProcessControl->Output_Disable
  Finish

test OutDis_2CE
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#0000    FALSE   FALSE   FALSE          FALSE          FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#8401    FALSE   TRUE    TRUE           FALSE          FALSE   doc=Activate->Init
  Data  2     TRUE      TRUE            FALSE   FALSE        FALSE          TRUE          FALSE    16#8006    FALSE   TRUE    FALSE          FALSE          FALSE   doc=R_TRIG at Reset OR S_StartReset->Output_Disable
  Data  3     TRUE      TRUE            FALSE   FALSE        TRUE           TRUE          FALSE    16#C010    TRUE    TRUE    FALSE          FALSE          FALSE   doc=NOT R_TRIG at ProcessControl AND ProcessControl AND NOT StaticControl->Control_Error
  Data  4     TRUE      TRUE            FALSE   FALSE        FALSE          TRUE          FALSE    16#C010    TRUE    TRUE    FALSE          FALSE          FALSE   doc=ProcessControl->Control_Error
  Finish


test OutDis_Safe_Lock_2RE2
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#0000    FALSE   FALSE   FALSE          FALSE          FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#8401    FALSE   TRUE    TRUE           FALSE          FALSE   doc=Activate->Init
  Data  2     TRUE      FALSE           FALSE   FALSE        FALSE          TRUE          FALSE    16#8006    FALSE   TRUE    FALSE          FALSE          FALSE   doc=R_TRIG at Reset OR S_StartReset->Output_Disable
  Data  3     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#8802    FALSE   TRUE    FALSE          FALSE          TRUE    doc=NOT S_SafeControl->Safe
  Data  4     TRUE      FALSE           TRUE    FALSE        TRUE           FALSE         FALSE    16#8404    FALSE   TRUE    FALSE          FALSE          FALSE   doc=S_SafeControl->Lock
  Data  5     TRUE      FALSE           TRUE    FALSE        TRUE           FALSE         FALSE    16#C011    TRUE    TRUE    FALSE          FALSE          FALSE   doc=Reset AND NOT R_TRIG at Reset AND NOT S_AutoReset->Reset_Error_2
  Data  6     TRUE      FALSE           TRUE    FALSE        TRUE           FALSE         FALSE    16#C011    TRUE    TRUE    FALSE          FALSE          FALSE   doc=Reset->Reset_Error_2
  Finish

test OutDis_Safe_Lock_RE2_Lock
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#0000    FALSE   FALSE   FALSE          FALSE          FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#8401    FALSE   TRUE    TRUE           FALSE          FALSE   doc=Activate->Init
  Data  2     TRUE      FALSE           FALSE   FALSE        FALSE          TRUE          FALSE    16#8006    FALSE   TRUE    FALSE          FALSE          FALSE   doc=R_TRIG at Reset OR S_StartReset->Output_Disable
  Data  3     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#8802    FALSE   TRUE    FALSE          FALSE          TRUE    doc=NOT S_SafeControl->Safe
  Data  4     TRUE      FALSE           TRUE    FALSE        TRUE           FALSE         FALSE    16#8404    FALSE   TRUE    FALSE          FALSE          FALSE   doc=S_SafeControl->Lock
  Data  5     TRUE      FALSE           TRUE    FALSE        TRUE           FALSE         FALSE    16#C011    TRUE    TRUE    FALSE          FALSE          FALSE   doc=Reset AND NOT R_TRIG at Reset AND NOT S_AutoReset->Reset_Error_2
  Data  6     TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE    16#8404    FALSE   TRUE    TRUE           FALSE          FALSE   doc=NOT Reset->Lock
  Finish

test OutDis_OutEn_0
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#0000    FALSE   FALSE   FALSE          FALSE          FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#8401    FALSE   TRUE    TRUE           FALSE          FALSE   doc=Activate->Init
  Data  2     TRUE      TRUE            FALSE   FALSE        FALSE          TRUE          FALSE    16#8006    FALSE   TRUE    FALSE          FALSE          FALSE   doc=R_TRIG at Reset OR S_StartReset->Output_Disable
  Data  3     TRUE      TRUE            FALSE   FALSE        TRUE           FALSE         TRUE     16#8000    FALSE   TRUE    FALSE          TRUE           FALSE   doc=SUBCONDITION_CHECK_A S_SafeControl AND (StaticControl AND ProcessControl)->Output_Enable
  Finish

test OutDis_OutEn_1
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0     FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#0000    FALSE   FALSE   FALSE          FALSE          FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE    16#8401    FALSE   TRUE    TRUE           FALSE          FALSE   doc=Activate->Init
  Data  2     TRUE      FALSE           TRUE    FALSE        FALSE          TRUE          FALSE    16#8006    FALSE   TRUE    FALSE          FALSE          FALSE   doc=R_TRIG at Reset OR S_StartReset->Output_Disable
  Data  3     TRUE      TRUE            FALSE   FALSE        TRUE           FALSE         TRUE     16#8000    FALSE   TRUE    FALSE          TRUE           FALSE   doc=SUBCONDITION_CHECK_B S_SafeControl AND (StaticControl AND ProcessControl)->Output_Enable
  Finish

    #                             DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
#@startuml
#Idle:                            16#0000    FALSE   FALSE   FALSE          FALSE          FALSE
#Init:                            16#8401    FALSE   TRUE    TRUE           FALSE          FALSE
#Safe:                            16#8802    FALSE   TRUE    FALSE          FALSE          TRUE 
#Lock:                            16#8404    FALSE   TRUE    TRUE           FALSE          FALSE
#Output_Disable:                  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE
#Output_Enable:                   16#8000    FALSE   TRUE    FALSE          TRUE           FALSE
#Init_Error:                      16#C020    TRUE    TRUE    FALSE          FALSE          FALSE
#Lock_Error:                      16#C030    TRUE    TRUE    FALSE          FALSE          FALSE
#
#T:.                                                                                    Time  Activate  ProcessControl  Reset   S_AutoReset  S_SafeControl  S_StartReset  StaticControl
#T:NOT Activate:                                                                        1     FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE
#T:Activate:                                                                            1     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE
#T:R_TRIG at Reset AND R_TRIG at ProcessControl:                                        1     TRUE      R_EDGE          R_EDGE  FALSE        TRUE           FALSE         FALSE
#T:R_TRIG at Reset OR S_StartReset (first condition is TRUE):                           1     TRUE      FALSE           R_EDGE  FALSE        FALSE          FALSE         FALSE
#T:R_TRIG at Reset OR S_StartReset (second condition is TRUE):                          1     TRUE      FALSE           FALSE   FALSE        FALSE          TRUE          FALSE
#T:R_TRIG at Reset OR S_AutoReset (first condition is TRUE):                            1     TRUE      FALSE           R_EDGE  FALSE        TRUE           TRUE          FALSE
#T:R_TRIG at Reset OR S_AutoReset (second condition is TRUE):                           1     TRUE      FALSE           FALSE   TRUE         TRUE           TRUE          FALSE
#T:NOT S_SafeControl:                                                                   1     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE
#T:SUBCONDITION_CHECK_C S_SafeControl AND R_TRIG at ProcessControl:                     1     TRUE      R_EDGE          FALSE   FALSE        TRUE           FALSE         FALSE
#T:NOT S_SafeControl:                                                                   1     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE
#T:S_SafeControl:                                                                       1     TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE
#T:NOT ProcessControl:                                                                  1     TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE
#T:NOT Reset:                                                                           1     TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE
#T:Reset:                                                                               1     TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE
#T:S_SafeControl AND ProcessControl:                                                    1     TRUE      TRUE            TRUE    FALSE        TRUE           FALSE         FALSE
#
#[*]-->Idle: NOT Activate
#Idle-->Init: Activate
#Init-->Init_Error: R_TRIG at Reset AND R_TRIG at ProcessControl
#Init_Error-->Init: NOT Reset
#Init_Error-->Init_Error: Reset
#Init-->Output_Disable: R_TRIG at Reset OR S_StartReset (first condition is TRUE)
#Init-->Output_Disable: R_TRIG at Reset OR S_StartReset (second condition is TRUE)
#Output_Disable-->Safe:NOT S_SafeControl
#Output_Disable-->Output_Enable: SUBCONDITION_CHECK_C S_SafeControl AND R_TRIG at ProcessControl
#Output_Enable-->Safe: NOT S_SafeControl
#Output_Enable-->Output_Disable: NOT ProcessControl
#Output_Enable-->Output_Enable: S_SafeControl AND ProcessControl
#Safe-->Lock: S_SafeControl
#Safe-->Safe: NOT S_SafeControl
#Lock-->Safe: NOT S_SafeControl
#Lock-->Lock_Error: R_TRIG at Reset AND R_TRIG at ProcessControl
#Lock-->Output_Disable: R_TRIG at Reset OR S_AutoReset (first condition is TRUE)
#Lock-->Output_Disable: R_TRIG at Reset OR S_AutoReset (second condition is TRUE)
#Lock_Error-->Lock: NOT Reset
#Lock_Error-->Lock_Error: Reset
#@enduml
#@begin generated
test logicals.safety.plcopen.SF_OutControl_0
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE           FALSE   FALSE        FALSE          TRUE          FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (second condition is TRUE)->Output_Disable
  Finish

test logicals.safety.plcopen.SF_OutControl_1
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset AND R_TRIG at ProcessControl->Init_Error
  Data  3       TRUE      TRUE            TRUE    FALSE        TRUE           FALSE         FALSE  16#C020    TRUE    TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset AND R_TRIG at ProcessControl->Init_Error
  Data  4       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=NOT Reset->Init
  Finish

test logicals.safety.plcopen.SF_OutControl_2
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset AND R_TRIG at ProcessControl->Init_Error
  Data  3       TRUE      TRUE            TRUE    FALSE        TRUE           FALSE         FALSE  16#C020    TRUE    TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset AND R_TRIG at ProcessControl->Init_Error
  Data  4       TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE  16#C020    TRUE    TRUE    FALSE          FALSE          FALSE  doc=Reset->Init_Error
  Finish

test logicals.safety.plcopen.SF_OutControl_3
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  3       TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  4       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8802    FALSE   TRUE    FALSE          FALSE          TRUE   doc=NOT S_SafeControl->Safe
  Data  5       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8802    FALSE   TRUE    FALSE          FALSE          TRUE   doc=NOT S_SafeControl->Safe
  Finish

test logicals.safety.plcopen.SF_OutControl_4
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  3       TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  4       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=SUBCONDITION_CHECK_C S_SafeControl AND R_TRIG at ProcessControl->Output_Enable
  Data  5       TRUE      TRUE            FALSE   FALSE        TRUE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE           FALSE  doc=SUBCONDITION_CHECK_C S_SafeControl AND R_TRIG at ProcessControl->Output_Enable
  Data  6       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8802    FALSE   TRUE    FALSE          FALSE          TRUE   doc=NOT S_SafeControl->Safe
  Finish

test logicals.safety.plcopen.SF_OutControl_5
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  3       TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  4       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=SUBCONDITION_CHECK_C S_SafeControl AND R_TRIG at ProcessControl->Output_Enable
  Data  5       TRUE      TRUE            FALSE   FALSE        TRUE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE           FALSE  doc=SUBCONDITION_CHECK_C S_SafeControl AND R_TRIG at ProcessControl->Output_Enable
  Data  6       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=NOT ProcessControl->Output_Disable
  Finish

test logicals.safety.plcopen.SF_OutControl_6
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  3       TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  4       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=SUBCONDITION_CHECK_C S_SafeControl AND R_TRIG at ProcessControl->Output_Enable
  Data  5       TRUE      TRUE            FALSE   FALSE        TRUE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE           FALSE  doc=SUBCONDITION_CHECK_C S_SafeControl AND R_TRIG at ProcessControl->Output_Enable
  Data  6       TRUE      TRUE            TRUE    FALSE        TRUE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE           FALSE  doc=S_SafeControl AND ProcessControl->Output_Enable
  Finish

test logicals.safety.plcopen.SF_OutControl_7
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  3       TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  4       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8802    FALSE   TRUE    FALSE          FALSE          TRUE   doc=NOT S_SafeControl->Safe
  Data  5       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8404    FALSE   TRUE    TRUE           FALSE          FALSE  doc=S_SafeControl->Lock
  Data  6       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8802    FALSE   TRUE    FALSE          FALSE          TRUE   doc=NOT S_SafeControl->Safe
  Finish

test logicals.safety.plcopen.SF_OutControl_8
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  3       TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  4       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8802    FALSE   TRUE    FALSE          FALSE          TRUE   doc=NOT S_SafeControl->Safe
  Data  5       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8404    FALSE   TRUE    TRUE           FALSE          FALSE  doc=S_SafeControl->Lock
  Data  6       TRUE      FALSE           FALSE   FALSE        TRUE           TRUE          FALSE  16#8404    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset OR S_AutoReset (first condition is TRUE)->Output_Disable
  Data  7       TRUE      FALSE           TRUE    FALSE        TRUE           TRUE          FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset OR S_AutoReset (first condition is TRUE)->Output_Disable
  Finish

test logicals.safety.plcopen.SF_OutControl_9
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  3       TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  4       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8802    FALSE   TRUE    FALSE          FALSE          TRUE   doc=NOT S_SafeControl->Safe
  Data  5       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8404    FALSE   TRUE    TRUE           FALSE          FALSE  doc=S_SafeControl->Lock
  Data  6       TRUE      FALSE           FALSE   TRUE         TRUE           TRUE          FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset OR S_AutoReset (second condition is TRUE)->Output_Disable
  Finish

test logicals.safety.plcopen.SF_OutControl_10
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  3       TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  4       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8802    FALSE   TRUE    FALSE          FALSE          TRUE   doc=NOT S_SafeControl->Safe
  Data  5       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8404    FALSE   TRUE    TRUE           FALSE          FALSE  doc=S_SafeControl->Lock
  Data  6       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8404    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset AND R_TRIG at ProcessControl->Lock_Error
  Data  7       TRUE      TRUE            TRUE    FALSE        TRUE           FALSE         FALSE  16#C030    TRUE    TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset AND R_TRIG at ProcessControl->Lock_Error
  Data  8       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8404    FALSE   TRUE    TRUE           FALSE          FALSE  doc=NOT Reset->Lock
  Finish

test logicals.safety.plcopen.SF_OutControl_11
  Head  Time  Activate  ProcessControl  Reset  S_AutoReset  S_SafeControl  S_StartReset  StaticControl  DiagCode?  Error?  Ready?  ResetRequest?  S_OutControl?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  0  0  0  0  0  0
  Data  0       FALSE     FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE          FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=Activate->Init
  Data  2       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  3       TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE  16#8006    FALSE   TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset OR S_StartReset (first condition is TRUE)->Output_Disable
  Data  4       TRUE      FALSE           FALSE   FALSE        FALSE          FALSE         FALSE  16#8802    FALSE   TRUE    FALSE          FALSE          TRUE   doc=NOT S_SafeControl->Safe
  Data  5       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8404    FALSE   TRUE    TRUE           FALSE          FALSE  doc=S_SafeControl->Lock
  Data  6       TRUE      FALSE           FALSE   FALSE        TRUE           FALSE         FALSE  16#8404    FALSE   TRUE    TRUE           FALSE          FALSE  doc=R_TRIG at Reset AND R_TRIG at ProcessControl->Lock_Error
  Data  7       TRUE      TRUE            TRUE    FALSE        TRUE           FALSE         FALSE  16#C030    TRUE    TRUE    FALSE          FALSE          FALSE  doc=R_TRIG at Reset AND R_TRIG at ProcessControl->Lock_Error
  Data  8       TRUE      FALSE           TRUE    FALSE        FALSE          FALSE         FALSE  16#C030    TRUE    TRUE    FALSE          FALSE          FALSE  doc=Reset->Lock_Error
  Finish

