*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_SafetyRequest		MaxDataRows=100		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  MonitoringTime=T#10ms
...  Reset=FALSE
...  S_Acknowledge=FALSE
...  S_OpMode=FALSE
*** Test Cases ***
test logicals.safety.plcopen.SF_SafetyRequest_Invalid_State
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  ENO?  CycleTime=T#10ms
  Tol    /    /         /               /      /              /         /             0          0       0       0              0                0                 0              0
  Shift  /    /         /               /      /              /         /             0          0       0       0              0                0                 0              0
  Init   /    /         /               /      /              /         /             16#9999    FALSE   FALSE   FALSE          FALSE            FALSE             FALSE          TRUE   
  Data   0    TRUE      T#20ms          FALSE  FALSE          FALSE     FALSE         16#9999    TRUE    TRUE    FALSE          FALSE            FALSE             FALSE          FALSE       doc=Invalid state
  Data   1    TRUE      T#20ms          FALSE  FALSE          FALSE     FALSE         16#9999    TRUE    TRUE    FALSE          FALSE            FALSE             FALSE          FALSE       doc=Invalid state
  Data   2    FALSE     T#20ms          FALSE  FALSE          FALSE     FALSE         16#0000    FALSE   FALSE   FALSE          FALSE            FALSE             FALSE          TRUE        doc=NOT Activate->Idle
  Data   3    TRUE      T#20ms          TRUE   FALSE          FALSE     FALSE         16#8401    FALSE   TRUE    FALSE          FALSE            FALSE             FALSE          TRUE        doc=Activate->Init
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_Monitoring_Time_LT_0
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#-20ms          FALSE   FALSE          FALSE     FALSE     16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE              doc=NOT Activate->Idle
  Data  1       TRUE      T#-20ms          FALSE   FALSE          FALSE     FALSE     16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=Activate->Init
  Data  2       TRUE      T#-20ms          FALSE   FALSE          FALSE     FALSE     16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3       TRUE      T#-20ms          TRUE    FALSE          FALSE     FALSE     16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE               doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4       TRUE      T#-20ms          FALSE   FALSE          FALSE     FALSE     16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE              doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  5       TRUE      T#-20ms          TRUE    FALSE          FALSE     FALSE     16#C020      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=MonitoringTime_Elapsed->Monitoring_Time_Elapsed
  Finish
  
test logicals.safety.plcopen.SF_SafetyRequest_Monitoring_Time_EQ_0
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#0ms          FALSE   FALSE          FALSE     FALSE       16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE              doc=NOT Activate->Idle
  Data  1       TRUE      T#0ms          FALSE   FALSE          FALSE     FALSE       16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=Activate->Init
  Data  2       TRUE      T#0ms          FALSE   FALSE          FALSE     FALSE       16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3       TRUE      T#0ms          TRUE    FALSE          FALSE     FALSE       16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE               doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4       TRUE      T#0ms          FALSE   FALSE          FALSE     FALSE       16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE              doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  5       TRUE      T#0ms          TRUE    FALSE          FALSE     FALSE       16#C020      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=MonitoringTime_Elapsed->Monitoring_Time_Elapsed
  Finish
  
test logicals.safety.plcopen.SF_SafetyRequest_Monitoring_Time_LT_Cycle_Time
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#9ms          FALSE   FALSE          FALSE     FALSE       16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE              doc=NOT Activate->Idle
  Data  1       TRUE      T#9ms          FALSE   FALSE          FALSE     FALSE       16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=Activate->Init
  Data  2       TRUE      T#9ms          FALSE   FALSE          FALSE     FALSE       16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3       TRUE      T#9ms          TRUE    FALSE          FALSE     FALSE       16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE               doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4       TRUE      T#9ms          FALSE   FALSE          FALSE     FALSE       16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE              doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  5       TRUE      T#9ms          TRUE    FALSE          FALSE     FALSE       16#C020      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=MonitoringTime_Elapsed->Monitoring_Time_Elapsed
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_Monitoring_Time_GT_Cycle_Time
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#11ms          FALSE   FALSE          FALSE     FALSE      16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE              doc=NOT Activate->Idle
  Data  1       TRUE      T#11ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=Activate->Init
  Data  2       TRUE      T#11ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3       TRUE      T#11ms          TRUE    FALSE          FALSE     FALSE      16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE               doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4       TRUE      T#11ms          FALSE   FALSE          FALSE     FALSE      16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE              doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  6       TRUE      T#11ms          TRUE    FALSE          FALSE     FALSE      16#C020      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=MonitoringTime_Elapsed->Monitoring_Time_Elapsed
  Finish
  
test logicals.safety.plcopen.SF_SafetyRequest_Monitoring_Time_EQ_Cycle_Time
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#10ms          FALSE   FALSE          FALSE     FALSE      16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE              doc=NOT Activate->Idle
  Data  1       TRUE      T#10ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=Activate->Init
  Data  2       TRUE      T#10ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3       TRUE      T#10ms          TRUE    FALSE          FALSE     FALSE      16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE               doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4       TRUE      T#10ms          FALSE   FALSE          FALSE     FALSE      16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE              doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  5       TRUE      T#10ms          TRUE    FALSE          FALSE     FALSE      16#C020      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=MonitoringTime_Elapsed->Monitoring_Time_Elapsed
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_8401_C001_8401
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#20ms          TRUE   FALSE          FALSE     FALSE       16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE              doc=NOT Activate->Idle
  Data  1       TRUE      T#20ms          TRUE   FALSE          FALSE     FALSE       16#8401      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE              doc=Activate->Init
  Data  2       TRUE      T#20ms          TRUE   FALSE          FALSE     FALSE       16#C001      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  3       TRUE      T#20ms          FALSE  FALSE          FALSE     FALSE       16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=NOT Reset->Init
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_8401_C001_C001
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#20ms          TRUE   FALSE          FALSE     FALSE       16#0000      FALSE    FALSE   FALSE           FALSE            FALSE             FALSE              doc=NOT Activate->Idle
  Data  1       TRUE      T#20ms          TRUE   FALSE          FALSE     FALSE       16#8401      FALSE    TRUE    FALSE           FALSE            FALSE             FALSE              doc=Activate->Init
  Data  2       TRUE      T#20ms          TRUE   FALSE          FALSE     FALSE       16#C001      TRUE     TRUE    FALSE           FALSE            FALSE             FALSE              doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  3       TRUE      T#20ms          TRUE   FALSE          FALSE     FALSE       16#C001      TRUE     TRUE    FALSE           FALSE            FALSE             FALSE              doc=Reset->Reset_Error_1
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_C020_C011_C020
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE      16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE              doc=NOT Activate->Idle
  Data  1       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=Activate->Init
  Data  2       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE               doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE              doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  6       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#C020      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=MonitoringTime_Elapsed->Monitoring_Time_Elapsed
  Data  7       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#C011      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=Reset AND NOT R_TRIG at Reset->Reset_Error_3
  Data  8       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#C020      TRUE      TRUE    TRUE           FALSE            FALSE             FALSE              doc=NOT Reset->Monitoring_Time_Elapsed
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_8002_prio1over3
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE      16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE              doc=NOT Activate->Idle
  Data  1       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=Activate->Init
  Data  2       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE               doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE              doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  5       TRUE      T#20ms          TRUE    TRUE           FALSE     FALSE      16#C020      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=PRIORITY_CHECK_8000 MonitoringTime_Elapsed AND S_Acknowledge->Monitoring_Time_Elapsed
  Data  6       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#C011      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=Reset AND NOT R_TRIG at Reset->Reset_Error_3
  Data  7       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#C011      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=Reset->Reset_Error_3
  Finish
  
test logicals.safety.plcopen.SF_SafetyRequest_8002_prio2over3
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE      16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE              doc=NOT Activate->Idle
  Data  1       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=Activate->Init
  Data  2       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE               doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE              doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  4       TRUE      T#20ms          FALSE   TRUE           TRUE      FALSE      16#8804      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE               doc=PRIORITY_CHECK_8000 S_OpMode AND S_Acknowledge->Wait_For_Confirmation_OpMode
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_C010_C014_C010
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE      16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE              doc=NOT Activate->Idle
  Data  1       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=Activate->Init
  Data  2       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE               doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE              doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  5       TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE      16#8000      FALSE     TRUE    FALSE          TRUE             FALSE             FALSE              doc=S_Acknowledge AND NOT S_OpMode->Safe_Mode
  Data  6       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#C010      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=NOT S_Acknowledge->Acknowledge_Lost
  Data  7       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#C014      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=Reset AND NOT R_Trig at Reset->Reset_Error_2
  Data  8       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#C010      TRUE      TRUE    TRUE           FALSE            FALSE             FALSE              doc=NOT Reset->Acknowledge_Lost
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_C010_C014_C014
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE      16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE              doc=NOT Activate->Idle
  Data  1       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=Activate->Init
  Data  2       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE              doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE               doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE              doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  5       TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE      16#8000      FALSE     TRUE    FALSE          TRUE             FALSE             FALSE              doc=S_Acknowledge AND NOT S_OpMode->Safe_Mode
  Data  6       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#C010      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=NOT S_Acknowledge->Acknowledge_Lost
  Data  7       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#C014      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=Reset AND NOT R_Trig at Reset->Reset_Error_2
  Data  8       TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE      16#C014      TRUE      TRUE    FALSE          FALSE            FALSE             FALSE              doc=Reset->Reset_Error_2
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_8401_8802_S_StartReset
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE      16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2       TRUE      T#20ms          FALSE   FALSE          FALSE     TRUE       16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=S_StartReset AND NOT S_Acknowledge->Operation_Mode
  Finish
  
test logicals.safety.plcopen.SF_SafetyRequest_8401_8804_S_StartReset
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE      16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE      16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2       TRUE      T#20ms          FALSE   TRUE           FALSE     TRUE       16#8804      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=S_StartReset AND S_Acknowledge->Operation_Mode
  Finish

#                                                      DiagCode?    Error?    Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?
#@startuml
#Idle:                                                 16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE
#Init:                                                 16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE
#Wait_For_Confirmation_OpMode:                         16#8804      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE 
#Operation_Mode:                                       16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE 
#Wait_For_Confirmation:                                16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE
#Monitoring_Time_Elapsed:                              16#C020      TRUE      TRUE    TRUE           FALSE            FALSE             FALSE
#Wait_For_OpMode:                                      16#8004      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE
#Safe_Mode:                                            16#8000      FALSE     TRUE    FALSE          TRUE             FALSE             FALSE
#Acknowledge_Lost:                                     16#C010      TRUE      TRUE    TRUE           FALSE            FALSE             FALSE
#
#T:.                                              Time    Activate  MonitoringTime  Reset   S_Acknowledge  S_OpMode  S_StartReset
#T:NOT Activate:                                  1       FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE
#T:Activate:                                      1       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE
#T:R_TRIG at Reset AND NOT S_Acknowledge:         1       TRUE      T#20ms          R_EDGE  FALSE          FALSE     FALSE
#T:R_TRIG at Reset AND S_Acknowledge:             1       TRUE      T#20ms          R_EDGE  TRUE           FALSE     FALSE
#T:NOT S_OpMode AND S_Acknowledge:                1       TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE
#T:NOT S_OpMode AND NOT S_Acknowledge:            1       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE
#T:S_Acknowledge AND NOT S_OpMode:                1       TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE
#T:S_Acknowledge AND S_OpMode:                    1       TRUE      T#20ms          FALSE   TRUE           TRUE      FALSE
#T:MonitoringTime_Elapsed:                        2       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE
#T:S_OpMode:                                      1       TRUE      T#20ms          FALSE   TRUE           TRUE      FALSE
#T:NOT S_OpMode:                                  1       TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE
#T:NOT S_Acknowledge:                             1       TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE
#T:S_OpMode AND NOT S_Acknowledge:                1       TRUE      T#20ms          FALSE   FALSE          TRUE      FALSE
#T:S_OpMode AND S_Acknowledge:                    1       TRUE      T#20ms          FALSE   TRUE           TRUE      FALSE
#T:R_TRIG at Reset:                               1       TRUE      T#20ms          R_EDGE  FALSE          FALSE     FALSE
#
#[*]-->Idle: NOT Activate
#Idle-->Init: Activate
#Init-->Operation_Mode: R_TRIG at Reset AND NOT S_Acknowledge
#Init-->Wait_For_Confirmation_OpMode: R_TRIG at Reset AND S_Acknowledge
#Operation_Mode-->Wait_For_Confirmation: NOT S_OpMode AND NOT S_Acknowledge
#Operation_Mode-->Wait_For_Confirmation_OpMode: S_Acknowledge AND S_OpMode
#Operation_Mode-->Operation_Mode: S_OpMode AND NOT S_Acknowledge
#Wait_For_Confirmation-->Monitoring_Time_Elapsed: MonitoringTime_Elapsed
#Wait_For_Confirmation-->Wait_For_Confirmation_OpMode: S_OpMode AND S_Acknowledge
#Wait_For_Confirmation-->Safe_Mode: S_Acknowledge AND NOT S_OpMode
#Wait_For_Confirmation_OpMode-->Operation_Mode: NOT S_Acknowledge
#Wait_For_Confirmation_OpMode-->Wait_For_Confirmation: NOT S_OpMode AND S_Acknowledge
#Wait_For_Confirmation_OpMode-->Wait_For_Confirmation_OpMode: S_OpMode AND S_Acknowledge
#Monitoring_Time_Elapsed-->Wait_For_OpMode: R_TRIG at Reset
#Safe_Mode-->Idle: NOT Activate
#Safe_Mode-->Acknowledge_Lost: NOT S_Acknowledge
#Safe_Mode-->Wait_For_Confirmation_OpMode: S_OpMode
#Safe_Mode-->Safe_Mode: S_Acknowledge AND NOT S_OpMode
#Acknowledge_Lost-->Wait_For_OpMode: R_TRIG at Reset
#Wait_For_OpMode-->Wait_For_Confirmation_OpMode: S_OpMode
#Wait_For_OpMode-->Wait_For_OpMode: NOT S_OpMode
#@enduml
#@begin generated
test logicals.safety.plcopen.SF_SafetyRequest_0
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3         TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE  16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4         TRUE      T#20ms          FALSE   TRUE           TRUE      FALSE  16#8804      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=S_Acknowledge AND S_OpMode->Wait_For_Confirmation_OpMode
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_1
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3         TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE  16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4         TRUE      T#20ms          FALSE   FALSE          TRUE      FALSE  16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=S_OpMode AND NOT S_Acknowledge->Operation_Mode
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_2
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2         TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset AND S_Acknowledge->Wait_For_Confirmation_OpMode
  Data  3         TRUE      T#20ms          TRUE    TRUE           FALSE     FALSE  16#8804      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=R_TRIG at Reset AND S_Acknowledge->Wait_For_Confirmation_OpMode
  Data  4         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=NOT S_Acknowledge->Operation_Mode
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_3
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2         TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset AND S_Acknowledge->Wait_For_Confirmation_OpMode
  Data  3         TRUE      T#20ms          TRUE    TRUE           FALSE     FALSE  16#8804      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=R_TRIG at Reset AND S_Acknowledge->Wait_For_Confirmation_OpMode
  Data  4         TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE  16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE  doc=NOT S_OpMode AND S_Acknowledge->Wait_For_Confirmation
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_4
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2         TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset AND S_Acknowledge->Wait_For_Confirmation_OpMode
  Data  3         TRUE      T#20ms          TRUE    TRUE           FALSE     FALSE  16#8804      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=R_TRIG at Reset AND S_Acknowledge->Wait_For_Confirmation_OpMode
  Data  4         TRUE      T#20ms          FALSE   TRUE           TRUE      FALSE  16#8804      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=S_OpMode AND S_Acknowledge->Wait_For_Confirmation_OpMode
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_5
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3         TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE  16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE  doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  5         TRUE      T#20ms          FALSE   TRUE           TRUE      FALSE  16#8804      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=S_OpMode AND S_Acknowledge->Wait_For_Confirmation_OpMode
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_6
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3         TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE  16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE  doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  5         TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE  16#8000      FALSE     TRUE    FALSE          TRUE             FALSE             FALSE  doc=S_Acknowledge AND NOT S_OpMode->Safe_Mode
  Data  6         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_7
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3         TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE  16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE  doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  5         TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE  16#8000      FALSE     TRUE    FALSE          TRUE             FALSE             FALSE  doc=S_Acknowledge AND NOT S_OpMode->Safe_Mode
  Data  6         TRUE      T#20ms          FALSE   TRUE           TRUE      FALSE  16#8804      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=S_OpMode->Wait_For_Confirmation_OpMode
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_8
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3         TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE  16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE  doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  5         TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE  16#8000      FALSE     TRUE    FALSE          TRUE             FALSE             FALSE  doc=S_Acknowledge AND NOT S_OpMode->Safe_Mode
  Data  6         TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE  16#8000      FALSE     TRUE    FALSE          TRUE             FALSE             FALSE  doc=S_Acknowledge AND NOT S_OpMode->Safe_Mode
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_9
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3         TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE  16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE  doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  6         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#C020      TRUE      TRUE    TRUE           FALSE            FALSE             FALSE  doc=MonitoringTime_Elapsed->Monitoring_Time_Elapsed
  Data  7         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#C020      TRUE      TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset->Wait_For_OpMode
  Data  8         TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE  16#8004      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE  doc=R_TRIG at Reset->Wait_For_OpMode
  Data  9         TRUE      T#20ms          FALSE   TRUE           TRUE      FALSE  16#8804      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=S_OpMode->Wait_For_Confirmation_OpMode
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_10
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3         TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE  16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE  doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  6         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#C020      TRUE      TRUE    TRUE           FALSE            FALSE             FALSE  doc=MonitoringTime_Elapsed->Monitoring_Time_Elapsed
  Data  7         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#C020      TRUE      TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset->Wait_For_OpMode
  Data  8         TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE  16#8004      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE  doc=R_TRIG at Reset->Wait_For_OpMode
  Data  9         TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE  16#8004      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE  doc=NOT S_OpMode->Wait_For_OpMode
  Finish

test logicals.safety.plcopen.SF_SafetyRequest_11
  Head  Time  Activate  MonitoringTime  Reset  S_Acknowledge  S_OpMode  S_StartReset  DiagCode?  Error?  Ready?  ResetRequest?  S_SafetyActive?  S_SafetyRequest?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0         FALSE     T#20ms          FALSE   FALSE          FALSE     FALSE  16#0000      FALSE     FALSE   FALSE          FALSE            FALSE             FALSE  doc=NOT Activate->Idle
  Data  1         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=Activate->Init
  Data  2         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8401      FALSE     TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  3         TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE  16#8802      FALSE     TRUE    FALSE          FALSE            TRUE              TRUE   doc=R_TRIG at Reset AND NOT S_Acknowledge->Operation_Mode
  Data  4         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#8002      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE  doc=NOT S_OpMode AND NOT S_Acknowledge->Wait_For_Confirmation
  Data  5         TRUE      T#20ms          FALSE   TRUE           FALSE     FALSE  16#8000      FALSE     TRUE    FALSE          TRUE             FALSE             FALSE  doc=S_Acknowledge AND NOT S_OpMode->Safe_Mode
  Data  6         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#C010      TRUE      TRUE    TRUE           FALSE            FALSE             FALSE  doc=NOT S_Acknowledge->Acknowledge_Lost
  Data  7         TRUE      T#20ms          FALSE   FALSE          FALSE     FALSE  16#C010      TRUE      TRUE    TRUE           FALSE            FALSE             FALSE  doc=R_TRIG at Reset->Wait_For_OpMode
  Data  8         TRUE      T#20ms          TRUE    FALSE          FALSE     FALSE  16#8004      FALSE     TRUE    FALSE          FALSE            FALSE             FALSE  doc=R_TRIG at Reset->Wait_For_OpMode
  Finish

