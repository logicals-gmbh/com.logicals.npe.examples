*** Settings ***
Library               com.logicals.lc3.testframework.robot.keywords.Keywords
Suite Setup           LC3 Setup
Suite Teardown        Disconnect
Documentation
...  | =Approved by:=  |
...  | Author:     |   |
...  | Date:       |   |
...  | Reviewer:   |   |
...  | Date:       |   |
...
...  = ReferencedDocuments: =
...  | title  | revision  | date  | remarks  |
...  |        |           |       |          |
...
...  = Change History: =
...  | revision | date | author(s) | change description/remarks |
...  |          |      |           |                            |
...
...  = Excluded Requirements =
...  |   |   |
...
*** Keywords ***
LC3 Setup
  Prepare Test Bed  safety.plcopen.SF_GuardLocking_2		MaxDataRows=300		TestSuitePath=${SUITE SOURCE}
  Set Defaults		&{DEFAULTS}
*** Variables ***
&{DEFAULTS}
...  Activate=FALSE
...  Reset=FALSE
...  S_AutoReset=0
...  S_Guard=0
...  S_GuardLock=0
...  S_SafetyActive=0
...  S_StartReset=0
...  UnlockRequest=FALSE
*** Test Cases ***
test logicals.safety.plcopen.SF_GuardLocking_2_Invalid_State
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?   ENO?       CycleTime=T#10ms
  Tol    /     /        /      /            /        /            /               /             /              0          0       0       0               0               0               0              0       
  Shift  /     /        /      /            /        /            /               /             /              0          0       0       0               0               0               0              0
  Init   /     /        /      /            /        /            /               /             /              16#9999    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE          TRUE
  Data   0     TRUE     FALSE  FALSE        FALSE    FALSE        FALSE           FALSE         FALSE          16#9999    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE          FALSE       doc=Invalid State
  Data   1     TRUE     FALSE  FALSE        FALSE    FALSE        FALSE           FALSE         FALSE          16#9999    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE          FALSE       doc=Invalid State
  Data   2     FALSE    FALSE  FALSE        FALSE    FALSE        FALSE           FALSE         FALSE          16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE          TRUE        doc=NOT Activate->Idle
  Data   3     TRUE     TRUE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE          16#8401    FALSE   TRUE    FALSE            FALSE           FALSE           FALSE          TRUE        doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_8401_C001
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE  FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      TRUE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    FALSE           FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      TRUE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C001    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=Reset AND NOT R_TRIG at Reset AND NOT S_Auto_Reset->Reset_Error_0
  Data  3     TRUE      TRUE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C001    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=Reset->Reset_Error_0
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_8801_C001
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE  FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      TRUE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE       doc=Activate AND NOT S_Guard AND NOT S_GuardLock->Init_S_Guard_And_S_GuardLock_False
  Data  2     TRUE      TRUE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C001    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=Reset AND NOT R_TRIG at Reset AND NOT S_Auto_Reset->Reset_Error_0
  Data  3     TRUE      TRUE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C001    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=Reset->Reset_Error_0
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_C001_8401
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C001    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE      doc=Reset AND NOT R_TRIG at Reset AND NOT S_Auto_Reset->Reset_Error_0
  Data  3     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE      doc=NOT Reset AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_C001_8801
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    FALSE           FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C001    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=Reset AND NOT R_TRIG at Reset AND NOT S_Auto_Reset->Reset_Error_0
  Data  3     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE       doc=NOT Reset->Init_S_Guard_And_S_GuardLock_False
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_var1_8401_8000
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=SUBCONDITION_CHECK_A S_Guard AND S_GuardLock AND S_StartReset->Guard_Closed_And_Locked
  Data  3     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=Guard_Closed_And_Locked
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_var2_8401_8000
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=SUBCONDITION_CHECK_B Reset AND R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=Guard_Closed_And_Locked
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_var3_8401_8000
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=SUBCONDITION_CHECK_C Reset AND R_TRIG at Reset AND S_Guard AND S_GuardLock AND S_StartReset->Guard_Closed_And_Locked
  Data  3     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=Guard_Closed_And_Locked
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_var1_8801_8000
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE       doc=Activate AND NOT S_Guard AND NOT S_GuardLock->Init_S_Guard_And_S_GuardLock_False
  Data  2     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=SUBCONDITION_CHECK_A S_Guard AND S_GuardLock AND S_StartReset->Guard_Closed_And_Locked
  Data  3     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=Guard_Closed_And_Locked
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_var2_8801_8000
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE       doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=SUBCONDITION_CHECK_B Reset AND R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=Guard_Closed_And_Locked
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_var3_8801_8000
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE       doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           TRUE          FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=SUBCONDITION_CHECK_C Reset AND R_TRIG at Reset AND S_Guard AND S_GuardLock AND S_StartReset->Guard_Closed_And_Locked
  Data  3     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_8801_8822
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE   doc=Activate AND (NOT S_Guard OR NOT S_GuardLock)->Init_S_Guard_Or_S_GuardLock_False
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE           FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    FALSE        TRUE            FALSE         TRUE   16#8822    FALSE   TRUE    FALSE           FALSE           TRUE            TRUE   doc=S_SafetyActive AND NOT S_Guard->Guard_Open_And_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_C420_C021
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE   doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE           FALSE           TRUE            TRUE    doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE   doc=NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)->Safety_Lost_S_Guard_Or_S_GuardLock_False
  Data  4     TRUE      TRUE    FALSE        FALSE    FALSE        TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE   doc=S_SafetyActive->Safety_Return
  Data  5     TRUE      TRUE    FALSE        FALSE    FALSE        TRUE            FALSE         FALSE  16#C021    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE   doc=Reset AND NOT R_TRIG at Reset->Reset_Error_2
  Data  6     TRUE      TRUE    FALSE        FALSE    FALSE        TRUE            FALSE         FALSE  16#C021    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE   doc=Reset->Reset_Error_2
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_C021_C420
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE    doc=NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)->Safety_Lost_S_Guard_Or_S_GuardLock_False
  Data  4     TRUE      TRUE    FALSE        FALSE    FALSE        TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE    doc=S_SafetyActive->Safety_Return
  Data  5     TRUE      TRUE    FALSE        FALSE    FALSE        TRUE            FALSE         FALSE  16#C021    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE    doc=Reset AND NOT R_TRIG at Reset->Reset_Error_2
  Data  6     TRUE      FALSE   FALSE        FALSE    FALSE        TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE    doc=NOT Reset->Safety_Return
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_C050_C420
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE   doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE           FALSE           TRUE            TRUE    doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE   doc=NOT S_SafetyActive AND NOT (S_Guard AND S_GuardLock)->Safety Lost 2
  Data  4     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE   doc=PRIORITY_CHECK_8000 S_SafetyActive->Safety_Return
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_C450_C420
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE   doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE           FALSE           TRUE            TRUE    doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE            FALSE           TRUE            FALSE   doc=NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety_Lost_1
  Data  4     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE   doc=PRIORITY_CHECK_8000 S_SafetyActive->Safety_Return
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_C420_C450
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE   doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE   doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE           FALSE           TRUE            TRUE    doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE  16#C050    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE   doc=NOT S_SafetyActive AND NOT (S_Guard AND S_GuardLock)->Safety_Lost_1
  Data  4     TRUE      TRUE    FALSE        FALSE    FALSE        TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE   doc=S_SafetyActive->Safety_Return
  Data  5     TRUE      FALSE   FALSE        FALSE    FALSE        TRUE            FALSE         FALSE  16#C420    TRUE    TRUE    TRUE            FALSE           FALSE           FALSE   doc=S_SafetyActive->Safety_Return
  Data  6     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE   doc=PRIORITY_CHECK_8000 Reset AND R_TRIG at Reset AND NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety Lost 1
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_8822_8832
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE     doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE     doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE      doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE      doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         TRUE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE      doc=UnlockRequest->Guard_Closed_But_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_prio1_8812_C450
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE     doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      FALSE   TRUE         TRUE     TRUE         FALSE           FALSE         FALSE  16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE    doc=COMBO_CHECK_8000_A S_Guard AND S_GuardLock AND S_AutoReset AND NOT S_SafetyActive AND NOT UnlockRequest->Safety_Lost_1
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_prio2_8812_C450
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE     doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      FALSE   TRUE         TRUE     TRUE         FALSE           FALSE         TRUE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE    doc=COMBO_CHECK_8000_B S_Guard AND S_GuardLock AND S_AutoReset AND NOT S_SafetyActive AND UnlockRequest->Safety_Lost_1
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_8812_8822
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE     doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      FALSE   TRUE         TRUE     TRUE         TRUE            FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=PRIORITY_CHECK_8000 S_Guard AND S_GuardLock AND S_AutoReset AND S_SafetyActive AND UnlockRequest->Guard_Open_And_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_8430_C031
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE           FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE           FALSE           TRUE            TRUE     doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE     doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    FALSE           FALSE           FALSE           FALSE    doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#C031    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE    doc=Reset AND NOT R_TRIG at Reset->Reset_Error_3
  Data  7     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#C031    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE    doc=Reset->Reset_Error_3
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_C031_8430
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE     doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE    doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#C031    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE    doc=Reset AND NOT R_TRIG at Reset->Reset_Error_3
  Data  7     TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=NOT Reset->Wait_For_Reset
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_prio1_8430_C010
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE     doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE    doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6     TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=NOT Reset->Wait_For_Reset
  Data  7     TRUE      TRUE    FALSE        FALSE    FALSE        TRUE            FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE    doc=COMBO_CHECK_8000_A Reset AND R_TRIG at Reset AND NOT S_Guard AND NOT S_GuardLock AND NOT R_TRIG at UnlockRequest->Reset_Error_3
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_prio2_8430_C010
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE     doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE    doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6     TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=NOT Reset->Wait_For_Reset
  Data  7     TRUE      TRUE    FALSE        FALSE    FALSE        TRUE            FALSE         TRUE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE    doc=COMBO_CHECK_8000_B Reset AND R_TRIG at Reset AND NOT S_Guard AND NOT S_GuardLock AND R_TRIG at UnlockRequest->Reset_Error_3
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_prio3_8430_C010
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE     doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE    doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6     TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=NOT Reset->Wait_For_Reset
  Data  7     TRUE      TRUE    FALSE        FALSE    TRUE         TRUE            FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE    doc=COMBO_CHECK_8000_C Reset AND R_TRIG at Reset AND NOT S_Guard AND S_GuardLock AND NOT R_TRIG at UnlockRequest->Reset_Error_3
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_prio4_8430_C010
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE     doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE    doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6     TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=NOT Reset->Wait_For_Reset
  Data  7     TRUE      TRUE    FALSE        FALSE    TRUE         TRUE            FALSE         TRUE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE    doc=COMBO_CHECK_8000_D Reset AND R_TRIG at Reset AND NOT S_Guard AND S_GuardLock AND R_TRIG at UnlockRequest->Reset_Error_3
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_prio5_8430_C010
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE     doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE    doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6     TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=NOT Reset->Wait_For_Reset
  Data  7     TRUE      TRUE    FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE    doc=COMBO_CHECK_8000_E Reset AND R_TRIG at Reset AND S_Guard AND NOT S_GuardLock AND NOT R_TRIG at UnlockRequest->Reset_Error_3
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_prio6_8430_C010
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE     doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE    doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6     TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=NOT Reset->Wait_For_Reset
  Data  7     TRUE      TRUE    FALSE        TRUE     FALSE        TRUE            FALSE         TRUE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE    doc=COMBO_CHECK_8000_F Reset AND R_TRIG at Reset AND S_Guard AND NOT S_GuardLock AND R_TRIG at UnlockRequest->Reset_Error_3
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_8430_8000
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE    doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE     doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE     doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    FALSE          FALSE           FALSE           FALSE    doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6     TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE    doc=NOT Reset->Wait_For_Reset
  Data  7     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         TRUE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE    doc=PRIORITY_CHECK_8010 Reset AND R_TRIG at Reset AND S_Guard AND S_GuardLock AND R_TRIG at UnlockRequest->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_8801_C010
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE  16#8801    FALSE   TRUE    FALSE           FALSE           FALSE           TRUE   doc=Activate AND (NOT S_Guard OR NOT S_GuardLock)->Init_S_Guard_Or_S_GuardLock_False
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE  doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE  doc=NOT S_Guard AND NOT S_Guard_Lock->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_C410_C011
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C410    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=S_GuardLock AND S_Guard->Guard_Return
  Data  4     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C011    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C011    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_C011_C410
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE      doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C410    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE      doc=S_GuardLock AND S_Guard->Guard_Return
  Data  4     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C011    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE      doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Data  5     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C410    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE      doc=Reset AND NOT R_TRIG at Reset->Reset_Error_1
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_var1_C410_C010
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C410    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=S_GuardLock AND S_Guard->Guard_Return
  Data  4     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C410    TRUE    TRUE    TRUE            FALSE           FALSE           FALSE      doc=NOT Reset->Guard_Return
  Data  5     TRUE      TRUE    FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=COMBO_CHECK_8000_A Reset AND R_TRIG at Reset AND NOT S_GuardLock AND NOT S_Guard->Guard_Error
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_var2_C410_C010
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C410    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=S_GuardLock AND S_Guard->Guard_Return
  Data  4     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C410    TRUE    TRUE    TRUE            FALSE           FALSE           FALSE      doc=NOT Reset->Guard_Return
  Data  5     TRUE      TRUE    FALSE        TRUE     FALSE        FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=COMBO_CHECK_8000_B Reset AND R_TRIG at Reset AND NOT S_GuardLock AND S_Guard->Guard_Error
  Finish
  
test logicals.safety.plcopen.SF_GuardLocking_2_var3_C410_C010
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C410    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=S_GuardLock AND S_Guard->Guard_Return
  Data  4     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#C410    TRUE    TRUE    TRUE            FALSE           FALSE           FALSE      doc=NOT Reset->Guard_Return
  Data  5     TRUE      TRUE    FALSE        FALSE    TRUE         FALSE           FALSE         FALSE  16#C010    TRUE    TRUE    FALSE           FALSE           FALSE           FALSE      doc=COMBO_CHECK_8000_C Reset AND R_TRIG at Reset AND S_GuardLock AND NOT S_Guard->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_8832_8812
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE       doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE       doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE       doc=NOT UnlockRequest->Wait_For_Operator
  Data  5     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE  16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE       doc=NOT S_Guard AND NOT S_GuardLock AND NOT S_AutoReset->Wait_For_Operator
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_C440_C041
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE           FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE            FALSE           FALSE           FALSE      doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  4     TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE           TRUE            FALSE           FALSE      doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         TRUE   16#8010    FALSE   TRUE    FALSE           FALSE           TRUE            FALSE      doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  205   TRUE      TRUE    FALSE        FALSE    TRUE         TRUE            FALSE         FALSE  16#C440    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE      doc=Unlock_Timer_Elapsed->Unlock_Request_Error
  Data  206   TRUE      TRUE    FALSE        FALSE    TRUE         TRUE            FALSE         FALSE  16#C041    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE      doc=Reset AND NOT R_TRIG at Reset->Reset_Error_4
  Data  207   TRUE      TRUE    FALSE        FALSE    TRUE         TRUE            FALSE         FALSE  16#C041    TRUE    TRUE    FALSE           FALSE           TRUE            FALSE      doc=Reset->Reset_Error_4
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_C041_C440
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE  16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE      doc=NOT Activate->Idle
  Data  1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE      doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE      doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE      doc=(R_TRIG at Reset OR S_StartReset) AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  4     TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE  16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE      doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5     TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         TRUE   16#8010    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE      doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  205   TRUE      TRUE    FALSE        FALSE    TRUE         TRUE            FALSE         FALSE  16#C440    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE      doc=Unlock_Timer_Elapsed->Unlock_Request_Error
  Data  206   TRUE      TRUE    FALSE        FALSE    TRUE         TRUE            FALSE         FALSE  16#C041    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE      doc=Reset AND NOT R_TRIG at Reset->Reset_Error_4
  Data  207   TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE  16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE      doc=NOT Reset->Unlock_Request_Error
  Finish

#                                            DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
#@startuml
#Idle:                                       16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE
#Guard_Closed_And_Locked:                    16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE
#Init_S_Guard_And_S_GuardLock_True:          16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE
#Init_S_Guard_Or_S_GuardLock_False:          16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE 
#Wait_For_Reset:                             16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE
#Wait_For_Operator:                          16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE 
#Guard_Open_And_Unlocked:                    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE 
#Guard_Closed_But_Unlocked:                  16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE 
#Wait_For_Unlocked:                          16#8010    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE
#Guard_Error:                                16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE
#Guard_Return:                               16#C410    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE
#Safety_Lost_S_Guard_And_S_GuardLock_True:   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE
#Safety_Lost_S_Guard_Or_S_GuardLock_False:   16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE
#Safety_Return:                              16#C420    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE
#Unlock_Request_Error:                       16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE
#
#T:.                                                                               Time  Activate  Reset   S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest
#T:NOT Activate:                                                                   1     FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE 
#T:Activate AND S_Guard AND S_GuardLock:                                           1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE 
#T:Activate AND (NOT S_Guard OR NOT S_GuardLock):                                  1     TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE 
#T:R_TRIG at Reset AND S_Guard AND S_GuardLock:                                    1     TRUE      R_EDGE  FALSE        TRUE     TRUE         FALSE           FALSE         FALSE 
#T:R_TRIG at Reset AND S_Guard AND R_TRIG at S_GuardLock:                          1     TRUE      R_EDGE  FALSE        TRUE     R_EDGE       FALSE           FALSE         FALSE 
#T:NOT Reset:                                                                      1     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE 
#T:NOT S_Guard AND NOT UnlockRequest:                                              1     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE 
#T:NOT S_Guard AND UnlockRequest:                                                  1     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE  
#T:NOT S_SafetyActive AND S_Guard AND S_GuardLock:                                 1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE 
#T:NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock):                        1     TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE 
#T:S_SafetyActive:                                                                 1     TRUE      FALSE   FALSE        FALSE    FALSE        TRUE            FALSE         FALSE 
#T:R_TRIG at Reset AND (NOT S_GuardLock OR NOT S_Guard) 1:                         1     TRUE      R_EDGE  FALSE        FALSE    TRUE         TRUE            FALSE         FALSE 
#T:R_TRIG at Reset AND (NOT S_GuardLock OR NOT S_Guard) 2:                         1     TRUE      R_EDGE  FALSE        TRUE     FALSE        TRUE            FALSE         FALSE 
#T:S_Guard AND S_GuardLock AND S_AutoReset:                                        1     TRUE      FALSE   TRUE         TRUE     TRUE         TRUE            FALSE         FALSE 
#T:NOT S_Guard OR NOT S_GuardLock:                                                 1     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE 
#T:NOT S_GuardLock OR NOT S_Guard:                                                 1     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE 
#T:S_GuardLock AND S_Guard:                                                        1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE 
#T:R_TRIG at Reset:                                                                1     TRUE      R_EDGE  FALSE        TRUE     TRUE         FALSE           FALSE         FALSE 
#T:R_TRIG at Reset AND S_GuardLock AND S_Guard AND NOT S_SafetyActive:             1     TRUE      R_EDGE  FALSE        TRUE     TRUE         FALSE           FALSE         FALSE 
#T:R_TRIG at Reset AND R_TRIG at S_GuardLock AND S_Guard AND NOT S_SafetyActive:   1     TRUE      R_EDGE  FALSE        TRUE     R_EDGE       FALSE           FALSE         FALSE 
#T:R_TRIG at Reset AND S_GuardLock AND S_Guard AND S_SafetyActive:                 1     TRUE      R_EDGE  FALSE        TRUE     TRUE         TRUE            FALSE         FALSE 
#T:R_TRIG at UnlockRequest AND S_SafetyActive:                                     1     TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         R_EDGE
#T:S_Guard AND S_GuardLock AND NOT S_AutoReset:                                    1     TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE 
#T:NOT UnlockRequest:                                                              1     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE 
#T:S_Guard:                                                                        1     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE 
#T:NOT S_Guard:                                                                    1     TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE 
#T:R_TRIG at UnlockRequest:                                                        1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         R_EDGE
#T:(S_SafetyActive AND UnlockRequest) OR NOT S_Guard 1:                            1     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         TRUE  
#T:(S_SafetyActive AND UnlockRequest) OR NOT S_Guard 2:                            1     TRUE      FALSE   FALSE        FALSE    FALSE        TRUE            FALSE         FALSE 
#T:NOT S_GuardLock:                                                                1     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE 
#T:Unlock_Timer_Elapsed:                                                         200     TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE 
#T:NOT Reset AND S_Guard AND NOT S_GuardLock:                                      1     TRUE      FALSE   FALSE        TRUE     FALSE        FALSE           FALSE         FALSE 
#T:NOT Reset AND S_Guard AND S_GuardLock AND NOT S_StartReset:                     1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE 
#T:NOT S_Guard AND NOT S_GuardLock AND NOT S_SafetyActive:                         1     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE 
#T:NOT Reset AND S_Guard AND S_GuardLock AND NOT S_SafetyActive:                   1     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE 
#
#T:SUBCONDITION_CHECK_A NOT S_GuardLock OR NOT S_Guard:                            1     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE 
#T:SUBCONDITION_CHECK_B NOT S_Guard:                                               1     TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE 
#T:SUBCONDITION_CHECK_C NOT S_GuardLock:                                           1     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE 

#[*]-->Idle: NOT Activate
#Idle-->Init_S_Guard_And_S_GuardLock_True: Activate AND S_Guard AND S_GuardLock
#Idle-->Init_S_Guard_Or_S_GuardLock_False: Activate AND (NOT S_Guard OR NOT S_GuardLock)
#Init_S_Guard_And_S_GuardLock_True-->Guard_Open_And_Unlocked: NOT S_Guard AND UnlockRequest
#Init_S_Guard_And_S_GuardLock_True-->Guard_Error: NOT S_Guard AND NOT UnlockRequest
#Init_S_Guard_And_S_GuardLock_True-->Guard_Closed_And_Locked: R_TRIG at Reset AND S_Guard AND S_GuardLock
#Init_S_Guard_And_S_GuardLock_True-->Init_S_Guard_Or_S_GuardLock_False: NOT Reset AND S_Guard AND NOT S_GuardLock
#Init_S_Guard_Or_S_GuardLock_False-->Guard_Open_And_Unlocked: NOT S_Guard AND UnlockRequest
#Init_S_Guard_Or_S_GuardLock_False-->Guard_Error: NOT S_Guard AND NOT UnlockRequest
#Init_S_Guard_Or_S_GuardLock_False-->Guard_Closed_And_Locked: R_TRIG at Reset AND S_Guard AND R_TRIG at S_GuardLock
#Init_S_Guard_Or_S_GuardLock_False-->Init_S_Guard_And_S_GuardLock_True: NOT Reset AND S_Guard AND S_GuardLock AND NOT S_StartReset
#Guard_Open_And_Unlocked-->Safety_Lost_S_Guard_And_S_GuardLock_True: NOT S_SafetyActive AND S_Guard AND S_GuardLock
#Guard_Open_And_Unlocked-->Safety_Lost_S_Guard_Or_S_GuardLock_False: NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)
#Guard_Open_And_Unlocked-->Guard_Closed_But_Unlocked: S_Guard
#Guard_Open_And_Unlocked-->Idle: NOT Activate
#Guard_Closed_But_Unlocked-->Safety_Lost_S_Guard_And_S_GuardLock_True: NOT S_SafetyActive AND S_Guard AND S_GuardLock
#Guard_Closed_But_Unlocked-->Safety_Lost_S_Guard_Or_S_GuardLock_False: NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)
#Guard_Closed_But_Unlocked-->Guard_Open_And_Unlocked: NOT S_Guard
#Guard_Closed_But_Unlocked-->Wait_For_Operator: NOT UnlockRequest
#Wait_For_Unlocked-->Safety_Lost_S_Guard_And_S_GuardLock_True: NOT S_SafetyActive AND S_Guard AND S_GuardLock
#Wait_For_Unlocked-->Safety_Lost_S_Guard_Or_S_GuardLock_False: NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)
#Wait_For_Unlocked-->Guard_Closed_But_Unlocked: NOT S_GuardLock
#Unlock_Request_Error-->Guard_Error: NOT S_Guard OR NOT S_GuardLock
#Unlock_Request_Error-->Guard_Closed_And_Locked: R_TRIG at Reset AND S_GuardLock AND S_Guard AND NOT S_SafetyActive
#Safety_Lost_S_Guard_And_S_GuardLock_True-->Safety_Return: S_SafetyActive
#Safety_Lost_S_Guard_And_S_GuardLock_True-->Guard_Closed_And_Locked : R_TRIG at Reset AND S_GuardLock AND S_Guard AND NOT S_SafetyActive
#Safety_Lost_S_Guard_And_S_GuardLock_True-->Safety_Lost_S_Guard_Or_S_GuardLock_False: NOT S_Guard AND NOT S_GuardLock AND NOT S_SafetyActive
#Safety_Lost_S_Guard_Or_S_GuardLock_False-->Safety_Return: S_SafetyActive
#Safety_Lost_S_Guard_Or_S_GuardLock_False-->Guard_Closed_And_Locked : R_TRIG at Reset AND R_TRIG at S_GuardLock AND S_Guard AND NOT S_SafetyActive
#Safety_Lost_S_Guard_Or_S_GuardLock_False-->Safety_Lost_S_Guard_And_S_GuardLock_True: NOT Reset AND S_Guard AND S_GuardLock AND NOT S_SafetyActive
#Safety_Return-->Safety_Lost_S_Guard_And_S_GuardLock_True: NOT S_SafetyActive AND S_Guard AND S_GuardLock
#Safety_Return-->Safety_Lost_S_Guard_Or_S_GuardLock_False: NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)
#Safety_Return-->Wait_For_Operator: R_TRIG at Reset AND (NOT S_GuardLock OR NOT S_Guard) 1
#Safety_Return-->Wait_For_Operator: R_TRIG at Reset AND (NOT S_GuardLock OR NOT S_Guard) 2
#Safety_Return-->Guard_Closed_And_Locked: R_TRIG at Reset AND S_GuardLock AND S_Guard AND S_SafetyActive
#Wait_For_Operator-->Safety_Lost_S_Guard_And_S_GuardLock_True: NOT S_SafetyActive AND S_Guard AND S_GuardLock
#Wait_For_Operator-->Safety_Lost_S_Guard_Or_S_GuardLock_False: NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)
#Wait_For_Operator-->Guard_Open_And_Unlocked: (S_SafetyActive AND UnlockRequest) OR NOT S_Guard 1
#Wait_For_Operator-->Guard_Open_And_Unlocked: (S_SafetyActive AND UnlockRequest) OR NOT S_Guard 2
#Wait_For_Operator-->Wait_For_Reset: S_Guard AND S_GuardLock AND NOT S_AutoReset
#Wait_For_Operator-->Guard_Closed_And_Locked: S_Guard AND S_GuardLock AND S_AutoReset
#Wait_For_Reset-->Guard_Error: NOT S_Guard OR NOT S_GuardLock
#Wait_For_Reset-->Guard_Closed_And_Locked: R_TRIG at Reset
#Wait_For_Reset-->Wait_For_Unlocked: R_TRIG at UnlockRequest
#Guard_Error-->Guard_Return: S_GuardLock AND S_Guard
#Guard_Return-->Guard_Error: NOT S_GuardLock OR NOT S_Guard
#Guard_Return-->Guard_Closed_And_Locked: R_TRIG at Reset
#Guard_Closed_And_Locked-->Guard_Error: SUBCONDITION_CHECK_A NOT S_GuardLock OR NOT S_Guard
#Guard_Closed_And_Locked-->Wait_For_Unlocked: R_TRIG at UnlockRequest AND S_SafetyActive
#Wait_For_Reset-->Guard_Error: NOT S_Guard
#Wait_For_Reset-->Guard_Error: NOT S_GuardLock
#Unlock_Request_Error-->Guard_Error: NOT S_Guard
#Unlock_Request_Error-->Guard_Error: NOT S_GuardLock
#Guard_Closed_And_Locked-->Guard_Error: SUBCONDITION_CHECK_B NOT S_Guard
#Guard_Closed_And_Locked-->Guard_Error: SUBCONDITION_CHECK_C NOT S_GuardLock
#Wait_For_Unlocked-->Unlock_Request_Error: Unlock_Timer_Elapsed
#@enduml
#@begin generated
test logicals.safety.plcopen.SF_GuardLocking_2_0
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        TRUE     FALSE        FALSE           FALSE         FALSE   16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=NOT Reset AND S_Guard AND NOT S_GuardLock->Init_S_Guard_Or_S_GuardLock_False
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_1
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE   16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=Activate AND (NOT S_Guard OR NOT S_GuardLock)->Init_S_Guard_Or_S_GuardLock_False
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_2
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE   16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=Activate AND (NOT S_Guard OR NOT S_GuardLock)->Init_S_Guard_Or_S_GuardLock_False
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_3
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE   16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=Activate AND (NOT S_Guard OR NOT S_GuardLock)->Init_S_Guard_Or_S_GuardLock_False
  Data  2       TRUE      FALSE   FALSE        TRUE     FALSE        FALSE           FALSE         FALSE   16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=R_TRIG at Reset AND S_Guard AND R_TRIG at S_GuardLock->Guard_Closed_And_Locked
  Data  3       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND R_TRIG at S_GuardLock->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_4
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE   16#8801    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=Activate AND (NOT S_Guard OR NOT S_GuardLock)->Init_S_Guard_Or_S_GuardLock_False
  Data  2       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=NOT Reset AND S_Guard AND S_GuardLock AND NOT S_StartReset->Init_S_Guard_And_S_GuardLock_True
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_5
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_6
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  4       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=SUBCONDITION_CHECK_A NOT S_GuardLock OR NOT S_Guard->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_7
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  4       TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=SUBCONDITION_CHECK_B NOT S_Guard->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_8
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  4       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=SUBCONDITION_CHECK_C NOT S_GuardLock->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_9
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety_Lost_S_Guard_And_S_GuardLock_True
  Data  4       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=R_TRIG at Reset AND S_GuardLock AND S_Guard AND NOT S_SafetyActive->Guard_Closed_And_Locked
  Data  5       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_GuardLock AND S_Guard AND NOT S_SafetyActive->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_10
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety_Lost_S_Guard_And_S_GuardLock_True
  Data  4       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_Guard AND NOT S_GuardLock AND NOT S_SafetyActive->Safety_Lost_S_Guard_Or_S_GuardLock_False
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_11
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE   16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)->Safety_Lost_S_Guard_Or_S_GuardLock_False
  Data  4       TRUE      FALSE   FALSE        FALSE    FALSE        TRUE            FALSE         FALSE   16#C420    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_SafetyActive->Safety_Return
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_12
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE   16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)->Safety_Lost_S_Guard_Or_S_GuardLock_False
  Data  4       TRUE      FALSE   FALSE        TRUE     FALSE        FALSE           FALSE         FALSE   16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=R_TRIG at Reset AND R_TRIG at S_GuardLock AND S_Guard AND NOT S_SafetyActive->Guard_Closed_And_Locked
  Data  5       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND R_TRIG at S_GuardLock AND S_Guard AND NOT S_SafetyActive->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_13
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE   16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)->Safety_Lost_S_Guard_Or_S_GuardLock_False
  Data  4       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT Reset AND S_Guard AND S_GuardLock AND NOT S_SafetyActive->Safety_Lost_S_Guard_And_S_GuardLock_True
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_14
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety_Lost_S_Guard_And_S_GuardLock_True
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_15
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE   16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)->Safety_Lost_S_Guard_Or_S_GuardLock_False
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_16
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard->Guard_Open_And_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_17
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C410    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_GuardLock AND S_Guard->Guard_Return
  Data  4       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_GuardLock OR NOT S_Guard->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_18
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard AND NOT UnlockRequest->Guard_Error
  Data  3       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C410    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_GuardLock AND S_Guard->Guard_Return
  Data  4       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C410    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset->Guard_Closed_And_Locked
  Data  5       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_19
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  4       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         TRUE    16#8010    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  6       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety_Lost_S_Guard_And_S_GuardLock_True
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_20
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  4       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         TRUE    16#8010    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  6       TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE   16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)->Safety_Lost_S_Guard_Or_S_GuardLock_False
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_21
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  4       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         TRUE    16#8010    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  6       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_GuardLock->Guard_Closed_But_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_22
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety_Lost_S_Guard_And_S_GuardLock_True
  Data  4       TRUE      FALSE   FALSE        FALSE    FALSE        TRUE            FALSE         FALSE   16#C420    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_SafetyActive->Safety_Return
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety_Lost_S_Guard_And_S_GuardLock_True
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_23
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety_Lost_S_Guard_And_S_GuardLock_True
  Data  4       TRUE      FALSE   FALSE        FALSE    FALSE        TRUE            FALSE         FALSE   16#C420    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_SafetyActive->Safety_Return
  Data  5       TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE   16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)->Safety_Lost_S_Guard_Or_S_GuardLock_False
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_24
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety_Lost_S_Guard_And_S_GuardLock_True
  Data  4       TRUE      FALSE   FALSE        FALSE    FALSE        TRUE            FALSE         FALSE   16#C420    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_SafetyActive->Safety_Return
  Data  5       TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE   16#C420    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND (NOT S_GuardLock OR NOT S_Guard) 1->Wait_For_Operator
  Data  6       TRUE      TRUE    FALSE        FALSE    TRUE         TRUE            FALSE         FALSE   16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=R_TRIG at Reset AND (NOT S_GuardLock OR NOT S_Guard) 1->Wait_For_Operator
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_25
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety_Lost_S_Guard_And_S_GuardLock_True
  Data  4       TRUE      FALSE   FALSE        FALSE    FALSE        TRUE            FALSE         FALSE   16#C420    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_SafetyActive->Safety_Return
  Data  5       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#C420    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND (NOT S_GuardLock OR NOT S_Guard) 2->Wait_For_Operator
  Data  6       TRUE      TRUE    FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=R_TRIG at Reset AND (NOT S_GuardLock OR NOT S_Guard) 2->Wait_For_Operator
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_26
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety_Lost_S_Guard_And_S_GuardLock_True
  Data  4       TRUE      FALSE   FALSE        FALSE    FALSE        TRUE            FALSE         FALSE   16#C420    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_SafetyActive->Safety_Return
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#C420    TRUE    TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND S_GuardLock AND S_Guard AND S_SafetyActive->Guard_Closed_And_Locked
  Data  6       TRUE      TRUE    FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_GuardLock AND S_Guard AND S_SafetyActive->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_27
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=NOT UnlockRequest->Wait_For_Operator
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C450    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND S_Guard AND S_GuardLock->Safety_Lost_S_Guard_And_S_GuardLock_True
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_28
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=NOT UnlockRequest->Wait_For_Operator
  Data  5       TRUE      FALSE   FALSE        FALSE    TRUE         FALSE           FALSE         FALSE   16#C050    TRUE    TRUE    FALSE          FALSE           TRUE            FALSE  doc=NOT S_SafetyActive AND (NOT S_Guard OR NOT S_GuardLock)->Safety_Lost_S_Guard_Or_S_GuardLock_False
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_29
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=NOT UnlockRequest->Wait_For_Operator
  Data  5       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=(S_SafetyActive AND UnlockRequest) OR NOT S_Guard 1->Guard_Open_And_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_30
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=NOT UnlockRequest->Wait_For_Operator
  Data  5       TRUE      FALSE   FALSE        FALSE    FALSE        TRUE            FALSE         FALSE   16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=(S_SafetyActive AND UnlockRequest) OR NOT S_Guard 2->Guard_Open_And_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_31
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=NOT UnlockRequest->Wait_For_Operator
  Data  5       TRUE      FALSE   TRUE         TRUE     TRUE         TRUE            FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=S_Guard AND S_GuardLock AND S_AutoReset->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_32
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  4       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         TRUE    16#8010    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  205     TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE   16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=Unlock_Timer_Elapsed->Unlock_Request_Error
  Data  206     TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard OR NOT S_GuardLock->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_33
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  4       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         TRUE    16#8010    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  205     TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE   16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=Unlock_Timer_Elapsed->Unlock_Request_Error
  Data  206     TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=R_TRIG at Reset AND S_GuardLock AND S_Guard AND NOT S_SafetyActive->Guard_Closed_And_Locked
  Data  207     TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_GuardLock AND S_Guard AND NOT S_SafetyActive->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_34
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  4       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         TRUE    16#8010    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  205     TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE   16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=Unlock_Timer_Elapsed->Unlock_Request_Error
  Data  206     TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_35
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  3       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset AND S_Guard AND S_GuardLock->Guard_Closed_And_Locked
  Data  4       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         TRUE    16#8010    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE  doc=R_TRIG at UnlockRequest AND S_SafetyActive->Wait_For_Unlocked
  Data  205     TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE   16#C440    TRUE    TRUE    TRUE           FALSE           TRUE            FALSE  doc=Unlock_Timer_Elapsed->Unlock_Request_Error
  Data  206     TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_GuardLock->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_36
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=NOT UnlockRequest->Wait_For_Operator
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard OR NOT S_GuardLock->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_37
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=NOT UnlockRequest->Wait_For_Operator
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at Reset->Guard_Closed_And_Locked
  Data  7       TRUE      TRUE    FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8000    FALSE   TRUE    FALSE          TRUE            FALSE           FALSE  doc=R_TRIG at Reset->Guard_Closed_And_Locked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_38
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=NOT UnlockRequest->Wait_For_Operator
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=R_TRIG at UnlockRequest->Wait_For_Unlocked
  Data  7       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         TRUE    16#8010    FALSE   TRUE    FALSE          FALSE           TRUE            FALSE  doc=R_TRIG at UnlockRequest->Wait_For_Unlocked
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_39
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=NOT UnlockRequest->Wait_For_Operator
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6       TRUE      FALSE   FALSE        FALSE    TRUE         TRUE            FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_Guard->Guard_Error
  Finish

test logicals.safety.plcopen.SF_GuardLocking_2_40
  Head  Time  Activate  Reset  S_AutoReset  S_Guard  S_GuardLock  S_SafetyActive  S_StartReset  UnlockRequest  DiagCode?  Error?  Ready?  ResetRequest?  S_GuardLocked?  S_UnlockGuard?  SafetyDemand?  CycleTime=T#10ms
  Tol  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Shift  /  /  /  /  /  /  /  /  /  0  0  0  0  0  0  0
  Data  0       FALSE     FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         FALSE   16#0000    FALSE   FALSE   FALSE          FALSE           FALSE           FALSE  doc=NOT Activate->Idle
  Data  1       TRUE      FALSE   FALSE        TRUE     TRUE         FALSE           FALSE         FALSE   16#8401    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=Activate AND S_Guard AND S_GuardLock->Init_S_Guard_And_S_GuardLock_True
  Data  2       TRUE      FALSE   FALSE        FALSE    FALSE        FALSE           FALSE         TRUE    16#8822    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=NOT S_Guard AND UnlockRequest->Guard_Open_And_Unlocked
  Data  3       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8832    FALSE   TRUE    FALSE          FALSE           TRUE            TRUE   doc=S_Guard->Guard_Closed_But_Unlocked
  Data  4       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#8812    FALSE   TRUE    FALSE          FALSE           FALSE           TRUE   doc=NOT UnlockRequest->Wait_For_Operator
  Data  5       TRUE      FALSE   FALSE        TRUE     TRUE         TRUE            FALSE         FALSE   16#8430    FALSE   TRUE    TRUE           FALSE           FALSE           FALSE  doc=S_Guard AND S_GuardLock AND NOT S_AutoReset->Wait_For_Reset
  Data  6       TRUE      FALSE   FALSE        TRUE     FALSE        TRUE            FALSE         FALSE   16#C010    TRUE    TRUE    FALSE          FALSE           FALSE           FALSE  doc=NOT S_GuardLock->Guard_Error
  Finish

