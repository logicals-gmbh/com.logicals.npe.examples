#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEII__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEII__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcdt___safety.plcopen.sf_twohandcontroltypeii_state.h>
#include <lcfu_iec61131__CONVERT.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEII
{
  LC_TD_BOOL LC_VD_ACTIVATE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_BUTTON1;
  LC_TD_DataType_SAFEBOOL LC_VD_S_BUTTON2;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_ERROR;
  LC_TD_BOOL LC_VD_READY;
  LC_TD_BOOL LC_VD_SAFETYDEMAND;
  LC_TD_WORD LC_VD_DIAGCODE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_TWOHANDOUT;
} LCCG_StructAttrib LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEII;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEII(p) \
{ \
  (p)->LC_VD_ACTIVATE = LC_EL_false; \
  (p)->LC_VD_S_BUTTON1 = LC_EL_false; \
  (p)->LC_VD_S_BUTTON2 = LC_EL_false; \
  (p)->LC_VD_READY = LC_EL_false; \
  (p)->LC_VD_S_TWOHANDOUT = LC_EL_false; \
  (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  (p)->LC_VD_ERROR = LC_EL_false; \
  (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEII(p,RF) \
{ \
  if (RF==0) (p)->LC_VD_ACTIVATE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_BUTTON1 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_BUTTON2 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_READY = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_TWOHANDOUT = LC_EL_false; \
  if (RF==0) (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  if (RF==0) (p)->LC_VD_ERROR = LC_EL_false; \
  if (RF==0) (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
}

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEII(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEII* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
