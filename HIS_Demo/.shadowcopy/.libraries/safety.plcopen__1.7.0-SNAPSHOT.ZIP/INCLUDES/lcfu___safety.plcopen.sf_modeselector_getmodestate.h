#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcdt___safety.plcopen.sf_modeselector_modestate.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_INT LC_VD_SF_MODESELECTOR_GETMODESTATE;
} LCCG_StructAttrib LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE(p) \
{ \
  LC_INIT_INT(&((p)->LC_VD_SF_MODESELECTOR_GETMODESTATE)); \
}

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE(LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE* LC_this, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE0, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE1, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE2, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE3, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE4, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE5, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE6, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE7, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
