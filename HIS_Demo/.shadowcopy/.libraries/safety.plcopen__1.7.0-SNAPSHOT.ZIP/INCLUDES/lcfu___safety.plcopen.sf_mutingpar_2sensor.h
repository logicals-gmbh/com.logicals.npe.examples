#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcdt___safety.plcopen.sf_mutingpar_2sensor_state.h>
#include <lcfu___safety.plcopen.sf_mutingpar_2sensor_geterrorstate.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__R_TRIG.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR
{
  LC_TD_BOOL LC_VD_ACTIVATE;
  LC_TD_BOOL LC_VD_MUTINGENABLE;
  LC_TD_BOOL LC_VD_MUTINGSWITCH11;
  LC_TD_BOOL LC_VD_MUTINGSWITCH12;
  LC_TD_BOOL LC_VD_RESET;
  LC_TD_TIME LC_VD_DISCTIMEENTRY;
  LC_TD_TIME LC_VD_MAXMUTINGTIME;
  LC_TD_DataType_SAFEBOOL LC_VD_S_AOPD_IN;
  LC_TD_DataType_SAFEBOOL LC_VD_S_STARTRESET;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_ERROR;
  LC_TD_BOOL LC_VD_READY;
  LC_TD_BOOL LC_VD_RESETREQUEST;
  LC_TD_BOOL LC_VD_SAFETYDEMAND;
  LC_TD_WORD LC_VD_DIAGCODE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_AOPD_OUT;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MUTINGACTIVE;
  LC_TD_FunctionBlock_TON LC_VD_DISCTIMEENTRYTIMER;
  LC_TD_FunctionBlock_TON LC_VD_MUTINGTIMER;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG_RESET;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG_S11;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG_S12;
} LCCG_StructAttrib LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR(p) LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR(p,RF) LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
