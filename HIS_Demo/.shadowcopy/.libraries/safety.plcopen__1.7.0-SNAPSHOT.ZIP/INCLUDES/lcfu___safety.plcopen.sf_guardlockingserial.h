#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcdt___safety.plcopen.sf_guardlockingserial_state.h>
#include <lcfu___safety.plcopen.sf_guardlockingserial_determinesafetylost.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__R_TRIG.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL
{
  LC_TD_BOOL LC_VD_ACTIVATE;
  LC_TD_BOOL LC_VD_RESET;
  LC_TD_BOOL LC_VD_UNLOCKREQUEST;
  LC_TD_DataType_SAFEBOOL LC_VD_S_AUTORESET;
  LC_TD_DataType_SAFEBOOL LC_VD_S_GUARD;
  LC_TD_DataType_SAFEBOOL LC_VD_S_SAFETYACTIVE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_STARTRESET;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_ERROR;
  LC_TD_BOOL LC_VD_READY;
  LC_TD_BOOL LC_VD_RESETREQUEST;
  LC_TD_BOOL LC_VD_SAFETYDEMAND;
  LC_TD_WORD LC_VD_DIAGCODE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_GUARDLOCKED;
  LC_TD_DataType_SAFEBOOL LC_VD_S_UNLOCKGUARD;
  LC_TD_FunctionBlock_R_TRIG LC_VD_RTRIGRESET;
  LC_TD_FunctionBlock_R_TRIG LC_VD_RTRIGUNLOCKREQUEST;
  LC_TD_FunctionBlock_TON LC_VD_UNLOCKWAITINGTIMER;
} LCCG_StructAttrib LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL(p) LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL(p,RF) LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
