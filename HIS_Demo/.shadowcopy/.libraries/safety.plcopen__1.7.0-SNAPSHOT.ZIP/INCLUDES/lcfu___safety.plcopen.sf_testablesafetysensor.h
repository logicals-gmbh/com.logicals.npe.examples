#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcdt___safety.plcopen.sf_testablesafetysensor_state.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__F_TRIG.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__R_TRIG.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR
{
  LC_TD_BOOL LC_VD_ACTIVATE;
  LC_TD_BOOL LC_VD_NOEXTERNALTEST;
  LC_TD_BOOL LC_VD_RESET;
  LC_TD_BOOL LC_VD_STARTTEST;
  LC_TD_TIME LC_VD_TESTTIME;
  LC_TD_DataType_SAFEBOOL LC_VD_S_AUTORESET;
  LC_TD_DataType_SAFEBOOL LC_VD_S_OSSD_IN;
  LC_TD_DataType_SAFEBOOL LC_VD_S_STARTRESET;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_ERROR;
  LC_TD_BOOL LC_VD_READY;
  LC_TD_BOOL LC_VD_RESETREQUEST;
  LC_TD_BOOL LC_VD_SAFETYDEMAND;
  LC_TD_BOOL LC_VD_TESTEXECUTED;
  LC_TD_BOOL LC_VD_TESTPOSSIBLE;
  LC_TD_WORD LC_VD_DIAGCODE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_OSSD_OUT;
  LC_TD_DataType_SAFEBOOL LC_VD_S_TESTOUT;
  LC_TD_FunctionBlock_F_TRIG LC_VD_FTRIGSOSSDIN;
  LC_TD_FunctionBlock_R_TRIG LC_VD_RTRIGRESET;
  LC_TD_FunctionBlock_R_TRIG LC_VD_RTRIGSOSSDIN;
  LC_TD_FunctionBlock_R_TRIG LC_VD_RTRIGSTARTTEST;
  LC_TD_FunctionBlock_TON LC_VD_TIMER1;
  LC_TD_FunctionBlock_TON LC_VD_TIMER2;
} LCCG_StructAttrib LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR(p) LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR(p,RF) LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
