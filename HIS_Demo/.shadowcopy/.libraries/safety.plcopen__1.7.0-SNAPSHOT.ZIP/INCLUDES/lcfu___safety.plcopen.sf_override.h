#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_OVERRIDE__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_OVERRIDE__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcdt___safety.plcopen.sf_override_state.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__R_TRIG.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE
{
  LC_TD_BOOL LC_VD_ACTIVATE;
  LC_TD_BOOL LC_VD_MUTINGERROR;
  LC_TD_BOOL LC_VD_MUTINGSWITCH11;
  LC_TD_BOOL LC_VD_MUTINGSWITCH12;
  LC_TD_BOOL LC_VD_MUTINGSWITCH21;
  LC_TD_BOOL LC_VD_MUTINGSWITCH22;
  LC_TD_BOOL LC_VD_RESET;
  LC_TD_TIME LC_VD_MAXOVERRIDETIME;
  LC_TD_DataType_SAFEBOOL LC_VD_S_AOPD_IN;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MUTING_AOPD_OUT;
  LC_TD_DataType_SAFEBOOL LC_VD_S_STARTSTOPOVERRIDE;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_ERROR;
  LC_TD_BOOL LC_VD_OVERRIDEACTIVE;
  LC_TD_BOOL LC_VD_OVERRIDEPOSSIBLE;
  LC_TD_BOOL LC_VD_READY;
  LC_TD_BOOL LC_VD_RESETREQUEST;
  LC_TD_BOOL LC_VD_SAFETYDEMAND;
  LC_TD_WORD LC_VD_DIAGCODE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_AOPD_OUT;
  LC_TD_BOOL LC_VD_ANYSWITCHACTIVE;
  LC_TD_FunctionBlock_TON LC_VD_OVERRIDETIMER;
  LC_TD_FunctionBlock_R_TRIG LC_VD_RTRIGRESET;
  LC_TD_FunctionBlock_R_TRIG LC_VD_RTRIGSTARTSTOPOVERRIDE;
} LCCG_StructAttrib LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE(p) LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE(p,RF) LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_OVERRIDE(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
