#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MODESELECTOR__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MODESELECTOR__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcdt___safety.plcopen.sf_modeselector_modestate.h>
#include <lcdt___safety.plcopen.sf_modeselector_state.h>
#include <lcfu___safety.plcopen.sf_modeselector_geterroropencircuit.h>
#include <lcfu___safety.plcopen.sf_modeselector_geterrorshortcircuit.h>
#include <lcfu___safety.plcopen.sf_modeselector_getmodestate.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__R_TRIG.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR
{
  LC_TD_BOOL LC_VD_ACTIVATE;
  LC_TD_BOOL LC_VD_AUTOSETMODE;
  LC_TD_BOOL LC_VD_RESET;
  LC_TD_TIME LC_VD_MODEMONITORTIME;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE0;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE1;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE2;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE3;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE4;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE5;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE6;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE7;
  LC_TD_DataType_SAFEBOOL LC_VD_S_SETMODE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_UNLOCK;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_ERROR;
  LC_TD_BOOL LC_VD_READY;
  LC_TD_BOOL LC_VD_RESETREQUEST;
  LC_TD_BOOL LC_VD_SAFETYDEMAND;
  LC_TD_WORD LC_VD_DIAGCODE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_ANYMODESEL;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE0SEL;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE1SEL;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE2SEL;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE3SEL;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE4SEL;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE5SEL;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE6SEL;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MODE7SEL;
  LC_TD_FunctionBlock_TON LC_VD_MODEMONITORTIMER;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG_RESET;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG_S_SETMODE;
} LCCG_StructAttrib LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR(p) LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR(p,RF) LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
