#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_OUTCONTROL__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_OUTCONTROL__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcdt___safety.plcopen.sf_outcontrol_state.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__R_TRIG.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL
{
  LC_TD_BOOL LC_VD_ACTIVATE;
  LC_TD_BOOL LC_VD_PROCESSCONTROL;
  LC_TD_BOOL LC_VD_RESET;
  LC_TD_BOOL LC_VD_STATICCONTROL;
  LC_TD_DataType_SAFEBOOL LC_VD_S_AUTORESET;
  LC_TD_DataType_SAFEBOOL LC_VD_S_SAFECONTROL;
  LC_TD_DataType_SAFEBOOL LC_VD_S_STARTRESET;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_ERROR;
  LC_TD_BOOL LC_VD_READY;
  LC_TD_BOOL LC_VD_RESETREQUEST;
  LC_TD_BOOL LC_VD_SAFETYDEMAND;
  LC_TD_WORD LC_VD_DIAGCODE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_OUTCONTROL;
  LC_TD_FunctionBlock_R_TRIG LC_VD_RTRIGPROCESSCONTROL;
  LC_TD_FunctionBlock_R_TRIG LC_VD_RTRIGRESET;
} LCCG_StructAttrib LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL(p) LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL(p,RF) LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_OUTCONTROL(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
