#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_RESETBUTTON__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_RESETBUTTON__H

#include <LC3CGBase.h>
#include <lcdt___safety.plcopen.sf_resetbutton_state.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__F_TRIG.h>
#include <lcfu_iec61131__R_TRIG.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON
{
  LC_TD_BOOL LC_VD_RESETIN;
  LC_TD_BOOL LC_VD_RESETREQUESTED;
  LC_TD_TIME LC_VD_TRAILINGMAXIMUM;
  LC_TD_TIME LC_VD_TRAILINGMINIMUM;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_ERROR;
  LC_TD_BOOL LC_VD_READY;
  LC_TD_BOOL LC_VD_RESETOUT;
  LC_TD_WORD LC_VD_DIAGCODE;
  LC_TD_FunctionBlock_F_TRIG LC_VD_FTRIGRESETIN;
  LC_TD_FunctionBlock_R_TRIG LC_VD_RTRIGRESETIN;
  LC_TD_FunctionBlock_TON LC_VD_TRAILINGMAXIMUMTIMER;
  LC_TD_FunctionBlock_TON LC_VD_TRAILINGMINIMUMTIMER;
} LCCG_StructAttrib LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON(p) LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON(p,RF) LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_RESETBUTTON(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
