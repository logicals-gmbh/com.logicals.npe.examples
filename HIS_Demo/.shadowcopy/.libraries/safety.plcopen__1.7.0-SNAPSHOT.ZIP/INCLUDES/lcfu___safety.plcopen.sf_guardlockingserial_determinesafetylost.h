#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcdt___safety.plcopen.sf_guardlockingserial_state.h>
#include <lcfu_iec61131__CONVERT.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_WORD LC_VD_SF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST;
} LCCG_StructAttrib LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST(p) \
{ \
  LC_INIT_WORD(&((p)->LC_VD_SF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST)); \
}

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST(LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST* LC_this, LC_TD_DataType_SAFEBOOL LC_VD_S_GUARD, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
