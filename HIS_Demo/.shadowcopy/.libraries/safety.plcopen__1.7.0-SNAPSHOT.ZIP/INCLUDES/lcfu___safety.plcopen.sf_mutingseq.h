#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcdt___safety.plcopen.sf_mutingpar_2sensor_state.h>
#include <lcdt___safety.plcopen.sf_mutingseq_state.h>
#include <lcfu___safety.plcopen.sf_mutingseq_geterrorstate.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__F_TRIG.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__R_TRIG.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ
{
  LC_TD_BOOL LC_VD_ACTIVATE;
  LC_TD_BOOL LC_VD_MUTINGENABLE;
  LC_TD_BOOL LC_VD_MUTINGSWITCH11;
  LC_TD_BOOL LC_VD_MUTINGSWITCH12;
  LC_TD_BOOL LC_VD_MUTINGSWITCH21;
  LC_TD_BOOL LC_VD_MUTINGSWITCH22;
  LC_TD_BOOL LC_VD_RESET;
  LC_TD_TIME LC_VD_MAXMUTINGTIME;
  LC_TD_DataType_SAFEBOOL LC_VD_S_AOPD_IN;
  LC_TD_DataType_SAFEBOOL LC_VD_S_STARTRESET;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_ERROR;
  LC_TD_BOOL LC_VD_READY;
  LC_TD_BOOL LC_VD_RESETREQUEST;
  LC_TD_BOOL LC_VD_SAFETYDEMAND;
  LC_TD_WORD LC_VD_DIAGCODE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_AOPD_OUT;
  LC_TD_DataType_SAFEBOOL LC_VD_S_MUTINGACTIVE;
  LC_TD_FunctionBlock_F_TRIG LC_VD_F_TRIG_S11;
  LC_TD_FunctionBlock_F_TRIG LC_VD_F_TRIG_S12;
  LC_TD_FunctionBlock_F_TRIG LC_VD_F_TRIG_S21;
  LC_TD_FunctionBlock_F_TRIG LC_VD_F_TRIG_S22;
  LC_TD_FunctionBlock_TON LC_VD_MUTINGTIMER;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG_RESET;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG_S11;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG_S12;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG_S21;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG_S22;
} LCCG_StructAttrib LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ(p) LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ(p,RF) LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
