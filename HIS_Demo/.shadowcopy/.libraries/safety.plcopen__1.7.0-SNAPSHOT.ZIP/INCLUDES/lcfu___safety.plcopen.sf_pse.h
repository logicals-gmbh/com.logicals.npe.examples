#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_PSE__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_PSE__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcfu___safety.plcopen.sfb_genericsafetydemand.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_PSE
{
  LC_TD_BOOL LC_VD_ACTIVATE;
  LC_TD_BOOL LC_VD_RESET;
  LC_TD_DataType_SAFEBOOL LC_VD_S_AUTORESET;
  LC_TD_DataType_SAFEBOOL LC_VD_S_PSE_IN;
  LC_TD_DataType_SAFEBOOL LC_VD_S_STARTRESET;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_ERROR;
  LC_TD_BOOL LC_VD_READY;
  LC_TD_BOOL LC_VD_RESETREQUEST;
  LC_TD_BOOL LC_VD_SAFETYDEMAND;
  LC_TD_WORD LC_VD_DIAGCODE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_PSE_OUT;
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESFB_GENERICSAFETYDEMAND LC_VD_GENERICSAFETYDEMAND;
} LCCG_StructAttrib LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_PSE;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_PSE(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_PSE* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_PSE(p) LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_PSE((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_PSE(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_PSE* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_PSE(p,RF) LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_PSE((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_PSE(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_PSE* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
