#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MUTINGPAR_GETERRORSTATE__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MUTINGPAR_GETERRORSTATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_GETERRORSTATE
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_UINT LC_VD_SF_MUTINGPAR_GETERRORSTATE;
} LCCG_StructAttrib LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_GETERRORSTATE;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_GETERRORSTATE(p) \
{ \
  LC_INIT_UINT(&((p)->LC_VD_SF_MUTINGPAR_GETERRORSTATE)); \
}

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGPAR_GETERRORSTATE(LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_GETERRORSTATE* LC_this, LC_TD_BOOL LC_VD_MS_11, LC_TD_BOOL LC_VD_MS_12, LC_TD_BOOL LC_VD_MS_21, LC_TD_BOOL LC_VD_MS_22, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
