#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT__H
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT__H

#include <LC3CGBase.h>
#include <lcdt___safety.plcopen.sf_modeselector_modestate.h>
#include <lcdt___safety.plcopen.sf_modeselector_state.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_UINT LC_VD_SF_MODESELECTOR_GETERROROPENCIRCUIT;
} LCCG_StructAttrib LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT(p) \
{ \
  LC_INIT_UINT(&((p)->LC_VD_SF_MODESELECTOR_GETERROROPENCIRCUIT)); \
}

/*                            Prototype                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT(LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT* LC_this, LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE LC_VD_MODESTATE, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
