#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEII__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEII__C

#include <lcfu___safety.plcopen.sf_twohandcontroltypeii.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>

/*                            FunctionBlocks                   */
void  lcfu___SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEII(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEII* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ACTIVATE));
    if (conditionResult)
    {
      {
        LC_TD_Function_TO_WORD lFunction_TO_WORD;
        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Idle, pEPDB);
        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
      }
    }
    else
    {
      {
        LC_TD_UINT caseSelector;
        {
          LC_TD_Function_TO_UINT lFunction_TO_UINT;
          LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
          lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
          lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
          caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
        }
        if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Idle))
        {
          {
            LC_TD_Function_TO_WORD lFunction_TO_WORD;
            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Init, pEPDB);
            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Init))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_BUTTON1,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Error_B1, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_BUTTON2,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Error_B2, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_BUTTON1,LC_this->LC_VD_S_BUTTON2));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Error_B1_and_B2, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Released, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Error_B1)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Error_B2)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Error_B1_and_B2))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Released, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Released))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_BUTTON1,LC_this->LC_VD_S_BUTTON2));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Actuated, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              if (LC_this->LC_VD_S_BUTTON1)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_1_Actuated, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
              else
              {
                if (LC_this->LC_VD_S_BUTTON2)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_2_Actuated, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_1_Actuated))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Released, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1)),LC_this->LC_VD_S_BUTTON2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Locked_On, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_BUTTON1,LC_this->LC_VD_S_BUTTON2));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Actuated, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Locked_On))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Released, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_2_Actuated))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Released, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_BUTTON1,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Locked_On, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_BUTTON1,LC_this->LC_VD_S_BUTTON2));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Actuated, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Locked_Off))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1)),LC_this->LC_VD_S_BUTTON2));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_1_Released, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_BUTTON1,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_2_Released, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Released, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_1_Released))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_BUTTON1,LC_this->LC_VD_S_BUTTON2));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Locked_Off, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_BUTTON1,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_2_Released, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Released, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_2_Released))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_BUTTON1,LC_this->LC_VD_S_BUTTON2));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Locked_Off, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1)),LC_this->LC_VD_S_BUTTON2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_1_Released, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Released, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Actuated))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_BUTTON1,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_2_Released, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1)),LC_this->LC_VD_S_BUTTON2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_1_Released, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_BUTTON2))));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Released, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else
        {
          ;
        }
      }
    }
  }
  {
    LC_TD_UINT caseSelector;
    {
      LC_TD_Function_TO_UINT lFunction_TO_UINT;
      LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
      lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
      caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
    }
    if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Idle))
    {
      LC_this->LC_VD_READY = LC_EL_false;
      LC_this->LC_VD_S_TWOHANDOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Actuated))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_TWOHANDOUT = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Init))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_TWOHANDOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Buttons_Released)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_1_Actuated)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_2_Actuated)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_2_Released)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Button_1_Released)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Locked_Off)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Locked_On))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_TWOHANDOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_true;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Error_B1)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Error_B2)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeII_State__Error_B1_and_B2))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_TWOHANDOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_ENO = LC_EL_false;
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_TWOHANDOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
  }
}

#endif
