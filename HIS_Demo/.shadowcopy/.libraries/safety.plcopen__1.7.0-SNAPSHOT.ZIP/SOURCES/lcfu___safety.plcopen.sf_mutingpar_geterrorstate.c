#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MUTINGPAR_GETERRORSTATE__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MUTINGPAR_GETERRORSTATE__C

#include <lcfu___safety.plcopen.sf_mutingpar_geterrorstate.h>

/*                            Functions                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGPAR_GETERRORSTATE(LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_GETERRORSTATE* LC_this, LC_TD_BOOL LC_VD_MS_11, LC_TD_BOOL LC_VD_MS_12, LC_TD_BOOL LC_VD_MS_21, LC_TD_BOOL LC_VD_MS_22, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_TD_UINT LC_VD_RESULT;
  LC_INIT_UINT(&(LC_VD_RESULT));
  if (LC_VD_MS_11)
  {
    LC_VD_RESULT = (LC_TD_UINT)(LC_VD_RESULT + (LC_TD_UINT)16);
  }
  if (LC_VD_MS_12)
  {
    LC_VD_RESULT = (LC_TD_UINT)(LC_VD_RESULT + (LC_TD_UINT)32);
  }
  if (LC_VD_MS_21)
  {
    LC_VD_RESULT = (LC_TD_UINT)(LC_VD_RESULT + (LC_TD_UINT)64);
  }
  if (LC_VD_MS_22)
  {
    LC_VD_RESULT = (LC_TD_UINT)(LC_VD_RESULT + (LC_TD_UINT)128);
  }
  LC_this->LC_VD_SF_MUTINGPAR_GETERRORSTATE = LC_VD_RESULT;
}

#endif
