#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_OVERRIDE__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_OVERRIDE__C

#include <lcfu___safety.plcopen.sf_override.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE* p = LC_this; \
  (p)->LC_VD_ACTIVATE = LC_EL_false; \
  (p)->LC_VD_S_AOPD_IN = LC_EL_false; \
  (p)->LC_VD_S_MUTING_AOPD_OUT = LC_EL_false; \
  (p)->LC_VD_MUTINGERROR = LC_EL_false; \
  (p)->LC_VD_MUTINGSWITCH11 = LC_EL_false; \
  (p)->LC_VD_MUTINGSWITCH12 = LC_EL_false; \
  (p)->LC_VD_MUTINGSWITCH21 = LC_EL_false; \
  (p)->LC_VD_MUTINGSWITCH22 = LC_EL_false; \
  (p)->LC_VD_MAXOVERRIDETIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0)); \
  (p)->LC_VD_S_STARTSTOPOVERRIDE = LC_EL_false; \
  (p)->LC_VD_RESET = LC_EL_false; \
  (p)->LC_VD_READY = LC_EL_false; \
  (p)->LC_VD_S_AOPD_OUT = LC_EL_false; \
  (p)->LC_VD_OVERRIDEPOSSIBLE = LC_EL_false; \
  (p)->LC_VD_OVERRIDEACTIVE = LC_EL_false; \
  (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  (p)->LC_VD_ERROR = LC_EL_false; \
  (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_OVERRIDETIMER)); \
  (p)->LC_VD_OVERRIDETIMER.LC_VD_IN = LC_EL_false; \
  LC_INIT_BOOL(&((p)->LC_VD_ANYSWITCHACTIVE)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGSTARTSTOPOVERRIDE)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGRESET)); \
}

void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE* p = LC_this; \
  if (RF==0) (p)->LC_VD_ACTIVATE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_AOPD_IN = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MUTING_AOPD_OUT = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MUTINGERROR = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MUTINGSWITCH11 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MUTINGSWITCH12 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MUTINGSWITCH21 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MUTINGSWITCH22 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MAXOVERRIDETIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0)); \
  if (RF==0) (p)->LC_VD_S_STARTSTOPOVERRIDE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_READY = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_AOPD_OUT = LC_EL_false; \
  if (RF==0) (p)->LC_VD_OVERRIDEPOSSIBLE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_OVERRIDEACTIVE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  if (RF==0) (p)->LC_VD_ERROR = LC_EL_false; \
  if (RF==0) (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  if (RF==0) \
    { \
    LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_OVERRIDETIMER),0); \
    (p)->LC_VD_OVERRIDETIMER.LC_VD_IN = LC_EL_false; \
    } \
  LC_WINIT_BOOL(&((p)->LC_VD_ANYSWITCHACTIVE),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGSTARTSTOPOVERRIDE),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGRESET),0); \
}

void  lcfu___SAFETYx2EPLCOPENx2ESF_OVERRIDE(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OVERRIDE* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_OVERRIDETIMER.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_OVERRIDETIMER.LC_VD_PT = LC_this->LC_VD_MAXOVERRIDETIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_OVERRIDETIMER), pEPDB);
  }
  LC_this->LC_VD_ANYSWITCHACTIVE = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_MUTINGSWITCH11,LC_this->LC_VD_MUTINGSWITCH12)),LC_this->LC_VD_MUTINGSWITCH21)),LC_this->LC_VD_MUTINGSWITCH22));
  {
    LC_this->LC_VD_RTRIGSTARTSTOPOVERRIDE.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGSTARTSTOPOVERRIDE.LC_VD_CLK = LC_this->LC_VD_S_STARTSTOPOVERRIDE;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGSTARTSTOPOVERRIDE), pEPDB);
  }
  {
    LC_this->LC_VD_RTRIGRESET.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGRESET.LC_VD_CLK = LC_this->LC_VD_RESET;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGRESET), pEPDB);
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ACTIVATE));
    if (conditionResult)
    {
      {
        LC_TD_Function_TO_WORD lFunction_TO_WORD;
        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Idle, pEPDB);
        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
      }
    }
    else
    {
      {
        LC_TD_UINT caseSelector;
        {
          LC_TD_Function_TO_UINT lFunction_TO_UINT;
          LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
          lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
          lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
          caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
        }
        if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Idle))
        {
          {
            LC_TD_Function_TO_WORD lFunction_TO_WORD;
            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Safety_Demand_AOPD, pEPDB);
            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Safety_Demand_AOPD))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGERROR,LC_this->LC_VD_S_AOPD_IN)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ANYSWITCHACTIVE))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Muting_Error_but_Override_not_possible, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGERROR,(lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_AOPD_IN)),LC_this->LC_VD_ANYSWITCHACTIVE))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Possible, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  if (LC_this->LC_VD_S_MUTING_AOPD_OUT)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__AOPD_Free, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Possible))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            {
              LC_TD_Function_NOT__BOOL lFunction_NOT;
              LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
              lFunction_NOT.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__NOT__BOOL(&lFunction_NOT, (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGERROR,(lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_AOPD_IN)),LC_this->LC_VD_ANYSWITCHACTIVE)))), pEPDB);
              conditionResult = lFunction_NOT.LC_VD_NOT;
            }
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Safety_Demand_AOPD, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              if (LC_this->LC_VD_RTRIGSTARTSTOPOVERRIDE.LC_VD_Q)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Active, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Active))
        {
          if (LC_this->LC_VD_OVERRIDETIMER.LC_VD_Q)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Error, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
          else
          {
            {
              LC_TD_BOOL conditionResult = LC_EL_false;
              conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_STARTSTOPOVERRIDE));
              if (conditionResult)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Interrupt, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
              else
              {
                {
                  LC_TD_BOOL conditionResult = LC_EL_false;
                  {
                    LC_TD_Function_NOT__BOOL lFunction_NOT;
                    LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
                    lFunction_NOT.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__NOT__BOOL(&lFunction_NOT, (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGERROR,(lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_AOPD_IN)),LC_this->LC_VD_ANYSWITCHACTIVE)))), pEPDB);
                    conditionResult = lFunction_NOT.LC_VD_NOT;
                  }
                  if (conditionResult)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Safety_Demand_AOPD, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Interrupt))
        {
          if (LC_this->LC_VD_OVERRIDETIMER.LC_VD_Q)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Error, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
          else
          {
            {
              LC_TD_BOOL conditionResult = LC_EL_false;
              {
                LC_TD_Function_NOT__BOOL lFunction_NOT;
                LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
                lFunction_NOT.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__NOT__BOOL(&lFunction_NOT, (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGERROR,(lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_AOPD_IN)),LC_this->LC_VD_ANYSWITCHACTIVE)))), pEPDB);
                conditionResult = lFunction_NOT.LC_VD_NOT;
              }
              if (conditionResult)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Safety_Demand_AOPD, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
              else
              {
                if (LC_this->LC_VD_S_STARTSTOPOVERRIDE)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Active, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Error))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Reset_Error, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              if (LC_this->LC_VD_RTRIGRESET.LC_VD_Q)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Safety_Demand_AOPD, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Reset_Error))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Error, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__AOPD_Free))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_MUTING_AOPD_OUT));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Safety_Demand_AOPD, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Muting_Error_but_Override_not_possible))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGERROR));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Override_State__Safety_Demand_AOPD, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else
        {
          ;
        }
      }
    }
  }
  {
    LC_TD_UINT caseSelector;
    {
      LC_TD_Function_TO_UINT lFunction_TO_UINT;
      LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
      lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
      caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
    }
    if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Idle))
    {
      {
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_OVERRIDETIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_false;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_OVERRIDEPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_OVERRIDEACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Reset_Error))
    {
      {
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_OVERRIDETIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_OVERRIDEPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_OVERRIDEACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Error))
    {
      {
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_OVERRIDETIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_OVERRIDEPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_OVERRIDEACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Safety_Demand_AOPD))
    {
      {
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_OVERRIDETIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_OVERRIDEPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_OVERRIDEACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Muting_Error_but_Override_not_possible))
    {
      {
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_OVERRIDETIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_OVERRIDEPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_OVERRIDEACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Possible))
    {
      {
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_OVERRIDETIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_OVERRIDEPOSSIBLE = LC_EL_true;
      LC_this->LC_VD_OVERRIDEACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Interrupt))
    {
      {
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_IN = LC_EL_true;
        lcfu_iec61131__TON(&(LC_this->LC_VD_OVERRIDETIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_OVERRIDEPOSSIBLE = LC_EL_true;
      LC_this->LC_VD_OVERRIDEACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_true;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Active))
    {
      {
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_IN = LC_EL_true;
        lcfu_iec61131__TON(&(LC_this->LC_VD_OVERRIDETIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_true;
      LC_this->LC_VD_OVERRIDEPOSSIBLE = LC_EL_true;
      LC_this->LC_VD_OVERRIDEACTIVE = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Override_State__AOPD_Free))
    {
      {
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_OVERRIDETIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_OVERRIDETIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_true;
      LC_this->LC_VD_OVERRIDEPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_OVERRIDEACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else
    {
      LC_this->LC_VD_ENO = LC_EL_false;
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_OVERRIDEPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_OVERRIDEACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
  }
}

#endif
