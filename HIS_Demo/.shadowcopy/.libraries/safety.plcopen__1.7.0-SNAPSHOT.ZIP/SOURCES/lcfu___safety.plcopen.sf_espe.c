#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_ESPE__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_ESPE__C

#include <lcfu___safety.plcopen.sf_espe.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ESPE(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ESPE* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ESPE* p = LC_this; \
  (p)->LC_VD_ACTIVATE = LC_EL_false; \
  (p)->LC_VD_S_ESPE_IN = LC_EL_false; \
  (p)->LC_VD_S_STARTRESET = LC_EL_false; \
  (p)->LC_VD_S_AUTORESET = LC_EL_false; \
  (p)->LC_VD_RESET = LC_EL_false; \
  (p)->LC_VD_READY = LC_EL_false; \
  (p)->LC_VD_S_ESPE_OUT = LC_EL_false; \
  (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  (p)->LC_VD_ERROR = LC_EL_false; \
  (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESFB_GENERICSAFETYDEMAND(&((p)->LC_VD_GENERICSAFETYDEMAND)); \
}

void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ESPE(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ESPE* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ESPE* p = LC_this; \
  if (RF==0) (p)->LC_VD_ACTIVATE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_ESPE_IN = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_STARTRESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_AUTORESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_READY = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_ESPE_OUT = LC_EL_false; \
  if (RF==0) (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  if (RF==0) (p)->LC_VD_ERROR = LC_EL_false; \
  if (RF==0) (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESFB_GENERICSAFETYDEMAND(&((p)->LC_VD_GENERICSAFETYDEMAND),0); \
}

void  lcfu___SAFETYx2EPLCOPENx2ESF_ESPE(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ESPE* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_ACTIVATE = LC_this->LC_VD_ACTIVATE;
    LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_S_SAFETYDEMANDIN = LC_this->LC_VD_S_ESPE_IN;
    LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_S_STARTRESET = LC_this->LC_VD_S_STARTRESET;
    LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_S_AUTORESET = LC_this->LC_VD_S_AUTORESET;
    LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_RESET = LC_this->LC_VD_RESET;
    lcfu___SAFETYx2EPLCOPENx2ESFB_GENERICSAFETYDEMAND(&(LC_this->LC_VD_GENERICSAFETYDEMAND), pEPDB);
    LC_this->LC_VD_ENO = LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_ENO;
    LC_this->LC_VD_READY = LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_READY;
    LC_this->LC_VD_S_ESPE_OUT = LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_S_SAFETYDEMANDOUT;
    LC_this->LC_VD_SAFETYDEMAND = LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_SAFETYDEMAND;
    LC_this->LC_VD_RESETREQUEST = LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_RESETREQUEST;
    LC_this->LC_VD_ERROR = LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_ERROR;
    LC_this->LC_VD_DIAGCODE = LC_this->LC_VD_GENERICSAFETYDEMAND.LC_VD_DIAGCODE;
  }
}

#endif
