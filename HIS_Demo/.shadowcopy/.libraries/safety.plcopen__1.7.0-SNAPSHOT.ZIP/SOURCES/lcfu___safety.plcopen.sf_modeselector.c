#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MODESELECTOR__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MODESELECTOR__C

#include <lcfu___safety.plcopen.sf_modeselector.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR* p = LC_this; \
  (p)->LC_VD_ACTIVATE = LC_EL_false; \
  (p)->LC_VD_S_MODE0 = LC_EL_false; \
  (p)->LC_VD_S_MODE1 = LC_EL_false; \
  (p)->LC_VD_S_MODE2 = LC_EL_false; \
  (p)->LC_VD_S_MODE3 = LC_EL_false; \
  (p)->LC_VD_S_MODE4 = LC_EL_false; \
  (p)->LC_VD_S_MODE5 = LC_EL_false; \
  (p)->LC_VD_S_MODE6 = LC_EL_false; \
  (p)->LC_VD_S_MODE7 = LC_EL_false; \
  (p)->LC_VD_S_UNLOCK = LC_EL_false; \
  (p)->LC_VD_S_SETMODE = LC_EL_false; \
  (p)->LC_VD_AUTOSETMODE = LC_EL_false; \
  (p)->LC_VD_MODEMONITORTIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0)); \
  (p)->LC_VD_RESET = LC_EL_false; \
  (p)->LC_VD_READY = LC_EL_false; \
  (p)->LC_VD_S_MODE0SEL = LC_EL_false; \
  (p)->LC_VD_S_MODE1SEL = LC_EL_false; \
  (p)->LC_VD_S_MODE2SEL = LC_EL_false; \
  (p)->LC_VD_S_MODE3SEL = LC_EL_false; \
  (p)->LC_VD_S_MODE4SEL = LC_EL_false; \
  (p)->LC_VD_S_MODE5SEL = LC_EL_false; \
  (p)->LC_VD_S_MODE6SEL = LC_EL_false; \
  (p)->LC_VD_S_MODE7SEL = LC_EL_false; \
  (p)->LC_VD_S_ANYMODESEL = LC_EL_false; \
  (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  (p)->LC_VD_ERROR = LC_EL_false; \
  (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_RESET)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_S_SETMODE)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_MODEMONITORTIMER)); \
}

void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR* p = LC_this; \
  if (RF==0) (p)->LC_VD_ACTIVATE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE0 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE1 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE2 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE3 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE4 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE5 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE6 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE7 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_UNLOCK = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_SETMODE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_AUTOSETMODE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MODEMONITORTIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0)); \
  if (RF==0) (p)->LC_VD_RESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_READY = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE0SEL = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE1SEL = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE2SEL = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE3SEL = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE4SEL = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE5SEL = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE6SEL = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MODE7SEL = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_ANYMODESEL = LC_EL_false; \
  if (RF==0) (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  if (RF==0) (p)->LC_VD_ERROR = LC_EL_false; \
  if (RF==0) (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_RESET),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_S_SETMODE),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_MODEMONITORTIMER),0); \
}

void  lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MODESELECTOR* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_TD_BOOL LC_VD_ONES_MODECHANGED;
  LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE LC_VD_MODESTATE;
  LC_INIT_BOOL(&(LC_VD_ONES_MODECHANGED));
  LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE(&(LC_VD_MODESTATE));
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ACTIVATE));
    if (conditionResult)
    {
      {
        LC_TD_Function_TO_WORD lFunction_TO_WORD;
        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Idle, pEPDB);
        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
      }
      {
        LC_this->LC_VD_MODEMONITORTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MODEMONITORTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MODEMONITORTIMER), pEPDB);
      }
    }
    else
    {
      {
        LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE lFunction_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE;
        LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE);
        lFunction_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE.LC_VD_ENO = LC_EL_true;
        lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE, LC_this->LC_VD_S_MODE0, LC_this->LC_VD_S_MODE1, LC_this->LC_VD_S_MODE2, LC_this->LC_VD_S_MODE3, LC_this->LC_VD_S_MODE4, LC_this->LC_VD_S_MODE5, LC_this->LC_VD_S_MODE6, LC_this->LC_VD_S_MODE7, pEPDB);
        LC_VD_MODESTATE = lFunction_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE.LC_VD_SF_MODESELECTOR_GETMODESTATE;
      }
      {
        LC_this->LC_VD_MODEMONITORTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MODEMONITORTIMER.LC_VD_IN = (LC_TD_BOOL)(LC_VD_MODESTATE == LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__No_S_ModeX);
        LC_this->LC_VD_MODEMONITORTIMER.LC_VD_PT = LC_this->LC_VD_MODEMONITORTIME;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MODEMONITORTIMER), pEPDB);
      }
      LC_VD_ONES_MODECHANGED = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_S_MODE0 != LC_this->LC_VD_S_MODE0SEL),(LC_TD_BOOL)(LC_this->LC_VD_S_MODE1 != LC_this->LC_VD_S_MODE1SEL))),(LC_TD_BOOL)(LC_this->LC_VD_S_MODE2 != LC_this->LC_VD_S_MODE2SEL))),(LC_TD_BOOL)(LC_this->LC_VD_S_MODE3 != LC_this->LC_VD_S_MODE3SEL))),(LC_TD_BOOL)(LC_this->LC_VD_S_MODE4 != LC_this->LC_VD_S_MODE4SEL))),(LC_TD_BOOL)(LC_this->LC_VD_S_MODE5 != LC_this->LC_VD_S_MODE5SEL))),(LC_TD_BOOL)(LC_this->LC_VD_S_MODE6 != LC_this->LC_VD_S_MODE6SEL))),(LC_TD_BOOL)(LC_this->LC_VD_S_MODE7 != LC_this->LC_VD_S_MODE7SEL)));
      {
        LC_this->LC_VD_R_TRIG_RESET.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_R_TRIG_RESET.LC_VD_CLK = LC_this->LC_VD_RESET;
        lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG_RESET), pEPDB);
      }
      {
        LC_this->LC_VD_R_TRIG_S_SETMODE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_R_TRIG_S_SETMODE.LC_VD_CLK = LC_this->LC_VD_S_SETMODE;
        lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG_S_SETMODE), pEPDB);
      }
      {
        LC_TD_UINT caseSelector;
        {
          LC_TD_Function_TO_UINT lFunction_TO_UINT;
          LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
          lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
          lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
          caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
        }
        if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Idle))
        {
          {
            LC_TD_Function_TO_WORD lFunction_TO_WORD;
            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Changed, pEPDB);
            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Changed))
        {
          if ((LC_TD_BOOL)(LC_VD_MODESTATE == LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__More_Than_One_S_ModeX))
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Short_Circuit, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
          else
          {
            if (LC_this->LC_VD_MODEMONITORTIMER.LC_VD_Q)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Open_Circuit, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_AUTOSETMODE,LC_this->LC_VD_R_TRIG_S_SETMODE.LC_VD_Q)),LC_this->LC_VD_S_UNLOCK)),(LC_TD_BOOL)(LC_VD_MODESTATE == LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__Only_One_S_ModeX)));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Selected, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Short_Circuit)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Short_Circuit_Fixed))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_R_TRIG_RESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Reset_Error_1, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((LC_TD_BOOL)(LC_VD_MODESTATE == LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__Only_One_S_ModeX),(LC_TD_BOOL)(LC_VD_MODESTATE == LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__No_S_ModeX))),LC_this->LC_VD_R_TRIG_RESET.LC_VD_Q));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Changed, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT;
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT(&lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT);
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT.LC_VD_ENO = LC_EL_true;
                    lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT(&lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT, LC_VD_MODESTATE, pEPDB);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT.LC_VD_SF_MODESELECTOR_GETERRORSHORTCIRCUIT, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Open_Circuit)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Open_Circuit_Fixed))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_R_TRIG_RESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Reset_Error_2, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_VD_MODESTATE == LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__Only_One_S_ModeX),LC_this->LC_VD_R_TRIG_RESET.LC_VD_Q));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Changed, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT;
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT(&lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT);
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT.LC_VD_ENO = LC_EL_true;
                    lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT(&lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT, LC_VD_MODESTATE, pEPDB);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT.LC_VD_SF_MODESELECTOR_GETERROROPENCIRCUIT, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Reset_Error_1))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT;
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT(&lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT);
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT(&lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT, LC_VD_MODESTATE, pEPDB);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT.LC_VD_SF_MODESELECTOR_GETERRORSHORTCIRCUIT, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Reset_Error_2))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT;
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT(&lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT);
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT(&lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT, LC_VD_MODESTATE, pEPDB);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT.LC_VD_SF_MODESELECTOR_GETERROROPENCIRCUIT, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Selected))
        {
          if ((LC_TD_BOOL)(LC_VD_MODESTATE == LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__More_Than_One_S_ModeX))
          {
            {
              LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT;
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT(&lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT);
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT.LC_VD_ENO = LC_EL_true;
              lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT(&lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT, LC_VD_MODESTATE, pEPDB);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT.LC_VD_SF_MODESELECTOR_GETERRORSHORTCIRCUIT, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
          else
          {
            if (LC_VD_ONES_MODECHANGED)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Changed, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_UNLOCK));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Locked, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Locked))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_VD_MODESTATE == LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__More_Than_One_S_ModeX),LC_this->LC_VD_S_UNLOCK));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT;
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT(&lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT);
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT(&lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT, LC_VD_MODESTATE, pEPDB);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, lFunction_TO_WORD__IN_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERRORSHORTCIRCUIT.LC_VD_SF_MODESELECTOR_GETERRORSHORTCIRCUIT, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_VD_ONES_MODECHANGED,LC_this->LC_VD_S_UNLOCK));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Changed, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  if (LC_this->LC_VD_S_UNLOCK)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Selected, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else
        {
          ;
        }
      }
    }
  }
  {
    LC_TD_UINT caseSelector;
    {
      LC_TD_Function_TO_UINT lFunction_TO_UINT;
      LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
      lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
      caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
    }
    if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Short_Circuit_Fixed)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Open_Circuit_Fixed))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_true;
      LC_this->LC_VD_S_ANYMODESEL = LC_EL_false;
      LC_this->LC_VD_S_MODE0SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE1SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE2SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE3SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE4SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE5SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE6SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE7SEL = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Short_Circuit)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Open_Circuit)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Reset_Error_1)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Reset_Error_2))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
      LC_this->LC_VD_S_ANYMODESEL = LC_EL_false;
      LC_this->LC_VD_S_MODE0SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE1SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE2SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE3SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE4SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE5SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE6SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE7SEL = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Idle))
    {
      LC_this->LC_VD_READY = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
      LC_this->LC_VD_S_ANYMODESEL = LC_EL_false;
      LC_this->LC_VD_S_MODE0SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE1SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE2SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE3SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE4SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE5SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE6SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE7SEL = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Changed))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_true;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
      LC_this->LC_VD_S_ANYMODESEL = LC_EL_false;
      LC_this->LC_VD_S_MODE0SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE1SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE2SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE3SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE4SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE5SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE6SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE7SEL = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Selected))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
      LC_this->LC_VD_S_ANYMODESEL = LC_EL_true;
      LC_this->LC_VD_S_MODE0SEL = LC_this->LC_VD_S_MODE0;
      LC_this->LC_VD_S_MODE1SEL = LC_this->LC_VD_S_MODE1;
      LC_this->LC_VD_S_MODE2SEL = LC_this->LC_VD_S_MODE2;
      LC_this->LC_VD_S_MODE3SEL = LC_this->LC_VD_S_MODE3;
      LC_this->LC_VD_S_MODE4SEL = LC_this->LC_VD_S_MODE4;
      LC_this->LC_VD_S_MODE5SEL = LC_this->LC_VD_S_MODE5;
      LC_this->LC_VD_S_MODE6SEL = LC_this->LC_VD_S_MODE6;
      LC_this->LC_VD_S_MODE7SEL = LC_this->LC_VD_S_MODE7;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Locked))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
      LC_this->LC_VD_S_ANYMODESEL = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_ENO = LC_EL_false;
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
      LC_this->LC_VD_S_ANYMODESEL = LC_EL_false;
      LC_this->LC_VD_S_MODE0SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE1SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE2SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE3SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE4SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE5SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE6SEL = LC_EL_false;
      LC_this->LC_VD_S_MODE7SEL = LC_EL_false;
    }
  }
}

#endif
