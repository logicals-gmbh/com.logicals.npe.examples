#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR__C

#include <lcfu___safety.plcopen.sf_testablesafetysensor.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR* p = LC_this; \
  (p)->LC_VD_ACTIVATE = LC_EL_false; \
  (p)->LC_VD_S_OSSD_IN = LC_EL_false; \
  (p)->LC_VD_STARTTEST = LC_EL_false; \
  (p)->LC_VD_TESTTIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(10000000)); \
  (p)->LC_VD_NOEXTERNALTEST = LC_EL_false; \
  (p)->LC_VD_S_STARTRESET = LC_EL_false; \
  (p)->LC_VD_S_AUTORESET = LC_EL_false; \
  (p)->LC_VD_RESET = LC_EL_false; \
  (p)->LC_VD_READY = LC_EL_false; \
  (p)->LC_VD_S_OSSD_OUT = LC_EL_false; \
  (p)->LC_VD_S_TESTOUT = LC_EL_true; \
  (p)->LC_VD_TESTPOSSIBLE = LC_EL_false; \
  (p)->LC_VD_TESTEXECUTED = LC_EL_false; \
  (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  (p)->LC_VD_ERROR = LC_EL_false; \
  (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGRESET)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGSOSSDIN)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGSTARTTEST)); \
  LC_INIT_FunctionBlock_F_TRIG(&((p)->LC_VD_FTRIGSOSSDIN)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TIMER1)); \
  (p)->LC_VD_TIMER1.LC_VD_IN = LC_EL_false; \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TIMER2)); \
  (p)->LC_VD_TIMER2.LC_VD_IN = LC_EL_false; \
}

void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR* p = LC_this; \
  if (RF==0) (p)->LC_VD_ACTIVATE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_OSSD_IN = LC_EL_false; \
  if (RF==0) (p)->LC_VD_STARTTEST = LC_EL_false; \
  if (RF==0) (p)->LC_VD_TESTTIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(10000000)); \
  if (RF==0) (p)->LC_VD_NOEXTERNALTEST = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_STARTRESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_AUTORESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_READY = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_OSSD_OUT = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_TESTOUT = LC_EL_true; \
  if (RF==0) (p)->LC_VD_TESTPOSSIBLE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_TESTEXECUTED = LC_EL_false; \
  if (RF==0) (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  if (RF==0) (p)->LC_VD_ERROR = LC_EL_false; \
  if (RF==0) (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGRESET),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGSOSSDIN),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGSTARTTEST),0); \
  LC_WINIT_FunctionBlock_F_TRIG(&((p)->LC_VD_FTRIGSOSSDIN),0); \
  if (RF==0) \
    { \
    LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TIMER1),0); \
    (p)->LC_VD_TIMER1.LC_VD_IN = LC_EL_false; \
    } \
  if (RF==0) \
    { \
    LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TIMER2),0); \
    (p)->LC_VD_TIMER2.LC_VD_IN = LC_EL_false; \
    } \
}

void  lcfu___SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_RTRIGRESET.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGRESET.LC_VD_CLK = LC_this->LC_VD_RESET;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGRESET), pEPDB);
  }
  {
    LC_this->LC_VD_RTRIGSOSSDIN.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGSOSSDIN.LC_VD_CLK = LC_this->LC_VD_S_OSSD_IN;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGSOSSDIN), pEPDB);
  }
  {
    LC_this->LC_VD_RTRIGSTARTTEST.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGSTARTTEST.LC_VD_CLK = LC_this->LC_VD_STARTTEST;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGSTARTTEST), pEPDB);
  }
  {
    LC_this->LC_VD_FTRIGSOSSDIN.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FTRIGSOSSDIN.LC_VD_CLK = LC_this->LC_VD_S_OSSD_IN;
    lcfu_iec61131__F_TRIG(&(LC_this->LC_VD_FTRIGSOSSDIN), pEPDB);
  }
  {
    LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TIMER1.LC_VD_PT = LC_this->LC_VD_TESTTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
  }
  {
    LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TIMER2.LC_VD_PT = LC_this->LC_VD_TESTTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ACTIVATE));
    if (conditionResult)
    {
      {
        LC_TD_Function_TO_WORD lFunction_TO_WORD;
        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Idle, pEPDB);
        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
      }
    }
    else
    {
      #if 0 /* Properties: */
      * COV_UT := defensive programming
      #endif  /* Properties: */

      {
        LC_TD_UINT caseSelector;
        {
          LC_TD_Function_TO_UINT lFunction_TO_UINT;
          LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
          lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
          lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
          caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
        }
        if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Idle))
        {
          {
            LC_TD_Function_TO_WORD lFunction_TO_WORD;
            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Init, pEPDB);
            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Init))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_TESTTIME > LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(150000000))),(LC_TD_BOOL)(LC_this->LC_VD_TESTTIME < LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0)))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Parameter_Error, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_1, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_OSSD_IN));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_1, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      {
                        LC_TD_BOOL conditionResult = LC_EL_false;
                        conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_OSSD_IN,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGSOSSDIN.LC_VD_Q)))),(lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_S_STARTRESET))));
                        if (conditionResult)
                        {
                          {
                            LC_TD_Function_TO_WORD lFunction_TO_WORD;
                            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_No_Test, pEPDB);
                            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Parameter_Error))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_5, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,(LC_TD_BOOL)(LC_this->LC_VD_TESTTIME <= LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(150000000)))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Init, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_5))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Parameter_Error, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_1))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Init, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_1))
        {
          if (LC_this->LC_VD_S_OSSD_IN)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Wait_for_Reset_1, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__End_External_Test))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_4, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_OSSD_IN))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_1, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_S_OSSD_IN)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGSOSSDIN.LC_VD_Q))));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_No_Test, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_4))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__End_External_Test, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_External_Test))
        {
          if (LC_this->LC_VD_S_OSSD_IN)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__End_External_Test, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__External_Function_Test))
        {
          if (LC_this->LC_VD_FTRIGSOSSDIN.LC_VD_Q)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_External_Test, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Request))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_TIMER1.LC_VD_Q,LC_this->LC_VD_S_OSSD_IN)),LC_this->LC_VD_NOEXTERNALTEST));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_1, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              if (LC_this->LC_VD_TIMER1.LC_VD_Q)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_2, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
              else
              {
                {
                  LC_TD_BOOL conditionResult = LC_EL_false;
                  conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_OSSD_IN));
                  if (conditionResult)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Active, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Active))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_TIMER2.LC_VD_Q,LC_this->LC_VD_S_OSSD_IN)),LC_this->LC_VD_NOEXTERNALTEST));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_1, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              if (LC_this->LC_VD_TIMER2.LC_VD_Q)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_2, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
              else
              {
                if (LC_this->LC_VD_S_OSSD_IN)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_Test_ok, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_1))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_3, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_NOEXTERNALTEST))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__External_Function_Test, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_OSSD_IN,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGSOSSDIN.LC_VD_Q)))),LC_this->LC_VD_RTRIGRESET.LC_VD_Q)),LC_this->LC_VD_NOEXTERNALTEST));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_No_Test, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      {
                        LC_TD_BOOL conditionResult = LC_EL_false;
                        {
                          LC_TD_Function_NOT__BOOL lFunction_NOT;
                          LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
                          lFunction_NOT.LC_VD_ENO = LC_EL_true;
                          lcfu_iec61131__NOT__BOOL(&lFunction_NOT, (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_OSSD_IN,LC_this->LC_VD_NOEXTERNALTEST)), pEPDB);
                          conditionResult = lFunction_NOT.LC_VD_NOT;
                        }
                        if (conditionResult)
                        {
                          {
                            LC_TD_Function_TO_WORD lFunction_TO_WORD;
                            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_2, pEPDB);
                            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_2))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_3, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_NOEXTERNALTEST))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__External_Function_Test, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_OSSD_IN,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGSOSSDIN.LC_VD_Q)))),LC_this->LC_VD_RTRIGRESET.LC_VD_Q)),LC_this->LC_VD_NOEXTERNALTEST));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_No_Test, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      {
                        LC_TD_BOOL conditionResult = LC_EL_false;
                        conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_OSSD_IN,LC_this->LC_VD_NOEXTERNALTEST));
                        if (conditionResult)
                        {
                          {
                            LC_TD_Function_TO_WORD lFunction_TO_WORD;
                            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_1, pEPDB);
                            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_3))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET)),LC_this->LC_VD_S_OSSD_IN)),LC_this->LC_VD_NOEXTERNALTEST));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_1, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_2, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Wait_for_Reset_1))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_2, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_OSSD_IN));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_1, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_OSSD_IN,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGSOSSDIN.LC_VD_Q)))),(lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_S_AUTORESET))));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_No_Test, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_2))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Wait_for_Reset_1, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_No_Test))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_OSSD_IN));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_1, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              if (LC_this->LC_VD_RTRIGSTARTTEST.LC_VD_Q)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Request, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_Test_ok))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_OSSD_IN));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_2, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              if (LC_this->LC_VD_RTRIGSTARTTEST.LC_VD_Q)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Request, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Wait_for_Reset_2))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_6, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_OSSD_IN));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_2, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_OSSD_IN,(lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_S_AUTORESET))));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_Test_ok, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_6))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Wait_for_Reset_2, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_2))
        {
          if (LC_this->LC_VD_S_OSSD_IN)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Wait_for_Reset_2, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
        }
        else
        {
          ;
        }
      }
    }
  }
  {
    LC_TD_UINT caseSelector;
    {
      LC_TD_Function_TO_UINT lFunction_TO_UINT;
      LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
      lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
      caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
    }
    if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Idle))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_false;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_false;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Init)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Wait_for_Reset_1)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__End_External_Test))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_false;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_1)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_External_Test))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_false;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_true;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_2))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_false;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_true;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__External_Function_Test))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_false;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_No_Test))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_true;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_true;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Wait_for_Reset_2))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_false;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Request))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_true;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_true;
      LC_this->LC_VD_S_TESTOUT = LC_EL_false;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Active))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_true;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_true;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_Test_ok))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_true;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_true;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Parameter_Error)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_1)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_2)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_3)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_4)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_5))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_false;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_6))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_false;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_1))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_false;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_2))
    {
      {
        LC_this->LC_VD_TIMER1.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER1.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER1), pEPDB);
      }
      {
        LC_this->LC_VD_TIMER2.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TIMER2.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TIMER2), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_false;
      LC_this->LC_VD_S_TESTOUT = LC_EL_true;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_ENO = LC_EL_false;
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_OSSD_OUT = LC_EL_false;
      LC_this->LC_VD_S_TESTOUT = LC_EL_false;
      LC_this->LC_VD_TESTPOSSIBLE = LC_EL_false;
      LC_this->LC_VD_TESTEXECUTED = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
  }
}

#endif
