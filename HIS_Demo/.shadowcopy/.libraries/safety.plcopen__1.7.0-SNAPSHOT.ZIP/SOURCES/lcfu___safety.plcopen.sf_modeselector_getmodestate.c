#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE__C

#include <lcfu___safety.plcopen.sf_modeselector_getmodestate.h>

/*                            Functions                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE(LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETMODESTATE* LC_this, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE0, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE1, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE2, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE3, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE4, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE5, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE6, LC_TD_DataType_SAFEBOOL LC_VD_S_MODE7, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_TD_INT LC_VD_COUNT;
  LC_VD_COUNT = (LC_TD_INT)0;
  if (LC_VD_S_MODE0)
  {
    LC_VD_COUNT = (LC_TD_INT)(LC_VD_COUNT + (LC_TD_INT)1);
  }
  if (LC_VD_S_MODE1)
  {
    LC_VD_COUNT = (LC_TD_INT)(LC_VD_COUNT + (LC_TD_INT)1);
  }
  if (LC_VD_S_MODE2)
  {
    LC_VD_COUNT = (LC_TD_INT)(LC_VD_COUNT + (LC_TD_INT)1);
  }
  if (LC_VD_S_MODE3)
  {
    LC_VD_COUNT = (LC_TD_INT)(LC_VD_COUNT + (LC_TD_INT)1);
  }
  if (LC_VD_S_MODE4)
  {
    LC_VD_COUNT = (LC_TD_INT)(LC_VD_COUNT + (LC_TD_INT)1);
  }
  if (LC_VD_S_MODE5)
  {
    LC_VD_COUNT = (LC_TD_INT)(LC_VD_COUNT + (LC_TD_INT)1);
  }
  if (LC_VD_S_MODE6)
  {
    LC_VD_COUNT = (LC_TD_INT)(LC_VD_COUNT + (LC_TD_INT)1);
  }
  if (LC_VD_S_MODE7)
  {
    LC_VD_COUNT = (LC_TD_INT)(LC_VD_COUNT + (LC_TD_INT)1);
  }
  if ((LC_TD_BOOL)(LC_VD_COUNT > (LC_TD_INT)1))
  {
    LC_this->LC_VD_SF_MODESELECTOR_GETMODESTATE = LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__More_Than_One_S_ModeX;
  }
  else
  {
    if ((LC_TD_BOOL)(LC_VD_COUNT == (LC_TD_INT)1))
    {
      LC_this->LC_VD_SF_MODESELECTOR_GETMODESTATE = LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__Only_One_S_ModeX;
    }
    else
    {
      LC_this->LC_VD_SF_MODESELECTOR_GETMODESTATE = LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__No_S_ModeX;
    }
  }
}

#endif
