#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_GUARD__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_GUARD__C

#include <lcfu___safety.plcopen.sf_guard.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARD(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARD* p = LC_this; \
  (p)->LC_VD_ACTIVATE = LC_EL_false; \
  (p)->LC_VD_S_GUARDSWITCH1 = LC_EL_false; \
  (p)->LC_VD_S_GUARDSWITCH2 = LC_EL_false; \
  (p)->LC_VD_DISCREPANCYTIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0)); \
  (p)->LC_VD_S_STARTRESET = LC_EL_false; \
  (p)->LC_VD_S_AUTORESET = LC_EL_false; \
  (p)->LC_VD_RESET = LC_EL_false; \
  (p)->LC_VD_READY = LC_EL_false; \
  (p)->LC_VD_S_GUARDOUT = LC_EL_false; \
  (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  (p)->LC_VD_ERROR = LC_EL_false; \
  (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_DISCREPANCYTIMER)); \
  (p)->LC_VD_DISCREPANCYTIMER.LC_VD_IN = LC_EL_false; \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGRESET)); \
}

void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARD(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARD* p = LC_this; \
  if (RF==0) (p)->LC_VD_ACTIVATE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_GUARDSWITCH1 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_GUARDSWITCH2 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_DISCREPANCYTIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0)); \
  if (RF==0) (p)->LC_VD_S_STARTRESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_AUTORESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_READY = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_GUARDOUT = LC_EL_false; \
  if (RF==0) (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  if (RF==0) (p)->LC_VD_ERROR = LC_EL_false; \
  if (RF==0) (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  if (RF==0) \
    { \
    LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_DISCREPANCYTIMER),0); \
    (p)->LC_VD_DISCREPANCYTIMER.LC_VD_IN = LC_EL_false; \
    } \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGRESET),0); \
}

void  lcfu___SAFETYx2EPLCOPENx2ESF_GUARD(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_PT = LC_this->LC_VD_DISCREPANCYTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_DISCREPANCYTIMER), pEPDB);
  }
  {
    LC_this->LC_VD_RTRIGRESET.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGRESET.LC_VD_CLK = LC_this->LC_VD_RESET;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGRESET), pEPDB);
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ACTIVATE));
    if (conditionResult)
    {
      {
        LC_TD_Function_TO_WORD lFunction_TO_WORD;
        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Equivalent_State__Idle, pEPDB);
        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
      }
    }
    else
    {
      {
        LC_TD_UINT caseSelector;
        {
          LC_TD_Function_TO_UINT lFunction_TO_UINT;
          LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
          lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
          lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
          caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
        }
        if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Idle))
        {
          {
            LC_TD_Function_TO_WORD lFunction_TO_WORD;
            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Init, pEPDB);
            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Init))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Open_Guard_Request, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_STARTRESET));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_Reset, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Normal, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Open_Guard_Request))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Guard_Opened, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Guard_Opened))
        {
          if (LC_this->LC_VD_S_GUARDSWITCH1)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_GuardSwitch2, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
          else
          {
            if (LC_this->LC_VD_S_GUARDSWITCH2)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_GuardSwitch1, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_GuardSwitch2))
        {
          if (LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_Q)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Discrepancytime_Error_1, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
          else
          {
            {
              LC_TD_BOOL conditionResult = LC_EL_false;
              conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH1));
              if (conditionResult)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Open_Guard_Request, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
              else
              {
                {
                  LC_TD_BOOL conditionResult = LC_EL_false;
                  conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_GUARDSWITCH1,LC_this->LC_VD_S_GUARDSWITCH2));
                  if (conditionResult)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Guard_Closed, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_GuardSwitch1))
        {
          if (LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_Q)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Discrepancytime_Error_2, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
          else
          {
            {
              LC_TD_BOOL conditionResult = LC_EL_false;
              conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH2));
              if (conditionResult)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Open_Guard_Request, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
              else
              {
                {
                  LC_TD_BOOL conditionResult = LC_EL_false;
                  conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_GUARDSWITCH1,LC_this->LC_VD_S_GUARDSWITCH2));
                  if (conditionResult)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Guard_Closed, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Discrepancytime_Error_1)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Discrepancytime_Error_2))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Guard_Opened, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Guard_Closed))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Open_Guard_Request, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_AUTORESET));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_Reset, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Normal, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_Reset))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Reset_Error, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH2))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Open_Guard_Request, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  if (LC_this->LC_VD_RTRIGRESET.LC_VD_Q)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Normal, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Normal))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDSWITCH2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Open_Guard_Request, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Reset_Error))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_Reset, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else
        {
          ;
        }
      }
    }
  }
  {
    LC_TD_UINT caseSelector;
    {
      LC_TD_Function_TO_UINT lFunction_TO_UINT;
      LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
      lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
      caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
    }
    if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Idle))
    {
      {
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_DISCREPANCYTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_false;
      LC_this->LC_VD_S_GUARDOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Normal))
    {
      {
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_DISCREPANCYTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDOUT = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Init)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Guard_Closed))
    {
      {
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_DISCREPANCYTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Open_Guard_Request)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Guard_Opened))
    {
      {
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_DISCREPANCYTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_true;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_GuardSwitch2)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_GuardSwitch1))
    {
      {
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_IN = LC_EL_true;
        lcfu_iec61131__TON(&(LC_this->LC_VD_DISCREPANCYTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_true;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_Reset))
    {
      {
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_DISCREPANCYTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Reset_Error)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Discrepancytime_Error_1)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Discrepancytime_Error_2))
    {
      {
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_DISCREPANCYTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_DISCREPANCYTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_ENO = LC_EL_false;
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
  }
}

#endif
