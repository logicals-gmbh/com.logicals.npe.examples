#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_EDM__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_EDM__C

#include <lcfu___safety.plcopen.sf_edm.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_EDM(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_EDM* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_EDM* p = LC_this; \
  (p)->LC_VD_ACTIVATE = LC_EL_false; \
  (p)->LC_VD_S_OUTCONTROL = LC_EL_false; \
  (p)->LC_VD_EDM1 = LC_EL_false; \
  (p)->LC_VD_EDM2 = LC_EL_false; \
  (p)->LC_VD_MONITORINGTIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0)); \
  (p)->LC_VD_RESET = LC_EL_false; \
  (p)->LC_VD_READY = LC_EL_false; \
  (p)->LC_VD_S_EDM_OUT = LC_EL_false; \
  (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  (p)->LC_VD_ERROR = LC_EL_false; \
  (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGRESET)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGSOUTCONTROL)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGEDM1)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGEDM2)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_MONITORINGTIMEROUTPUTDISABLE)); \
  (p)->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_IN = LC_EL_false; \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_MONITORINGTIMEROUTPUTENABLE)); \
  (p)->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_IN = LC_EL_false; \
}

void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_EDM(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_EDM* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_EDM* p = LC_this; \
  if (RF==0) (p)->LC_VD_ACTIVATE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_OUTCONTROL = LC_EL_false; \
  if (RF==0) (p)->LC_VD_EDM1 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_EDM2 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MONITORINGTIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0)); \
  if (RF==0) (p)->LC_VD_RESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_READY = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_EDM_OUT = LC_EL_false; \
  if (RF==0) (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  if (RF==0) (p)->LC_VD_ERROR = LC_EL_false; \
  if (RF==0) (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGRESET),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGSOUTCONTROL),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGEDM1),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGEDM2),0); \
  if (RF==0) \
    { \
    LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_MONITORINGTIMEROUTPUTDISABLE),0); \
    (p)->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_IN = LC_EL_false; \
    } \
  if (RF==0) \
    { \
    LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_MONITORINGTIMEROUTPUTENABLE),0); \
    (p)->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_IN = LC_EL_false; \
    } \
}

void  lcfu___SAFETYx2EPLCOPENx2ESF_EDM(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_EDM* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_RTRIGRESET.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGRESET.LC_VD_CLK = LC_this->LC_VD_RESET;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGRESET), pEPDB);
  }
  {
    LC_this->LC_VD_RTRIGSOUTCONTROL.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGSOUTCONTROL.LC_VD_CLK = LC_this->LC_VD_S_OUTCONTROL;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGSOUTCONTROL), pEPDB);
  }
  {
    LC_this->LC_VD_RTRIGEDM1.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGEDM1.LC_VD_CLK = LC_this->LC_VD_EDM1;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGEDM1), pEPDB);
  }
  {
    LC_this->LC_VD_RTRIGEDM2.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGEDM2.LC_VD_CLK = LC_this->LC_VD_EDM2;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGEDM2), pEPDB);
  }
  {
    LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_PT = LC_this->LC_VD_MONITORINGTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE), pEPDB);
  }
  {
    LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_PT = LC_this->LC_VD_MONITORINGTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE), pEPDB);
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ACTIVATE));
    if (conditionResult)
    {
      {
        LC_TD_Function_TO_WORD lFunction_TO_WORD;
        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Idle, pEPDB);
        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
      }
    }
    else
    {
      {
        LC_TD_UINT caseSelector;
        {
          LC_TD_Function_TO_UINT lFunction_TO_UINT;
          LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
          lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
          lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
          caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
        }
        if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Idle))
        {
          {
            LC_TD_Function_TO_WORD lFunction_TO_WORD;
            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Init, pEPDB);
            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Init))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_1, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_RTRIGSOUTCONTROL.LC_VD_Q));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Init_Error, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  if (LC_this->LC_VD_RTRIGRESET.LC_VD_Q)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_1))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Init, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Init_Error))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Init, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_OUTCONTROL,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM1)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_13a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_OUTCONTROL,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM1))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_11a, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_OUTCONTROL,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM2))));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_12a, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      {
                        LC_TD_BOOL conditionResult = LC_EL_false;
                        conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_Q,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM1)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM2))));
                        if (conditionResult)
                        {
                          {
                            LC_TD_Function_TO_WORD lFunction_TO_WORD;
                            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_23a, pEPDB);
                            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                          }
                        }
                        else
                        {
                          {
                            LC_TD_BOOL conditionResult = LC_EL_false;
                            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_Q,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM1))));
                            if (conditionResult)
                            {
                              {
                                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_21a, pEPDB);
                                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                              }
                            }
                            else
                            {
                              {
                                LC_TD_BOOL conditionResult = LC_EL_false;
                                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_Q,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM2))));
                                if (conditionResult)
                                {
                                  {
                                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_22a, pEPDB);
                                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                                  }
                                }
                                else
                                {
                                  if (LC_this->LC_VD_S_OUTCONTROL)
                                  {
                                    {
                                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Enable, pEPDB);
                                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_11a))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q)))),LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2)),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_RTRIGEDM1.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_21, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_EDM1,LC_this->LC_VD_EDM2));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_11b, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_11b))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_11a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q)))),LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2)),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_RTRIGEDM1.LC_VD_Q))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_21, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_12a))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q)))),LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2)),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_RTRIGEDM2.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_22, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_EDM1,LC_this->LC_VD_EDM2));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_12b, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_12b))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_EDM1,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_12a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q)))),LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2)),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_RTRIGEDM2.LC_VD_Q))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_22, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_13a))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q)))),LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2)),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_RTRIGEDM1.LC_VD_Q)),LC_this->LC_VD_RTRIGEDM2.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_23, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_EDM1,LC_this->LC_VD_EDM2));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_13b, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_13b))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_13a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_21))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_11a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_22))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_12a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_23))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_13a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_21a))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q)))),LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2)),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_RTRIGEDM1.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_31, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_EDM1,LC_this->LC_VD_EDM2));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_21b, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_21b))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_21a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_22a))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q)))),LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2)),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_RTRIGEDM2.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_32, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  if (LC_this->LC_VD_EDM2)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_22b, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_22b))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_EDM1,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_22a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_23a))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q)))),LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2)),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_RTRIGEDM1.LC_VD_Q)),LC_this->LC_VD_RTRIGEDM2.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_33, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_EDM1,LC_this->LC_VD_EDM2));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_23b, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_23b))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM1)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_EDM2))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_23a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_31))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_21a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_32))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_22a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_33))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_23a, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Enable))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_Q,LC_this->LC_VD_EDM1)),LC_this->LC_VD_EDM2));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_33, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_Q,LC_this->LC_VD_EDM1));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_31, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_Q,LC_this->LC_VD_EDM2));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_32, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      {
                        LC_TD_BOOL conditionResult = LC_EL_false;
                        conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_OUTCONTROL));
                        if (conditionResult)
                        {
                          {
                            LC_TD_Function_TO_WORD lFunction_TO_WORD;
                            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_31))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_41, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                {
                  LC_TD_Function_NOT__BOOL lFunction__rightOp_NOT;
                  LC_INIT_Function_NOT__BOOL(&lFunction__rightOp_NOT);
                  lFunction__rightOp_NOT.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__NOT__BOOL(&lFunction__rightOp_NOT, (lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_RTRIGEDM1.LC_VD_Q,LC_this->LC_VD_RTRIGEDM2.LC_VD_Q)), pEPDB);
                  conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,lFunction__rightOp_NOT.LC_VD_NOT));
                }
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_32))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_42, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                {
                  LC_TD_Function_NOT__BOOL lFunction__rightOp_NOT;
                  LC_INIT_Function_NOT__BOOL(&lFunction__rightOp_NOT);
                  lFunction__rightOp_NOT.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__NOT__BOOL(&lFunction__rightOp_NOT, (lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_RTRIGEDM1.LC_VD_Q,LC_this->LC_VD_RTRIGEDM2.LC_VD_Q)), pEPDB);
                  conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,lFunction__rightOp_NOT.LC_VD_NOT));
                }
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_33))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_43, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                {
                  LC_TD_Function_NOT__BOOL lFunction__rightOp_NOT;
                  LC_INIT_Function_NOT__BOOL(&lFunction__rightOp_NOT);
                  lFunction__rightOp_NOT.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__NOT__BOOL(&lFunction__rightOp_NOT, (lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_RTRIGEDM1.LC_VD_Q,LC_this->LC_VD_RTRIGEDM2.LC_VD_Q)), pEPDB);
                  conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,lFunction__rightOp_NOT.LC_VD_NOT));
                }
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_41))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_31, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_42))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_32, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_43))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_33, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else
        {
          ;
        }
      }
    }
  }
  {
    LC_TD_UINT caseSelector;
    {
      LC_TD_Function_TO_UINT lFunction_TO_UINT;
      LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
      lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
      caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
    }
    if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Idle))
    {
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE), pEPDB);
      }
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_false;
      LC_this->LC_VD_S_EDM_OUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Init))
    {
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE), pEPDB);
      }
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_EDM_OUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_true;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable))
    {
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_IN = LC_EL_true;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE), pEPDB);
      }
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_EDM_OUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_true;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Enable))
    {
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_IN = LC_EL_true;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE), pEPDB);
      }
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_EDM_OUT = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_1)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_21)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_22)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_23)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_31)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_32)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_33)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_41)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_42)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_43)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Init_Error))
    {
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE), pEPDB);
      }
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_EDM_OUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_11a)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_12a)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_13a)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_21a)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_22a)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_23a))
    {
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE), pEPDB);
      }
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_EDM_OUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_11b)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_12b)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_13b)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_21b)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_22b)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_23b)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_31)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_32)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_33))
    {
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTDISABLE), pEPDB);
      }
      {
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MONITORINGTIMEROUTPUTENABLE), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_EDM_OUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_ENO = LC_EL_false;
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_EDM_OUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
  }
}

#endif
