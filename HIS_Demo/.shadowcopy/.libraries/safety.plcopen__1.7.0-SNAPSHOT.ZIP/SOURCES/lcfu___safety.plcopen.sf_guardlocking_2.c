#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2__C

#include <lcfu___safety.plcopen.sf_guardlocking_2.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2* p = LC_this; \
  (p)->LC_VD_ACTIVATE = LC_EL_false; \
  (p)->LC_VD_S_GUARD = LC_EL_false; \
  (p)->LC_VD_S_SAFETYACTIVE = LC_EL_false; \
  (p)->LC_VD_S_GUARDLOCK = LC_EL_false; \
  (p)->LC_VD_UNLOCKREQUEST = LC_EL_false; \
  (p)->LC_VD_S_STARTRESET = LC_EL_false; \
  (p)->LC_VD_S_AUTORESET = LC_EL_false; \
  (p)->LC_VD_RESET = LC_EL_false; \
  (p)->LC_VD_READY = LC_EL_false; \
  (p)->LC_VD_S_GUARDLOCKED = LC_EL_false; \
  (p)->LC_VD_S_UNLOCKGUARD = LC_EL_false; \
  (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  (p)->LC_VD_ERROR = LC_EL_false; \
  (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  (p)->LC_VD_MAXWAITTIME = LC_TIME_VALUE(RT_CC_CONST_LL(2),RT_CC_CONST_LL(0)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGRESET)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGUNLOCKREQUEST)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_UNLOCKWAITINGTIMER)); \
  (p)->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_false; \
}

void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2* p = LC_this; \
  if (RF==0) (p)->LC_VD_ACTIVATE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_GUARD = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_SAFETYACTIVE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_GUARDLOCK = LC_EL_false; \
  if (RF==0) (p)->LC_VD_UNLOCKREQUEST = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_STARTRESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_AUTORESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_READY = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_GUARDLOCKED = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_UNLOCKGUARD = LC_EL_false; \
  if (RF==0) (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  if (RF==0) (p)->LC_VD_ERROR = LC_EL_false; \
  if (RF==0) (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  if (RF==0) (p)->LC_VD_MAXWAITTIME = LC_TIME_VALUE(RT_CC_CONST_LL(2),RT_CC_CONST_LL(0)); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGRESET),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGUNLOCKREQUEST),0); \
  if (RF==0) \
    { \
    LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_UNLOCKWAITINGTIMER),0); \
    (p)->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_false; \
    } \
}

void  lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_RTRIGRESET.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGRESET.LC_VD_CLK = LC_this->LC_VD_RESET;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGRESET), pEPDB);
  }
  {
    LC_this->LC_VD_RTRIGUNLOCKREQUEST.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGUNLOCKREQUEST.LC_VD_CLK = LC_this->LC_VD_UNLOCKREQUEST;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGUNLOCKREQUEST), pEPDB);
  }
  {
    LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_PT = LC_this->LC_VD_MAXWAITTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ACTIVATE));
    if (conditionResult)
    {
      {
        LC_TD_Function_TO_WORD lFunction_TO_WORD;
        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Idle, pEPDB);
        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
      }
    }
    else
    {
      {
        LC_TD_UINT caseSelector;
        {
          LC_TD_Function_TO_UINT lFunction_TO_UINT;
          LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
          lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
          lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
          caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
        }
        if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Idle))
        {
          {
            LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE;
            LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE);
            lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE.LC_VD_ENO = LC_EL_true;
            lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE, LC_this->LC_VD_S_GUARD, LC_this->LC_VD_S_GUARDLOCK, pEPDB);
            LC_this->LC_VD_DIAGCODE = lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE.LC_VD_SF_GUARDLOCKING_2_DETERMINEINITSUBSTATE;
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Init_S_Guard_And_S_GuardLock_True)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Init_S_Guard_Or_S_GuardLock_False))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_STARTRESET))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_0, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARD)),LC_this->LC_VD_UNLOCKREQUEST));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Open_And_Unlocked, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARD)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_UNLOCKREQUEST))));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Error, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      {
                        LC_TD_BOOL conditionResult = LC_EL_false;
                        conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_S_STARTRESET)),LC_this->LC_VD_S_GUARD)),LC_this->LC_VD_S_GUARDLOCK));
                        if (conditionResult)
                        {
                          {
                            LC_TD_Function_TO_WORD lFunction_TO_WORD;
                            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_And_Locked, pEPDB);
                            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                          }
                        }
                        else
                        {
                          {
                            LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE;
                            LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE);
                            lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE.LC_VD_ENO = LC_EL_true;
                            lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE, LC_this->LC_VD_S_GUARD, LC_this->LC_VD_S_GUARDLOCK, pEPDB);
                            LC_this->LC_VD_DIAGCODE = lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE.LC_VD_SF_GUARDLOCKING_2_DETERMINEINITSUBSTATE;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_0))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE);
                lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE, LC_this->LC_VD_S_GUARD, LC_this->LC_VD_S_GUARDLOCK, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINEINITSUBSTATE.LC_VD_SF_GUARDLOCKING_2_DETERMINEINITSUBSTATE;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Open_And_Unlocked))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_SAFETYACTIVE));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE);
                lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE, LC_this->LC_VD_S_GUARD, LC_this->LC_VD_S_GUARDLOCK, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE.LC_VD_SF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE;
              }
            }
            else
            {
              if (LC_this->LC_VD_S_GUARD)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_But_Unlocked, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Safety_Lost_S_Guard_And_S_GuardLock_True)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Safety_Lost_S_Guard_Or_S_GuardLock_False))
        {
          if (LC_this->LC_VD_S_SAFETYACTIVE)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Safety_Return, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
          else
          {
            {
              LC_TD_BOOL conditionResult = LC_EL_false;
              conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_S_GUARDLOCK)),LC_this->LC_VD_S_GUARD));
              if (conditionResult)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_And_Locked, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
              else
              {
                {
                  LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE;
                  LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE);
                  lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE.LC_VD_ENO = LC_EL_true;
                  lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE, LC_this->LC_VD_S_GUARD, LC_this->LC_VD_S_GUARDLOCK, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE.LC_VD_SF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE;
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Safety_Return))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_2, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_SAFETYACTIVE));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE;
                    LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE);
                    lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE.LC_VD_ENO = LC_EL_true;
                    lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE, LC_this->LC_VD_S_GUARD, LC_this->LC_VD_S_GUARDLOCK, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE.LC_VD_SF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,(lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDLOCK)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARD))))));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Wait_For_Operator, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      {
                        LC_TD_BOOL conditionResult = LC_EL_false;
                        conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_S_GUARDLOCK)),LC_this->LC_VD_S_GUARD));
                        if (conditionResult)
                        {
                          {
                            LC_TD_Function_TO_WORD lFunction_TO_WORD;
                            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_And_Locked, pEPDB);
                            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_2))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Safety_Return, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_But_Unlocked))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_SAFETYACTIVE));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE);
                lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE, LC_this->LC_VD_S_GUARD, LC_this->LC_VD_S_GUARDLOCK, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE.LC_VD_SF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARD));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Open_And_Unlocked, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_UNLOCKREQUEST));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Wait_For_Operator, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Wait_For_Operator))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_SAFETYACTIVE));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE);
                lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE, LC_this->LC_VD_S_GUARD, LC_this->LC_VD_S_GUARDLOCK, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE.LC_VD_SF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_SAFETYACTIVE,LC_this->LC_VD_UNLOCKREQUEST)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARD))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Open_And_Unlocked, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_GUARD,LC_this->LC_VD_S_GUARDLOCK)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_AUTORESET))));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Wait_For_Reset, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      {
                        LC_TD_BOOL conditionResult = LC_EL_false;
                        conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_GUARD,LC_this->LC_VD_S_GUARDLOCK)),LC_this->LC_VD_S_AUTORESET));
                        if (conditionResult)
                        {
                          {
                            LC_TD_Function_TO_WORD lFunction_TO_WORD;
                            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_And_Locked, pEPDB);
                            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Wait_For_Reset))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_3, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARD)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDLOCK))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Error, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  if (LC_this->LC_VD_RTRIGRESET.LC_VD_Q)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_And_Locked, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                  else
                  {
                    if (LC_this->LC_VD_RTRIGUNLOCKREQUEST.LC_VD_Q)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Wait_For_Unlocked, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_3))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Wait_For_Reset, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Error))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_S_GUARDLOCK,LC_this->LC_VD_S_GUARD));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Return, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Return))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDLOCK)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARD))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Error, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_1, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  if (LC_this->LC_VD_RTRIGRESET.LC_VD_Q)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_And_Locked, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_1))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Return, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Wait_For_Unlocked))
        {
          {
            LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
            lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
          }
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_SAFETYACTIVE));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE);
                lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(&lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE, LC_this->LC_VD_S_GUARD, LC_this->LC_VD_S_GUARDLOCK, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE.LC_VD_SF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDLOCK));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_But_Unlocked, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  if (LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_Q)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Unlock_Request_Error, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Unlock_Request_Error))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_4, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARD)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDLOCK))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Error, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGRESET.LC_VD_Q,LC_this->LC_VD_S_GUARDLOCK)),LC_this->LC_VD_S_GUARD));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_And_Locked, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_4))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Unlock_Request_Error, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_And_Locked))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARDLOCK)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_GUARD))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Error, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RTRIGUNLOCKREQUEST.LC_VD_Q,LC_this->LC_VD_S_SAFETYACTIVE));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Wait_For_Unlocked, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else
        {
          ;
        }
      }
    }
  }
  {
    LC_TD_UINT caseSelector;
    {
      LC_TD_Function_TO_UINT lFunction_TO_UINT;
      LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
      lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
      caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
    }
    if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_0)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Error)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_1)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_2)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_3))
    {
      {
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDLOCKED = LC_EL_false;
      LC_this->LC_VD_S_UNLOCKGUARD = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Return))
    {
      {
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDLOCKED = LC_EL_false;
      LC_this->LC_VD_S_UNLOCKGUARD = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Safety_Lost_S_Guard_And_S_GuardLock_True)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Unlock_Request_Error))
    {
      {
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDLOCKED = LC_EL_false;
      LC_this->LC_VD_S_UNLOCKGUARD = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Safety_Return))
    {
      {
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDLOCKED = LC_EL_false;
      LC_this->LC_VD_S_UNLOCKGUARD = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Safety_Lost_S_Guard_Or_S_GuardLock_False)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Reset_Error_4))
    {
      {
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDLOCKED = LC_EL_false;
      LC_this->LC_VD_S_UNLOCKGUARD = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Idle))
    {
      {
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_false;
      LC_this->LC_VD_S_GUARDLOCKED = LC_EL_false;
      LC_this->LC_VD_S_UNLOCKGUARD = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_And_Locked))
    {
      {
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDLOCKED = LC_EL_true;
      LC_this->LC_VD_S_UNLOCKGUARD = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Init_S_Guard_And_S_GuardLock_True)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Wait_For_Reset))
    {
      {
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDLOCKED = LC_EL_false;
      LC_this->LC_VD_S_UNLOCKGUARD = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Init_S_Guard_Or_S_GuardLock_False)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Wait_For_Operator))
    {
      {
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDLOCKED = LC_EL_false;
      LC_this->LC_VD_S_UNLOCKGUARD = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_true;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Open_And_Unlocked)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Guard_Closed_But_Unlocked))
    {
      {
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDLOCKED = LC_EL_false;
      LC_this->LC_VD_S_UNLOCKGUARD = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_true;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Wait_For_Unlocked))
    {
      {
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_UNLOCKWAITINGTIMER.LC_VD_IN = LC_EL_true;
        lcfu_iec61131__TON(&(LC_this->LC_VD_UNLOCKWAITINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDLOCKED = LC_EL_false;
      LC_this->LC_VD_S_UNLOCKGUARD = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else
    {
      LC_this->LC_VD_ENO = LC_EL_false;
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_GUARDLOCKED = LC_EL_false;
      LC_this->LC_VD_S_UNLOCKGUARD = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
  }
}

#endif
