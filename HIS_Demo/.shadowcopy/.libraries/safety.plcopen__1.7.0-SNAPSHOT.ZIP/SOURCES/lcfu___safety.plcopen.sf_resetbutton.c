#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_RESETBUTTON__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_RESETBUTTON__C

#include <lcfu___safety.plcopen.sf_resetbutton.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON* p = LC_this; \
  (p)->LC_VD_RESETREQUESTED = LC_EL_true; \
  (p)->LC_VD_RESETIN = LC_EL_false; \
  (p)->LC_VD_TRAILINGMINIMUM = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(350000000)); \
  (p)->LC_VD_TRAILINGMAXIMUM = LC_TIME_VALUE(RT_CC_CONST_LL(2),RT_CC_CONST_LL(0)); \
  (p)->LC_VD_READY = LC_EL_false; \
  (p)->LC_VD_RESETOUT = LC_EL_false; \
  (p)->LC_VD_ERROR = LC_EL_false; \
  (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TRAILINGMINIMUMTIMER)); \
  (p)->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_IN = LC_EL_false; \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TRAILINGMAXIMUMTIMER)); \
  (p)->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_IN = LC_EL_false; \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGRESETIN)); \
  LC_INIT_FunctionBlock_F_TRIG(&((p)->LC_VD_FTRIGRESETIN)); \
}

void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON* p = LC_this; \
  if (RF==0) (p)->LC_VD_RESETREQUESTED = LC_EL_true; \
  if (RF==0) (p)->LC_VD_RESETIN = LC_EL_false; \
  if (RF==0) (p)->LC_VD_TRAILINGMINIMUM = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(350000000)); \
  if (RF==0) (p)->LC_VD_TRAILINGMAXIMUM = LC_TIME_VALUE(RT_CC_CONST_LL(2),RT_CC_CONST_LL(0)); \
  if (RF==0) (p)->LC_VD_READY = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESETOUT = LC_EL_false; \
  if (RF==0) (p)->LC_VD_ERROR = LC_EL_false; \
  if (RF==0) (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  if (RF==0) \
    { \
    LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TRAILINGMINIMUMTIMER),0); \
    (p)->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_IN = LC_EL_false; \
    } \
  if (RF==0) \
    { \
    LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TRAILINGMAXIMUMTIMER),0); \
    (p)->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_IN = LC_EL_false; \
    } \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RTRIGRESETIN),0); \
  LC_WINIT_FunctionBlock_F_TRIG(&((p)->LC_VD_FTRIGRESETIN),0); \
}

void  lcfu___SAFETYx2EPLCOPENx2ESF_RESETBUTTON(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_RESETBUTTON* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_PT = LC_this->LC_VD_TRAILINGMINIMUM;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMINIMUMTIMER), pEPDB);
  }
  {
    LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_PT = LC_this->LC_VD_TRAILINGMAXIMUM;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMAXIMUMTIMER), pEPDB);
  }
  {
    LC_this->LC_VD_RTRIGRESETIN.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RTRIGRESETIN.LC_VD_CLK = LC_this->LC_VD_RESETIN;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RTRIGRESETIN), pEPDB);
  }
  {
    LC_this->LC_VD_FTRIGRESETIN.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FTRIGRESETIN.LC_VD_CLK = LC_this->LC_VD_RESETIN;
    lcfu_iec61131__F_TRIG(&(LC_this->LC_VD_FTRIGRESETIN), pEPDB);
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESETREQUESTED));
    if (conditionResult)
    {
      {
        LC_TD_Function_TO_WORD lFunction_TO_WORD;
        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Idle, pEPDB);
        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
      }
    }
    else
    {
      #if 0 /* Properties: */
      * COV_UT := defensive programming
      #endif  /* Properties: */

      {
        LC_TD_UINT caseSelector;
        {
          LC_TD_Function_TO_UINT lFunction_TO_UINT;
          LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
          lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
          lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
          caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
        }
        if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Idle))
        {
          {
            LC_TD_Function_TO_WORD lFunction_TO_WORD;
            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Wait_for_R_TRIG, pEPDB);
            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Wait_for_R_TRIG))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_TRAILINGMINIMUM > LC_this->LC_VD_TRAILINGMAXIMUM),(LC_TD_BOOL)(LC_this->LC_VD_TRAILINGMINIMUM < LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(100000000)))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Parameter_Error, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESETIN,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RTRIGRESETIN.LC_VD_Q))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Reset_Error, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  if (LC_this->LC_VD_RTRIGRESETIN.LC_VD_Q)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Wait_for_F_TRIG, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Reset_Error))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESETIN));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Wait_for_R_TRIG, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Wait_for_F_TRIG))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_FTRIGRESETIN.LC_VD_Q,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Error_Trailing_Minimum, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              if (LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_Q)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Error_Trailing_Maximum, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
              else
              {
                if (LC_this->LC_VD_FTRIGRESETIN.LC_VD_Q)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Reset_Detected, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Error_Trailing_Maximum))
        {
          if (LC_this->LC_VD_RTRIGRESETIN.LC_VD_Q)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Wait_for_F_TRIG, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Error_Trailing_Minimum))
        {
          if (LC_this->LC_VD_RTRIGRESETIN.LC_VD_Q)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Wait_for_F_TRIG, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Reset_Detected))
        {
          {
            LC_TD_Function_TO_WORD lFunction_TO_WORD;
            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Wait_for_R_TRIG, pEPDB);
            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
          }
        }
        else
        {
          ;
        }
      }
    }
  }
  {
    LC_TD_UINT caseSelector;
    {
      LC_TD_Function_TO_UINT lFunction_TO_UINT;
      LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
      lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
      caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
    }
    if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Parameter_Error))
    {
      {
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMINIMUMTIMER), pEPDB);
      }
      {
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMAXIMUMTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_RESETOUT = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Reset_Error))
    {
      {
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMINIMUMTIMER), pEPDB);
      }
      {
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMAXIMUMTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_RESETOUT = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Error_Trailing_Maximum))
    {
      {
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMINIMUMTIMER), pEPDB);
      }
      {
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMAXIMUMTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_RESETOUT = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Error_Trailing_Minimum))
    {
      {
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMINIMUMTIMER), pEPDB);
      }
      {
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMAXIMUMTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_RESETOUT = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Idle))
    {
      {
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMINIMUMTIMER), pEPDB);
      }
      {
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMAXIMUMTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_false;
      LC_this->LC_VD_RESETOUT = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Wait_for_R_TRIG))
    {
      {
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMINIMUMTIMER), pEPDB);
      }
      {
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMAXIMUMTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_RESETOUT = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Wait_for_F_TRIG))
    {
      {
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_IN = LC_EL_true;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMINIMUMTIMER), pEPDB);
      }
      {
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_IN = LC_EL_true;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMAXIMUMTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_RESETOUT = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Reset_Detected))
    {
      {
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMINIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMINIMUMTIMER), pEPDB);
      }
      {
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_TRAILINGMAXIMUMTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_TRAILINGMAXIMUMTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_RESETOUT = LC_EL_true;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else
    {
      LC_this->LC_VD_ENO = LC_EL_false;
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_RESETOUT = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
  }
}

#endif
