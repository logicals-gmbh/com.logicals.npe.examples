#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST__C

#include <lcfu___safety.plcopen.sf_guardlockingserial_determinesafetylost.h>

/*                            Functions                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST(LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST* LC_this, LC_TD_DataType_SAFEBOOL LC_VD_S_GUARD, struct _lcoplck_epdb_1_impl* pEPDB)
{
  if (LC_VD_S_GUARD)
  {
    {
      LC_TD_Function_TO_WORD lFunction_TO_WORD;
      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Safety_Lost_S_Guard_True, pEPDB);
      LC_this->LC_VD_SF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST = lFunction_TO_WORD.LC_VD_TO_WORD;
    }
  }
  else
  {
    {
      LC_TD_Function_TO_WORD lFunction_TO_WORD;
      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Safety_Lost_S_Guard_False, pEPDB);
      LC_this->LC_VD_SF_GUARDLOCKINGSERIAL_DETERMINESAFETYLOST = lFunction_TO_WORD.LC_VD_TO_WORD;
    }
  }
}

#endif
