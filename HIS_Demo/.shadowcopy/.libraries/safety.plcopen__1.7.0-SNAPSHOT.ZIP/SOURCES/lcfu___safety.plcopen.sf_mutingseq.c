#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ__C

#include <lcfu___safety.plcopen.sf_mutingseq.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ* p = LC_this; \
  (p)->LC_VD_ACTIVATE = LC_EL_false; \
  (p)->LC_VD_S_AOPD_IN = LC_EL_false; \
  (p)->LC_VD_MUTINGSWITCH11 = LC_EL_false; \
  (p)->LC_VD_MUTINGSWITCH12 = LC_EL_false; \
  (p)->LC_VD_MUTINGSWITCH21 = LC_EL_false; \
  (p)->LC_VD_MUTINGSWITCH22 = LC_EL_false; \
  (p)->LC_VD_MAXMUTINGTIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0)); \
  (p)->LC_VD_MUTINGENABLE = LC_EL_false; \
  (p)->LC_VD_S_STARTRESET = LC_EL_false; \
  (p)->LC_VD_RESET = LC_EL_false; \
  (p)->LC_VD_READY = LC_EL_false; \
  (p)->LC_VD_S_AOPD_OUT = LC_EL_false; \
  (p)->LC_VD_S_MUTINGACTIVE = LC_EL_false; \
  (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  (p)->LC_VD_ERROR = LC_EL_false; \
  (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_MUTINGTIMER)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_RESET)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_S11)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_S12)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_S21)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_S22)); \
  LC_INIT_FunctionBlock_F_TRIG(&((p)->LC_VD_F_TRIG_S11)); \
  LC_INIT_FunctionBlock_F_TRIG(&((p)->LC_VD_F_TRIG_S12)); \
  LC_INIT_FunctionBlock_F_TRIG(&((p)->LC_VD_F_TRIG_S21)); \
  LC_INIT_FunctionBlock_F_TRIG(&((p)->LC_VD_F_TRIG_S22)); \
}

void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ* p = LC_this; \
  if (RF==0) (p)->LC_VD_ACTIVATE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_AOPD_IN = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MUTINGSWITCH11 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MUTINGSWITCH12 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MUTINGSWITCH21 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MUTINGSWITCH22 = LC_EL_false; \
  if (RF==0) (p)->LC_VD_MAXMUTINGTIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0)); \
  if (RF==0) (p)->LC_VD_MUTINGENABLE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_STARTRESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_READY = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_AOPD_OUT = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_MUTINGACTIVE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  if (RF==0) (p)->LC_VD_ERROR = LC_EL_false; \
  if (RF==0) (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_MUTINGTIMER),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_RESET),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_S11),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_S12),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_S21),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_S22),0); \
  LC_WINIT_FunctionBlock_F_TRIG(&((p)->LC_VD_F_TRIG_S11),0); \
  LC_WINIT_FunctionBlock_F_TRIG(&((p)->LC_VD_F_TRIG_S12),0); \
  LC_WINIT_FunctionBlock_F_TRIG(&((p)->LC_VD_F_TRIG_S21),0); \
  LC_WINIT_FunctionBlock_F_TRIG(&((p)->LC_VD_F_TRIG_S22),0); \
}

void  lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_TD_UINT LC_VD_CONTROLCODE;
  LC_VD_CONTROLCODE = (LC_TD_UINT)0;
  {
    LC_this->LC_VD_R_TRIG_RESET.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_R_TRIG_RESET.LC_VD_CLK = LC_this->LC_VD_RESET;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG_RESET), pEPDB);
  }
  {
    LC_this->LC_VD_R_TRIG_S11.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_R_TRIG_S11.LC_VD_CLK = LC_this->LC_VD_MUTINGSWITCH11;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG_S11), pEPDB);
  }
  {
    LC_this->LC_VD_R_TRIG_S12.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_R_TRIG_S12.LC_VD_CLK = LC_this->LC_VD_MUTINGSWITCH12;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG_S12), pEPDB);
  }
  {
    LC_this->LC_VD_R_TRIG_S21.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_R_TRIG_S21.LC_VD_CLK = LC_this->LC_VD_MUTINGSWITCH21;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG_S21), pEPDB);
  }
  {
    LC_this->LC_VD_R_TRIG_S22.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_R_TRIG_S22.LC_VD_CLK = LC_this->LC_VD_MUTINGSWITCH22;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG_S22), pEPDB);
  }
  {
    LC_this->LC_VD_F_TRIG_S11.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_F_TRIG_S11.LC_VD_CLK = LC_this->LC_VD_MUTINGSWITCH11;
    lcfu_iec61131__F_TRIG(&(LC_this->LC_VD_F_TRIG_S11), pEPDB);
  }
  {
    LC_this->LC_VD_F_TRIG_S12.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_F_TRIG_S12.LC_VD_CLK = LC_this->LC_VD_MUTINGSWITCH12;
    lcfu_iec61131__F_TRIG(&(LC_this->LC_VD_F_TRIG_S12), pEPDB);
  }
  {
    LC_this->LC_VD_F_TRIG_S21.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_F_TRIG_S21.LC_VD_CLK = LC_this->LC_VD_MUTINGSWITCH21;
    lcfu_iec61131__F_TRIG(&(LC_this->LC_VD_F_TRIG_S21), pEPDB);
  }
  {
    LC_this->LC_VD_F_TRIG_S22.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_F_TRIG_S22.LC_VD_CLK = LC_this->LC_VD_MUTINGSWITCH22;
    lcfu_iec61131__F_TRIG(&(LC_this->LC_VD_F_TRIG_S22), pEPDB);
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_TO_WORD lFunction__leftOp_TO_WORD__IN_AND__IN2_TO_WORD;
      LC_TD_Function_AND__WORD lFunction__leftOp_TO_WORD__IN_AND;
      LC_TD_Function_TO_WORD lFunction__leftOp_TO_WORD;
      LC_TD_Function_TO_WORD lFunction__rightOp_TO_WORD;
      LC_INIT_Function_TO_WORD(&lFunction__leftOp_TO_WORD__IN_AND__IN2_TO_WORD);
      LC_INIT_Function_AND__WORD(&lFunction__leftOp_TO_WORD__IN_AND);
      LC_INIT_Function_TO_WORD(&lFunction__leftOp_TO_WORD);
      LC_INIT_Function_TO_WORD(&lFunction__rightOp_TO_WORD);
      lFunction__leftOp_TO_WORD__IN_AND__IN2_TO_WORD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_WORD__UINT(&lFunction__leftOp_TO_WORD__IN_AND__IN2_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Error_Muting_Sequence_Base, pEPDB);
      lFunction__leftOp_TO_WORD__IN_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__ANY__2(&lFunction__leftOp_TO_WORD__IN_AND, LC_this->LC_VD_DIAGCODE, lFunction__leftOp_TO_WORD__IN_AND__IN2_TO_WORD.LC_VD_TO_WORD, pEPDB);
      lFunction__leftOp_TO_WORD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_WORD__WORD(&lFunction__leftOp_TO_WORD, lFunction__leftOp_TO_WORD__IN_AND.LC_VD_AND, pEPDB);
      lFunction__rightOp_TO_WORD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_WORD__UINT(&lFunction__rightOp_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Error_Muting_Sequence_Base, pEPDB);
      conditionResult = (LC_TD_BOOL)(lFunction__leftOp_TO_WORD.LC_VD_TO_WORD == lFunction__rightOp_TO_WORD.LC_VD_TO_WORD);
    }
    if (conditionResult)
    {
      LC_VD_CONTROLCODE = LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Error_Muting_Sequence_Base;
    }
    else
    {
      ;
      {
        LC_TD_Function_TO_UINT lFunction_TO_UINT;
        LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
        lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
        LC_VD_CONTROLCODE = lFunction_TO_UINT.LC_VD_TO_UINT;
      }
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ACTIVATE));
    if (conditionResult)
    {
      {
        LC_TD_Function_TO_WORD lFunction_TO_WORD;
        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Idle, pEPDB);
        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
      }
    }
    else
    {
      {
        LC_TD_UINT caseSelector;
        {
          LC_TD_Function_TO_UINT lFunction_TO_UINT;
          LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
          lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
          lcfu_iec61131__TO_UINT__UINT(&lFunction_TO_UINT, LC_VD_CONTROLCODE, pEPDB);
          caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
        }
        if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Idle))
        {
          {
            LC_TD_Function_TO_WORD lFunction_TO_WORD;
            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Init, pEPDB);
            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Init))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_R_TRIG_RESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Reset_Error_1, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_MAXMUTINGTIME < LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0))),(LC_TD_BOOL)(LC_this->LC_VD_MAXMUTINGTIME > LC_TIME_VALUE(RT_CC_CONST_LL(7200),RT_CC_CONST_LL(0)))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Parameter_Error, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_R_TRIG_RESET.LC_VD_Q,LC_this->LC_VD_S_STARTRESET));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Safe, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Reset_Error_1))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Init, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Safe))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_AOPD_IN));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Safety_Demand_AOPD, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__AOPD_Free, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Safety_Demand_AOPD))
        {
          if (LC_this->LC_VD_S_AOPD_IN)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Wait_for_Reset, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Wait_for_Reset))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_R_TRIG_RESET.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Reset_Error_2, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              if (LC_this->LC_VD_R_TRIG_RESET.LC_VD_Q)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Safe, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Reset_Error_2))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Wait_for_Reset, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Muting_Sequence_Base))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            {
              LC_TD_Function_NOT__BOOL lFunction_NOT;
              LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
              lFunction_NOT.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__NOT__BOOL(&lFunction_NOT, (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_MUTINGSWITCH11,LC_this->LC_VD_MUTINGSWITCH12)),LC_this->LC_VD_MUTINGSWITCH21)),LC_this->LC_VD_MUTINGSWITCH22)), pEPDB);
              conditionResult = lFunction_NOT.LC_VD_NOT;
            }
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Wait_for_Reset, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Timer_MaxMuting))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            {
              LC_TD_Function_NOT__BOOL lFunction_NOT;
              LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
              lFunction_NOT.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__NOT__BOOL(&lFunction_NOT, (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_MUTINGSWITCH11,LC_this->LC_VD_MUTINGSWITCH12)),LC_this->LC_VD_MUTINGSWITCH21)),LC_this->LC_VD_MUTINGSWITCH22)), pEPDB);
              conditionResult = lFunction_NOT.LC_VD_NOT;
            }
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Wait_for_Reset, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__AOPD_Free))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGENABLE)),LC_this->LC_VD_R_TRIG_S11.LC_VD_Q)),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGENABLE)),LC_this->LC_VD_R_TRIG_S22.LC_VD_Q))));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE;
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE);
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE, LC_this->LC_VD_MUTINGSWITCH11, LC_this->LC_VD_MUTINGSWITCH12, LC_this->LC_VD_MUTINGSWITCH21, LC_this->LC_VD_MUTINGSWITCH22, pEPDB);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, (LC_TD_UINT)((LC_TD_UINT)(LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Muting_Sequence_Base + (LC_TD_UINT)3840) + lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_SF_MUTINGSEQ_GETERRORSTATE), pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_MUTINGSWITCH12,LC_this->LC_VD_MUTINGSWITCH21)),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGSWITCH11,LC_this->LC_VD_MUTINGSWITCH22))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE;
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE);
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_ENO = LC_EL_true;
                    lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE, LC_this->LC_VD_MUTINGSWITCH11, LC_this->LC_VD_MUTINGSWITCH12, LC_this->LC_VD_MUTINGSWITCH21, LC_this->LC_VD_MUTINGSWITCH22, pEPDB);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, (LC_TD_UINT)(LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Muting_Sequence_Base + lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_SF_MUTINGSEQ_GETERRORSTATE), pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_AOPD_IN));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Safety_Demand_AOPD, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      {
                        LC_TD_BOOL conditionResult = LC_EL_false;
                        conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGENABLE,(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_R_TRIG_S11.LC_VD_Q,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH12)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH21)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH22))))));
                        if (conditionResult)
                        {
                          {
                            LC_TD_Function_TO_WORD lFunction_TO_WORD;
                            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Muting_Forward_Start, pEPDB);
                            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                          }
                        }
                        else
                        {
                          {
                            LC_TD_BOOL conditionResult = LC_EL_false;
                            conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGENABLE,(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH11)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH12)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH21)))),LC_this->LC_VD_R_TRIG_S22.LC_VD_Q))));
                            if (conditionResult)
                            {
                              {
                                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Muting_Backward_Start, pEPDB);
                                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Muting_Forward_Start))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGENABLE));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE;
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE);
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE, LC_this->LC_VD_MUTINGSWITCH11, LC_this->LC_VD_MUTINGSWITCH12, LC_this->LC_VD_MUTINGSWITCH21, LC_this->LC_VD_MUTINGSWITCH22, pEPDB);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, (LC_TD_UINT)((LC_TD_UINT)(LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Muting_Sequence_Base + (LC_TD_UINT)3840) + lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_SF_MUTINGSEQ_GETERRORSTATE), pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH11)),LC_this->LC_VD_MUTINGSWITCH21)),LC_this->LC_VD_MUTINGSWITCH22));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE;
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE);
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_ENO = LC_EL_true;
                    lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE, LC_this->LC_VD_MUTINGSWITCH11, LC_this->LC_VD_MUTINGSWITCH12, LC_this->LC_VD_MUTINGSWITCH21, LC_this->LC_VD_MUTINGSWITCH22, pEPDB);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, (LC_TD_UINT)((LC_TD_UINT)(LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Muting_Sequence_Base + (LC_TD_UINT)256) + lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_SF_MUTINGSEQ_GETERRORSTATE), pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_AOPD_IN));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Safety_Demand_AOPD, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      {
                        LC_TD_BOOL conditionResult = LC_EL_false;
                        conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGENABLE,LC_this->LC_VD_MUTINGSWITCH11)),LC_this->LC_VD_R_TRIG_S12.LC_VD_Q)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH21)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH22))));
                        if (conditionResult)
                        {
                          {
                            LC_TD_Function_TO_WORD lFunction_TO_WORD;
                            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Muting_Forward_Active, pEPDB);
                            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Muting_Forward_Active))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGENABLE));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE;
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE);
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE, LC_this->LC_VD_MUTINGSWITCH11, LC_this->LC_VD_MUTINGSWITCH12, LC_this->LC_VD_MUTINGSWITCH21, LC_this->LC_VD_MUTINGSWITCH22, pEPDB);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, (LC_TD_UINT)((LC_TD_UINT)(LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Muting_Sequence_Base + (LC_TD_UINT)3840) + lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_SF_MUTINGSEQ_GETERRORSTATE), pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_R_TRIG_S11.LC_VD_Q,LC_this->LC_VD_R_TRIG_S12.LC_VD_Q)),LC_this->LC_VD_F_TRIG_S22.LC_VD_Q)),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGSWITCH11,LC_this->LC_VD_F_TRIG_S12.LC_VD_Q)))),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_MUTINGSWITCH11,LC_this->LC_VD_MUTINGSWITCH12)),LC_this->LC_VD_F_TRIG_S21.LC_VD_Q)))),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH11)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH12)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH22)))))),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH11)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH12)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH21)))),LC_this->LC_VD_R_TRIG_S22.LC_VD_Q)))),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_R_TRIG_S21.LC_VD_Q,LC_this->LC_VD_R_TRIG_S22.LC_VD_Q)))),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_F_TRIG_S11.LC_VD_Q,LC_this->LC_VD_F_TRIG_S12.LC_VD_Q)))),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_F_TRIG_S12.LC_VD_Q,LC_this->LC_VD_F_TRIG_S21.LC_VD_Q))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE;
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE);
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_ENO = LC_EL_true;
                    lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE, LC_this->LC_VD_MUTINGSWITCH11, LC_this->LC_VD_MUTINGSWITCH12, LC_this->LC_VD_MUTINGSWITCH21, LC_this->LC_VD_MUTINGSWITCH22, pEPDB);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, (LC_TD_UINT)((LC_TD_UINT)(LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Muting_Sequence_Base + (LC_TD_UINT)512) + lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_SF_MUTINGSEQ_GETERRORSTATE), pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  if (LC_this->LC_VD_MUTINGTIMER.LC_VD_Q)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Timer_MaxMuting, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                  else
                  {
                    {
                      LC_TD_BOOL conditionResult = LC_EL_false;
                      conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH11)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH12)))),LC_this->LC_VD_F_TRIG_S21.LC_VD_Q)),LC_this->LC_VD_MUTINGSWITCH22));
                      if (conditionResult)
                      {
                        {
                          LC_TD_Function_TO_WORD lFunction_TO_WORD;
                          LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                          lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                          lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__AOPD_Free, pEPDB);
                          LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Muting_Backward_Start))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGENABLE));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE;
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE);
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE, LC_this->LC_VD_MUTINGSWITCH11, LC_this->LC_VD_MUTINGSWITCH12, LC_this->LC_VD_MUTINGSWITCH21, LC_this->LC_VD_MUTINGSWITCH22, pEPDB);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, (LC_TD_UINT)((LC_TD_UINT)(LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Muting_Sequence_Base + (LC_TD_UINT)3840) + lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_SF_MUTINGSEQ_GETERRORSTATE), pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_MUTINGSWITCH11,LC_this->LC_VD_MUTINGSWITCH12)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH22))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE;
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE);
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_ENO = LC_EL_true;
                    lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE, LC_this->LC_VD_MUTINGSWITCH11, LC_this->LC_VD_MUTINGSWITCH12, LC_this->LC_VD_MUTINGSWITCH21, LC_this->LC_VD_MUTINGSWITCH22, pEPDB);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, (LC_TD_UINT)((LC_TD_UINT)(LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Muting_Sequence_Base + (LC_TD_UINT)768) + lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_SF_MUTINGSEQ_GETERRORSTATE), pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_AOPD_IN));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Safety_Demand_AOPD, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      {
                        LC_TD_BOOL conditionResult = LC_EL_false;
                        conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGENABLE,(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH11)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH12)))),LC_this->LC_VD_R_TRIG_S21.LC_VD_Q)),LC_this->LC_VD_MUTINGSWITCH22))));
                        if (conditionResult)
                        {
                          {
                            LC_TD_Function_TO_WORD lFunction_TO_WORD;
                            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Muting_Backward_Active, pEPDB);
                            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Muting_Backward_Active))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGENABLE));
            if (conditionResult)
            {
              {
                LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE;
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE);
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_ENO = LC_EL_true;
                lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE, LC_this->LC_VD_MUTINGSWITCH11, LC_this->LC_VD_MUTINGSWITCH12, LC_this->LC_VD_MUTINGSWITCH21, LC_this->LC_VD_MUTINGSWITCH22, pEPDB);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, (LC_TD_UINT)((LC_TD_UINT)(LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Muting_Sequence_Base + (LC_TD_UINT)3840) + lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_SF_MUTINGSEQ_GETERRORSTATE), pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_F_TRIG_S11.LC_VD_Q,LC_this->LC_VD_R_TRIG_S21.LC_VD_Q)),LC_this->LC_VD_R_TRIG_S22.LC_VD_Q)),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGSWITCH22,LC_this->LC_VD_F_TRIG_S21.LC_VD_Q)))),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_MUTINGSWITCH22,LC_this->LC_VD_MUTINGSWITCH21)),LC_this->LC_VD_F_TRIG_S12.LC_VD_Q)))),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH22)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH21)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH11)))))),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH22)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH21)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH12)))),LC_this->LC_VD_R_TRIG_S11.LC_VD_Q)))),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_R_TRIG_S11.LC_VD_Q,LC_this->LC_VD_R_TRIG_S12.LC_VD_Q)))),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_F_TRIG_S22.LC_VD_Q,LC_this->LC_VD_F_TRIG_S21.LC_VD_Q)))),(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_F_TRIG_S21.LC_VD_Q,LC_this->LC_VD_F_TRIG_S12.LC_VD_Q))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE;
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE);
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_ENO = LC_EL_true;
                    lcfu___SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE(&lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE, LC_this->LC_VD_MUTINGSWITCH11, LC_this->LC_VD_MUTINGSWITCH12, LC_this->LC_VD_MUTINGSWITCH21, LC_this->LC_VD_MUTINGSWITCH22, pEPDB);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, (LC_TD_UINT)((LC_TD_UINT)(LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Muting_Sequence_Base + (LC_TD_UINT)1024) + lFunction_TO_WORD__IN__rightOp_SAFETYx2EPLCOPENx2ESF_MUTINGSEQ_GETERRORSTATE.LC_VD_SF_MUTINGSEQ_GETERRORSTATE), pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  if (LC_this->LC_VD_MUTINGTIMER.LC_VD_Q)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Timer_MaxMuting, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                  else
                  {
                    {
                      LC_TD_BOOL conditionResult = LC_EL_false;
                      conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_MUTINGSWITCH11,LC_this->LC_VD_F_TRIG_S12.LC_VD_Q)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH21)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_MUTINGSWITCH22))));
                      if (conditionResult)
                      {
                        {
                          LC_TD_Function_TO_WORD lFunction_TO_WORD;
                          LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                          lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                          lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__AOPD_Free, pEPDB);
                          LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else
        {
          ;
        }
      }
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_TO_WORD lFunction__leftOp_TO_WORD__IN_AND__IN2_TO_WORD;
      LC_TD_Function_AND__WORD lFunction__leftOp_TO_WORD__IN_AND;
      LC_TD_Function_TO_WORD lFunction__leftOp_TO_WORD;
      LC_TD_Function_TO_WORD lFunction__rightOp_TO_WORD;
      LC_INIT_Function_TO_WORD(&lFunction__leftOp_TO_WORD__IN_AND__IN2_TO_WORD);
      LC_INIT_Function_AND__WORD(&lFunction__leftOp_TO_WORD__IN_AND);
      LC_INIT_Function_TO_WORD(&lFunction__leftOp_TO_WORD);
      LC_INIT_Function_TO_WORD(&lFunction__rightOp_TO_WORD);
      lFunction__leftOp_TO_WORD__IN_AND__IN2_TO_WORD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_WORD__UINT(&lFunction__leftOp_TO_WORD__IN_AND__IN2_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Error_Muting_Sequence_Base, pEPDB);
      lFunction__leftOp_TO_WORD__IN_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__ANY__2(&lFunction__leftOp_TO_WORD__IN_AND, LC_this->LC_VD_DIAGCODE, lFunction__leftOp_TO_WORD__IN_AND__IN2_TO_WORD.LC_VD_TO_WORD, pEPDB);
      lFunction__leftOp_TO_WORD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_WORD__WORD(&lFunction__leftOp_TO_WORD, lFunction__leftOp_TO_WORD__IN_AND.LC_VD_AND, pEPDB);
      lFunction__rightOp_TO_WORD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_WORD__UINT(&lFunction__rightOp_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Error_Muting_Sequence_Base, pEPDB);
      conditionResult = (LC_TD_BOOL)(lFunction__leftOp_TO_WORD.LC_VD_TO_WORD == lFunction__rightOp_TO_WORD.LC_VD_TO_WORD);
    }
    if (conditionResult)
    {
      LC_VD_CONTROLCODE = LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Error_Muting_Sequence_Base;
    }
    else
    {
      ;
      {
        LC_TD_Function_TO_UINT lFunction_TO_UINT;
        LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
        lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
        LC_VD_CONTROLCODE = lFunction_TO_UINT.LC_VD_TO_UINT;
      }
    }
  }
  {
    LC_TD_UINT caseSelector;
    {
      LC_TD_Function_TO_UINT lFunction_TO_UINT;
      LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
      lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UINT__UINT(&lFunction_TO_UINT, LC_VD_CONTROLCODE, pEPDB);
      caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
    }
    if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Idle))
    {
      {
        LC_this->LC_VD_MUTINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MUTINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_false;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_S_MUTINGACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Init))
    {
      {
        LC_this->LC_VD_MUTINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MUTINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_S_MUTINGACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Reset_Error_1)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Reset_Error_2)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Muting_Sequence_Base)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Parameter_Error)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Error_Timer_MaxMuting))
    {
      {
        LC_this->LC_VD_MUTINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MUTINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_S_MUTINGACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__AOPD_Free))
    {
      {
        LC_this->LC_VD_MUTINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MUTINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_true;
      LC_this->LC_VD_S_MUTINGACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Safety_Demand_AOPD))
    {
      {
        LC_this->LC_VD_MUTINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MUTINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_S_MUTINGACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_true;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Wait_for_Reset))
    {
      {
        LC_this->LC_VD_MUTINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MUTINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_S_MUTINGACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Safe))
    {
      {
        LC_this->LC_VD_MUTINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MUTINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_S_MUTINGACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Muting_Forward_Start))
    {
      {
        LC_this->LC_VD_MUTINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MUTINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_true;
      LC_this->LC_VD_S_MUTINGACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Muting_Forward_Active))
    {
      {
        LC_this->LC_VD_MUTINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_IN = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_PT = LC_this->LC_VD_MAXMUTINGTIME;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MUTINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_true;
      LC_this->LC_VD_S_MUTINGACTIVE = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Muting_Backward_Start))
    {
      {
        LC_this->LC_VD_MUTINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_IN = LC_EL_false;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MUTINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_true;
      LC_this->LC_VD_S_MUTINGACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_MutingSeq_State__Muting_Backward_Active))
    {
      {
        LC_this->LC_VD_MUTINGTIMER.LC_VD_ENO = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_IN = LC_EL_true;
        LC_this->LC_VD_MUTINGTIMER.LC_VD_PT = LC_this->LC_VD_MAXMUTINGTIME;
        lcfu_iec61131__TON(&(LC_this->LC_VD_MUTINGTIMER), pEPDB);
      }
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_true;
      LC_this->LC_VD_S_MUTINGACTIVE = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else
    {
      LC_this->LC_VD_ENO = LC_EL_false;
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_AOPD_OUT = LC_EL_false;
      LC_this->LC_VD_S_MUTINGACTIVE = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
  }
  LC_this->LC_VD_ENO = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_ENO,LC_this->LC_VD_S_AOPD_IN)),LC_this->LC_VD_S_STARTRESET));
}

#endif
