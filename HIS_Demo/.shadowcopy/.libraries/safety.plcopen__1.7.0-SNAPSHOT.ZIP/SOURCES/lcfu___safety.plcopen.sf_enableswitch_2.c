#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2__C

#include <lcfu___safety.plcopen.sf_enableswitch_2.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2* p = LC_this; \
  (p)->LC_VD_ACTIVATE = LC_EL_false; \
  (p)->LC_VD_S_SAFETYACTIVE = LC_EL_false; \
  (p)->LC_VD_S_ENABLEIN = LC_EL_false; \
  (p)->LC_VD_RESET = LC_EL_false; \
  (p)->LC_VD_READY = LC_EL_false; \
  (p)->LC_VD_S_ENABLESWITCHOUT = LC_EL_false; \
  (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  (p)->LC_VD_ERROR = LC_EL_false; \
  (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_RESET)); \
}

void LC_WINIT_FUN_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2* p = LC_this; \
  if (RF==0) (p)->LC_VD_ACTIVATE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_SAFETYACTIVE = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_ENABLEIN = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESET = LC_EL_false; \
  if (RF==0) (p)->LC_VD_READY = LC_EL_false; \
  if (RF==0) (p)->LC_VD_S_ENABLESWITCHOUT = LC_EL_false; \
  if (RF==0) (p)->LC_VD_SAFETYDEMAND = LC_EL_false; \
  if (RF==0) (p)->LC_VD_RESETREQUEST = LC_EL_false; \
  if (RF==0) (p)->LC_VD_ERROR = LC_EL_false; \
  if (RF==0) (p)->LC_VD_DIAGCODE = (LC_TD_WORD)0; \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_RESET),0); \
}

void  lcfu___SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2(LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_R_TRIG_RESET.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_R_TRIG_RESET.LC_VD_CLK = LC_this->LC_VD_RESET;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG_RESET), pEPDB);
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ACTIVATE));
    if (conditionResult)
    {
      {
        LC_TD_Function_TO_WORD lFunction_TO_WORD;
        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Idle, pEPDB);
        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
      }
    }
    else
    {
      {
        LC_TD_UINT caseSelector;
        {
          LC_TD_Function_TO_UINT lFunction_TO_UINT;
          LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
          lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
          lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
          caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
        }
        if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Idle))
        {
          {
            LC_TD_Function_TO_WORD lFunction_TO_WORD;
            LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
            lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
            lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Basic_Operation_Mode, pEPDB);
            LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Basic_Operation_Mode))
        {
          if (LC_this->LC_VD_S_SAFETYACTIVE)
          {
            {
              LC_TD_Function_TO_WORD lFunction_TO_WORD;
              LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
              lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
              lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Safe_Operation_Mode, pEPDB);
              LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Safe_Operation_Mode))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_SAFETYACTIVE));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Basic_Operation_Mode, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              if (LC_this->LC_VD_S_ENABLEIN)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Operation_Error_1_EnableIn, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
              else
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Not_Enabled, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Operation_Error_1_EnableIn)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Operation_Error_1_Not_EnableIn))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_SAFETYACTIVE));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Basic_Operation_Mode, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_RESET,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_R_TRIG_RESET.LC_VD_Q))));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Reset_Error_1, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
                else
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_ENABLEIN)),LC_this->LC_VD_R_TRIG_RESET.LC_VD_Q));
                    if (conditionResult)
                    {
                      {
                        LC_TD_Function_TO_WORD lFunction_TO_WORD;
                        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Not_Enabled, pEPDB);
                        LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                      }
                    }
                    else
                    {
                      if (LC_this->LC_VD_S_ENABLEIN)
                      {
                        {
                          LC_TD_Function_TO_WORD lFunction_TO_WORD;
                          LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                          lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                          lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Operation_Error_1_EnableIn, pEPDB);
                          LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                        }
                      }
                      else
                      {
                        {
                          LC_TD_Function_TO_WORD lFunction_TO_WORD;
                          LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                          lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                          lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Operation_Error_1_Not_EnableIn, pEPDB);
                          LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Reset_Error_1))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_SAFETYACTIVE));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Basic_Operation_Mode, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
                if (conditionResult)
                {
                  if (LC_this->LC_VD_S_ENABLEIN)
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Operation_Error_1_EnableIn, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                  else
                  {
                    {
                      LC_TD_Function_TO_WORD lFunction_TO_WORD;
                      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                      lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Operation_Error_1_Not_EnableIn, pEPDB);
                      LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                    }
                  }
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Not_Enabled))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_SAFETYACTIVE));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Basic_Operation_Mode, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              if (LC_this->LC_VD_S_ENABLEIN)
              {
                {
                  LC_TD_Function_TO_WORD lFunction_TO_WORD;
                  LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                  lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                  lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Enabled, pEPDB);
                  LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                }
              }
            }
          }
        }
        else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Enabled))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_SAFETYACTIVE));
            if (conditionResult)
            {
              {
                LC_TD_Function_TO_WORD lFunction_TO_WORD;
                LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Basic_Operation_Mode, pEPDB);
                LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
              }
            }
            else
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_S_ENABLEIN));
                if (conditionResult)
                {
                  {
                    LC_TD_Function_TO_WORD lFunction_TO_WORD;
                    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
                    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
                    lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Not_Enabled, pEPDB);
                    LC_this->LC_VD_DIAGCODE = lFunction_TO_WORD.LC_VD_TO_WORD;
                  }
                }
              }
            }
          }
        }
        else
        {
          ;
        }
      }
    }
  }
  {
    LC_TD_UINT caseSelector;
    {
      LC_TD_Function_TO_UINT lFunction_TO_UINT;
      LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
      lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UINT__WORD(&lFunction_TO_UINT, LC_this->LC_VD_DIAGCODE, pEPDB);
      caseSelector = lFunction_TO_UINT.LC_VD_TO_UINT;
    }
    if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Idle))
    {
      LC_this->LC_VD_READY = LC_EL_false;
      LC_this->LC_VD_S_ENABLESWITCHOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Basic_Operation_Mode)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Safe_Operation_Mode))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_ENABLESWITCHOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Not_Enabled))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_ENABLESWITCHOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_true;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Enabled))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_ENABLESWITCHOUT = LC_EL_true;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_false;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Reset_Error_1)||(caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Operation_Error_1_EnableIn))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_ENABLESWITCHOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else if ((caseSelector==LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Operation_Error_1_Not_EnableIn))
    {
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_ENABLESWITCHOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_ENO = LC_EL_false;
      LC_this->LC_VD_READY = LC_EL_true;
      LC_this->LC_VD_S_ENABLESWITCHOUT = LC_EL_false;
      LC_this->LC_VD_SAFETYDEMAND = LC_EL_false;
      LC_this->LC_VD_RESETREQUEST = LC_EL_false;
      LC_this->LC_VD_ERROR = LC_EL_true;
    }
  }
}

#endif
