#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT__C

#include <lcfu___safety.plcopen.sf_modeselector_geterroropencircuit.h>

/*                            Functions                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT(LC_TD_Function_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_GETERROROPENCIRCUIT* LC_this, LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE LC_VD_MODESTATE, struct _lcoplck_epdb_1_impl* pEPDB)
{
  if ((LC_TD_BOOL)(LC_VD_MODESTATE == LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__Only_One_S_ModeX))
  {
    LC_this->LC_VD_SF_MODESELECTOR_GETERROROPENCIRCUIT = LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Open_Circuit_Fixed;
  }
  else
  {
    LC_this->LC_VD_SF_MODESELECTOR_GETERROROPENCIRCUIT = LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Open_Circuit;
  }
}

#endif
