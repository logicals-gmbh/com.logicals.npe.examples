/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTU_UDINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTU_UDINT__C
#define LC_PROT_LCFU_IEC61131__CTU_UDINT__C

#include <lcfu_iec61131__CTU_UDINT.h>

/*                            FunctionBlocks                   */
void lcfu_iec61131__CTU_UDINT(LC_TD_FunctionBlock_CTU_UDINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  _lcfu_iec61131__CTU_ANY(LC_this, UDINT, LC_IDP_PVmax_UDINT)
}
#endif
