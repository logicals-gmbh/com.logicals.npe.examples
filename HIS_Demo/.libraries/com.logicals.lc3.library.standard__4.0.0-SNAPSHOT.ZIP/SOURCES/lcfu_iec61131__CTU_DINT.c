/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTU_DINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTU_DINT__C
#define LC_PROT_LCFU_IEC61131__CTU_DINT__C

#include <lcfu_iec61131__CTU_DINT.h>

/*                            FunctionBlocks                   */
void lcfu_iec61131__CTU_DINT(LC_TD_FunctionBlock_CTU_DINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  _lcfu_iec61131__CTU_ANY(LC_this, DINT, LC_IDP_PVmax_DINT)
}
#endif
