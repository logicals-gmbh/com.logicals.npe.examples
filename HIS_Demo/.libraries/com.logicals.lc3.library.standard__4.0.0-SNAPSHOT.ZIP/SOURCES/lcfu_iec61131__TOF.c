/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block TOF for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__TOF__C
#define LC_PROT_LCFU_IEC61131__TOF__C

#include <lcfu_iec61131__TOF.h>
#include <RTAPITimer.h>
#if NPE_HIS_CHANNEL2
#include <LC3CGAnyBitOp.h>
#endif

/*                            FunctionBlocks                   */
void  lcfu_iec61131__TOF(LC_TD_FunctionBlock_TOF* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
#if !NPE_HIS_CHANNEL2
 if (LC_this->LC_VD_IN)
 {
   /* Reset instance data */
   LC_this->LC_VD_M=LC_EL_true;
   LC_this->LC_VD_Q=LC_EL_true;
   LC_MF_RESET_TIME(LC_this->LC_VD_ET);
 }
 else
 {
   /* Detect Falling Trigger */
   if (LC_this->LC_VD_M)
   {
     LC_this->LC_VD_M=LC_EL_false;
     /* Start Timer */
     LC_this->LC_VD_STARTT=LC_MF_CURRENT_TIME_API;
   }

   /* If timer is running */
   if (LC_this->LC_VD_Q)
   {
     /* Calc Time */
     LC_this->LC_VD_ET=LC_MF_NUMERIC_SUB(LC_TD_TIME,LC_MF_CURRENT_TIME_API,LC_this->LC_VD_STARTT);
     /* Check if Timer has reached it's limit */
     if (LC_MF_COMPARE_GE(LC_TD_TIME,LC_this->LC_VD_ET,LC_this->LC_VD_PT))
     {
       /* Reset Outputs */
       LC_this->LC_VD_Q=LC_EL_false;
       LC_this->LC_VD_ET=LC_this->LC_VD_PT;
     }
   }
 }
#else
  if (LC_MF_COMPARE_EQ(LC_TD_BOOL, LC_this->LC_VD_IN, LC_EL_false))
  {
    /* Detect Falling Trigger */
    if (LC_MF_COMPARE_EQ(LC_TD_BOOL, LC_this->LC_VD_M, LC_EL_true))
    {
      LC_this->LC_VD_M=LC_EL_false;
      /* Start Timer */
      LC_this->LC_VD_STARTT=LC_MF_CURRENT_TIME_API;
    }

    /* If timer is running */
    if (LC_MF_COMPARE_EQ(LC_TD_BOOL, LC_this->LC_VD_Q, LC_EL_true))
    {
      /* Calc Time */
      LC_this->LC_VD_ET=LC_MF_NUMERIC_SUB(LC_TD_TIME,LC_MF_CURRENT_TIME_API,LC_this->LC_VD_STARTT);
      /* Check if Timer has reached it's limit */
      if (LC_MF_COMPARE_GE(LC_TD_TIME,LC_this->LC_VD_ET,LC_this->LC_VD_PT))
      {
        /* Reset Outputs */
        LC_this->LC_VD_Q=LC_EL_false;
        LC_this->LC_VD_ET=LC_this->LC_VD_PT;
      }
    }
  }
  else
  {
    /* Reset instance data */
    LC_this->LC_VD_M=LC_EL_true;
    LC_this->LC_VD_Q=LC_EL_true;
    LC_MF_RESET_TIME(LC_this->LC_VD_ET);
  }
#endif
}

#endif
