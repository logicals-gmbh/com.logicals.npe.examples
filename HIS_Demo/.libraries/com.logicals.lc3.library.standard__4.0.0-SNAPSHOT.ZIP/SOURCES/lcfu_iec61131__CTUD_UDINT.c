/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTUD_UDINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTUD_UDINT__C
#define LC_PROT_LCFU_IEC61131__CTUD_UDINT__C

#include <lcfu_iec61131__CTUD_UDINT.h>

/*                            FunctionBlocks                   */
void lcfu_iec61131__CTUD_UDINT(LC_TD_FunctionBlock_CTUD_UDINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  _lcfu_iec61131__CTUD_ANY(LC_this, UDINT, LC_IDP_PVmax_UDINT, LC_IDP_PVmin_UDINT)
}
#endif
