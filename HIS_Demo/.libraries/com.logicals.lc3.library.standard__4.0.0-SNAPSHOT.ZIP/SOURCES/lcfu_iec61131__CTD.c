/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTD for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTD__C
#define LC_PROT_LCFU_IEC61131__CTD__C

#include <lcfu_iec61131__CTD.h>

/*                            FunctionBlocks                   */
void lcfu_iec61131__CTD(LC_TD_FunctionBlock_CTD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  _lcfu_iec61131__CTD_ANY(LC_this, INT, LC_IDP_PVmin_INT)
}
#endif
