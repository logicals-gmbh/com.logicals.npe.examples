#ifndef LC_PROT_LCFU_IEC61131__CLEAREXCEPTIONSTATUS__C
#define LC_PROT_LCFU_IEC61131__CLEAREXCEPTIONSTATUS__C

#include <lcfu_iec61131__CLEAREXCEPTIONSTATUS.h>
#include "LC3CgError.h"

/*                            Functions                        */
void  lcfu_iec61131__CLEAREXCEPTIONSTATUS(LC_TD_Function_CLEAREXCEPTIONSTATUS* LC_this, LC_TD_DataType_SAFEBOOL LC_VD_CMDCLEAREXCEPTION, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Vendor Code */
  if (LC_VD_CMDCLEAREXCEPTION == LC_EL_true)
	{
		LC3CGERR_ResetErrorInformation(pEPDB);
	}
}

#endif
