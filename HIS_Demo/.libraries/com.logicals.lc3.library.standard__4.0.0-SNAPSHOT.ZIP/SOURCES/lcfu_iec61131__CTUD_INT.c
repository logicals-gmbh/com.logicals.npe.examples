/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTUD_INT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTUD_INT__C
#define LC_PROT_LCFU_IEC61131__CTUD_INT__C

#include <lcfu_iec61131__CTUD_INT.h>

/*                            FunctionBlocks                   */
void lcfu_iec61131__CTUD_INT(LC_TD_FunctionBlock_CTUD_INT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  _lcfu_iec61131__CTUD_ANY(LC_this, INT, LC_IDP_PVmax_INT, LC_IDP_PVmin_INT)
}
#endif
