/* Copyright (C) logi.cals GmbH. All rights reserved. */

#ifndef LC_PROT_LCFU_IEC61131__EXPT_C
#define LC_PROT_LCFU_IEC61131__EXPT_C


#include <lcfu_iec61131__EXPT.h>

#if !NPE_HIS_CHANNEL2
#define LC_MF_EXPT_SINTEGER_CALC LC_MF_EXPT_SINTEGER_IMPL
#define LC_MF_EXPT_UINTEGER_CALC LC_MF_EXPT_UINTEGER_IMPL
#define LC_EXPT_CALC_SCOPE
#define LC_EXPT_ERROR_PARAMETER
#define LC_EXPT_SET_ERROR(errorId) \
  LC3CGERR_SetErrorInformationFunc(LC_This, pENO, pEPDB, errorId, dbgFile, dbgLine, dbgFunction)
#else
#define LC_EXPT_CALC_SCOPE static
#define LC_EXPT_ERROR_PARAMETER , volatile LC3CGERR_ErrorIds *calculationError
/* Defer reporting until the independent check has verified this error as well. */
#define LC_EXPT_SET_ERROR(errorId) \
  do { *calculationError = (errorId); *pENO = LC_EL_false; } while (0)
#endif

#if 1
#define LC_EXPT_TRACELINE(line)
#else
#include <LC3RTLibSpecial.h>
#include <RTSTrace.h>
#define LC_EXPT_TRACELINE(line)        RT_TRACE(printf("%s(%d): MSG\n",__FILE__,line));
#endif

/*
 ** recursive function to calculate base**exp, method is divide and conquer
 ** returns 0 on overflow (over ulonglong max)
 ** does not handle singed values!
 */
static lc_uint64_t integerPow(lc_uint64_t base, lc_uint32_t exp)
{
  lc_uint64_t a;
  if (exp == 1)
  {
    LC_EXPT_TRACELINE(1)
    return base;
  }
  a = integerPow(base, exp / 2);
  if (a == 0)
  {
    LC_EXPT_TRACELINE(2)
    return 0;
  }
  if (a >= LC_UINT64_MAX / a)
  {
    LC_EXPT_TRACELINE(3)
    return 0;
  }
  a *= a;

  if (exp % 2 == 0)
  {
    LC_EXPT_TRACELINE(4);
    return a;
  }
  if (a >= LC_UINT64_MAX / base)
  {
    LC_EXPT_TRACELINE(5)
    return 0;
  }

  LC_EXPT_TRACELINE(6)
  return a * base;
}

/*
 ** impl for a**b for signed values, range up to maxval
 */
LC_EXPT_CALC_SCOPE lc_int64_t LC_MF_EXPT_SINTEGER_CALC(lc_uint64_t maxval, lc_int64_t in1, lc_int64_t in2, LC_TD_BOOL *pENO, void const * LC_This, struct _lcoplck_epdb_1_impl* pEPDB, char const * dbgFile, unsigned int dbgLine, char const * dbgFunction LC_EXPT_ERROR_PARAMETER)
{
  lc_uint64_t underflowMaxVal = maxval / 2 + 1;
  lc_uint64_t overflowMaxVal = maxval / 2;
  lc_uint8_t isNeg = 0;
  LC_TD_BOOL localEno;
  lc_uint64_t result;

  if (pENO == NULL)
  {
    /* not reachable if called correctly with pENO!=NULL */
    LC_EXPT_TRACELINE(-1)
    pENO = &localEno;
  }

  if ((in2 == 0) || (in1 == 1))
  {
    LC_EXPT_TRACELINE(13)
    return 1;
  }
  if (in1 == -1)
  {
    if (in2 % 2 == 0)
    {
      LC_EXPT_TRACELINE(14)
      return 1;
    }
    LC_EXPT_TRACELINE(15)
    return -1;
  }
  if (in1 == 0)
  {
    if (in2 > 0)
    {
      LC_EXPT_TRACELINE(16)
      return 0;
    }

    LC_EXPT_SET_ERROR(LC3CGERR_ErrorId_EXPT_SINTEGER_IN1_0_INV_IN2);

    LC_EXPT_TRACELINE(17)
    return overflowMaxVal;
  }
  if (in2 < 0)
  {
    LC_EXPT_TRACELINE(18)
    return 0;
  }
  if (in2 == 1)
  {
    LC_EXPT_TRACELINE(19)
    return in1;
  }

  if ((lc_uint64_t) in1 == underflowMaxVal)
  {
    LC_EXPT_TRACELINE(10)
    LC_EXPT_SET_ERROR(LC3CGERR_ErrorId_EXPT_SINTEGER_IN1_UNDERFLOW_MAX);
    return in1;
  }

  if (in1 < 0)
  {
    if (in2 % 2 != 0)
    {
      isNeg = 1;
    }
    in1 = -in1;
  }

  /* 2**64 is not more possible. so max exponent is 63 */
  if (in2 >= 64)
  {
    LC_EXPT_SET_ERROR(LC3CGERR_ErrorId_EXPT_SINTEGER_IN2_GE_64);
    if (!isNeg)
    {
      LC_EXPT_TRACELINE(11)
      return overflowMaxVal;
    }
    /* special handling for long-long-min necessary. - else compilers change it to 0 */
    if (maxval == LC_UINT64_MAX)
    {
      LC_EXPT_TRACELINE(12)
      return LC_INT64_MIN;
    }
    LC_EXPT_TRACELINE(20)
    /* underflowmaxval is 2**31 or 2**15, ... (64bit handled above) */
    return -(lc_int64_t) underflowMaxVal;
  }

  result = integerPow((lc_uint64_t) in1, (lc_uint32_t) in2);

  if (isNeg && (result > underflowMaxVal || result == 0))
  {
    LC_EXPT_SET_ERROR(LC3CGERR_ErrorId_EXPT_SINTEGER_LT_UNDERFLOW_MIN);
    /* special handling for long-long-min necessary. - else compilers change it to 0 */
    if (maxval == LC_UINT64_MAX)
    {
      LC_EXPT_TRACELINE(21)
      return LC_INT64_MIN;
    }
    LC_EXPT_TRACELINE(22)
    /* underflowmaxval is 2**31 or 2**15, ... (64bit handled above) */
    return -(lc_int64_t) underflowMaxVal;
  }

  if ((!isNeg) && (result > overflowMaxVal || result == 0))
  {
    LC_EXPT_TRACELINE(23)
    LC_EXPT_SET_ERROR(LC3CGERR_ErrorId_EXPT_SINTEGER_GE_OVERFLOW_MAX);
    return overflowMaxVal;
  }

  if (isNeg)
  {
    LC_EXPT_TRACELINE(24)
    /* The valid negative limit must not be cast to signed and then negated. */
    if (result == (lc_uint64_t)LC_INT64_MAX + 1u)
    {
      return LC_INT64_MIN;
    }
    return -(lc_int64_t)result;
  }

  LC_EXPT_TRACELINE(25)
  return result;
}

/*
 ** impl for a**b for unsigned values, range up to maxval
 */
LC_EXPT_CALC_SCOPE lc_uint64_t LC_MF_EXPT_UINTEGER_CALC(lc_uint64_t maxval, lc_uint64_t in1, lc_uint64_t in2, LC_TD_BOOL *pENO, void const * LC_This, struct _lcoplck_epdb_1_impl* pEPDB, char const * dbgFile, unsigned int dbgLine, char const * dbgFunction LC_EXPT_ERROR_PARAMETER)
{
  LC_TD_BOOL localEno;
  lc_uint64_t result;

  if (pENO == NULL)
  {
    /* not reachable if called correctly with pENO!=NULL */
    LC_EXPT_TRACELINE(-1)
    pENO = &localEno;
  }

  if ((in2 == 0) || (in1 == 1))
  {
    LC_EXPT_TRACELINE(31)
    return 1;
  }
  if (in1 == 0)
  {
    LC_EXPT_TRACELINE(32)
    return 0;
  }
  if (in2 == 1)
  {
    LC_EXPT_TRACELINE(33)
    return in1;
  }

  /* 2**64 is not more possible. so max exponent is 63 */
  if (in2 >= 64)
  {
    LC_EXPT_TRACELINE(34)
    LC_EXPT_SET_ERROR(LC3CGERR_ErrorId_EXPT_UINTEGER_IN2_GE_64);
    return maxval;
  }
  result = integerPow(in1, (lc_uint32_t) in2);

  if (result > maxval || result == 0)
  {
    LC_EXPT_TRACELINE(35)
    LC_EXPT_SET_ERROR(LC3CGERR_ErrorId_EXPT_UINTEGER_OVERFLOW);
    return maxval;
  }

  LC_EXPT_TRACELINE(36)
  return result;
}

#if NPE_HIS_CHANNEL2
/* Unsigned subtraction also handles LINT_MIN without signed negation. */
static lc_uint64_t LC_EXPT_MAGNITUDE(lc_int64_t value)
{
  return value < 0 ? (lc_uint64_t)0 - (lc_uint64_t)value : (lc_uint64_t)value;
}

/* Preconditions: base >= 2, exponent >= 2, limit is the IEC magnitude limit.
** Repeated division verifies both the power and its range, independently of
** integerPow's recursive multiplications. Each remainder must be zero.
** The bound reaches zero after at most 64 steps, even for huge exponents.
*/
static int LC_EXPT_VERIFY_POWER(lc_uint64_t base, lc_uint64_t exponent,
                               lc_uint64_t result, lc_uint64_t limit, int *overflow)
{
  lc_uint64_t quotient = result;
  lc_uint64_t bound = limit;
  int exact = 1;
  while (exponent != 0 && bound != 0)
  {
    if (quotient % base != 0)
    {
      exact = 0;
    }
    quotient /= base;
    bound /= base;
    --exponent;
  }
  *overflow = (bound == 0);
  return *overflow || (exact && quotient == 1 && result <= limit);
}

static int LC_EXPT_VERIFY_SINTEGER(lc_uint64_t maxval, lc_int64_t in1, lc_int64_t in2,
                                  lc_int64_t result, LC3CGERR_ErrorIds error, LC_TD_BOOL eno)
{
  LC3CGERR_ErrorIds expectedError = LC3CGERR_ErrorId_NO_ERROR;
  lc_int64_t expectedResult;
  lc_uint64_t positiveLimit = maxval >> 1;
  lc_uint64_t negativeLimit = positiveLimit + 1u;
  int valid = 1;

  /* Deliberately classify by exponent first, unlike the calculation path. */
  if (in2 <= 0)
  {
    expectedResult = in2 == 0 || in1 == 1 ? 1 : 0;
    if (in2 != 0 && in1 == -1)
    {
      expectedResult = ((lc_uint64_t)in2 & 1u) ? -1 : 1;
    }
    else if (in2 != 0 && in1 == 0)
    {
      expectedResult = (lc_int64_t)positiveLimit;
      expectedError = LC3CGERR_ErrorId_EXPT_SINTEGER_IN1_0_INV_IN2;
    }
    valid = result == expectedResult;
  }
  else if (in2 == 1 || (in1 >= -1 && in1 <= 1))
  {
    expectedResult = in1 == -1 && !((lc_uint64_t)in2 & 1u) ? 1 : in1;
    valid = result == expectedResult;
  }
  else
  {
    int negative = in1 < 0 && ((lc_uint64_t)in2 & 1u);
    int overflow;
    lc_uint64_t limit = negative ? negativeLimit : positiveLimit;
    valid = LC_EXPT_VERIFY_POWER(LC_EXPT_MAGNITUDE(in1), (lc_uint64_t)in2,
                                 LC_EXPT_MAGNITUDE(result), limit, &overflow);
    if (overflow)
    {
      if (in1 == LC_INT64_MIN && maxval == LC_UINT64_MAX)
      {
        /* Preserve the existing LINT_MIN shortcut, also for even exponents. */
        expectedError = LC3CGERR_ErrorId_EXPT_SINTEGER_IN1_UNDERFLOW_MAX;
        expectedResult = LC_INT64_MIN;
      }
      else
      {
        expectedError = in2 >= 64 ? LC3CGERR_ErrorId_EXPT_SINTEGER_IN2_GE_64
          : (negative ? LC3CGERR_ErrorId_EXPT_SINTEGER_LT_UNDERFLOW_MIN
                      : LC3CGERR_ErrorId_EXPT_SINTEGER_GE_OVERFLOW_MAX);
        expectedResult = negative ? -(lc_int64_t)positiveLimit - 1 : (lc_int64_t)positiveLimit;
      }
      valid = valid && result == expectedResult;
    }
    else
    {
      valid = valid && ((result < 0) == negative);
    }
  }
  return valid && error == expectedError &&
    eno == (expectedError == LC3CGERR_ErrorId_NO_ERROR ? LC_EL_true : LC_EL_false);
}

static int LC_EXPT_VERIFY_UINTEGER(lc_uint64_t maxval, lc_uint64_t in1, lc_uint64_t in2,
                                  lc_uint64_t result, LC3CGERR_ErrorIds error, LC_TD_BOOL eno)
{
  LC3CGERR_ErrorIds expectedError = LC3CGERR_ErrorId_NO_ERROR;
  int valid;
  if (in2 <= 1)
  {
    valid = result == (in2 == 0 ? 1u : in1);
  }
  else if (in1 <= 1)
  {
    valid = result == in1;
  }
  else
  {
    int overflow;
    valid = LC_EXPT_VERIFY_POWER(in1, in2, result, maxval, &overflow);
    if (overflow)
    {
      expectedError = in2 >= 64 ? LC3CGERR_ErrorId_EXPT_UINTEGER_IN2_GE_64
                              : LC3CGERR_ErrorId_EXPT_UINTEGER_OVERFLOW;
      valid = valid && result == maxval;
    }
  }
  return valid && error == expectedError &&
    eno == (expectedError == LC3CGERR_ErrorId_NO_ERROR ? LC_EL_true : LC_EL_false);
}

lc_int64_t LC_MF_EXPT_SINTEGER_IMPL(lc_uint64_t maxval, lc_int64_t in1, lc_int64_t in2, LC_TD_BOOL *pENO, void const * LC_This, struct _lcoplck_epdb_1_impl* pEPDB, char const * dbgFile, unsigned int dbgLine, char const * dbgFunction)
{
  LC_TD_BOOL calculationEno = LC_EL_true;
  volatile LC3CGERR_ErrorIds calculationError = LC3CGERR_ErrorId_NO_ERROR;
  volatile lc_int64_t result = LC_MF_EXPT_SINTEGER_CALC(maxval, in1, in2, &calculationEno,
    LC_This, pEPDB, dbgFile, dbgLine, dbgFunction, &calculationError);
  /* Materialize the observations so optimization cannot remove verification. */
  volatile LC_TD_BOOL observedEno = calculationEno;
  LC3CGERR_ErrorIds error = calculationError;
  lc_int64_t observedResult = result;
  if (!LC_EXPT_VERIFY_SINTEGER(maxval, in1, in2, observedResult, error, observedEno))
  {
    error = LC3CGERR_ErrorId_HIS_VERIFY_EXPT_FAILED;
  }
  if (error != LC3CGERR_ErrorId_NO_ERROR)
  {
    LC3CGERR_SetErrorInformationFunc(LC_This, pENO, pEPDB, error, dbgFile, dbgLine, dbgFunction);
  }
  return observedResult;
}

lc_uint64_t LC_MF_EXPT_UINTEGER_IMPL(lc_uint64_t maxval, lc_uint64_t in1, lc_uint64_t in2, LC_TD_BOOL *pENO, void const * LC_This, struct _lcoplck_epdb_1_impl* pEPDB, char const * dbgFile, unsigned int dbgLine, char const * dbgFunction)
{
  LC_TD_BOOL calculationEno = LC_EL_true;
  volatile LC3CGERR_ErrorIds calculationError = LC3CGERR_ErrorId_NO_ERROR;
  volatile lc_uint64_t result = LC_MF_EXPT_UINTEGER_CALC(maxval, in1, in2, &calculationEno,
    LC_This, pEPDB, dbgFile, dbgLine, dbgFunction, &calculationError);
  volatile LC_TD_BOOL observedEno = calculationEno;
  LC3CGERR_ErrorIds error = calculationError;
  lc_uint64_t observedResult = result;
  if (!LC_EXPT_VERIFY_UINTEGER(maxval, in1, in2, observedResult, error, observedEno))
  {
    error = LC3CGERR_ErrorId_HIS_VERIFY_EXPT_FAILED;
  }
  if (error != LC3CGERR_ErrorId_NO_ERROR)
  {
    LC3CGERR_SetErrorInformationFunc(LC_This, pENO, pEPDB, error, dbgFile, dbgLine, dbgFunction);
  }
  return observedResult;
}
#endif

/*
  ul2Exp32 : ULINT := UDINT#MAX;
  EXPT(ul2Exp32, 8); // 1,4,3,2
  EXPT(2, 3); // 1,6
  EXPT(ULINT#2642246, 3); // 1,5
  EXPT(LINT#MIN, 3); // 10
  EXPT(SINT#2, 64); // 11
  EXPT(LINT#-2, 101); // 12
  EXPT(USINT#2, 10); // 20
  EXPT(INT#2, 0); // 13
  EXPT(INT#1, 8); // 13
  EXPT(-1, 2); // 14
  EXPT(-1, 3); // 15
  EXPT(INT#0, 4); // 16
  EXPT(0, -2); // 17
  EXPT(3, -3); // 18
  EXPT(SINT#7, 1); // 19
  EXPT(-3, 65); // 20

  EXPT(LINT#-2642246, 3); // 21
  EXPT(SINT#-2,11); // 22
  EXPT(SINT#2,10); // 23
  EXPT(INT#-2,3);  // 24
  EXPT(INT#2,4); // 25

  EXPT(UINT#2,0); // 31
  EXPT(UINT#1,8); // 31	
  EXPT(UINT#0,2);  // 32
  EXPT(UINT#4,1);  // 33
  EXPT(UINT#2,64);  // 34
  EXPT(USINT#2,14);  // 35	
*/

/* POU C files share a translation unit: keep implementation macros local.
** Retain the include guard and the public interface macros from EXPT.h.
*/
#undef LC_MF_EXPT_SINTEGER_CALC
#undef LC_MF_EXPT_UINTEGER_CALC
#undef LC_EXPT_CALC_SCOPE
#undef LC_EXPT_ERROR_PARAMETER
#undef LC_EXPT_SET_ERROR
#undef LC_EXPT_TRACELINE

#endif
