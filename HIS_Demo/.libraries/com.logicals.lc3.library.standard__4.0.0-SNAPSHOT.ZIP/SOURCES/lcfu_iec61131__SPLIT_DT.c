/* Copyright (C) logi.cals GmbH. All rights reserved. */

#ifndef LC_PROT_LCFU_IEC61131__SPLIT_DT_C
#define LC_PROT_LCFU_IEC61131__SPLIT_DT_C

#include <lcfu_iec61131__SPLIT_DT.h>
#include <LC3RTLibStdTypes.h>

#if RT_TARGET_TIME_FREQU < 1000
#error LCOIII-147650: SPLIT_DT requires RT_TARGET_TIME_FREQU >= 1000
#endif

#if !defined(_LC_INTERN_TIME_HELPER_DECLARED)
#define _LC_INTERN_TIME_HELPER_DECLARED
/* declared in CONCAT_DT.c and SPLIT_DT.c */
struct _lc_tm {
  lc_int32_t tm_sec;
  lc_int32_t tm_min;
  lc_int32_t tm_hour;
  lc_int32_t tm_mday;
  lc_int32_t tm_mon;
  lc_int32_t tm_year;
  lc_int32_t tm_wday;
  lc_int32_t tm_yday;
  lc_int32_t tm_isdst;
};
#endif  /* _LC_INTERN_TIME_HELPER_DECLARED */

#define _lc_time_t lc_int64_t

static void _lc_gmtime(_lc_time_t time, struct _lc_tm *timep);

#if !NPE_HIS_CHANNEL2
#define LC_SPLIT_DT_CALC_SCOPE
#define LC_SPLIT_DT_ERROR_PARAMETER
#define LC_SPLIT_DT_SET_ERROR(errorId) \
  LC3CGERR_SetErrorInformationFunc(LC_this, &(LC_this->LC_VD_ENO), pEPDB, errorId, dbgFile, dbgLine, dbgFunction)
#else
#define LC_SPLIT_DT_CALC_SCOPE static
#define LC_SPLIT_DT_ERROR_PARAMETER , volatile LC3CGERR_ErrorIds *calculationError
/* Report only after the independent checker has verified the error path. */
#define LC_SPLIT_DT_SET_ERROR(errorId) \
  do { *calculationError = (errorId); LC_this->LC_VD_ENO = LC_EL_false; } while (0)
#endif

LC_SPLIT_DT_CALC_SCOPE void lcfu_iec61131__SplitDateAndTime(LC_TD_DT value, LC_TD_Function_SPLIT_DT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB, char const * dbgFile, unsigned int dbgLine, char const * dbgFunction LC_SPLIT_DT_ERROR_PARAMETER)
{
  struct _lc_tm tm;
  _lc_time_t t_in_sec;
  lc_uint64_t big_time;

  big_time = (lc_uint64_t)value / (RT_TARGET_TIME_FREQU / 1000);
  LC_this->LC_VD_MILLISECOND = (LC_TD_UINT)(big_time % 1000);
  big_time /= 1000; /* now we have time seconds in ms */

  if (big_time > 0xFFFFFFFEL)
  {
    /* value is out of range (2106-02-07-06:28:14) */
    LC_this->LC_VD_MILLISECOND = 0;

    LC_SPLIT_DT_SET_ERROR(LC3CGERR_ErrorId_SPLIT_DT_TIME_OVERFLOW);
    return;
  }

  /* NOTE: time_t ist signed, so at first cast unsigend to signed LongLong and than signed int */
  t_in_sec = (_lc_time_t)(lc_int64_t)big_time;
  _lc_gmtime(t_in_sec,&tm);

  LC_this->LC_VD_YEAR   = (LC_TD_UINT)(tm.tm_year + 1900);
  LC_this->LC_VD_MONTH  = (LC_TD_USINT)(tm.tm_mon + 1);
  LC_this->LC_VD_DAY    = (LC_TD_USINT)tm.tm_mday;
  LC_this->LC_VD_HOUR   = (LC_TD_USINT)tm.tm_hour;
  LC_this->LC_VD_MINUTE = (LC_TD_USINT)tm.tm_min;
  LC_this->LC_VD_SECOND = (LC_TD_USINT)tm.tm_sec;
}

#if NPE_HIS_CHANNEL2
/* Invert the calendar decomposition without using _lc_gmtime or its tables. */
static int LC_SPLIT_DT_VERIFY(lc_uint64_t input,
  LC_TD_Function_SPLIT_DT const volatile *result, LC3CGERR_ErrorIds error)
{
  static const lc_uint16_t daysBeforeMonth[13] = {
    0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365
  };
  lc_uint64_t ticksPerMillisecond = (lc_uint64_t)(RT_TARGET_TIME_FREQU / 1000);
  /* The legacy calculation accepts seconds through 0xFFFFFFFE, including .999. */
  lc_uint64_t firstInvalidMillisecond = (lc_uint64_t)0xFFFFFFFFUL * 1000u;
  lc_uint32_t year, month, day, hour, minute, second, millisecond;
  lc_uint32_t leap, monthLength, days;
  lc_uint64_t reconstructed, lowerTicks;
  int overflow = ticksPerMillisecond <= LC_UINT64_MAX / firstInvalidMillisecond &&
    input >= firstInvalidMillisecond * ticksPerMillisecond;

  if (overflow)
  {
    return error == LC3CGERR_ErrorId_SPLIT_DT_TIME_OVERFLOW &&
      result->LC_VD_ENO == LC_EL_false && result->LC_VD_MILLISECOND == 0 &&
      result->LC_VD_YEAR == 0 && result->LC_VD_MONTH == 0 && result->LC_VD_DAY == 0 &&
      result->LC_VD_HOUR == 0 && result->LC_VD_MINUTE == 0 && result->LC_VD_SECOND == 0;
  }
  if (error != LC3CGERR_ErrorId_NO_ERROR || result->LC_VD_ENO != LC_EL_true)
  {
    return 0;
  }

  year = result->LC_VD_YEAR;
  month = result->LC_VD_MONTH;
  day = result->LC_VD_DAY;
  hour = result->LC_VD_HOUR;
  minute = result->LC_VD_MINUTE;
  second = result->LC_VD_SECOND;
  millisecond = result->LC_VD_MILLISECOND;
  if (year < 1970u || year > 2106u || month < 1u || month > 12u ||
      hour > 23u || minute > 59u || second > 59u || millisecond > 999u)
  {
    return 0;
  }

  leap = year % 400u == 0u || (year % 100u != 0u && year % 4u == 0u);
  monthLength = daysBeforeMonth[month] - daysBeforeMonth[month - 1u] +
    (month == 2u ? leap : 0u);
  if (day < 1u || day > monthLength)
  {
    return 0;
  }

  /* 477 leap years precede 1970. Count complete years directly, without loops. */
  days = 365u * (year - 1970u) +
    (year - 1u) / 4u - (year - 1u) / 100u + (year - 1u) / 400u - 477u +
    daysBeforeMonth[month - 1u] + (month > 2u ? leap : 0u) + day - 1u;
  reconstructed = (((lc_uint64_t)days * 24u + hour) * 60u + minute) * 60u + second;
  reconstructed = reconstructed * 1000u + millisecond;
  if (reconstructed >= firstInvalidMillisecond ||
      reconstructed > LC_UINT64_MAX / ticksPerMillisecond)
  {
    return 0;
  }

  lowerTicks = reconstructed * ticksPerMillisecond;
  /* Preserve discarded sub-millisecond ticks, without overflowing the upper bound. */
  return input >= lowerTicks && input - lowerTicks < ticksPerMillisecond;
}

void lcfu_iec61131__SplitDateAndTime_HIS(LC_TD_DT value, LC_TD_Function_SPLIT_DT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB, char const * dbgFile, unsigned int dbgLine, char const * dbgFunction)
{
  LC_TD_Function_SPLIT_DT calculation;
  volatile LC_TD_Function_SPLIT_DT observed;
  volatile lc_uint64_t observedInput = (lc_uint64_t)value;
  volatile LC3CGERR_ErrorIds calculationError = LC3CGERR_ErrorId_NO_ERROR;
  LC3CGERR_ErrorIds error;

  /* Calculate privately; success must not depend on the caller's output fields or ENO. */
  LC_INIT_Function_SPLIT_DT(&calculation);
  calculation.LC_VD_ENO = LC_EL_true;
  lcfu_iec61131__SplitDateAndTime(value, &calculation, pEPDB,
    dbgFile, dbgLine, dbgFunction, &calculationError);

  /* Materialize every observation so optimization cannot remove verification. */
  observed.LC_VD_ENO = calculation.LC_VD_ENO;
  observed.LC_VD_YEAR = calculation.LC_VD_YEAR;
  observed.LC_VD_MONTH = calculation.LC_VD_MONTH;
  observed.LC_VD_DAY = calculation.LC_VD_DAY;
  observed.LC_VD_HOUR = calculation.LC_VD_HOUR;
  observed.LC_VD_MINUTE = calculation.LC_VD_MINUTE;
  observed.LC_VD_SECOND = calculation.LC_VD_SECOND;
  observed.LC_VD_MILLISECOND = calculation.LC_VD_MILLISECOND;
  error = calculationError;
  if (!LC_SPLIT_DT_VERIFY(observedInput, &observed, error))
  {
    error = LC3CGERR_ErrorId_HIS_VERIFY_SPLIT_DT_FAILED;
  }
  else if (error == LC3CGERR_ErrorId_NO_ERROR)
  {
    LC_this->LC_VD_YEAR = observed.LC_VD_YEAR;
    LC_this->LC_VD_MONTH = observed.LC_VD_MONTH;
    LC_this->LC_VD_DAY = observed.LC_VD_DAY;
    LC_this->LC_VD_HOUR = observed.LC_VD_HOUR;
    LC_this->LC_VD_MINUTE = observed.LC_VD_MINUTE;
    LC_this->LC_VD_SECOND = observed.LC_VD_SECOND;
    LC_this->LC_VD_MILLISECOND = observed.LC_VD_MILLISECOND;
  }
  else
  {
    /* The verified legacy overflow changes only MILLISECOND and ENO. */
    LC_this->LC_VD_MILLISECOND = 0;
  }
  if (error != LC3CGERR_ErrorId_NO_ERROR)
  {
    LC3CGERR_SetErrorInformationFunc(LC_this, &(LC_this->LC_VD_ENO), pEPDB,
      error, dbgFile, dbgLine, dbgFunction);
  }
}
#endif

/* the following code for a gmtime is extracted from:
** http://www.cise.ufl.edu/~cop4600/cgi-bin/lxr/http/source.cgi/lib/ansi/gmtime.c
** http://www.cise.ufl.edu/~cop4600/cgi-bin/lxr/http/source.cgi/lib/ansi/loc_time.h
** http://www.cise.ufl.edu/~cop4600/cgi-bin/lxr/http/source.cgi/lib/ansi/misc.c#L82
*/

#define YEAR0             1900            /* the first year */
#define EPOCH_YR          1970            /* EPOCH = Jan 1 1970 00:00:00 */
#define SECS_DAY          (24L * 60L * 60L)
#define LEAPYEAR(year)    (!((year) % 4) && (((year) % 100) || !((year) % 400)))
#define YEARSIZE(year)    (LEAPYEAR(year) ? 366 : 365)

static const lc_uint32_t _ytab[2][12] = {
  { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 },
  { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }
};

static void _lc_gmtime(_lc_time_t time, struct _lc_tm *timep)
{
  lc_uint32_t dayclock, dayno;
  lc_uint32_t year = EPOCH_YR;

  dayclock = (lc_uint32_t)time % SECS_DAY;
  dayno = (lc_uint32_t)time / SECS_DAY;

  timep->tm_sec = dayclock % 60;
  timep->tm_min = (dayclock % 3600) / 60;
  timep->tm_hour = dayclock / 3600;
  timep->tm_wday = (dayno + 4) % 7; /* day 0 was a thursday */
  while (dayno >= YEARSIZE(year)) {
    dayno -= YEARSIZE(year);
    year++;
  }
  timep->tm_year = year - YEAR0;
  timep->tm_yday = dayno;
  timep->tm_mon = 0;
  while (dayno >= _ytab[LEAPYEAR(year)][timep->tm_mon]) {
    dayno -= _ytab[LEAPYEAR(year)][timep->tm_mon];
    timep->tm_mon++;
  }
  timep->tm_mday = dayno + 1;
  timep->tm_isdst = 0;
}

#undef _lc_time_t
#undef LC_SPLIT_DT_CALC_SCOPE
#undef LC_SPLIT_DT_ERROR_PARAMETER
#undef LC_SPLIT_DT_SET_ERROR

#endif
