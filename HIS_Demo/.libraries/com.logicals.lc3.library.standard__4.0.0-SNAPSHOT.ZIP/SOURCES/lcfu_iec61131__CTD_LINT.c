/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTD_LINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTD_LINT__C
#define LC_PROT_LCFU_IEC61131__CTD_LINT__C

#include <lcfu_iec61131__CTD_LINT.h>

/*                            FunctionBlocks                   */
void lcfu_iec61131__CTD_LINT(LC_TD_FunctionBlock_CTD_LINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  _lcfu_iec61131__CTD_ANY(LC_this, LINT, LC_IDP_PVmin_LINT)
}
#endif
