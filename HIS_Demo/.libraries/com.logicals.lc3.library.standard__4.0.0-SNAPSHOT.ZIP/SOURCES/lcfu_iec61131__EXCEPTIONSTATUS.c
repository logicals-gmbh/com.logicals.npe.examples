#ifndef LC_PROT_LCFU_IEC61131__EXCEPTIONSTATUS__C
#define LC_PROT_LCFU_IEC61131__EXCEPTIONSTATUS__C

#include <lcfu_iec61131__EXCEPTIONSTATUS.h>

#include "LC3CgError.h"

/*                            Functions                        */
void  lcfu_iec61131__EXCEPTIONSTATUS(LC_TD_Function_EXCEPTIONSTATUS* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Vendor Code */
  LC3CGERR_ErrorInformation const * errStatus = LC3CGERR_GetErrorInformation(pEPDB);

  LC_this->LC_VD_NOEXCEPTION = LC_EL_true;

  if (errStatus!=NULL)
	{
		LC_this->LC_VD_NOEXCEPTION = (errStatus->errorId==LC3CGERR_ErrorId_NO_ERROR)?LC_EL_true:LC_EL_false;
	}
}

#endif
