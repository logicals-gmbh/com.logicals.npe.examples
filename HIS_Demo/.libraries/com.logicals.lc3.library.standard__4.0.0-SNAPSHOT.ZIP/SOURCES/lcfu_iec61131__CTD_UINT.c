/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTD_UINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTD_UINT__C
#define LC_PROT_LCFU_IEC61131__CTD_UINT__C

#include <lcfu_iec61131__CTD_UINT.h>

/*                            FunctionBlocks                   */
void lcfu_iec61131__CTD_UINT(LC_TD_FunctionBlock_CTD_UINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  _lcfu_iec61131__CTD_ANY(LC_this, UINT, LC_IDP_PVmin_UINT)
}
#endif
