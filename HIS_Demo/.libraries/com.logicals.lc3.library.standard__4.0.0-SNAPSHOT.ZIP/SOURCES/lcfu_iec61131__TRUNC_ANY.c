/* Copyright (C) logi.cals GmbH. All rights reserved. */

#ifndef LC_PROT_LCFU_IEC61131__TRUNC_ANY_C
#define LC_PROT_LCFU_IEC61131__TRUNC_ANY_C

/* not safety features or math support */
#if !defined(LC3CG_SAFETY_FEATURES_ONLY) || defined(LC3CG_SAFETY_FEATURES_MATHLIB)

#include <lcfu_iec61131__TRUNC_ANY.h>
#include <LC3RTLibMath.h>

LC_TD_REAL LCfu_iec61131__TRUNC_ANY__REAL(float value)
{
  LC_MODFF_PAR ipart;

  /* ipart is the integer part of value */
  LC_MODFF(value, &ipart);

  return (LC_TD_REAL)ipart;
}

LC_TD_LREAL LCfu_iec61131__TRUNC_ANY__LREAL(double value)
{
  LC_MODF_PAR ipart;

  /* ipart is the integer part of value */
  LC_MODF(value, &ipart);

  return (LC_TD_LREAL)ipart;
}
#endif /* !defined(LC3CG_SAFETY_FEATURES_ONLY) || defined(LC3CG_SAFETY_FEATURES_MATHLIB) */
#endif
