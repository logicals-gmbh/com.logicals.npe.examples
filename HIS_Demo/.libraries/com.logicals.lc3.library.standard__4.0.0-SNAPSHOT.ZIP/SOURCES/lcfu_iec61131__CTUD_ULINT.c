/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTUD_ULINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTUD_ULINT__C
#define LC_PROT_LCFU_IEC61131__CTUD_ULINT__C

#include <lcfu_iec61131__CTUD_ULINT.h>

/*                            FunctionBlocks                   */
void lcfu_iec61131__CTUD_ULINT(LC_TD_FunctionBlock_CTUD_ULINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  _lcfu_iec61131__CTUD_ANY(LC_this, ULINT, LC_IDP_PVmax_ULINT, LC_IDP_PVmin_ULINT)
}
#endif
