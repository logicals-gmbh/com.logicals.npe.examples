/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function MOVE for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__MOVE__H
#define LC_PROT_LCFU_IEC61131__MOVE__H

#include <LC3CGBase.h>

/* support for elementary datatypes -------------------------- */
#define DEF_LC_TD_Function_MOVE_ANY(type) \
typedef struct _LC_TD_Function_MOVE__##type \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	LC_TD_##type LC_VD_MOVE; \
} LCCG_StructAttrib LC_TD_Function_MOVE__##type;

DEF_LC_TD_Function_MOVE_ANY(BOOL)
DEF_LC_TD_Function_MOVE_ANY(SINT)
DEF_LC_TD_Function_MOVE_ANY(INT)
DEF_LC_TD_Function_MOVE_ANY(DINT)
DEF_LC_TD_Function_MOVE_ANY(LINT)
DEF_LC_TD_Function_MOVE_ANY(USINT)
DEF_LC_TD_Function_MOVE_ANY(UINT)
DEF_LC_TD_Function_MOVE_ANY(UDINT)
DEF_LC_TD_Function_MOVE_ANY(ULINT)
DEF_LC_TD_Function_MOVE_ANY(BYTE)
DEF_LC_TD_Function_MOVE_ANY(WORD)
DEF_LC_TD_Function_MOVE_ANY(DWORD)
DEF_LC_TD_Function_MOVE_ANY(LWORD)
DEF_LC_TD_Function_MOVE_ANY(REAL)
DEF_LC_TD_Function_MOVE_ANY(LREAL)
DEF_LC_TD_Function_MOVE_ANY(TIME)
DEF_LC_TD_Function_MOVE_ANY(DATE)
DEF_LC_TD_Function_MOVE_ANY(TOD)
DEF_LC_TD_Function_MOVE_ANY(DT)
DEF_LC_TD_Function_MOVE_ANY(CHAR)
DEF_LC_TD_Function_MOVE_ANY(STRING)

/* missing elementary types: LTIME, LTOD, LDT */

/*                            Initialization Macro             */
#define LC_INIT_Function_MOVE_ANY(p,type) \
{ \
	LC_INIT_##type(&((p)->LC_VD_MOVE)); \
}

#define LC_INIT_Function_MOVE__BOOL(p)   LC_INIT_Function_MOVE_ANY(p,BOOL)
#define LC_INIT_Function_MOVE__SINT(p)   LC_INIT_Function_MOVE_ANY(p,SINT)
#define LC_INIT_Function_MOVE__INT(p)    LC_INIT_Function_MOVE_ANY(p,INT)
#define LC_INIT_Function_MOVE__DINT(p)   LC_INIT_Function_MOVE_ANY(p,DINT)
#define LC_INIT_Function_MOVE__LINT(p)   LC_INIT_Function_MOVE_ANY(p,LINT)
#define LC_INIT_Function_MOVE__USINT(p)  LC_INIT_Function_MOVE_ANY(p,USINT)
#define LC_INIT_Function_MOVE__UINT(p)   LC_INIT_Function_MOVE_ANY(p,UINT)
#define LC_INIT_Function_MOVE__UDINT(p)  LC_INIT_Function_MOVE_ANY(p,UDINT)
#define LC_INIT_Function_MOVE__ULINT(p)  LC_INIT_Function_MOVE_ANY(p,ULINT)
#define LC_INIT_Function_MOVE__BYTE(p)   LC_INIT_Function_MOVE_ANY(p,BYTE)
#define LC_INIT_Function_MOVE__WORD(p)   LC_INIT_Function_MOVE_ANY(p,WORD)
#define LC_INIT_Function_MOVE__DWORD(p)  LC_INIT_Function_MOVE_ANY(p,DWORD)
#define LC_INIT_Function_MOVE__LWORD(p)  LC_INIT_Function_MOVE_ANY(p,LWORD)
#define LC_INIT_Function_MOVE__REAL(p)   LC_INIT_Function_MOVE_ANY(p,REAL)
#define LC_INIT_Function_MOVE__LREAL(p)  LC_INIT_Function_MOVE_ANY(p,LREAL)
#define LC_INIT_Function_MOVE__TIME(p)   LC_INIT_Function_MOVE_ANY(p,TIME)
#define LC_INIT_Function_MOVE__DATE(p)   LC_INIT_Function_MOVE_ANY(p,DATE)
#define LC_INIT_Function_MOVE__TOD(p)    LC_INIT_Function_MOVE_ANY(p,TOD)
#define LC_INIT_Function_MOVE__DT(p)     LC_INIT_Function_MOVE_ANY(p,DT)
#define LC_INIT_Function_MOVE__CHAR(p)   LC_INIT_Function_MOVE_ANY(p,CHAR)
#define LC_INIT_Function_MOVE__STRING(p) LC_INIT_Function_MOVE_ANY(p,STRING)

/* Non-Inline (FB like) Implementation of MOVE Function */
#define lcfu_iec61131__MOVE__BOOL(LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (LC_TD_BOOL)(IN)
#define lcfu_iec61131__MOVE__SINT(LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__INT(LC_this, IN, pEPDB)    (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__DINT(LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__LINT(LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__USINT(LC_this, IN, pEPDB)  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__UINT(LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__UDINT(LC_this, IN, pEPDB)  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__ULINT(LC_this, IN, pEPDB)  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__BYTE(LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__WORD(LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__DWORD(LC_this, IN, pEPDB)  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__LWORD(LC_this, IN, pEPDB)  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REAL(LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__LREAL(LC_this, IN, pEPDB)  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__TIME(LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__DATE(LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__TOD(LC_this, IN, pEPDB)    (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__DT(LC_this, IN, pEPDB)     (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__CHAR(LC_this, IN, pEPDB)   LC_MOV_CHAR((LC_this)->LC_VD_MOVE,(IN))
#define lcfu_iec61131__MOVE__STRING(LC_this, IN, pEPDB) LC_MOV_STRING_SIZED_OR_UNSIZED_OUTPUT(LC_this, MOVE, IN)


/* support for elementary datatypes (references) ------------- */
#define LC_TD_IMPL__MOVE__REF(stType, cType) \
struct \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	cType* LC_VD_MOVE; \
} LCCG_StructAttrib

/*                            Initialization Macro             */
#define LC_INIT_IMPL__MOVE__REF(stType,cType,p) \
{ \
	(p)->LC_VD_MOVE = NULL; \
}

/* Non-Inline (FB like) Implementation of MOVE Function */
#define lcfu_iec61131__MOVE__REF__BOOL(ctype, LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__SINT(ctype, LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__INT(ctype, LC_this, IN, pEPDB)    (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__DINT(ctype, LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__LINT(ctype, LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__USINT(ctype, LC_this, IN, pEPDB)  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__UINT(ctype, LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__UDINT(ctype, LC_this, IN, pEPDB)  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__ULINT(ctype, LC_this, IN, pEPDB)  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__BYTE(ctype, LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__WORD(ctype, LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__DWORD(ctype, LC_this, IN, pEPDB)  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__LWORD(ctype, LC_this, IN, pEPDB)  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__REAL(ctype, LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__LREAL(ctype, LC_this, IN, pEPDB)  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__TIME(ctype, LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__DATE(ctype, LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__TOD(ctype, LC_this, IN, pEPDB)    (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__DT(ctype, LC_this, IN, pEPDB)     (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__CHAR(ctype, LC_this, IN, pEPDB)   (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__STRING(ctype, LC_this, IN, pEPDB) (LC_this)->LC_VD_MOVE  = (IN)


/* support for arrays, structs, refs ------------------------- */
#define LC_TD_IMPL__MOVE__DERIVED(stType, cType) \
struct \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	cType LC_VD_MOVE; \
} LCCG_StructAttrib
#define LC_TD_IMPL__MOVE__ARRAY(stType, cType, dimension) \
struct \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	cType LC_VD_MOVE[dimension]; \
} LCCG_StructAttrib
#define LC_TD_IMPL__MOVE__REF__DERIVED(stType, cType) \
struct \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	cType* LC_VD_MOVE; \
} LCCG_StructAttrib
#define LC_TD_IMPL__MOVE__REF__ARRAY(stType, cType, dimension) \
struct \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	cType (* LC_VD_MOVE)[dimension]; \
} LCCG_StructAttrib

/*                            Initialization Macro             */
#define LC_INIT_IMPL__MOVE__DERIVED(stType, cType, p)               LC_INIT_##stType(&((p)->LC_VD_MOVE));
#define LC_INIT_IMPL__MOVE__ARRAY(stType, cType, dimension, p)      LC_INIT_ARRAY(&((p)->LC_VD_MOVE), stType, dimension);
#define LC_INIT_IMPL__MOVE__REF__DERIVED(stType, cType, p)          LC_INIT_IMPL__MOVE__REF(stType, cType, p)
#define LC_INIT_IMPL__MOVE__REF__ARRAY(stType, cType, dimension, p) LC_INIT_IMPL__MOVE__REF(stType, cType, p)

/*                            Implementation Macros            */
#define lcfu_iec61131__MOVE__DERIVED(ctype, LC_this, IN, pEPDB)                       (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__ARRAY(ctype, dimension, LC_this, IN, pEPDB)              LC_ASSIGN_ARRAY_VAR((LC_this)->LC_VD_MOVE[0], (IN)[0], ctype, dimension);
#define lcfu_iec61131__MOVE__ARRAY__STRING(ctype, dimension, LC_this, IN, pEPDB)      lcfu_iec61131__MOVE__ARRAY(ctype, dimension, LC_this, IN, pEPDB)
#define lcfu_iec61131__MOVE__REF__DERIVED(ctype, LC_this, IN, pEPDB)                  (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__ARRAY(ctype, dimension, LC_this, IN, pEPDB)         (LC_this)->LC_VD_MOVE  = (IN)
#define lcfu_iec61131__MOVE__REF__ARRAY__STRING(ctype, dimension, LC_this, IN, pEPDB) lcfu_iec61131__MOVE__REF__ARRAY(ctype, dimension, LC_this, IN, pEPDB)

#endif
