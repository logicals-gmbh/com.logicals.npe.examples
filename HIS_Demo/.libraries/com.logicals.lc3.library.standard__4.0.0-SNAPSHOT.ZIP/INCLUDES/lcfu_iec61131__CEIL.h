/* Copyright (C) logi.cals GmbH. All rights reserved.             */

/*
** TASK :: C implementation of rounding function CEIL for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CEIL__H
#define LC_PROT_LCFU_IEC61131__CEIL__H

#include <LC3CGBase.h>
#include <LC3RTLibMath.h>

#define DEF_LC_TD_Function_CEIL_ANY_REAL(realtype) \
typedef struct _LC_TD_Function_CEIL__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##realtype LC_VD_CEIL; \
} LCCG_StructAttrib LC_TD_Function_CEIL__##realtype;

DEF_LC_TD_Function_CEIL_ANY_REAL(REAL)
DEF_LC_TD_Function_CEIL_ANY_REAL(LREAL)

/*                            Initialization Macro             */
#define LC_INIT_Function_CEIL_ANY_REAL(p,realtype) \
{ \
  LC_INIT_##realtype(&((p)->LC_VD_CEIL)); \
}

#define LC_INIT_Function_CEIL__REAL(p)  LC_INIT_Function_CEIL_ANY_REAL(p,REAL)
#define LC_INIT_Function_CEIL__LREAL(p) LC_INIT_Function_CEIL_ANY_REAL(p,LREAL)

/*
**  Calculates the ceil (up) rounding of input.
**  The output shall be of the same realtype as IN.
*/
/*  Prototype */
#define lcfu_iec61131__CEIL__REAL(LC_this, IN, pEPDB)  (LC_this)->LC_VD_CEIL = ((LC_TD_REAL)(LC_CEILF(IN)))
#define lcfu_iec61131__CEIL__LREAL(LC_this, IN, pEPDB) (LC_this)->LC_VD_CEIL = ((LC_TD_LREAL)(LC_CEIL(IN)))

#endif
