/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function TRUNC* for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__TRUNC_ANY__H
#define LC_PROT_LCFU_IEC61131__TRUNC_ANY__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
#define DEF_LC_TD_Function_TRUNC_ANY_INT(inttype,realtype) \
typedef struct _LC_TD_Function_TRUNC_##inttype##__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##inttype LC_VD_TRUNC_##inttype; \
} LCCG_StructAttrib LC_TD_Function_TRUNC_##inttype##__##realtype;

DEF_LC_TD_Function_TRUNC_ANY_INT(USINT,REAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(UINT,REAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(UDINT,REAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(ULINT,REAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(SINT,REAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(INT,REAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(DINT,REAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(LINT,REAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(USINT,LREAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(UINT,LREAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(UDINT,LREAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(ULINT,LREAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(SINT,LREAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(INT,LREAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(DINT,LREAL)
DEF_LC_TD_Function_TRUNC_ANY_INT(LINT,LREAL)

/*                            Initialization Macro             */
#define LC_INIT_Function_TRUNC_ANY_INT(p,inttype) \
{ \
  LC_INIT_##inttype(&((p)->LC_VD_TRUNC_##inttype)); \
}

#define LC_INIT_Function_TRUNC_USINT__REAL(p)  LC_INIT_Function_TRUNC_ANY_INT(p,USINT)
#define LC_INIT_Function_TRUNC_UINT__REAL(p)   LC_INIT_Function_TRUNC_ANY_INT(p,UINT)
#define LC_INIT_Function_TRUNC_UDINT__REAL(p)  LC_INIT_Function_TRUNC_ANY_INT(p,UDINT)
#define LC_INIT_Function_TRUNC_ULINT__REAL(p)  LC_INIT_Function_TRUNC_ANY_INT(p,ULINT)
#define LC_INIT_Function_TRUNC_SINT__REAL(p)   LC_INIT_Function_TRUNC_ANY_INT(p,SINT)
#define LC_INIT_Function_TRUNC_INT__REAL(p)    LC_INIT_Function_TRUNC_ANY_INT(p,INT)
#define LC_INIT_Function_TRUNC_DINT__REAL(p)   LC_INIT_Function_TRUNC_ANY_INT(p,DINT)
#define LC_INIT_Function_TRUNC_LINT__REAL(p)   LC_INIT_Function_TRUNC_ANY_INT(p,LINT)
#define LC_INIT_Function_TRUNC_USINT__LREAL(p) LC_INIT_Function_TRUNC_ANY_INT(p,USINT)
#define LC_INIT_Function_TRUNC_UINT__LREAL(p)  LC_INIT_Function_TRUNC_ANY_INT(p,UINT)
#define LC_INIT_Function_TRUNC_UDINT__LREAL(p) LC_INIT_Function_TRUNC_ANY_INT(p,UDINT)
#define LC_INIT_Function_TRUNC_ULINT__LREAL(p) LC_INIT_Function_TRUNC_ANY_INT(p,ULINT)
#define LC_INIT_Function_TRUNC_SINT__LREAL(p)  LC_INIT_Function_TRUNC_ANY_INT(p,SINT)
#define LC_INIT_Function_TRUNC_INT__LREAL(p)   LC_INIT_Function_TRUNC_ANY_INT(p,INT)
#define LC_INIT_Function_TRUNC_DINT__LREAL(p)  LC_INIT_Function_TRUNC_ANY_INT(p,DINT)
#define LC_INIT_Function_TRUNC_LINT__LREAL(p)  LC_INIT_Function_TRUNC_ANY_INT(p,LINT)

/*                            Implementation helper            */
extern LC_TD_REAL LCfu_iec61131__TRUNC_ANY__REAL(float value);
extern LC_TD_LREAL LCfu_iec61131__TRUNC_ANY__LREAL(double value);

#define LC_MF_TRUNC_REAL(type,IN)  ((LC_TD_##type)LCfu_iec61131__TRUNC_ANY__REAL(IN))
#define LC_MF_TRUNC_LREAL(type,IN) ((LC_TD_##type)LCfu_iec61131__TRUNC_ANY__LREAL(IN))

/*                            Implementation                   */
#define lcfu_iec61131__TRUNC_USINT__REAL(LC_this,IN,pEPDB)  (LC_this)->LC_VD_TRUNC_USINT = LC_MF_TRUNC_REAL(USINT,IN)
#define lcfu_iec61131__TRUNC_UINT__REAL(LC_this,IN,pEPDB)   (LC_this)->LC_VD_TRUNC_UINT = LC_MF_TRUNC_REAL(UINT,IN)
#define lcfu_iec61131__TRUNC_UDINT__REAL(LC_this,IN,pEPDB)  (LC_this)->LC_VD_TRUNC_UDINT = LC_MF_TRUNC_REAL(UDINT,IN)
#define lcfu_iec61131__TRUNC_ULINT__REAL(LC_this,IN,pEPDB)  (LC_this)->LC_VD_TRUNC_ULINT = LC_MF_TRUNC_REAL(ULINT,IN)
#define lcfu_iec61131__TRUNC_SINT__REAL(LC_this,IN,pEPDB)   (LC_this)->LC_VD_TRUNC_SINT = LC_MF_TRUNC_REAL(SINT,IN)
#define lcfu_iec61131__TRUNC_INT__REAL(LC_this,IN,pEPDB)    (LC_this)->LC_VD_TRUNC_INT = LC_MF_TRUNC_REAL(INT,IN)
#define lcfu_iec61131__TRUNC_DINT__REAL(LC_this,IN,pEPDB)   (LC_this)->LC_VD_TRUNC_DINT = LC_MF_TRUNC_REAL(DINT,IN)
#define lcfu_iec61131__TRUNC_LINT__REAL(LC_this,IN,pEPDB)   (LC_this)->LC_VD_TRUNC_LINT = LC_MF_TRUNC_REAL(LINT,IN)
#define lcfu_iec61131__TRUNC_USINT__LREAL(LC_this,IN,pEPDB) (LC_this)->LC_VD_TRUNC_USINT = LC_MF_TRUNC_LREAL(USINT,IN)
#define lcfu_iec61131__TRUNC_UINT__LREAL(LC_this,IN,pEPDB)  (LC_this)->LC_VD_TRUNC_UINT = LC_MF_TRUNC_LREAL(UINT,IN)
#define lcfu_iec61131__TRUNC_UDINT__LREAL(LC_this,IN,pEPDB) (LC_this)->LC_VD_TRUNC_UDINT = LC_MF_TRUNC_LREAL(UDINT,IN)
#define lcfu_iec61131__TRUNC_ULINT__LREAL(LC_this,IN,pEPDB) (LC_this)->LC_VD_TRUNC_ULINT = LC_MF_TRUNC_LREAL(ULINT,IN)
#define lcfu_iec61131__TRUNC_SINT__LREAL(LC_this,IN,pEPDB)  (LC_this)->LC_VD_TRUNC_SINT = LC_MF_TRUNC_LREAL(SINT,IN)
#define lcfu_iec61131__TRUNC_INT__LREAL(LC_this,IN,pEPDB)   (LC_this)->LC_VD_TRUNC_INT = LC_MF_TRUNC_LREAL(INT,IN)
#define lcfu_iec61131__TRUNC_DINT__LREAL(LC_this,IN,pEPDB)  (LC_this)->LC_VD_TRUNC_DINT = LC_MF_TRUNC_LREAL(DINT,IN)
#define lcfu_iec61131__TRUNC_LINT__LREAL(LC_this,IN,pEPDB)  (LC_this)->LC_VD_TRUNC_LINT = LC_MF_TRUNC_LREAL(LINT,IN)

#endif
