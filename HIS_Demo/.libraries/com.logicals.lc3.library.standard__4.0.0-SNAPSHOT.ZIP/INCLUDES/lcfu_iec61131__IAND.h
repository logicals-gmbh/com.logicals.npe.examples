/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function IAND for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__IAND__H
#define LC_PROT_LCFU_IEC61131__IAND__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
#define DEF_LC_TD_Function_IAND_ANY(type) \
typedef struct _LC_TD_Function_IAND__##type \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	LC_TD_##type LC_VD_IAND; \
} LCCG_StructAttrib LC_TD_Function_IAND__##type;

DEF_LC_TD_Function_IAND_ANY(SINT)
DEF_LC_TD_Function_IAND_ANY(USINT)
DEF_LC_TD_Function_IAND_ANY(INT)
DEF_LC_TD_Function_IAND_ANY(UINT)
DEF_LC_TD_Function_IAND_ANY(DINT)
DEF_LC_TD_Function_IAND_ANY(UDINT)
DEF_LC_TD_Function_IAND_ANY(LINT)
DEF_LC_TD_Function_IAND_ANY(ULINT)

/*                            Initialization Macro             */
#define LC_INIT_Function_IAND_ANY(p,type) \
{ \
	LC_INIT_##type(&((p)->LC_VD_IAND)); \
}

#define LC_INIT_Function_IAND__SINT(p)   LC_INIT_Function_IAND_ANY(p,SINT)
#define LC_INIT_Function_IAND__USINT(p)  LC_INIT_Function_IAND_ANY(p,USINT)
#define LC_INIT_Function_IAND__INT(p)    LC_INIT_Function_IAND_ANY(p,INT)
#define LC_INIT_Function_IAND__UINT(p)   LC_INIT_Function_IAND_ANY(p,UINT)
#define LC_INIT_Function_IAND__DINT(p)   LC_INIT_Function_IAND_ANY(p,DINT)
#define LC_INIT_Function_IAND__UDINT(p)  LC_INIT_Function_IAND_ANY(p,UDINT)
#define LC_INIT_Function_IAND__LINT(p)   LC_INIT_Function_IAND_ANY(p,LINT)
#define LC_INIT_Function_IAND__ULINT(p)  LC_INIT_Function_IAND_ANY(p,ULINT)

/* Preserve the legacy interface and calculation when HIS is disabled. */
#if !NPE_HIS_ENABLED
/* Bitwise and Boolean IAND of arguments                        */
#define LC_MF_IAND_ANY_2(IN1,IN2)                                                                  ((IN1)&(IN2))
#define LC_MF_IAND_ANY_3(IN1,IN2,IN3)                                                              ((IN1)&(IN2)&(IN3))
#define LC_MF_IAND_ANY_4(IN1,IN2,IN3,IN4)                                                          ((IN1)&(IN2)&(IN3)&(IN4))
#define LC_MF_IAND_ANY_5(IN1,IN2,IN3,IN4,IN5)                                                      ((IN1)&(IN2)&(IN3)&(IN4)&(IN5))
#define LC_MF_IAND_ANY_6(IN1,IN2,IN3,IN4,IN5,IN6)                                                  ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6))
#define LC_MF_IAND_ANY_7(IN1,IN2,IN3,IN4,IN5,IN6,IN7)                                              ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7))
#define LC_MF_IAND_ANY_8(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8)                                          ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8))
#define LC_MF_IAND_ANY_9(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9)                                      ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9))
#define LC_MF_IAND_ANY_10(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10)                                ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10))
#define LC_MF_IAND_ANY_11(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11)                           ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10)&(IN11))
#define LC_MF_IAND_ANY_12(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12)                      ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10)&(IN11)&(IN12))
#define LC_MF_IAND_ANY_13(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13)                 ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10)&(IN11)&(IN12)&(IN13))
#define LC_MF_IAND_ANY_14(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14)            ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10)&(IN11)&(IN12)&(IN13)&(IN14))
#define LC_MF_IAND_ANY_15(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15)       ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10)&(IN11)&(IN12)&(IN13)&(IN14)&(IN15))
#define LC_MF_IAND_ANY_16(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,IN16)  ((IN1)&(IN2)&(IN3)&(IN4)&(IN5)&(IN6)&(IN7)&(IN8)&(IN9)&(IN10)&(IN11)&(IN12)&(IN13)&(IN14)&(IN15)&(IN16))

/*                            Impl (not inlined)                     */
#define lcfu_iec61131__IAND__ANY__2(LC_this, IN1, IN2, pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_2(IN1,IN2)

#define lcfu_iec61131__IAND__ANY__3(LC_this, IN1, IN2, IN3,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_3(IN1,IN2,IN3)

#define lcfu_iec61131__IAND__ANY__4(LC_this, IN1, IN2, IN3,IN4,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_4(IN1,IN2,IN3,IN4)

#define lcfu_iec61131__IAND__ANY__5(LC_this, IN1, IN2, IN3,IN4,IN5,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_5(IN1,IN2,IN3,IN4,IN5)

#define lcfu_iec61131__IAND__ANY__6(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_6(IN1,IN2,IN3,IN4,IN5,IN6)

#define lcfu_iec61131__IAND__ANY__7(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_7(IN1,IN2,IN3,IN4,IN5,IN6,IN7)

#define lcfu_iec61131__IAND__ANY__8(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_8(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8)

#define lcfu_iec61131__IAND__ANY__9(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_9(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9)

#define lcfu_iec61131__IAND__ANY__10(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_10(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10)

#define lcfu_iec61131__IAND__ANY__11(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_11(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11)

#define lcfu_iec61131__IAND__ANY__12(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_12(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12)

#define lcfu_iec61131__IAND__ANY__13(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_13(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13)

#define lcfu_iec61131__IAND__ANY__14(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_14(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14)

#define lcfu_iec61131__IAND__ANY__15(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_15(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15)

#define lcfu_iec61131__IAND__ANY__16(LC_this, IN1, IN2, IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,IN16,pEPDB) \
   (LC_this)->LC_VD_IAND = LC_MF_IAND_ANY_16(IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,IN16)

#endif /* !NPE_HIS_ENABLED */

/* HIS interfaces use normal ANY_INT values in both channels. */
#if NPE_HIS_ENABLED
#include <LC3CGAnyBitOp.h>
#include <LC3CGError.h>

#if NPE_HIS_CHANNEL2
/* Keep verification separate for the later independent HIS verification review.
** Convert through the matching unsigned width before complementing, including
** signed inputs and C integer promotions. Volatile complemented operands retain
** the diverse calculation; the primary result is materialized by the caller.
*/
#define LC_IAND_DEFINE_STEP(type,utype) \
static inline int LCmfIandVerify_LC_TD_##type(LC_TD_##type left, \
  LC_TD_##type right, LC_TD_##type result) \
{ \
  volatile LC_TD_##utype invertedLeft = (LC_TD_##utype)~(LC_TD_##utype)left; \
  volatile LC_TD_##utype invertedRight = (LC_TD_##utype)~(LC_TD_##utype)right; \
  LC_TD_##utype invertedResult = (LC_TD_##utype)LC_MF_BITWISE_AND(invertedLeft, invertedRight); \
  return invertedResult == (LC_TD_##utype)~(LC_TD_##utype)result; \
} \
static inline LC_TD_##type LCmfIandStep_LC_TD_##type(LC_TD_##type left, \
  LC_TD_##type right, void const *pThis, struct _lcoplck_epdb_1_impl const *pEPDB) \
{ \
  volatile LC_TD_##type calculated = (LC_TD_##type)(left & right); \
  LC_TD_##type result = calculated; \
  if (!LCmfIandVerify_LC_TD_##type(left, right, result)) \
  { \
    LC3CGERR_SetErrorInformationFunc(pThis, (LC_TD_BOOL *)0, pEPDB, \
      LC3CGERR_ErrorId_HIS_VERIFY_IAND_FAILED, LC3CGERR__FILE, LC3CGERR__LINE, LC3CGERR__FUNCTION); \
  } \
  return result; \
}
#else
#define LC_IAND_DEFINE_STEP(type,utype) \
static inline LC_TD_##type LCmfIandStep_LC_TD_##type(LC_TD_##type left, \
  LC_TD_##type right, void const *pThis, struct _lcoplck_epdb_1_impl const *pEPDB) \
{ \
  (void)pThis; \
  (void)pEPDB; \
  return (LC_TD_##type)(left & right); \
}
#endif

/* All inputs have been captured before any result is published. */
#define LC_IAND_DEFINE_HIS(type,utype) \
LC_IAND_DEFINE_STEP(type,utype) \
static inline void LCmfIandHis_LC_TD_##type(LC_TD_Function_IAND__##type *LC_this, \
  LC_TD_##type const *inputs, unsigned count, struct _lcoplck_epdb_1_impl const *pEPDB) \
{ \
  LC_TD_##type result = inputs[0]; \
  unsigned i; \
  for (i = 1; i < count; ++i) \
  { \
    result = LCmfIandStep_LC_TD_##type(result, inputs[i], LC_this, pEPDB); \
  } \
  LC_this->LC_VD_IAND = result; \
}

LC_IAND_DEFINE_HIS(SINT,USINT)
LC_IAND_DEFINE_HIS(USINT,USINT)
LC_IAND_DEFINE_HIS(INT,UINT)
LC_IAND_DEFINE_HIS(UINT,UINT)
LC_IAND_DEFINE_HIS(DINT,UDINT)
LC_IAND_DEFINE_HIS(UDINT,UDINT)
LC_IAND_DEFINE_HIS(LINT,ULINT)
LC_IAND_DEFINE_HIS(ULINT,ULINT)

#undef LC_IAND_DEFINE_HIS
#undef LC_IAND_DEFINE_STEP

#define LC_IAND_HIS_NAME(TYP) LC_IAND_HIS_NAME_(TYP)
#define LC_IAND_HIS_NAME_(TYP) LCmfIandHis_##TYP

#define lcfu_iec61131__IAND__ANY__HIS__2(TYP,LC_this,IN1,IN2,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[2]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 2, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__3(TYP,LC_this,IN1,IN2,IN3,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[3]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 3, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__4(TYP,LC_this,IN1,IN2,IN3,IN4,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[4]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 4, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__5(TYP,LC_this,IN1,IN2,IN3,IN4,IN5,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[5]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  lc_iand_inputs[4] = (IN5); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 5, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__6(TYP,LC_this,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[6]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  lc_iand_inputs[4] = (IN5); \
  lc_iand_inputs[5] = (IN6); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 6, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__7(TYP,LC_this,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[7]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  lc_iand_inputs[4] = (IN5); \
  lc_iand_inputs[5] = (IN6); \
  lc_iand_inputs[6] = (IN7); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 7, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__8(TYP,LC_this,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[8]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  lc_iand_inputs[4] = (IN5); \
  lc_iand_inputs[5] = (IN6); \
  lc_iand_inputs[6] = (IN7); \
  lc_iand_inputs[7] = (IN8); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 8, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__9(TYP,LC_this,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[9]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  lc_iand_inputs[4] = (IN5); \
  lc_iand_inputs[5] = (IN6); \
  lc_iand_inputs[6] = (IN7); \
  lc_iand_inputs[7] = (IN8); \
  lc_iand_inputs[8] = (IN9); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 9, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__10(TYP,LC_this,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[10]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  lc_iand_inputs[4] = (IN5); \
  lc_iand_inputs[5] = (IN6); \
  lc_iand_inputs[6] = (IN7); \
  lc_iand_inputs[7] = (IN8); \
  lc_iand_inputs[8] = (IN9); \
  lc_iand_inputs[9] = (IN10); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 10, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__11(TYP,LC_this,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[11]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  lc_iand_inputs[4] = (IN5); \
  lc_iand_inputs[5] = (IN6); \
  lc_iand_inputs[6] = (IN7); \
  lc_iand_inputs[7] = (IN8); \
  lc_iand_inputs[8] = (IN9); \
  lc_iand_inputs[9] = (IN10); \
  lc_iand_inputs[10] = (IN11); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 11, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__12(TYP,LC_this,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[12]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  lc_iand_inputs[4] = (IN5); \
  lc_iand_inputs[5] = (IN6); \
  lc_iand_inputs[6] = (IN7); \
  lc_iand_inputs[7] = (IN8); \
  lc_iand_inputs[8] = (IN9); \
  lc_iand_inputs[9] = (IN10); \
  lc_iand_inputs[10] = (IN11); \
  lc_iand_inputs[11] = (IN12); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 12, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__13(TYP,LC_this,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[13]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  lc_iand_inputs[4] = (IN5); \
  lc_iand_inputs[5] = (IN6); \
  lc_iand_inputs[6] = (IN7); \
  lc_iand_inputs[7] = (IN8); \
  lc_iand_inputs[8] = (IN9); \
  lc_iand_inputs[9] = (IN10); \
  lc_iand_inputs[10] = (IN11); \
  lc_iand_inputs[11] = (IN12); \
  lc_iand_inputs[12] = (IN13); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 13, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__14(TYP,LC_this,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[14]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  lc_iand_inputs[4] = (IN5); \
  lc_iand_inputs[5] = (IN6); \
  lc_iand_inputs[6] = (IN7); \
  lc_iand_inputs[7] = (IN8); \
  lc_iand_inputs[8] = (IN9); \
  lc_iand_inputs[9] = (IN10); \
  lc_iand_inputs[10] = (IN11); \
  lc_iand_inputs[11] = (IN12); \
  lc_iand_inputs[12] = (IN13); \
  lc_iand_inputs[13] = (IN14); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 14, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__15(TYP,LC_this,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[15]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  lc_iand_inputs[4] = (IN5); \
  lc_iand_inputs[5] = (IN6); \
  lc_iand_inputs[6] = (IN7); \
  lc_iand_inputs[7] = (IN8); \
  lc_iand_inputs[8] = (IN9); \
  lc_iand_inputs[9] = (IN10); \
  lc_iand_inputs[10] = (IN11); \
  lc_iand_inputs[11] = (IN12); \
  lc_iand_inputs[12] = (IN13); \
  lc_iand_inputs[13] = (IN14); \
  lc_iand_inputs[14] = (IN15); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 15, (pEPDB)); \
} while (0)

#define lcfu_iec61131__IAND__ANY__HIS__16(TYP,LC_this,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,IN16,pEPDB) \
do \
{ \
  TYP lc_iand_inputs[16]; \
  lc_iand_inputs[0] = (IN1); \
  lc_iand_inputs[1] = (IN2); \
  lc_iand_inputs[2] = (IN3); \
  lc_iand_inputs[3] = (IN4); \
  lc_iand_inputs[4] = (IN5); \
  lc_iand_inputs[5] = (IN6); \
  lc_iand_inputs[6] = (IN7); \
  lc_iand_inputs[7] = (IN8); \
  lc_iand_inputs[8] = (IN9); \
  lc_iand_inputs[9] = (IN10); \
  lc_iand_inputs[10] = (IN11); \
  lc_iand_inputs[11] = (IN12); \
  lc_iand_inputs[12] = (IN13); \
  lc_iand_inputs[13] = (IN14); \
  lc_iand_inputs[14] = (IN15); \
  lc_iand_inputs[15] = (IN16); \
  LC_IAND_HIS_NAME(TYP)((LC_this), lc_iand_inputs, 16, (pEPDB)); \
} while (0)

#endif /* NPE_HIS_ENABLED */

#endif
