#ifndef LC_PROT_LCFU_IEC61131__EXCEPTIONSTATUS__H
#define LC_PROT_LCFU_IEC61131__EXCEPTIONSTATUS__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_EXCEPTIONSTATUS
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_DataType_SAFEBOOL LC_VD_NOEXCEPTION;
} LCCG_StructAttrib LC_TD_Function_EXCEPTIONSTATUS;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_EXCEPTIONSTATUS(p) \
{ \
  LC_INIT_DataType_SAFEBOOL(&((p)->LC_VD_NOEXCEPTION)); \
}

/*                            Prototype                        */
void  lcfu_iec61131__EXCEPTIONSTATUS(LC_TD_Function_EXCEPTIONSTATUS* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
