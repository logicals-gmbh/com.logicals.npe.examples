/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block F_TRIG for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__F_TRIG__H
#define LC_PROT_LCFU_IEC61131__F_TRIG__H

#include <LC3CGBase.h>
#include <LC3CGAnyBitOp.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_F_TRIG
{
	LC_TD_BOOL LC_VD_CLK;
	LC_TD_BOOL LC_VD_ENO;
	LC_TD_BOOL LC_VD_Q;
	LC_TD_BOOL LC_VD_M;
} LCCG_StructAttrib LC_TD_FunctionBlock_F_TRIG;

/*                            Initialization Macro (cold start) */

/* According to IEC61131-3 1st revision and to Techical Report 2: M:=TRUE; - this is NOT what the 2nd and 3rd Rev says */
#define LC_INIT_FunctionBlock_F_TRIG(p) \
{ \
	LC_INIT_BOOL(&((p)->LC_VD_CLK)); \
	LC_INIT_BOOL(&((p)->LC_VD_Q)); \
        (p)->LC_VD_M=LC_EL_true; \
}

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_F_TRIG(p,RF) { if (LC_WINIT_IS_NOT_RETAINED(RF)) LC_INIT_FunctionBlock_F_TRIG(p) }

/*                            Impl (not inlined)               */
#if !NPE_HIS_CHANNEL2

#define lcfu_iec61131__F_TRIG(LC_this, pEPDB) \
        (LC_this)->LC_VD_Q = (!((LC_this)->LC_VD_CLK)) && !((LC_this)->LC_VD_M); \
        (LC_this)->LC_VD_M = !((LC_this)->LC_VD_CLK)

#else

#define lcfu_iec61131__F_TRIG(LC_this, pEPDB) \
        { \
          LC_TD_BOOL LC_invertedClk = LC_MF_LOGICAL_NOT((LC_this)->LC_VD_CLK); \
          LC_TD_BOOL LC_clkChanged = LC_MF_LOGICAL_XOR(LC_invertedClk, (LC_this)->LC_VD_M); \
          (LC_this)->LC_VD_Q = LC_MF_LOGICAL_AND(LC_invertedClk, LC_clkChanged); \
          (LC_this)->LC_VD_M = LC_invertedClk; \
        }

#endif

#endif
