/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block R_TRIG for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__R_TRIG__H
#define LC_PROT_LCFU_IEC61131__R_TRIG__H

#include <LC3CGBase.h>
#include <LC3CGAnyBitOp.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_R_TRIG
{
	LC_TD_BOOL LC_VD_CLK;
	LC_TD_BOOL LC_VD_ENO;
	LC_TD_BOOL LC_VD_Q;
	LC_TD_BOOL LC_VD_M;
} LCCG_StructAttrib LC_TD_FunctionBlock_R_TRIG;

/*                            Initialization Macro (cold start) */
#define LC_INIT_FunctionBlock_R_TRIG(p) \
{ \
	LC_INIT_BOOL(&((p)->LC_VD_CLK)); \
	LC_INIT_BOOL(&((p)->LC_VD_Q)); \
	LC_INIT_BOOL(&((p)->LC_VD_M)); \
}

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_R_TRIG(p,RF) { if (LC_WINIT_IS_NOT_RETAINED(RF)) LC_INIT_FunctionBlock_R_TRIG(p) }

/*                            Impl (not inlined)               */
#if !NPE_HIS_CHANNEL2

#define lcfu_iec61131__R_TRIG(LC_this, pEPDB) \
        (LC_this)->LC_VD_Q = (LC_this)->LC_VD_CLK && (!((LC_this)->LC_VD_M)); \
        (LC_this)->LC_VD_M = (LC_this)->LC_VD_CLK

#else

#define lcfu_iec61131__R_TRIG(LC_this, pEPDB) \
        { \
          LC_TD_BOOL LC_currentClk = (LC_this)->LC_VD_CLK; \
          (LC_this)->LC_VD_Q = LC_EL_false; \
          if (LC_MF_COMPARE_NE(LC_TD_BOOL, LC_currentClk, (LC_this)->LC_VD_M)) \
          { \
            (LC_this)->LC_VD_Q = LC_currentClk; \
          } \
          (LC_this)->LC_VD_M = LC_currentClk; \
        }

#endif

#endif
