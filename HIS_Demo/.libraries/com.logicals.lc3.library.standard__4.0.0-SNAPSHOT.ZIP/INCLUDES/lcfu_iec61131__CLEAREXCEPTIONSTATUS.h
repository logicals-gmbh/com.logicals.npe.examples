#ifndef LC_PROT_LCFU_IEC61131__CLEAREXCEPTIONSTATUS__H
#define LC_PROT_LCFU_IEC61131__CLEAREXCEPTIONSTATUS__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_CLEAREXCEPTIONSTATUS
{
  LC_TD_BOOL LC_VD_ENO;
} LCCG_StructAttrib LC_TD_Function_CLEAREXCEPTIONSTATUS;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_CLEAREXCEPTIONSTATUS(p) \
{ \
}

/*                            Prototype                        */
void  lcfu_iec61131__CLEAREXCEPTIONSTATUS(LC_TD_Function_CLEAREXCEPTIONSTATUS* LC_this, LC_TD_DataType_SAFEBOOL LC_VD_CMDCLEAREXCEPTION, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
