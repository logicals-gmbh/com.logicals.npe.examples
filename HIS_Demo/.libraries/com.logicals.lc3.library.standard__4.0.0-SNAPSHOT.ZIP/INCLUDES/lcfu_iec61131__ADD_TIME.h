/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function ADD_TIME for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__ADD_TIME__H
#define LC_PROT_LCFU_IEC61131__ADD_TIME__H

#include <LC3CGBase.h>
#include <LC3CGAnyIntOp.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_ADD_TIME   \
{                                            \
	LC_TD_BOOL LC_VD_ENO;                \
	LC_TD_TIME LC_VD_ADD_TIME;              \
} LCCG_StructAttrib LC_TD_Function_ADD_TIME;

/*                            Initialization Macro             */

#define LC_INIT_Function_ADD_TIME(p)   LC_INIT_TIME(&((p)->LC_VD_ADD_TIME));

/*                            Impl (not inlined)                     */
#define  lcfu_iec61131__ADD_TIME(LC_this, IN1, IN2, pEPDB) \
   (LC_this)->LC_VD_ADD_TIME = LC_MF_NUMERIC_ADD(LC_TD_TIME,IN1,IN2)

#endif
