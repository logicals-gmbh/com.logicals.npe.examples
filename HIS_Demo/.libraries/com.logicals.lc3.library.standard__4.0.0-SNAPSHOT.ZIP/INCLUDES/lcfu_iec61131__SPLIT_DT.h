/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function SPLIT_DT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__SPLIT_DT__H
#define LC_PROT_LCFU_IEC61131__SPLIT_DT__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_SPLIT_DT
{
	LC_TD_BOOL LC_VD_ENO;
	LC_TD_USINT LC_VD_DAY;
	LC_TD_USINT LC_VD_HOUR;
	LC_TD_USINT LC_VD_MINUTE;
	LC_TD_USINT LC_VD_MONTH;
	LC_TD_USINT LC_VD_SECOND;
	LC_TD_UINT LC_VD_MILLISECOND;
	LC_TD_UINT LC_VD_YEAR;
} LCCG_StructAttrib LC_TD_Function_SPLIT_DT;

/*                            Initialization Macro             */
#define LC_INIT_Function_SPLIT_DT(p) \
{ \
	LC_INIT_UINT(&((p)->LC_VD_YEAR)); \
	LC_INIT_USINT(&((p)->LC_VD_MONTH)); \
	LC_INIT_USINT(&((p)->LC_VD_DAY)); \
	LC_INIT_USINT(&((p)->LC_VD_HOUR)); \
	LC_INIT_USINT(&((p)->LC_VD_MINUTE)); \
	LC_INIT_USINT(&((p)->LC_VD_SECOND)); \
	LC_INIT_UINT(&((p)->LC_VD_MILLISECOND)); \
}

/*                            Implementation helper            */
#if NPE_HIS_CHANNEL2
extern void lcfu_iec61131__SplitDateAndTime_HIS(LC_TD_DT value, LC_TD_Function_SPLIT_DT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB, char const * dbgFile, unsigned int dbgLine, char const * dbgFunction);
#else
extern void lcfu_iec61131__SplitDateAndTime(LC_TD_DT value, LC_TD_Function_SPLIT_DT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB, char const * dbgFile, unsigned int dbgLine, char const * dbgFunction);
#endif

/*                            Implementation                   */
#if NPE_HIS_CHANNEL2
#define lcfu_iec61131__SPLIT_DT(LC_this, IN, pEPDB) lcfu_iec61131__SplitDateAndTime_HIS(IN,LC_this,pEPDB,LC3CGERR__FILE,LC3CGERR__LINE,LC3CGERR__FUNCTION)
#else
#define lcfu_iec61131__SPLIT_DT(LC_this, IN, pEPDB) lcfu_iec61131__SplitDateAndTime(IN,LC_this,pEPDB,LC3CGERR__FILE,LC3CGERR__LINE,LC3CGERR__FUNCTION)
#endif

#endif
