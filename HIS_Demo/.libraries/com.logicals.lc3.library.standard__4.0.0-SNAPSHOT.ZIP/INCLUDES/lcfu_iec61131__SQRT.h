/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function SQRT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__SQRT__H
#define LC_PROT_LCFU_IEC61131__SQRT__H

#include <LC3CGBase.h>
#include <LC3RTLibMath.h>       /* for sqrt() */

#define DEF_LC_TD_Function_SQRT_ANY_REAL(realtype) \
typedef struct _LC_TD_Function_SQRT__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##realtype LC_VD_SQRT; \
} LCCG_StructAttrib LC_TD_Function_SQRT__##realtype;

DEF_LC_TD_Function_SQRT_ANY_REAL(REAL)
DEF_LC_TD_Function_SQRT_ANY_REAL(LREAL)

/*                            Initialization Macro             */
#define LC_INIT_Function_SQRT_ANY_REAL(p,realtype) \
{ \
  LC_INIT_##realtype(&((p)->LC_VD_SQRT)); \
}

#define LC_INIT_Function_SQRT__REAL(p)  LC_INIT_Function_SQRT_ANY_REAL(p,REAL)
#define LC_INIT_Function_SQRT__LREAL(p) LC_INIT_Function_SQRT_ANY_REAL(p,LREAL)

/*
**  calculates the square root of input
**  The output shall be of the same realtype as IN.
*/
#define LC_MF_SQRT_SETERR(THIS) (LC3CGERR_SetErrorInformation((THIS),pEPDB,LC3CGERR_ErrorId_SQRT_INVARG))

#define LC_MF_SQRT_ANY_REAL(realtype,fun,IN,THIS)  ((IN)<0.0f?LC_MF_SQRT_SETERR(THIS),0.0f:(LC_TD_##realtype)fun(IN))
#define LC_MF_SQRT_ANY_LREAL(realtype,fun,IN,THIS) ((IN)<0.0 ?LC_MF_SQRT_SETERR(THIS),0.0 :(LC_TD_##realtype)fun(IN))

/*  Prototype */
#define lcfu_iec61131__SQRT__REAL(LC_this, IN, pEPDB)  (LC_this)->LC_VD_SQRT = LC_MF_SQRT_ANY_REAL(REAL,LC_SQRTF,IN,(LC_this))
#define lcfu_iec61131__SQRT__LREAL(LC_this, IN, pEPDB) (LC_this)->LC_VD_SQRT = LC_MF_SQRT_ANY_LREAL(LREAL,LC_SQRT,IN,(LC_this))

#endif
