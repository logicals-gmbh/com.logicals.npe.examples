/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function SIZEOF for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__SIZEOF__H
#define LC_PROT_LCFU_IEC61131__SIZEOF__H

#include <LC3CGBase.h>
#include <LC3CGAnyIntOp.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_SIZEOF
{
	LC_TD_BOOL LC_VD_ENO;
	LC_TD_UDINT LC_VD_SIZEOF;
} LCCG_StructAttrib LC_TD_Function_SIZEOF;

/*                            Initialization Macro             */
#define LC_INIT_Function_SIZEOF(p) \
{ \
	LC_INIT_UDINT(&((p)->LC_VD_SIZEOF)); \
}

/*                            Impl (not inlined)               */
#define lcfu_iec61131__SIZEOF__ANY(basetype,LC_this, IN, pEPDB)                 (LC_this)->LC_VD_SIZEOF = ((LC_TD_UDINT)sizeof(basetype))
#define lcfu_iec61131__SIZEOF__DERIVED(basetype, LC_this, IN, pEPDB)            (LC_this)->LC_VD_SIZEOF = ((LC_TD_UDINT)sizeof(basetype))
#define lcfu_iec61131__SIZEOF__REF__ANY(basetype,LC_this, IN, pEPDB)            (LC_this)->LC_VD_SIZEOF = ((LC_TD_UDINT)sizeof(basetype *))

#define lcfu_iec61131__SIZEOF__ARRAY(basetype, dim, LC_this, IN, pEPDB)         (LC_this)->LC_VD_SIZEOF = LC_MF_NUMERIC_MUL(LC_TD_UDINT, (LC_TD_UDINT)LC_MF_ARRAY_1_SIZE(dim), (LC_TD_UDINT)sizeof(basetype))


#ifndef LC3CG_SAFETY_FEATURES_ONLY
#define lcfu_iec61131__SIZEOF__CHAR(LC_this, IN, pEPDB)                         (LC_this)->LC_VD_SIZEOF = ((LC_TD_UDINT)2 * (LC_TD_UDINT)sizeof(LcCgChar))
#define lcfu_iec61131__SIZEOF__STRING(LC_this, IN, pEPDB)                       (LC_this)->LC_VD_SIZEOF = ((LC_TD_UDINT)LC_GET_STRING_BUFFER_SIZE(IN))
#define lcfu_iec61131__SIZEOF__ARRAY__STRING(basetype, dim, LC_this, IN, pEPDB) lcfu_iec61131__SIZEOF__ARRAY(basetype, dim, LC_this, IN, pEPDB)
#endif

#endif
