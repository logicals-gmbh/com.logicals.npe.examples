#ifndef LC3CGCOUNTERIMPL_H
#define LC3CGCOUNTERIMPL_H

/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK      :: C implementation of function block
** NOTES     :: for RTS compatible Systems.
**              CTU, CTU_INT, CTU_DINT, CTU_LINT, CTU_UINT, CTU_UDINT, CTU_ULINT
**              CTD, CTD_INT, CTD_DINT, CTD_LINT, CTD_UINT, CTD_UDINT, CTD_ULINT
*/

/** \defgroup DocGrpLCStdIECLibMacrosCounter Macros for counter modules
 * \ingroup DocGrpLCStdIECLibMacros
 */

/***************************************************************************
** Global Includes, Defines , Types
****************************************************************************/
#include <LC3CGEdgeDetect.h>
#include <LC3CGAnyBitOp.h>
#include <LC3CGAnyIntOp.h>

/*                            Typedefs                         */

/** \ingroup DocGrpLCStdIECLibMacrosCounter
 * \brief Define instance data for CDT block
 *
 * Generates a list of variables, which are used by the library block.<br>
 * \param [in] type name of IEC data type
 */
#define _typedef_FunctionBlock_CTD_ANY(type) \
        LC_TD_BOOL LC_VD_CD; \
        LC_TD_BOOL LC_VD_LD; \
        LC_TD_##type LC_VD_PV; \
        LC_TD_BOOL LC_VD_ENO; \
        LC_TD_BOOL LC_VD_Q; \
        LC_TD_##type LC_VD_CV; \
        LC_TD_BOOL LC_VD_CD_M;

/** \ingroup DocGrpLCStdIECLibMacrosCounter
 * \brief Define instance data for CTU block
 *
 * Generates a list of variables, which are used by the library block.<br>
 * \param [in] type name of IEC data type
 */
#define _typedef_FunctionBlock_CTU_ANY(type) \
        LC_TD_BOOL LC_VD_CU; \
        LC_TD_BOOL LC_VD_R; \
        LC_TD_##type LC_VD_PV; \
        LC_TD_BOOL LC_VD_ENO; \
        LC_TD_BOOL LC_VD_Q; \
        LC_TD_##type LC_VD_CV; \
        LC_TD_BOOL LC_VD_CU_M;

/** \ingroup DocGrpLCStdIECLibMacrosCounter
 * \brief Define instance data for CTUD block
 *
 * Generates a list of variables, which are used by the library block.<br>
 * \param [in] type name of IEC data type
 */
#define _typedef_FunctionBlock_CTUD_ANY(type) \
        LC_TD_BOOL LC_VD_CD; \
        LC_TD_BOOL LC_VD_CU; \
        LC_TD_BOOL LC_VD_LD; \
        LC_TD_BOOL LC_VD_R; \
        LC_TD_##type LC_VD_PV; \
        LC_TD_BOOL LC_VD_ENO; \
        LC_TD_BOOL LC_VD_QD; \
        LC_TD_BOOL LC_VD_QU; \
        LC_TD_##type LC_VD_CV; \
        LC_TD_BOOL LC_VD_CD_M; \
        LC_TD_BOOL LC_VD_CU_M;

/** \ingroup DocGrpLCStdIECLibMacrosCounter
 * \brief Initialize instance data for CDT block
 *
 * Initialize variables, which are used by the library block.<br>
 * \param [in] type name of IEC data type
 * \param [out] p pointer to instance data
 */
#define _INIT_FunctionBlock_CTD_ANY(type,p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_CD)); \
  LC_INIT_BOOL(&((p)->LC_VD_LD)); \
  LC_INIT_##type(&((p)->LC_VD_PV)); \
  LC_INIT_BOOL(&((p)->LC_VD_Q)); \
  LC_INIT_##type(&((p)->LC_VD_CV)); \
  LC_INIT_BOOL(&((p)->LC_VD_CD_M)); \
}

/** \ingroup DocGrpLCStdIECLibMacrosCounter
 * \brief Initialize instance data for CTU block
 *
 * Initialize variables, which are used by the library block.<br>
 * \param [in] type name of IEC data type
 * \param [out] p pointer to instance data
 */
#define _INIT_FunctionBlock_CTU_ANY(type,p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_CU)); \
  LC_INIT_BOOL(&((p)->LC_VD_R)); \
  LC_INIT_##type(&((p)->LC_VD_PV)); \
  LC_INIT_BOOL(&((p)->LC_VD_Q)); \
  LC_INIT_##type(&((p)->LC_VD_CV)); \
  LC_INIT_BOOL(&((p)->LC_VD_CU_M)); \
}

/** \ingroup DocGrpLCStdIECLibMacrosCounter
 * \brief Initialize instance data for CTUD block
 *
 * Initialize variables, which are used by the library block.<br>
 * \param [in] type name of IEC data type
 * \param [out] p pointer to instance data
 */
#define _INIT_FunctionBlock_CTUD_ANY(type,p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_CU)); \
  LC_INIT_BOOL(&((p)->LC_VD_CD)); \
  LC_INIT_BOOL(&((p)->LC_VD_R)); \
  LC_INIT_BOOL(&((p)->LC_VD_LD)); \
  LC_INIT_##type(&((p)->LC_VD_PV)); \
  LC_INIT_BOOL(&((p)->LC_VD_QU)); \
  LC_INIT_BOOL(&((p)->LC_VD_QD)); \
  LC_INIT_##type(&((p)->LC_VD_CV)); \
  LC_INIT_BOOL(&((p)->LC_VD_CU_M)); \
  LC_INIT_BOOL(&((p)->LC_VD_CD_M)); \
}


/*                            Implementation                   */
#if !NPE_HIS_CHANNEL2

#define _lcfu_iec61131__CTU_ANY(LC_this, type, PVmax) \
  /* Perform Edge Recognition */ \
  LC3_MSI_EDGE((LC_this)->LC_VD_CU,(LC_this)->LC_VD_CU_M) \
  \
  if (LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_R, LC_EL_true)) \
  { \
    (LC_this)->LC_VD_CV = LC_MC_##type(0x0); \
  } \
  else \
  { \
    if (LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_CU, LC_EL_true)) \
    { \
      if (LC_MF_COMPARE_LT(LC_TD_##type, (LC_this)->LC_VD_CV, PVmax)) \
      { \
        (LC_this)->LC_VD_CV = LC_MF_NUMERIC_ADD(LC_TD_##type, (LC_this)->LC_VD_CV, LC_MC_##type(0x1)); \
      } \
    } \
  } \
  (LC_this)->LC_VD_Q = LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_GE(LC_TD_##type, (LC_this)->LC_VD_CV, (LC_this)->LC_VD_PV));

#define _lcfu_iec61131__CTD_ANY(LC_this, type, PVmin) \
  /* Perform Edge Recognition */ \
  LC3_MSI_EDGE((LC_this)->LC_VD_CD,(LC_this)->LC_VD_CD_M) \
  \
  if (LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_LD, LC_EL_true)) \
  { \
    (LC_this)->LC_VD_CV = (LC_this)->LC_VD_PV; \
  } \
  else \
  { \
    if (LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_CD, LC_EL_true)) \
    { \
      if (LC_MF_COMPARE_GT(LC_TD_##type, (LC_this)->LC_VD_CV, PVmin)) \
      { \
        (LC_this)->LC_VD_CV = LC_MF_NUMERIC_SUB(LC_TD_##type, (LC_this)->LC_VD_CV, LC_MC_##type(0x1)); \
      } \
    } \
  } \
  (LC_this)->LC_VD_Q = LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_LE(LC_TD_##type, (LC_this)->LC_VD_CV, LC_MC_##type(0x0)));

#define _lcfu_iec61131__CTUD_ANY(LC_this, type, PVmax, PVmin) \
  /* Perform Edge Recognition */ \
  LC3_MSI_EDGE((LC_this)->LC_VD_CU,(LC_this)->LC_VD_CU_M) \
  LC3_MSI_EDGE((LC_this)->LC_VD_CD,(LC_this)->LC_VD_CD_M) \
  \
  if (LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_R, LC_EL_true)) \
  { \
    (LC_this)->LC_VD_CV = LC_MC_##type(0x0); \
  } \
  else \
  { \
    if (LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_LD, LC_EL_true)) \
    { \
      (LC_this)->LC_VD_CV = (LC_this)->LC_VD_PV; \
    } \
    else \
    { \
      if (LC_MF_COMPARE_EQ(LC_TD_BOOL, LC_MF_LOGICAL_AND((LC_this)->LC_VD_CU, (LC_this)->LC_VD_CD), LC_EL_false)) \
      { \
        if (LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_CU, LC_EL_true)) \
        { \
          if (LC_MF_COMPARE_LT(LC_TD_##type, (LC_this)->LC_VD_CV, PVmax)) \
          { \
            (LC_this)->LC_VD_CV = LC_MF_NUMERIC_ADD(LC_TD_##type, (LC_this)->LC_VD_CV, LC_MC_##type(0x1)); \
          } \
        } \
        else \
        { \
          if (LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_CD, LC_EL_true)) \
          { \
            if (LC_MF_COMPARE_GT(LC_TD_##type, (LC_this)->LC_VD_CV, PVmin)) \
            { \
              (LC_this)->LC_VD_CV = LC_MF_NUMERIC_SUB(LC_TD_##type, (LC_this)->LC_VD_CV, LC_MC_##type(0x1)); \
            } \
          } \
        } \
      } \
    } \
  } \
  (LC_this)->LC_VD_QU = LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_GE(LC_TD_##type, (LC_this)->LC_VD_CV, (LC_this)->LC_VD_PV)); \
  (LC_this)->LC_VD_QD = LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_LE(LC_TD_##type, (LC_this)->LC_VD_CV, LC_MC_##type(0x0)));

#else

#define _lcfu_iec61131__CTU_ANY(LC_this, type, PVmax) \
  /* Perform Edge Recognition */ \
  LC3_MSI_EDGE((LC_this)->LC_VD_CU,(LC_this)->LC_VD_CU_M) \
  \
  if (!LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_R, LC_EL_true)) \
  { \
    if (LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_CU, LC_EL_true)) \
    { \
      if (LC_MF_COMPARE_LT(LC_TD_##type, (LC_this)->LC_VD_CV, PVmax)) \
      { \
        (LC_this)->LC_VD_CV = LC_MF_NUMERIC_ADD(LC_TD_##type, (LC_this)->LC_VD_CV, LC_MC_##type(0x1)); \
      } \
    } \
  } \
  else \
  { \
    (LC_this)->LC_VD_CV = LC_MC_##type(0x0); \
  } \
  (LC_this)->LC_VD_Q = LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_GE(LC_TD_##type, (LC_this)->LC_VD_CV, (LC_this)->LC_VD_PV));

#define _lcfu_iec61131__CTD_ANY(LC_this, type, PVmin) \
  /* Perform Edge Recognition */ \
  LC3_MSI_EDGE((LC_this)->LC_VD_CD,(LC_this)->LC_VD_CD_M) \
  \
  if (!LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_LD, LC_EL_true)) \
  { \
    if (LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_CD, LC_EL_true)) \
    { \
      if (LC_MF_COMPARE_GT(LC_TD_##type, (LC_this)->LC_VD_CV, PVmin)) \
      { \
        (LC_this)->LC_VD_CV = LC_MF_NUMERIC_SUB(LC_TD_##type, (LC_this)->LC_VD_CV, LC_MC_##type(0x1)); \
      } \
    } \
  } \
  else \
  { \
    (LC_this)->LC_VD_CV = (LC_this)->LC_VD_PV; \
  } \
  (LC_this)->LC_VD_Q = LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_LE(LC_TD_##type, (LC_this)->LC_VD_CV, LC_MC_##type(0x0)));

#define _lcfu_iec61131__CTUD_ANY(LC_this, type, PVmax, PVmin) \
  /* Perform Edge Recognition */ \
  LC3_MSI_EDGE((LC_this)->LC_VD_CU,(LC_this)->LC_VD_CU_M) \
  LC3_MSI_EDGE((LC_this)->LC_VD_CD,(LC_this)->LC_VD_CD_M) \
  \
  if (!LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_R, LC_EL_true)) \
  { \
    if (!LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_LD, LC_EL_true)) \
    { \
      if (LC_MF_COMPARE_EQ(LC_TD_BOOL, LC_MF_LOGICAL_AND((LC_this)->LC_VD_CU, (LC_this)->LC_VD_CD), LC_EL_false)) \
      { \
        if (!LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_CU, LC_EL_true)) \
        { \
          if (LC_MF_COMPARE_EQ(LC_TD_BOOL, (LC_this)->LC_VD_CD, LC_EL_true)) \
          { \
            if (LC_MF_COMPARE_GT(LC_TD_##type, (LC_this)->LC_VD_CV, PVmin)) \
            { \
              (LC_this)->LC_VD_CV = LC_MF_NUMERIC_SUB(LC_TD_##type, (LC_this)->LC_VD_CV, LC_MC_##type(0x1)); \
            } \
          } \
        } \
        else \
        { \
          if (LC_MF_COMPARE_LT(LC_TD_##type, (LC_this)->LC_VD_CV, PVmax)) \
          { \
            (LC_this)->LC_VD_CV = LC_MF_NUMERIC_ADD(LC_TD_##type, (LC_this)->LC_VD_CV, LC_MC_##type(0x1)); \
          } \
        } \
      } \
    } \
    else \
    { \
      (LC_this)->LC_VD_CV = (LC_this)->LC_VD_PV; \
    } \
  } \
  else \
  { \
    (LC_this)->LC_VD_CV = LC_MC_##type(0x0); \
  } \
  (LC_this)->LC_VD_QU = LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_GE(LC_TD_##type, (LC_this)->LC_VD_CV, (LC_this)->LC_VD_PV)); \
  (LC_this)->LC_VD_QD = LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_LE(LC_TD_##type, (LC_this)->LC_VD_CV, LC_MC_##type(0x0)));

#endif

#endif /* LC3CGCOUNTERIMPL_H */
