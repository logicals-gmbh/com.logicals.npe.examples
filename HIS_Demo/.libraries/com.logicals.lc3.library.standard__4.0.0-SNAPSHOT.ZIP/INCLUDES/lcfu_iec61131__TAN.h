/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function TAN for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__TAN__H
#define LC_PROT_LCFU_IEC61131__TAN__H

#include <LC3CGBase.h>
#include <LC3RTLibMath.h>       /* for tan() */

#define DEF_LC_TD_Function_TAN_ANY_REAL(realtype) \
typedef struct _LC_TD_Function_TAN__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##realtype LC_VD_TAN; \
} LCCG_StructAttrib LC_TD_Function_TAN__##realtype;

DEF_LC_TD_Function_TAN_ANY_REAL(REAL)
DEF_LC_TD_Function_TAN_ANY_REAL(LREAL)

/*                            Initialization Macro             */
#define LC_INIT_Function_TAN_ANY_REAL(p,realtype) \
{ \
  LC_INIT_##realtype(&((p)->LC_VD_TAN)); \
}

#define LC_INIT_Function_TAN__REAL(p)  LC_INIT_Function_TAN_ANY_REAL(p,REAL)
#define LC_INIT_Function_TAN__LREAL(p) LC_INIT_Function_TAN_ANY_REAL(p,LREAL)

/*
**  calculates the tangent of input in radians
**  The output shall be of the same realtype as IN.
*/
/*  Prototype */
#define lcfu_iec61131__TAN__REAL(LC_this, IN, pEPDB)  (LC_this)->LC_VD_TAN = ((LC_TD_REAL)(LC_TANF(IN)))
#define lcfu_iec61131__TAN__LREAL(LC_this, IN, pEPDB) (LC_this)->LC_VD_TAN = ((LC_TD_LREAL)(LC_TAN(IN)))

#endif
