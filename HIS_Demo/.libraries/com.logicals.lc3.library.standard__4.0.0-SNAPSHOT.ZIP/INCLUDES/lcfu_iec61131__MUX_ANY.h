/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function MUX_* for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__MUX__H
#define LC_PROT_LCFU_IEC61131__MUX__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
#define DEF_LC_TD_Function_MUX_ANY_ANY(ktype,type) \
typedef struct _LC_TD_Function_MUX_##ktype##__##type \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	LC_TD_##type LC_VD_MUX_##ktype; \
} LCCG_StructAttrib LC_TD_Function_MUX_##ktype##__##type;

DEF_LC_TD_Function_MUX_ANY_ANY(USINT,BOOL)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,BYTE)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,WORD)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,DWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,LWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,SINT)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,INT)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,DINT)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,LINT)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,USINT)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,UINT)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,UDINT)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,ULINT)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,REAL)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,LREAL)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,TIME)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,DATE)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,TOD)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,DT)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,CHAR)
DEF_LC_TD_Function_MUX_ANY_ANY(USINT,STRING)

DEF_LC_TD_Function_MUX_ANY_ANY(UINT,BOOL)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,BYTE)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,WORD)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,DWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,LWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,SINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,INT)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,DINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,LINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,USINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,UINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,UDINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,ULINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,REAL)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,LREAL)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,TIME)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,DATE)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,TOD)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,DT)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,CHAR)
DEF_LC_TD_Function_MUX_ANY_ANY(UINT,STRING)

DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,BOOL)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,BYTE)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,WORD)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,DWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,LWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,SINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,INT)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,DINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,LINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,USINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,UINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,UDINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,ULINT)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,REAL)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,LREAL)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,TIME)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,DATE)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,TOD)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,DT)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,CHAR)
DEF_LC_TD_Function_MUX_ANY_ANY(UDINT,STRING)

DEF_LC_TD_Function_MUX_ANY_ANY(SINT,BOOL)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,BYTE)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,WORD)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,DWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,LWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,SINT)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,INT)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,DINT)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,LINT)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,USINT)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,UINT)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,UDINT)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,ULINT)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,REAL)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,LREAL)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,TIME)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,DATE)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,TOD)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,DT)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,CHAR)
DEF_LC_TD_Function_MUX_ANY_ANY(SINT,STRING)

DEF_LC_TD_Function_MUX_ANY_ANY(INT,BOOL)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,BYTE)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,WORD)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,DWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,LWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,SINT)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,INT)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,DINT)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,LINT)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,USINT)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,UINT)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,UDINT)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,ULINT)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,REAL)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,LREAL)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,TIME)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,DATE)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,TOD)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,DT)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,CHAR)
DEF_LC_TD_Function_MUX_ANY_ANY(INT,STRING)

DEF_LC_TD_Function_MUX_ANY_ANY(DINT,BOOL)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,BYTE)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,WORD)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,DWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,LWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,SINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,INT)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,DINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,LINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,USINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,UINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,UDINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,ULINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,REAL)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,LREAL)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,TIME)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,DATE)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,TOD)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,DT)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,CHAR)
DEF_LC_TD_Function_MUX_ANY_ANY(DINT,STRING)

DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,BOOL)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,BYTE)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,WORD)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,DWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,LWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,SINT)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,INT)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,DINT)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,LINT)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,USINT)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,UINT)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,UDINT)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,ULINT)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,REAL)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,LREAL)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,TIME)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,DATE)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,TOD)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,DT)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,CHAR)
DEF_LC_TD_Function_MUX_ANY_ANY(BYTE,STRING)

DEF_LC_TD_Function_MUX_ANY_ANY(WORD,BOOL)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,BYTE)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,WORD)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,DWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,LWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,SINT)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,INT)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,DINT)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,LINT)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,USINT)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,UINT)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,UDINT)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,ULINT)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,REAL)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,LREAL)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,TIME)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,DATE)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,TOD)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,DT)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,CHAR)
DEF_LC_TD_Function_MUX_ANY_ANY(WORD,STRING)

DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,BOOL)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,BYTE)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,WORD)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,DWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,LWORD)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,SINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,INT)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,DINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,LINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,USINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,UINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,UDINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,ULINT)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,REAL)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,LREAL)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,TIME)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,DATE)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,TOD)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,DT)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,CHAR)
DEF_LC_TD_Function_MUX_ANY_ANY(DWORD,STRING)

/*                            Initialization Macro             */
#define LC_INIT_Function_MUX_ANY_ANY(p,ktype,type) \
{ \
	LC_INIT_##type(&((p)->LC_VD_MUX_##ktype)); \
}

#define LC_INIT_Function_MUX_USINT__BOOL(p)   LC_INIT_Function_MUX_ANY_ANY(p,USINT,BOOL)
#define LC_INIT_Function_MUX_USINT__SINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,USINT,SINT)
#define LC_INIT_Function_MUX_USINT__INT(p)    LC_INIT_Function_MUX_ANY_ANY(p,USINT,INT)
#define LC_INIT_Function_MUX_USINT__DINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,USINT,DINT)
#define LC_INIT_Function_MUX_USINT__LINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,USINT,LINT)
#define LC_INIT_Function_MUX_USINT__USINT(p)  LC_INIT_Function_MUX_ANY_ANY(p,USINT,USINT)
#define LC_INIT_Function_MUX_USINT__UINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,USINT,UINT)
#define LC_INIT_Function_MUX_USINT__UDINT(p)  LC_INIT_Function_MUX_ANY_ANY(p,USINT,UDINT)
#define LC_INIT_Function_MUX_USINT__ULINT(p)  LC_INIT_Function_MUX_ANY_ANY(p,USINT,ULINT)
#define LC_INIT_Function_MUX_USINT__BYTE(p)   LC_INIT_Function_MUX_ANY_ANY(p,USINT,BYTE)
#define LC_INIT_Function_MUX_USINT__WORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,USINT,WORD)
#define LC_INIT_Function_MUX_USINT__DWORD(p)  LC_INIT_Function_MUX_ANY_ANY(p,USINT,DWORD)
#define LC_INIT_Function_MUX_USINT__LWORD(p)  LC_INIT_Function_MUX_ANY_ANY(p,USINT,LWORD)
#define LC_INIT_Function_MUX_USINT__REAL(p)   LC_INIT_Function_MUX_ANY_ANY(p,USINT,REAL)
#define LC_INIT_Function_MUX_USINT__LREAL(p)  LC_INIT_Function_MUX_ANY_ANY(p,USINT,LREAL)
#define LC_INIT_Function_MUX_USINT__TIME(p)   LC_INIT_Function_MUX_ANY_ANY(p,USINT,TIME)
#define LC_INIT_Function_MUX_USINT__DATE(p)   LC_INIT_Function_MUX_ANY_ANY(p,USINT,DATE)
#define LC_INIT_Function_MUX_USINT__TOD(p)    LC_INIT_Function_MUX_ANY_ANY(p,USINT,TOD)
#define LC_INIT_Function_MUX_USINT__DT(p)     LC_INIT_Function_MUX_ANY_ANY(p,USINT,DT)
#define LC_INIT_Function_MUX_USINT__CHAR(p)   LC_INIT_Function_MUX_ANY_ANY(p,USINT,CHAR)
#define LC_INIT_Function_MUX_USINT__STRING(p) LC_INIT_Function_MUX_ANY_ANY(p,USINT,STRING)

#define LC_INIT_Function_MUX_UINT__BOOL(p)    LC_INIT_Function_MUX_ANY_ANY(p,UINT,BOOL)
#define LC_INIT_Function_MUX_UINT__SINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,UINT,SINT)
#define LC_INIT_Function_MUX_UINT__INT(p)     LC_INIT_Function_MUX_ANY_ANY(p,UINT,INT)
#define LC_INIT_Function_MUX_UINT__DINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,UINT,DINT)
#define LC_INIT_Function_MUX_UINT__LINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,UINT,LINT)
#define LC_INIT_Function_MUX_UINT__USINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,UINT,USINT)
#define LC_INIT_Function_MUX_UINT__UINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,UINT,UINT)
#define LC_INIT_Function_MUX_UINT__UDINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,UINT,UDINT)
#define LC_INIT_Function_MUX_UINT__ULINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,UINT,ULINT)
#define LC_INIT_Function_MUX_UINT__BYTE(p)    LC_INIT_Function_MUX_ANY_ANY(p,UINT,BYTE)
#define LC_INIT_Function_MUX_UINT__WORD(p)    LC_INIT_Function_MUX_ANY_ANY(p,UINT,WORD)
#define LC_INIT_Function_MUX_UINT__DWORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,UINT,DWORD)
#define LC_INIT_Function_MUX_UINT__LWORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,UINT,LWORD)
#define LC_INIT_Function_MUX_UINT__REAL(p)    LC_INIT_Function_MUX_ANY_ANY(p,UINT,REAL)
#define LC_INIT_Function_MUX_UINT__LREAL(p)   LC_INIT_Function_MUX_ANY_ANY(p,UINT,LREAL)
#define LC_INIT_Function_MUX_UINT__TIME(p)    LC_INIT_Function_MUX_ANY_ANY(p,UINT,TIME)
#define LC_INIT_Function_MUX_UINT__DATE(p)    LC_INIT_Function_MUX_ANY_ANY(p,UINT,DATE)
#define LC_INIT_Function_MUX_UINT__TOD(p)     LC_INIT_Function_MUX_ANY_ANY(p,UINT,TOD)
#define LC_INIT_Function_MUX_UINT__DT(p)      LC_INIT_Function_MUX_ANY_ANY(p,UINT,DT)
#define LC_INIT_Function_MUX_UINT__CHAR(p)    LC_INIT_Function_MUX_ANY_ANY(p,UINT,CHAR)
#define LC_INIT_Function_MUX_UINT__STRING(p)  LC_INIT_Function_MUX_ANY_ANY(p,UINT,STRING)

#define LC_INIT_Function_MUX_UDINT__BOOL(p)   LC_INIT_Function_MUX_ANY_ANY(p,UDINT,BOOL)
#define LC_INIT_Function_MUX_UDINT__SINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,UDINT,SINT)
#define LC_INIT_Function_MUX_UDINT__INT(p)    LC_INIT_Function_MUX_ANY_ANY(p,UDINT,INT)
#define LC_INIT_Function_MUX_UDINT__DINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,UDINT,DINT)
#define LC_INIT_Function_MUX_UDINT__LINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,UDINT,LINT)
#define LC_INIT_Function_MUX_UDINT__USINT(p)  LC_INIT_Function_MUX_ANY_ANY(p,UDINT,USINT)
#define LC_INIT_Function_MUX_UDINT__UINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,UDINT,UINT)
#define LC_INIT_Function_MUX_UDINT__UDINT(p)  LC_INIT_Function_MUX_ANY_ANY(p,UDINT,UDINT)
#define LC_INIT_Function_MUX_UDINT__ULINT(p)  LC_INIT_Function_MUX_ANY_ANY(p,UDINT,ULINT)
#define LC_INIT_Function_MUX_UDINT__BYTE(p)   LC_INIT_Function_MUX_ANY_ANY(p,UDINT,BYTE)
#define LC_INIT_Function_MUX_UDINT__WORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,UDINT,WORD)
#define LC_INIT_Function_MUX_UDINT__DWORD(p)  LC_INIT_Function_MUX_ANY_ANY(p,UDINT,DWORD)
#define LC_INIT_Function_MUX_UDINT__LWORD(p)  LC_INIT_Function_MUX_ANY_ANY(p,UDINT,LWORD)
#define LC_INIT_Function_MUX_UDINT__REAL(p)   LC_INIT_Function_MUX_ANY_ANY(p,UDINT,REAL)
#define LC_INIT_Function_MUX_UDINT__LREAL(p)  LC_INIT_Function_MUX_ANY_ANY(p,UDINT,LREAL)
#define LC_INIT_Function_MUX_UDINT__TIME(p)   LC_INIT_Function_MUX_ANY_ANY(p,UDINT,TIME)
#define LC_INIT_Function_MUX_UDINT__DATE(p)   LC_INIT_Function_MUX_ANY_ANY(p,UDINT,DATE)
#define LC_INIT_Function_MUX_UDINT__TOD(p)    LC_INIT_Function_MUX_ANY_ANY(p,UDINT,TOD)
#define LC_INIT_Function_MUX_UDINT__DT(p)     LC_INIT_Function_MUX_ANY_ANY(p,UDINT,DT)
#define LC_INIT_Function_MUX_UDINT__CHAR(p)   LC_INIT_Function_MUX_ANY_ANY(p,UDINT,CHAR)
#define LC_INIT_Function_MUX_UDINT__STRING(p) LC_INIT_Function_MUX_ANY_ANY(p,UDINT,STRING)

#define LC_INIT_Function_MUX_SINT__BOOL(p)    LC_INIT_Function_MUX_ANY_ANY(p,SINT,BOOL)
#define LC_INIT_Function_MUX_SINT__SINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,SINT,SINT)
#define LC_INIT_Function_MUX_SINT__INT(p)     LC_INIT_Function_MUX_ANY_ANY(p,SINT,INT)
#define LC_INIT_Function_MUX_SINT__DINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,SINT,DINT)
#define LC_INIT_Function_MUX_SINT__LINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,SINT,LINT)
#define LC_INIT_Function_MUX_SINT__USINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,SINT,USINT)
#define LC_INIT_Function_MUX_SINT__UINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,SINT,UINT)
#define LC_INIT_Function_MUX_SINT__UDINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,SINT,UDINT)
#define LC_INIT_Function_MUX_SINT__ULINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,SINT,ULINT)
#define LC_INIT_Function_MUX_SINT__BYTE(p)    LC_INIT_Function_MUX_ANY_ANY(p,SINT,BYTE)
#define LC_INIT_Function_MUX_SINT__WORD(p)    LC_INIT_Function_MUX_ANY_ANY(p,SINT,WORD)
#define LC_INIT_Function_MUX_SINT__DWORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,SINT,DWORD)
#define LC_INIT_Function_MUX_SINT__LWORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,SINT,LWORD)
#define LC_INIT_Function_MUX_SINT__REAL(p)    LC_INIT_Function_MUX_ANY_ANY(p,SINT,REAL)
#define LC_INIT_Function_MUX_SINT__LREAL(p)   LC_INIT_Function_MUX_ANY_ANY(p,SINT,LREAL)
#define LC_INIT_Function_MUX_SINT__TIME(p)    LC_INIT_Function_MUX_ANY_ANY(p,SINT,TIME)
#define LC_INIT_Function_MUX_SINT__DATE(p)    LC_INIT_Function_MUX_ANY_ANY(p,SINT,DATE)
#define LC_INIT_Function_MUX_SINT__TOD(p)     LC_INIT_Function_MUX_ANY_ANY(p,SINT,TOD)
#define LC_INIT_Function_MUX_SINT__DT(p)      LC_INIT_Function_MUX_ANY_ANY(p,SINT,DT)
#define LC_INIT_Function_MUX_SINT__CHAR(p)    LC_INIT_Function_MUX_ANY_ANY(p,SINT,CHAR)
#define LC_INIT_Function_MUX_SINT__STRING(p)  LC_INIT_Function_MUX_ANY_ANY(p,SINT,STRING)

#define LC_INIT_Function_MUX_INT__BOOL(p)     LC_INIT_Function_MUX_ANY_ANY(p,INT,BOOL)
#define LC_INIT_Function_MUX_INT__SINT(p)     LC_INIT_Function_MUX_ANY_ANY(p,INT,SINT)
#define LC_INIT_Function_MUX_INT__INT(p)      LC_INIT_Function_MUX_ANY_ANY(p,INT,INT)
#define LC_INIT_Function_MUX_INT__DINT(p)     LC_INIT_Function_MUX_ANY_ANY(p,INT,DINT)
#define LC_INIT_Function_MUX_INT__LINT(p)     LC_INIT_Function_MUX_ANY_ANY(p,INT,LINT)
#define LC_INIT_Function_MUX_INT__USINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,INT,USINT)
#define LC_INIT_Function_MUX_INT__UINT(p)     LC_INIT_Function_MUX_ANY_ANY(p,INT,UINT)
#define LC_INIT_Function_MUX_INT__UDINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,INT,UDINT)
#define LC_INIT_Function_MUX_INT__ULINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,INT,ULINT)
#define LC_INIT_Function_MUX_INT__BYTE(p)     LC_INIT_Function_MUX_ANY_ANY(p,INT,BYTE)
#define LC_INIT_Function_MUX_INT__WORD(p)     LC_INIT_Function_MUX_ANY_ANY(p,INT,WORD)
#define LC_INIT_Function_MUX_INT__DWORD(p)    LC_INIT_Function_MUX_ANY_ANY(p,INT,DWORD)
#define LC_INIT_Function_MUX_INT__LWORD(p)    LC_INIT_Function_MUX_ANY_ANY(p,INT,LWORD)
#define LC_INIT_Function_MUX_INT__REAL(p)     LC_INIT_Function_MUX_ANY_ANY(p,INT,REAL)
#define LC_INIT_Function_MUX_INT__LREAL(p)    LC_INIT_Function_MUX_ANY_ANY(p,INT,LREAL)
#define LC_INIT_Function_MUX_INT__TIME(p)     LC_INIT_Function_MUX_ANY_ANY(p,INT,TIME)
#define LC_INIT_Function_MUX_INT__DATE(p)     LC_INIT_Function_MUX_ANY_ANY(p,INT,DATE)
#define LC_INIT_Function_MUX_INT__TOD(p)      LC_INIT_Function_MUX_ANY_ANY(p,INT,TOD)
#define LC_INIT_Function_MUX_INT__DT(p)       LC_INIT_Function_MUX_ANY_ANY(p,INT,DT)
#define LC_INIT_Function_MUX_INT__CHAR(p)     LC_INIT_Function_MUX_ANY_ANY(p,INT,CHAR)
#define LC_INIT_Function_MUX_INT__STRING(p)   LC_INIT_Function_MUX_ANY_ANY(p,INT,STRING)

#define LC_INIT_Function_MUX_DINT__BOOL(p)    LC_INIT_Function_MUX_ANY_ANY(p,DINT,BOOL)
#define LC_INIT_Function_MUX_DINT__SINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,DINT,SINT)
#define LC_INIT_Function_MUX_DINT__INT(p)     LC_INIT_Function_MUX_ANY_ANY(p,DINT,INT)
#define LC_INIT_Function_MUX_DINT__DINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,DINT,DINT)
#define LC_INIT_Function_MUX_DINT__LINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,DINT,LINT)
#define LC_INIT_Function_MUX_DINT__USINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,DINT,USINT)
#define LC_INIT_Function_MUX_DINT__UINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,DINT,UINT)
#define LC_INIT_Function_MUX_DINT__UDINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,DINT,UDINT)
#define LC_INIT_Function_MUX_DINT__ULINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,DINT,ULINT)
#define LC_INIT_Function_MUX_DINT__BYTE(p)    LC_INIT_Function_MUX_ANY_ANY(p,DINT,BYTE)
#define LC_INIT_Function_MUX_DINT__WORD(p)    LC_INIT_Function_MUX_ANY_ANY(p,DINT,WORD)
#define LC_INIT_Function_MUX_DINT__DWORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,DINT,DWORD)
#define LC_INIT_Function_MUX_DINT__LWORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,DINT,LWORD)
#define LC_INIT_Function_MUX_DINT__REAL(p)    LC_INIT_Function_MUX_ANY_ANY(p,DINT,REAL)
#define LC_INIT_Function_MUX_DINT__LREAL(p)   LC_INIT_Function_MUX_ANY_ANY(p,DINT,LREAL)
#define LC_INIT_Function_MUX_DINT__TIME(p)    LC_INIT_Function_MUX_ANY_ANY(p,DINT,TIME)
#define LC_INIT_Function_MUX_DINT__DATE(p)    LC_INIT_Function_MUX_ANY_ANY(p,DINT,DATE)
#define LC_INIT_Function_MUX_DINT__TOD(p)     LC_INIT_Function_MUX_ANY_ANY(p,DINT,TOD)
#define LC_INIT_Function_MUX_DINT__DT(p)      LC_INIT_Function_MUX_ANY_ANY(p,DINT,DT)
#define LC_INIT_Function_MUX_DINT__CHAR(p)    LC_INIT_Function_MUX_ANY_ANY(p,DINT,CHAR)
#define LC_INIT_Function_MUX_DINT__STRING(p)  LC_INIT_Function_MUX_ANY_ANY(p,DINT,STRING)

#define LC_INIT_Function_MUX_BYTE__BOOL(p)    LC_INIT_Function_MUX_ANY_ANY(p,BYTE,BOOL)
#define LC_INIT_Function_MUX_BYTE__SINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,BYTE,SINT)
#define LC_INIT_Function_MUX_BYTE__INT(p)     LC_INIT_Function_MUX_ANY_ANY(p,BYTE,INT)
#define LC_INIT_Function_MUX_BYTE__DINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,BYTE,DINT)
#define LC_INIT_Function_MUX_BYTE__LINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,BYTE,LINT)
#define LC_INIT_Function_MUX_BYTE__USINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,BYTE,USINT)
#define LC_INIT_Function_MUX_BYTE__UINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,BYTE,UINT)
#define LC_INIT_Function_MUX_BYTE__UDINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,BYTE,UDINT)
#define LC_INIT_Function_MUX_BYTE__ULINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,BYTE,ULINT)
#define LC_INIT_Function_MUX_BYTE__BYTE(p)    LC_INIT_Function_MUX_ANY_ANY(p,BYTE,BYTE)
#define LC_INIT_Function_MUX_BYTE__WORD(p)    LC_INIT_Function_MUX_ANY_ANY(p,BYTE,WORD)
#define LC_INIT_Function_MUX_BYTE__DWORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,BYTE,DWORD)
#define LC_INIT_Function_MUX_BYTE__LWORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,BYTE,LWORD)
#define LC_INIT_Function_MUX_BYTE__REAL(p)    LC_INIT_Function_MUX_ANY_ANY(p,BYTE,REAL)
#define LC_INIT_Function_MUX_BYTE__LREAL(p)   LC_INIT_Function_MUX_ANY_ANY(p,BYTE,LREAL)
#define LC_INIT_Function_MUX_BYTE__TIME(p)    LC_INIT_Function_MUX_ANY_ANY(p,BYTE,TIME)
#define LC_INIT_Function_MUX_BYTE__DATE(p)    LC_INIT_Function_MUX_ANY_ANY(p,BYTE,DATE)
#define LC_INIT_Function_MUX_BYTE__TOD(p)     LC_INIT_Function_MUX_ANY_ANY(p,BYTE,TOD)
#define LC_INIT_Function_MUX_BYTE__DT(p)      LC_INIT_Function_MUX_ANY_ANY(p,BYTE,DT)
#define LC_INIT_Function_MUX_BYTE__CHAR(p)    LC_INIT_Function_MUX_ANY_ANY(p,BYTE,CHAR)
#define LC_INIT_Function_MUX_BYTE__STRING(p)  LC_INIT_Function_MUX_ANY_ANY(p,BYTE,STRING)

#define LC_INIT_Function_MUX_WORD__BOOL(p)    LC_INIT_Function_MUX_ANY_ANY(p,WORD,BOOL)
#define LC_INIT_Function_MUX_WORD__SINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,WORD,SINT)
#define LC_INIT_Function_MUX_WORD__INT(p)     LC_INIT_Function_MUX_ANY_ANY(p,WORD,INT)
#define LC_INIT_Function_MUX_WORD__DINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,WORD,DINT)
#define LC_INIT_Function_MUX_WORD__LINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,WORD,LINT)
#define LC_INIT_Function_MUX_WORD__USINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,WORD,USINT)
#define LC_INIT_Function_MUX_WORD__UINT(p)    LC_INIT_Function_MUX_ANY_ANY(p,WORD,UINT)
#define LC_INIT_Function_MUX_WORD__UDINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,WORD,UDINT)
#define LC_INIT_Function_MUX_WORD__ULINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,WORD,ULINT)
#define LC_INIT_Function_MUX_WORD__BYTE(p)    LC_INIT_Function_MUX_ANY_ANY(p,WORD,BYTE)
#define LC_INIT_Function_MUX_WORD__WORD(p)    LC_INIT_Function_MUX_ANY_ANY(p,WORD,WORD)
#define LC_INIT_Function_MUX_WORD__DWORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,WORD,DWORD)
#define LC_INIT_Function_MUX_WORD__LWORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,WORD,LWORD)
#define LC_INIT_Function_MUX_WORD__REAL(p)    LC_INIT_Function_MUX_ANY_ANY(p,WORD,REAL)
#define LC_INIT_Function_MUX_WORD__LREAL(p)   LC_INIT_Function_MUX_ANY_ANY(p,WORD,LREAL)
#define LC_INIT_Function_MUX_WORD__TIME(p)    LC_INIT_Function_MUX_ANY_ANY(p,WORD,TIME)
#define LC_INIT_Function_MUX_WORD__DATE(p)    LC_INIT_Function_MUX_ANY_ANY(p,WORD,DATE)
#define LC_INIT_Function_MUX_WORD__TOD(p)     LC_INIT_Function_MUX_ANY_ANY(p,WORD,TOD)
#define LC_INIT_Function_MUX_WORD__DT(p)      LC_INIT_Function_MUX_ANY_ANY(p,WORD,DT)
#define LC_INIT_Function_MUX_WORD__CHAR(p)    LC_INIT_Function_MUX_ANY_ANY(p,WORD,CHAR)
#define LC_INIT_Function_MUX_WORD__STRING(p)  LC_INIT_Function_MUX_ANY_ANY(p,WORD,STRING)

#define LC_INIT_Function_MUX_DWORD__BOOL(p)   LC_INIT_Function_MUX_ANY_ANY(p,DWORD,BOOL)
#define LC_INIT_Function_MUX_DWORD__SINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,DWORD,SINT)
#define LC_INIT_Function_MUX_DWORD__INT(p)    LC_INIT_Function_MUX_ANY_ANY(p,DWORD,INT)
#define LC_INIT_Function_MUX_DWORD__DINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,DWORD,DINT)
#define LC_INIT_Function_MUX_DWORD__LINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,DWORD,LINT)
#define LC_INIT_Function_MUX_DWORD__USINT(p)  LC_INIT_Function_MUX_ANY_ANY(p,DWORD,USINT)
#define LC_INIT_Function_MUX_DWORD__UINT(p)   LC_INIT_Function_MUX_ANY_ANY(p,DWORD,UINT)
#define LC_INIT_Function_MUX_DWORD__UDINT(p)  LC_INIT_Function_MUX_ANY_ANY(p,DWORD,UDINT)
#define LC_INIT_Function_MUX_DWORD__ULINT(p)  LC_INIT_Function_MUX_ANY_ANY(p,DWORD,ULINT)
#define LC_INIT_Function_MUX_DWORD__BYTE(p)   LC_INIT_Function_MUX_ANY_ANY(p,DWORD,BYTE)
#define LC_INIT_Function_MUX_DWORD__WORD(p)   LC_INIT_Function_MUX_ANY_ANY(p,DWORD,WORD)
#define LC_INIT_Function_MUX_DWORD__DWORD(p)  LC_INIT_Function_MUX_ANY_ANY(p,DWORD,DWORD)
#define LC_INIT_Function_MUX_DWORD__LWORD(p)  LC_INIT_Function_MUX_ANY_ANY(p,DWORD,LWORD)
#define LC_INIT_Function_MUX_DWORD__REAL(p)   LC_INIT_Function_MUX_ANY_ANY(p,DWORD,REAL)
#define LC_INIT_Function_MUX_DWORD__LREAL(p)  LC_INIT_Function_MUX_ANY_ANY(p,DWORD,LREAL)
#define LC_INIT_Function_MUX_DWORD__TIME(p)   LC_INIT_Function_MUX_ANY_ANY(p,DWORD,TIME)
#define LC_INIT_Function_MUX_DWORD__DATE(p)   LC_INIT_Function_MUX_ANY_ANY(p,DWORD,DATE)
#define LC_INIT_Function_MUX_DWORD__TOD(p)    LC_INIT_Function_MUX_ANY_ANY(p,DWORD,TOD)
#define LC_INIT_Function_MUX_DWORD__DT(p)     LC_INIT_Function_MUX_ANY_ANY(p,DWORD,DT)
#define LC_INIT_Function_MUX_DWORD__CHAR(p)   LC_INIT_Function_MUX_ANY_ANY(p,DWORD,CHAR)
#define LC_INIT_Function_MUX_DWORD__STRING(p) LC_INIT_Function_MUX_ANY_ANY(p,DWORD,STRING)


/* +++++ implementation support for ANY_ELEMENTARY (without CHAR/STRING) +++++++++++++++++++++++ */
/*                            helper macros                          */
#define LC_MF_MUX_SWITCH(K) switch(K) {

#if !NPE_HIS_CHANNEL2
#define LC_MF_MUX_ANY_BEGIN(ktype,K) switch(K) {
#define LC_MF_MUX_ANY_FIRST_CASE(ktype,value) case value:
#define LC_MF_MUX_ANY_NEXT_CASE(ktype,value) case value:
#define LC_MF_MUX_ANY_CASE_END break;
#define LC_MF_MUX_ANY_DEFAULT_BEGIN default:
#define LC_MF_MUX_ANY_END break; }
#else
#define LC_MF_MUX_ANY_BEGIN(ktype,K) \
  do \
  { \
    LC_TD_##ktype const LC_MUX_K = (K);
#define LC_MF_MUX_ANY_FIRST_CASE(ktype,value) \
  if (!((LC_MUX_K) != LC_MC_##ktype(value))) \
  {
#define LC_MF_MUX_ANY_NEXT_CASE(ktype,value) \
  else if (!((LC_MUX_K) != LC_MC_##ktype(value))) \
  {
#define LC_MF_MUX_ANY_CASE_END }
#define LC_MF_MUX_ANY_DEFAULT_BEGIN else {
#define LC_MF_MUX_ANY_END } } while (0)
#endif

/* Note1: since MUX is a function, the instance has been initialized immediate before calling the impl-function.
**        so there is no need to initialize it here anymore.
** Note2: since we do not know the real type of ANY we cant initialize it in none-elementary cases
** Note3: there is no need for init in case of ERROR (iec61131)
*/
#define LC_MF_MUX_ANY_DEFAULT(ktype,LC_this) \
  LC_MF_MUX_ANY_DEFAULT_BEGIN \
  LC3CGERR_SetErrorInformation(LC_this,pEPDB,LC3CGERR_ErrorId_MUX_INV_SELECTION ); \
  LC_MF_MUX_ANY_END

#define LC_MF_MUX_ANY_K_0(ktype,LC_this,IN0) \
  LC_MF_MUX_ANY_FIRST_CASE(ktype,0) \
  (LC_this)->LC_VD_MUX_##ktype = (IN0); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_1(ktype,LC_this,IN0,IN1) \
  LC_MF_MUX_ANY_K_0(ktype,LC_this,IN0) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,1) \
  (LC_this)->LC_VD_MUX_##ktype = (IN1); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_2(ktype,LC_this,IN0,IN1,IN2) \
  LC_MF_MUX_ANY_K_1(ktype,LC_this,IN0,IN1) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,2) \
  (LC_this)->LC_VD_MUX_##ktype = (IN2); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_3(ktype,LC_this,IN0,IN1,IN2,IN3) \
  LC_MF_MUX_ANY_K_2(ktype,LC_this,IN0,IN1,IN2) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,3) \
  (LC_this)->LC_VD_MUX_##ktype = (IN3); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_4(ktype,LC_this,IN0,IN1,IN2,IN3,IN4) \
  LC_MF_MUX_ANY_K_3(ktype,LC_this,IN0,IN1,IN2,IN3) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,4) \
  (LC_this)->LC_VD_MUX_##ktype = (IN4); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_5(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5) \
  LC_MF_MUX_ANY_K_4(ktype,LC_this,IN0,IN1,IN2,IN3,IN4) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,5) \
  (LC_this)->LC_VD_MUX_##ktype = (IN5); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_6(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6) \
  LC_MF_MUX_ANY_K_5(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,6) \
  (LC_this)->LC_VD_MUX_##ktype = (IN6); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_7(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7) \
  LC_MF_MUX_ANY_K_6(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,7) \
  (LC_this)->LC_VD_MUX_##ktype = (IN7); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_8(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8) \
  LC_MF_MUX_ANY_K_7(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,8) \
  (LC_this)->LC_VD_MUX_##ktype = (IN8); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_9(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9) \
  LC_MF_MUX_ANY_K_8(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,9) \
  (LC_this)->LC_VD_MUX_##ktype = (IN9); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_10(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10) \
  LC_MF_MUX_ANY_K_9(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,10) \
  (LC_this)->LC_VD_MUX_##ktype = (IN10); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_11(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11) \
  LC_MF_MUX_ANY_K_10(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,11) \
  (LC_this)->LC_VD_MUX_##ktype = (IN11); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_12(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12) \
  LC_MF_MUX_ANY_K_11(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,12) \
  (LC_this)->LC_VD_MUX_##ktype = (IN12); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_13(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13) \
  LC_MF_MUX_ANY_K_12(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,13) \
  (LC_this)->LC_VD_MUX_##ktype = (IN13); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_14(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14) \
  LC_MF_MUX_ANY_K_13(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,14) \
  (LC_this)->LC_VD_MUX_##ktype = (IN14); \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_K_15(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15) \
  LC_MF_MUX_ANY_K_14(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,15) \
  (LC_this)->LC_VD_MUX_##ktype = (IN15); \
  LC_MF_MUX_ANY_CASE_END

/*                            Implementation helper                  */
#define lcfu_iec61131__MUX_ANY__ANY__3(ktype,LC_this,K,IN0,IN1,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_1(ktype,LC_this,IN0,IN1) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__4(ktype,LC_this,K,IN0,IN1,IN2,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_2(ktype,LC_this,IN0,IN1,IN2) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__5(ktype,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_3(ktype,LC_this,IN0,IN1,IN2,IN3) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__6(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_4(ktype,LC_this,IN0,IN1,IN2,IN3,IN4) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__7(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_5(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__8(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_6(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__9(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_7(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__10(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_8(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__11(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_9(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__12(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_10(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__13(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_11(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__14(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_12(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__15(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_13(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__16(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_14(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY__17(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_K_15(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

/*                            Implementation                         */
#define lcfu_iec61131__MUX_USINT__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(USINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(USINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(USINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_USINT__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_UINT__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(UINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(UINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(UINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_UINT__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_UDINT__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(UDINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(UDINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(UDINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_SINT__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(SINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(SINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(SINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_SINT__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_INT__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(INT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(INT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(INT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_INT__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_DINT__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(DINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(DINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(DINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_DINT__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_BYTE__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(BYTE,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(BYTE,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(BYTE,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_WORD__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(WORD,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(WORD,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(WORD,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_WORD__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_DWORD__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(DWORD,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(DWORD,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(DWORD,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

/* +++++ implementation support for CHAR +++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
#define LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this) \
  default: LC_INIT_CHAR(&((LC_this)->LC_VD_MUX_##ktype)); LC3CGERR_SetErrorInformation(LC_this,pEPDB,LC3CGERR_ErrorId_MUX_INV_SELECTION ); break; }

#define LC_MF_MUX_CHAR_K_0(ktype,LC_this,IN0) \
  case 0: *((LC_this)->LC_VD_MUX_##ktype) = *(IN0); break
#define LC_MF_MUX_CHAR_K_1(ktype,LC_this,IN0,IN1) \
  LC_MF_MUX_CHAR_K_0(ktype,LC_this,IN0); \
  case 1: *((LC_this)->LC_VD_MUX_##ktype) = *(IN1); break
#define LC_MF_MUX_CHAR_K_2(ktype,LC_this,IN0,IN1,IN2) \
  LC_MF_MUX_CHAR_K_1(ktype,LC_this,IN0,IN1); \
  case 2: *((LC_this)->LC_VD_MUX_##ktype) = *(IN2); break
#define LC_MF_MUX_CHAR_K_3(ktype,LC_this,IN0,IN1,IN2,IN3) \
  LC_MF_MUX_CHAR_K_2(ktype,LC_this,IN0,IN1,IN2); \
  case 3: *((LC_this)->LC_VD_MUX_##ktype) = *(IN3); break
#define LC_MF_MUX_CHAR_K_4(ktype,LC_this,IN0,IN1,IN2,IN3,IN4) \
  LC_MF_MUX_CHAR_K_3(ktype,LC_this,IN0,IN1,IN2,IN3); \
  case 4: *((LC_this)->LC_VD_MUX_##ktype) = *(IN4); break
#define LC_MF_MUX_CHAR_K_5(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5) \
  LC_MF_MUX_CHAR_K_4(ktype,LC_this,IN0,IN1,IN2,IN3,IN4); \
  case 5: *((LC_this)->LC_VD_MUX_##ktype) = *(IN5); break
#define LC_MF_MUX_CHAR_K_6(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6) \
  LC_MF_MUX_CHAR_K_5(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5); \
  case 6: *((LC_this)->LC_VD_MUX_##ktype) = *(IN6); break
#define LC_MF_MUX_CHAR_K_7(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7) \
  LC_MF_MUX_CHAR_K_6(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6); \
  case 7: *((LC_this)->LC_VD_MUX_##ktype) = *(IN7); break
#define LC_MF_MUX_CHAR_K_8(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8) \
  LC_MF_MUX_CHAR_K_7(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7); \
  case 8: *((LC_this)->LC_VD_MUX_##ktype) = *(IN8); break
#define LC_MF_MUX_CHAR_K_9(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9) \
  LC_MF_MUX_CHAR_K_8(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8); \
  case 9: *((LC_this)->LC_VD_MUX_##ktype) = *(IN9); break
#define LC_MF_MUX_CHAR_K_10(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10) \
  LC_MF_MUX_CHAR_K_9(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9); \
  case 10: *((LC_this)->LC_VD_MUX_##ktype) = *(IN10); break
#define LC_MF_MUX_CHAR_K_11(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11) \
  LC_MF_MUX_CHAR_K_10(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10); \
  case 11: *((LC_this)->LC_VD_MUX_##ktype) = *(IN11); break
#define LC_MF_MUX_CHAR_K_12(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12) \
  LC_MF_MUX_CHAR_K_11(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11); \
  case 12: *((LC_this)->LC_VD_MUX_##ktype) = *(IN12); break
#define LC_MF_MUX_CHAR_K_13(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13) \
  LC_MF_MUX_CHAR_K_12(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12); \
  case 13: *((LC_this)->LC_VD_MUX_##ktype) = *(IN13); break
#define LC_MF_MUX_CHAR_K_14(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14) \
  LC_MF_MUX_CHAR_K_13(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13); \
  case 14: *((LC_this)->LC_VD_MUX_##ktype) = *(IN14); break
#define LC_MF_MUX_CHAR_K_15(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15) \
  LC_MF_MUX_CHAR_K_14(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14); \
  case 15: *((LC_this)->LC_VD_MUX_##ktype) = *(IN15); break

/*                            Implementation helper                  */
#define lcfu_iec61131__MUX_ANY__CHAR__3(ktype,LC_this,K,IN0,IN1,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_1(ktype,LC_this,IN0,IN1); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__4(ktype,LC_this,K,IN0,IN1,IN2,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_2(ktype,LC_this,IN0,IN1,IN2); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__5(ktype,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_3(ktype,LC_this,IN0,IN1,IN2,IN3); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__6(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_4(ktype,LC_this,IN0,IN1,IN2,IN3,IN4); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__7(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_5(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__8(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_6(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__9(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_7(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__10(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_8(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__11(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_9(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__12(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_10(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__13(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_11(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__14(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_12(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__15(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_13(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__16(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_14(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__CHAR__17(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_CHAR_K_15(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15); \
  LC_MF_MUX_CHAR_DEFAULT(ktype,LC_this)

/*                            Implementation                         */
#define lcfu_iec61131__MUX_USINT__CHAR__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__3(USINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__4(USINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__5(USINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__6(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__7(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__8(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__9(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__10(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__11(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__12(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__13(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__14(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__15(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__16(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_USINT__CHAR__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__17(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_UINT__CHAR__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__3(UINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__4(UINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__5(UINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__6(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__7(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__8(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__9(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__10(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__11(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__12(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__13(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__14(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__15(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__16(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_UINT__CHAR__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__17(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_UDINT__CHAR__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__3(UDINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__4(UDINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__5(UDINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__6(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__7(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__8(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__9(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__10(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__11(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__12(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__13(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__14(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__15(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__16(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_UDINT__CHAR__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__17(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_SINT__CHAR__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__3(SINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__4(SINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__5(SINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__6(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__7(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__8(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__9(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__10(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__11(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__12(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__13(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__14(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__15(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__16(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_SINT__CHAR__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__17(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_INT__CHAR__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__3(INT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__4(INT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__5(INT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__6(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__7(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__8(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__9(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__10(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__11(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__12(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__13(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__14(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__15(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__16(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_INT__CHAR__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__17(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_DINT__CHAR__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__3(DINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__4(DINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__5(DINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__6(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__7(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__8(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__9(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__10(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__11(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__12(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__13(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__14(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__15(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__16(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_DINT__CHAR__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__17(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_BYTE__CHAR__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__3(BYTE,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__4(BYTE,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__5(BYTE,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__6(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__7(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__8(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__9(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__10(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__11(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__12(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__13(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__14(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__15(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__16(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_BYTE__CHAR__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__17(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_WORD__CHAR__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__3(WORD,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__4(WORD,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__5(WORD,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__6(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__7(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__8(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__9(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__10(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__11(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__12(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__13(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__14(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__15(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__16(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_WORD__CHAR__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__17(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_DWORD__CHAR__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__3(DWORD,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__4(DWORD,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__5(DWORD,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__6(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__7(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__8(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__9(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__10(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__11(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__12(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__13(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__14(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__15(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__16(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_DWORD__CHAR__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__CHAR__17(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

/* +++++ implementation support for STRING +++++++++++++++++++++++++++++++++++++++++++++++++++++ */
#define LC_MF_MUX_STRING_DEFAULT(ktype,LC_this) \
  default: (LC_this)->LC_VD_MUX_##ktype=LC_EMPTY_UNSIZED_STRING; LC3CGERR_SetErrorInformation(LC_this,pEPDB,LC3CGERR_ErrorId_MUX_INV_SELECTION ); break; }

#define LC_MF_MUX_STRING_COPY(ktype, LC_this, IN) LC_MOV_STRING_SIZED_OR_UNSIZED_OUTPUT(LC_this, MUX_##ktype, IN)

#define LC_MF_MUX_STRING_K_0(ktype,LC_this,IN0) \
  case 0: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN0); break
#define LC_MF_MUX_STRING_K_1(ktype,LC_this,IN0,IN1) \
  LC_MF_MUX_STRING_K_0(ktype,LC_this,IN0); \
  case 1: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN1); break
#define LC_MF_MUX_STRING_K_2(ktype,LC_this,IN0,IN1,IN2) \
  LC_MF_MUX_STRING_K_1(ktype,LC_this,IN0,IN1); \
  case 2: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN2); break
#define LC_MF_MUX_STRING_K_3(ktype,LC_this,IN0,IN1,IN2,IN3) \
  LC_MF_MUX_STRING_K_2(ktype,LC_this,IN0,IN1,IN2); \
  case 3: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN3); break
#define LC_MF_MUX_STRING_K_4(ktype,LC_this,IN0,IN1,IN2,IN3,IN4) \
  LC_MF_MUX_STRING_K_3(ktype,LC_this,IN0,IN1,IN2,IN3); \
  case 4: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN4); break
#define LC_MF_MUX_STRING_K_5(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5) \
  LC_MF_MUX_STRING_K_4(ktype,LC_this,IN0,IN1,IN2,IN3,IN4); \
  case 5: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN5); break
#define LC_MF_MUX_STRING_K_6(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6) \
  LC_MF_MUX_STRING_K_5(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5); \
  case 6: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN6); break
#define LC_MF_MUX_STRING_K_7(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7) \
  LC_MF_MUX_STRING_K_6(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6); \
  case 7: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN7); break
#define LC_MF_MUX_STRING_K_8(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8) \
  LC_MF_MUX_STRING_K_7(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7); \
  case 8: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN8); break
#define LC_MF_MUX_STRING_K_9(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9) \
  LC_MF_MUX_STRING_K_8(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8); \
  case 9: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN9); break
#define LC_MF_MUX_STRING_K_10(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10) \
  LC_MF_MUX_STRING_K_9(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9); \
  case 10: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN10); break
#define LC_MF_MUX_STRING_K_11(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11) \
  LC_MF_MUX_STRING_K_10(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10); \
  case 11: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN11); break
#define LC_MF_MUX_STRING_K_12(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12) \
  LC_MF_MUX_STRING_K_11(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11); \
  case 12: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN12); break
#define LC_MF_MUX_STRING_K_13(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13) \
  LC_MF_MUX_STRING_K_12(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12); \
  case 13: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN13); break
#define LC_MF_MUX_STRING_K_14(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14) \
  LC_MF_MUX_STRING_K_13(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13); \
  case 14: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN14); break
#define LC_MF_MUX_STRING_K_15(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15) \
  LC_MF_MUX_STRING_K_14(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14); \
  case 15: LC_MF_MUX_STRING_COPY(ktype,LC_this, IN15); break

/*                            Implementation helper                  */
#define lcfu_iec61131__MUX_ANY__STRING__3(ktype,LC_this,K,IN0,IN1,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_1(ktype,LC_this,IN0,IN1); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__4(ktype,LC_this,K,IN0,IN1,IN2,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_2(ktype,LC_this,IN0,IN1,IN2); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__5(ktype,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_3(ktype,LC_this,IN0,IN1,IN2,IN3); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__6(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_4(ktype,LC_this,IN0,IN1,IN2,IN3,IN4); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__7(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_5(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__8(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_6(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__9(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_7(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__10(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_8(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__11(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_9(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__12(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_10(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__13(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_11(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__14(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_12(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__15(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_13(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__16(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_14(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__STRING__17(ktype,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  LC_MF_MUX_SWITCH(K) \
  LC_MF_MUX_STRING_K_15(ktype,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15); \
  LC_MF_MUX_STRING_DEFAULT(ktype,LC_this)

/*                            Implementation                         */
#define lcfu_iec61131__MUX_USINT__STRING__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__3(USINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__4(USINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__5(USINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__6(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__7(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__8(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__9(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__10(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__11(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__12(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__13(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__14(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__15(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__16(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_USINT__STRING__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__17(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_UINT__STRING__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__3(UINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__4(UINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__5(UINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__6(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__7(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__8(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__9(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__10(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__11(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__12(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__13(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__14(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__15(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__16(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_UINT__STRING__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__17(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_UDINT__STRING__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__3(UDINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__4(UDINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__5(UDINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__6(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__7(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__8(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__9(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__10(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__11(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__12(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__13(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__14(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__15(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__16(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_UDINT__STRING__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__17(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_SINT__STRING__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__3(SINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__4(SINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__5(SINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__6(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__7(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__8(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__9(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__10(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__11(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__12(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__13(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__14(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__15(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__16(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_SINT__STRING__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__17(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_INT__STRING__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__3(INT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__4(INT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__5(INT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__6(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__7(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__8(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__9(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__10(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__11(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__12(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__13(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__14(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__15(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__16(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_INT__STRING__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__17(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_DINT__STRING__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__3(DINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__4(DINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__5(DINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__6(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__7(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__8(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__9(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__10(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__11(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__12(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__13(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__14(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__15(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__16(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_DINT__STRING__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__17(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_BYTE__STRING__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__3(BYTE,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__4(BYTE,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__5(BYTE,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__6(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__7(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__8(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__9(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__10(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__11(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__12(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__13(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__14(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__15(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__16(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_BYTE__STRING__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__17(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_WORD__STRING__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__3(WORD,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__4(WORD,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__5(WORD,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__6(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__7(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__8(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__9(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__10(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__11(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__12(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__13(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__14(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__15(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__16(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_WORD__STRING__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__17(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_DWORD__STRING__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__3(DWORD,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__4(DWORD,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__5(DWORD,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__6(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__7(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__8(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__9(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__10(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__11(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__12(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__13(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__14(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__15(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__16(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_DWORD__STRING__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__STRING__17(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

/* support for refto elementary datatypes (references) ------------- */
#define LC_TD_IMPL__MUX__REF(ktype,stType, cType) \
struct \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	cType* LC_VD_MUX_##ktype; \
} LCCG_StructAttrib


#define LC_TD_IMPL__MUX_SINT__REF(stType,cType)  LC_TD_IMPL__MUX__REF(SINT,stType,cType)
#define LC_TD_IMPL__MUX_INT__REF(stType,cType)   LC_TD_IMPL__MUX__REF(INT,stType,cType)
#define LC_TD_IMPL__MUX_DINT__REF(stType,cType)  LC_TD_IMPL__MUX__REF(DINT,stType,cType)
#define LC_TD_IMPL__MUX_LINT__REF(stType,cType)  LC_TD_IMPL__MUX__REF(LINT,stType,cType)
#define LC_TD_IMPL__MUX_USINT__REF(stType,cType) LC_TD_IMPL__MUX__REF(USINT,stType,cType)
#define LC_TD_IMPL__MUX_UINT__REF(stType,cType)  LC_TD_IMPL__MUX__REF(UINT,stType,cType)
#define LC_TD_IMPL__MUX_UDINT__REF(stType,cType) LC_TD_IMPL__MUX__REF(UDINT,stType,cType)
#define LC_TD_IMPL__MUX_ULINT__REF(stType,cType) LC_TD_IMPL__MUX__REF(ULINT,stType,cType)
#define LC_TD_IMPL__MUX_BYTE__REF(stType,cType)  LC_TD_IMPL__MUX__REF(BYTE,stType,cType)
#define LC_TD_IMPL__MUX_WORD__REF(stType,cType)  LC_TD_IMPL__MUX__REF(WORD,stType,cType)
#define LC_TD_IMPL__MUX_DWORD__REF(stType,cType) LC_TD_IMPL__MUX__REF(DWORD,stType,cType)
#define LC_TD_IMPL__MUX_LWORD__REF(stType,cType) LC_TD_IMPL__MUX__REF(LWORD,stType,cType)

/*                            Initialization Macro             */
#define LC_INIT_IMPL__MUX__REF(ktype,stType,cType,p)  { (p)->LC_VD_MUX_##ktype = NULL; }

#define LC_INIT_IMPL__MUX_SINT__REF(stType,cType, p)  LC_INIT_IMPL__MUX__REF(SINT,stType,cType,p)
#define LC_INIT_IMPL__MUX_INT__REF(stType,cType, p)   LC_INIT_IMPL__MUX__REF(INT,stType,cType,p)
#define LC_INIT_IMPL__MUX_DINT__REF(stType,cType, p)  LC_INIT_IMPL__MUX__REF(DINT,stType,cType,p)
#define LC_INIT_IMPL__MUX_LINT__REF(stType,cType, p)  LC_INIT_IMPL__MUX__REF(LINT,stType,cType,p)

#define LC_INIT_IMPL__MUX_USINT__REF(stType,cType, p) LC_INIT_IMPL__MUX__REF(USINT,stType,cType,p)
#define LC_INIT_IMPL__MUX_UINT__REF(stType,cType, p)  LC_INIT_IMPL__MUX__REF(UINT,stType,cType,p)
#define LC_INIT_IMPL__MUX_UDINT__REF(stType,cType, p) LC_INIT_IMPL__MUX__REF(UDINT,stType,cType,p)
#define LC_INIT_IMPL__MUX_ULINT__REF(stType,cType, p) LC_INIT_IMPL__MUX__REF(ULINT,stType,cType,p)

#define LC_INIT_IMPL__MUX_BYTE__REF(stType,cType, p)  LC_INIT_IMPL__MUX__REF(BYTE,stType,cType,p)
#define LC_INIT_IMPL__MUX_WORD__REF(stType,cType, p)  LC_INIT_IMPL__MUX__REF(WORD,stType,cType,p)
#define LC_INIT_IMPL__MUX_DWORD__REF(stType,cType, p) LC_INIT_IMPL__MUX__REF(DWORD,stType,cType,p)
#define LC_INIT_IMPL__MUX_LWORD__REF(stType,cType, p) LC_INIT_IMPL__MUX__REF(LWORD,stType,cType,p

/*                            Impl (not inlined)               */
#define lcfu_iec61131__MUX_INT__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(INT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(INT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(INT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)


#define lcfu_iec61131__MUX_USINT__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(USINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(USINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(USINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_USINT__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(USINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_UINT__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(UINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(UINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(UINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_UINT__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(UINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_UDINT__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(UDINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(UDINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(UDINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_UDINT__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(UDINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_ULINT__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(ULINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(ULINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(ULINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(ULINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(ULINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(ULINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(ULINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(ULINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(ULINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(ULINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(ULINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(ULINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(ULINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(ULINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_ULINT__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(ULINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_SINT__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(SINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(SINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(SINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_SINT__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(SINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_INT__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(INT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(INT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(INT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_INT__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(INT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_DINT__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(DINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(DINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(DINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_DINT__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(DINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_LINT__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(LINT,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(LINT,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(LINT,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(LINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(LINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(LINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(LINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(LINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(LINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(LINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(LINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(LINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(LINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(LINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_LINT__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(LINT,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_BYTE__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(BYTE,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(BYTE,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(BYTE,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_BYTE__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(BYTE,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_WORD__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(WORD,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(WORD,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(WORD,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_WORD__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(WORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_DWORD__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(DWORD,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(DWORD,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(DWORD,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_DWORD__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(DWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_LWORD__REF__ANY__3(LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__3(LWORD,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__4(LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__4(LWORD,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__5(LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__5(LWORD,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__6(LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__6(LWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__7(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__7(LWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__8(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__8(LWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__9(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__9(LWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__10(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__10(LWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__11(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__11(LWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__12(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__12(LWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__13(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__13(LWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__14(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__14(LWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__15(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__15(LWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__16(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__16(LWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_LWORD__REF__ANY__17(LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY__17(LWORD,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

/* +++++ implementation (TYPE, Init) for STRUCT, ARRAY, REF +++++++++++++++++++++++++++++++++++++++++ */
#define LC_TD_IMPL__MUX__DERIVED(ktype,stType, cType) \
struct \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	cType LC_VD_MUX_##ktype; \
} LCCG_StructAttrib

#define LC_TD_IMPL__MUX__ARRAY(ktype,stType, cType, dimension) \
struct \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	cType LC_VD_MUX_##ktype[LC_MF_ARRAY_1_SIZE(dimension)]; \
} LCCG_StructAttrib

#define LC_TD_IMPL__MUX__REF__DERIVED(ktype,stType, cType) \
struct \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	cType* LC_VD_MUX_##ktype; \
} LCCG_StructAttrib

#define LC_TD_IMPL__MUX__REF__ARRAY(ktype,stType, cType, dimension) \
struct \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	cType (* LC_VD_MUX_##ktype)[LC_MF_ARRAY_1_SIZE(dimension)]; \
} LCCG_StructAttrib

#define LC_TD_IMPL__MUX_SINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__DERIVED(SINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_INT__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__DERIVED(INT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_DINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__DERIVED(DINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_LINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__DERIVED(LINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_USINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__DERIVED(USINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_UINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__DERIVED(UINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_UDINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__DERIVED(UDINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_ULINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__DERIVED(ULINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_BYTE__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__DERIVED(BYTE,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_WORD__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__DERIVED(WORD,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_DWORD__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__DERIVED(DWORD,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_LWORD__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__DERIVED(LWORD,DataTypeStructName, LCTDDataTypeStructName)

#define LC_TD_IMPL__MUX_SINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__ARRAY(SINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_INT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__ARRAY(INT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_DINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__ARRAY(DINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_LINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__ARRAY(LINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_USINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__ARRAY(USINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_UINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__ARRAY(UINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_UDINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__ARRAY(UDINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_ULINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__ARRAY(ULINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_BYTE__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__ARRAY(BYTE,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_WORD__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__ARRAY(WORD,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_DWORD__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__ARRAY(DWORD,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_LWORD__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__ARRAY(LWORD,DataTypeStructName, LCTDDataTypeStructName,dim)

#define LC_TD_IMPL__MUX_SINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__REF__DERIVED(SINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_INT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__REF__DERIVED(INT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_DINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__REF__DERIVED(DINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_LINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__REF__DERIVED(LINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_USINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__REF__DERIVED(USINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_UINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__REF__DERIVED(UINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_UDINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__REF__DERIVED(UDINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_ULINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__REF__DERIVED(ULINT,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_BYTE__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__REF__DERIVED(BYTE,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_WORD__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__REF__DERIVED(WORD,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_DWORD__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__REF__DERIVED(DWORD,DataTypeStructName, LCTDDataTypeStructName)
#define LC_TD_IMPL__MUX_LWORD__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName) LC_TD_IMPL__MUX__REF__DERIVED(LWORD,DataTypeStructName, LCTDDataTypeStructName)

#define LC_TD_IMPL__MUX_SINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__REF__ARRAY(SINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_INT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__REF__ARRAY(INT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_DINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__REF__ARRAY(DINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_LINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__REF__ARRAY(LINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_USINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__REF__ARRAY(USINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_UINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__REF__ARRAY(UINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_UDINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__REF__ARRAY(UDINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_ULINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__REF__ARRAY(ULINT,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_BYTE__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__REF__ARRAY(BYTE,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_WORD__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__REF__ARRAY(WORD,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_DWORD__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__REF__ARRAY(DWORD,DataTypeStructName, LCTDDataTypeStructName,dim)
#define LC_TD_IMPL__MUX_LWORD__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,dim) LC_TD_IMPL__MUX__REF__ARRAY(LWORD,DataTypeStructName, LCTDDataTypeStructName,dim)

/*                            Initialization Macro             */
#define LC_INIT_IMPL__MUX__DERIVED(ktype,stType, cType, p)               LC_INIT_##stType(&((p)->LC_VD_MUX_##ktype));
#define LC_INIT_IMPL__MUX__ARRAY(ktype,stType, cType, dimension, p)      LC_INIT_ARRAY(&((p)->LC_VD_MUX_##ktype), stType, LC_MF_ARRAY_1_SIZE(dimension));
#define LC_INIT_IMPL__MUX__REF__DERIVED(ktype,stType, cType, p)          LC_INIT_IMPL__MUX_##ktype##__REF(stType, cType, p)
#define LC_INIT_IMPL__MUX__REF__ARRAY(ktype,stType, cType, dimension, p) LC_INIT_IMPL__MUX_##ktype##__REF(stType, cType, p)

#define LC_INIT_IMPL__MUX_SINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__DERIVED(SINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_INT__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__DERIVED(INT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_DINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__DERIVED(DINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_LINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__DERIVED(LINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_USINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__DERIVED(USINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_UINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__DERIVED(UINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_UDINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__DERIVED(UDINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_ULINT__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__DERIVED(ULINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_BYTE__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__DERIVED(BYTE,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_WORD__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__DERIVED(WORD,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_DWORD__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__DERIVED(DWORD,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_LWORD__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__DERIVED(LWORD,DataTypeStructName, LCTDDataTypeStructName,p)

#define LC_INIT_IMPL__MUX_SINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__ARRAY(SINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_INT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__ARRAY(INT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_DINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__ARRAY(DINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_LINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__ARRAY(LINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_USINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__ARRAY(USINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_UINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__ARRAY(UINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_UDINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__ARRAY(UDINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_ULINT__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__ARRAY(ULINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_BYTE__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__ARRAY(BYTE,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_WORD__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__ARRAY(WORD,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_DWORD__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__ARRAY(DWORD,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_LWORD__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__ARRAY(LWORD,DataTypeStructName, LCTDDataTypeStructName,p,dim)

#define LC_INIT_IMPL__MUX_SINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__REF__DERIVED(SINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_INT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__REF__DERIVED(INT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_DINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__REF__DERIVED(DINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_LINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__REF__DERIVED(LINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_USINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__REF__DERIVED(USINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_UINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__REF__DERIVED(UINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_UDINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__REF__DERIVED(UDINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_ULINT__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__REF__DERIVED(ULINT,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_BYTE__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__REF__DERIVED(BYTE,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_WORD__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__REF__DERIVED(WORD,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_DWORD__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__REF__DERIVED(DWORD,DataTypeStructName, LCTDDataTypeStructName,p)
#define LC_INIT_IMPL__MUX_LWORD__REF__DERIVED(DataTypeStructName, LCTDDataTypeStructName,p) LC_INIT_IMPL__MUX__REF__DERIVED(LWORD,DataTypeStructName, LCTDDataTypeStructName,p)

#define LC_INIT_IMPL__MUX_SINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__REF__ARRAY(SINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_INT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__REF__ARRAY(INT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_DINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__REF__ARRAY(DINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_LINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__REF__ARRAY(LINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_USINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__REF__ARRAY(USINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_UINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__REF__ARRAY(UINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_UDINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__REF__ARRAY(UDINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_ULINT__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__REF__ARRAY(ULINT,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_BYTE__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__REF__ARRAY(BYTE,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_WORD__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__REF__ARRAY(WORD,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_DWORD__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__REF__ARRAY(DWORD,DataTypeStructName, LCTDDataTypeStructName,p,dim)
#define LC_INIT_IMPL__MUX_LWORD__REF__ARRAY(DataTypeStructName, LCTDDataTypeStructName,p,dim) LC_INIT_IMPL__MUX__REF__ARRAY(LWORD,DataTypeStructName, LCTDDataTypeStructName,p,dim)

#define LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN,ctype,dim) LC_ASSIGN_ARRAY_VAR((LC_this)->LC_VD_MUX_##ktype[0],(IN)[0],ctype,LC_MF_ARRAY_1_SIZE(dim));

#define LC_MF_MUX_ANY_ARRAY_K_0(ktype,ctype,dim,LC_this,IN0) \
  LC_MF_MUX_ANY_FIRST_CASE(ktype,0) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN0,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_1(ktype,ctype,dim,LC_this,IN0,IN1) \
  LC_MF_MUX_ANY_ARRAY_K_0(ktype,ctype,dim,LC_this,IN0) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,1) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN1,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_2(ktype,ctype,dim,LC_this,IN0,IN1,IN2) \
  LC_MF_MUX_ANY_ARRAY_K_1(ktype,ctype,dim,LC_this,IN0,IN1) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,2) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN2,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_3(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3) \
  LC_MF_MUX_ANY_ARRAY_K_2(ktype,ctype,dim,LC_this,IN0,IN1,IN2) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,3) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN3,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_4(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4) \
  LC_MF_MUX_ANY_ARRAY_K_3(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,4) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN4,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_5(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5) \
  LC_MF_MUX_ANY_ARRAY_K_4(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,5) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN5,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_6(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6) \
  LC_MF_MUX_ANY_ARRAY_K_5(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,6) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN6,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_7(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7) \
  LC_MF_MUX_ANY_ARRAY_K_6(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,7) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN7,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_8(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8) \
  LC_MF_MUX_ANY_ARRAY_K_7(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,8) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN8,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_9(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9) \
  LC_MF_MUX_ANY_ARRAY_K_8(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,9) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN9,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_10(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10) \
  LC_MF_MUX_ANY_ARRAY_K_9(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,10) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN10,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_11(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11) \
  LC_MF_MUX_ANY_ARRAY_K_10(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,11) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN11,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_12(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12) \
  LC_MF_MUX_ANY_ARRAY_K_11(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,12) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN12,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_13(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13) \
  LC_MF_MUX_ANY_ARRAY_K_12(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,13) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN13,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_14(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14) \
  LC_MF_MUX_ANY_ARRAY_K_13(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,14) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN14,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END
#define LC_MF_MUX_ANY_ARRAY_K_15(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15) \
  LC_MF_MUX_ANY_ARRAY_K_14(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14) \
  LC_MF_MUX_ANY_NEXT_CASE(ktype,15) \
  LC_MF_MUX_ANY_ASSIGN_ARRAY(LC_this,ktype,IN15,ctype,dim) \
  LC_MF_MUX_ANY_CASE_END

/*                            Implementation helper                  */
#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(ktype,ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_1(ktype,ctype,dim,LC_this,IN0,IN1) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_2(ktype,ctype,dim,LC_this,IN0,IN1,IN2) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_3(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_4(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_5(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_6(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_7(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_8(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_9(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_10(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_11(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_12(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_13(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_14(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

#define lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(ktype,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  LC_MF_MUX_ANY_BEGIN(ktype,K) \
  LC_MF_MUX_ANY_ARRAY_K_15(ktype,ctype,dim,LC_this,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15) \
  LC_MF_MUX_ANY_DEFAULT(ktype,LC_this)

/*                            Implementation                         */
#define lcfu_iec61131__MUX_SINT__ARRAY__3(ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(SINT,ctype,dim,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__4(ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__5(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__6(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__7(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__8(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__9(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__10(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__11(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__12(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__13(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__14(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__15(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__16(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_SINT__ARRAY__17(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(SINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_INT__ARRAY__3(ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(INT,ctype,dim,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__4(ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__5(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__6(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__7(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__8(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__9(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__10(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__11(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__12(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__13(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__14(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__15(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__16(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_INT__ARRAY__17(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(INT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_DINT__ARRAY__3(ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(DINT,ctype,dim,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__4(ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__5(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__6(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__7(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__8(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__9(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__10(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__11(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__12(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__13(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__14(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__15(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__16(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_DINT__ARRAY__17(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(DINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_LINT__ARRAY__3(ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(LINT,ctype,dim,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__4(ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__5(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__6(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__7(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__8(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__9(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__10(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__11(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__12(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__13(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__14(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__15(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__16(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_LINT__ARRAY__17(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(LINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_USINT__ARRAY__3(ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(USINT,ctype,dim,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__4(ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__5(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__6(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__7(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__8(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__9(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__10(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__11(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__12(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__13(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__14(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__15(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__16(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_USINT__ARRAY__17(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(USINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_UINT__ARRAY__3(ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(UINT,ctype,dim,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__4(ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__5(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__6(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__7(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__8(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__9(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__10(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__11(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__12(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__13(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__14(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__15(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__16(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_UINT__ARRAY__17(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(UINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_UDINT__ARRAY__3(ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(UDINT,ctype,dim,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__4(ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__5(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__6(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__7(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__8(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__9(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__10(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__11(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__12(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__13(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__14(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__15(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__16(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_UDINT__ARRAY__17(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(UDINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_ULINT__ARRAY__3(ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(ULINT,ctype,dim,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__4(ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__5(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__6(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__7(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__8(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__9(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__10(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__11(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__12(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__13(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__14(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__15(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__16(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_ULINT__ARRAY__17(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(ULINT,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_BYTE__ARRAY__3(ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(BYTE,ctype,dim,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__4(ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__5(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__6(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__7(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__8(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__9(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__10(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__11(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__12(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__13(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__14(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__15(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__16(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_BYTE__ARRAY__17(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(BYTE,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_WORD__ARRAY__3(ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(WORD,ctype,dim,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__4(ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__5(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__6(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__7(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__8(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__9(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__10(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__11(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__12(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__13(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__14(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__15(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__16(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_WORD__ARRAY__17(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(WORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_DWORD__ARRAY__3(ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(DWORD,ctype,dim,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__4(ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__5(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__6(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__7(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__8(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__9(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__10(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__11(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__12(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__13(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__14(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__15(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__16(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_DWORD__ARRAY__17(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(DWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#define lcfu_iec61131__MUX_LWORD__ARRAY__3(ctype,dim,LC_this,K,IN0,IN1,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__3(LWORD,ctype,dim,LC_this,K,IN0,IN1,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__4(ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__4(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__5(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__5(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__6(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__6(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__7(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__7(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__8(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__8(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__9(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__9(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__10(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__10(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__11(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__11(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__12(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__12(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__13(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__13(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__14(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__14(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__15(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__15(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__16(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__16(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,pEPDB)
#define lcfu_iec61131__MUX_LWORD__ARRAY__17(ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB) \
  lcfu_iec61131__MUX_ANY__ANY_ARRAY__17(LWORD,ctype,dim,LC_this,K,IN0,IN1,IN2,IN3,IN4,IN5,IN6,IN7,IN8,IN9,IN10,IN11,IN12,IN13,IN14,IN15,pEPDB)

#endif
