/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTD_DINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTD_DINT__H
#define LC_PROT_LCFU_IEC61131__CTD_DINT__H

#include <LC3CGBase.h>
#include <LC3CGCounterImpl.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_CTD_DINT
{
  _typedef_FunctionBlock_CTD_ANY(DINT)
} LCCG_StructAttrib LC_TD_FunctionBlock_CTD_DINT;

/*                            Initialization Macro (cold start) */
#define LC_INIT_FunctionBlock_CTD_DINT(p) _INIT_FunctionBlock_CTD_ANY(DINT,p)

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_CTD_DINT(p,RF) { if (LC_WINIT_IS_NOT_RETAINED(RF)) LC_INIT_FunctionBlock_CTD_DINT(p) }


/*                            Prototype                        */
void  lcfu_iec61131__CTD_DINT(LC_TD_FunctionBlock_CTD_DINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
