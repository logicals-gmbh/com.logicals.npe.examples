/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function ROR for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__ROR__H
#define LC_PROT_LCFU_IEC61131__ROR__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
#define DEF_LC_TD_Function_ROR_ANY(type) \
typedef struct _LC_TD_Function_ROR__##type \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	LC_TD_##type LC_VD_ROR; \
} LCCG_StructAttrib LC_TD_Function_ROR__##type;

DEF_LC_TD_Function_ROR_ANY(BOOL)
DEF_LC_TD_Function_ROR_ANY(BYTE)
DEF_LC_TD_Function_ROR_ANY(WORD)
DEF_LC_TD_Function_ROR_ANY(DWORD)
DEF_LC_TD_Function_ROR_ANY(LWORD)

/*                            Initialization Macro             */
#define LC_INIT_Function_ROR_ANY(p,type) \
{ \
	LC_INIT_##type(&((p)->LC_VD_ROR)); \
}

#define LC_INIT_Function_ROR__BOOL(p)   LC_INIT_Function_ROR_ANY(p,BOOL)
#define LC_INIT_Function_ROR__BYTE(p)   LC_INIT_Function_ROR_ANY(p,BYTE)
#define LC_INIT_Function_ROR__WORD(p)   LC_INIT_Function_ROR_ANY(p,WORD)
#define LC_INIT_Function_ROR__DWORD(p)  LC_INIT_Function_ROR_ANY(p,DWORD)
#define LC_INIT_Function_ROR__LWORD(p)  LC_INIT_Function_ROR_ANY(p,LWORD)

/*                            Rotating operation               */
#if !NPE_HIS_CHANNEL2
#define LC_MF_ROR_ANY(type,IN,N) \
        (LC_TD_##type) (((IN) >> ((N) & (sizeof(LC_TD_##type)*8-1))) | ((((N) & (sizeof(LC_TD_##type)*8-1)) == 0) ? 0 : (IN) << ((sizeof(LC_TD_##type)*8 - ((N) & (sizeof(LC_TD_##type)*8-1))))))
#else

/* Avoid -n here: negating INT_MIN would overflow before the modulo reduction. */
static inline LC_TD_size_t LCmfRORRotateCount(LC_TD_INT n, LC_TD_size_t width)
{
	if (n >= (LC_TD_INT)0)
	{
		return (LC_TD_size_t)n % width;
	}
	else
	{
		const LC_TD_size_t negativeShift = ((LC_TD_size_t)(-(n + (LC_TD_INT)1)) + (LC_TD_size_t)1) % width;
		return (negativeShift == (LC_TD_size_t)0) ? (LC_TD_size_t)0 : (width - negativeShift);
	}
}

static inline uint64_t LCmfRORPow2(LC_TD_size_t exponent)
{
	uint64_t half;
	uint64_t squared;

	if (exponent == (LC_TD_size_t)0)
	{
		return (uint64_t)1;
	}

	half = LCmfRORPow2(exponent / (LC_TD_size_t)2);
	squared = half * half;
	return ((exponent % (LC_TD_size_t)2) == (LC_TD_size_t)0) ? squared : (squared * (uint64_t)2);
}

#define LC_MF_ROR_DEFINE_ANY_BIT_HELPER(type,stype) \
static inline LC_TD_##type LCmfROR_LC_TD_##type(LC_TD_##type in, LC_TD_INT n) \
{ \
	const LC_TD_size_t width = (LC_TD_size_t)(sizeof(stype) * 8u); \
	const LC_TD_size_t shift = LCmfRORRotateCount(n, width); \
	const uint64_t value = (uint64_t)((stype)in); \
	uint64_t factor; \
	uint64_t wrapFactor; \
	if (shift == (LC_TD_size_t)0) \
	{ \
		return in; \
	} \
	factor = LCmfRORPow2(shift); \
	wrapFactor = LCmfRORPow2(width - shift); \
	return (LC_TD_##type)((stype)((value / factor) + ((value % factor) * wrapFactor))); \
}

LC_MF_ROR_DEFINE_ANY_BIT_HELPER(BYTE,uint8_t)
LC_MF_ROR_DEFINE_ANY_BIT_HELPER(WORD,uint16_t)
LC_MF_ROR_DEFINE_ANY_BIT_HELPER(DWORD,uint32_t)
LC_MF_ROR_DEFINE_ANY_BIT_HELPER(LWORD,uint64_t)

#undef LC_MF_ROR_DEFINE_ANY_BIT_HELPER

#define LC_MF_ROR_ANY(type,IN,N) LCmfROR_LC_TD_##type((LC_TD_##type)(IN),(LC_TD_INT)(N))

#endif

/*                            Impl (not inlined)               */
#define lcfu_iec61131__ROR__BOOL(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_ROR = (IN)
#define lcfu_iec61131__ROR__BYTE(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_ROR = LC_MF_ROR_ANY(BYTE,IN,N)
#define lcfu_iec61131__ROR__WORD(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_ROR = LC_MF_ROR_ANY(WORD,IN,N)
#define lcfu_iec61131__ROR__DWORD(LC_this, IN, N, pEPDB) (LC_this)->LC_VD_ROR = LC_MF_ROR_ANY(DWORD,IN,N)
#define lcfu_iec61131__ROR__LWORD(LC_this, IN, N, pEPDB) (LC_this)->LC_VD_ROR = LC_MF_ROR_ANY(LWORD,IN,N)

#endif
