/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block TOF for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__TOF__H
#define LC_PROT_LCFU_IEC61131__TOF__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_TOF
{
  LC_TD_BOOL LC_VD_IN;
  LC_TD_TIME LC_VD_PT;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_Q;
  LC_TD_TIME LC_VD_ET;
  LC_TD_BOOL LC_VD_M;
  LC_TD_TIME LC_VD_STARTT;
} LCCG_StructAttrib LC_TD_FunctionBlock_TOF;

/*                            Initialization Macro (cold start) */
#define LC_INIT_FunctionBlock_TOF(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_IN)); \
  LC_INIT_TIME(&((p)->LC_VD_PT)); \
  LC_INIT_BOOL(&((p)->LC_VD_Q)); \
  LC_INIT_TIME(&((p)->LC_VD_ET)); \
  LC_INIT_TIME(&((p)->LC_VD_STARTT)); \
  LC_INIT_BOOL(&((p)->LC_VD_M)); \
}

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_TOF(p,RF) { if (LC_WINIT_IS_NOT_RETAINED(RF)) LC_INIT_FunctionBlock_TOF(p) }


/*                            Prototype                        */
void  lcfu_iec61131__TOF(LC_TD_FunctionBlock_TOF* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
