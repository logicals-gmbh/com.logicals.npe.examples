/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function EXP for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__EXP__H
#define LC_PROT_LCFU_IEC61131__EXP__H

#include <LC3CGBase.h>
#include <LC3RTLibMath.h>       /* for exp() */

#define DEF_LC_TD_Function_EXP_ANY_REAL(realtype) \
typedef struct _LC_TD_Function_EXP__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##realtype LC_VD_EXP; \
} LCCG_StructAttrib LC_TD_Function_EXP__##realtype;

DEF_LC_TD_Function_EXP_ANY_REAL(REAL)
DEF_LC_TD_Function_EXP_ANY_REAL(LREAL)

/*                            Initialization Macro             */
#define LC_INIT_Function_EXP_ANY_REAL(p,realtype) \
{ \
  LC_INIT_##realtype(&((p)->LC_VD_EXP)); \
}

#define LC_INIT_Function_EXP__REAL(p)  LC_INIT_Function_EXP_ANY_REAL(p,REAL)
#define LC_INIT_Function_EXP__LREAL(p) LC_INIT_Function_EXP_ANY_REAL(p,LREAL)

/*
**  calculates the natural exponential of input
**  The output shall be of the same realtype as IN.
*/
/*  Prototype */
#define lcfu_iec61131__EXP__REAL(LC_this, IN, pEPDB)  (LC_this)->LC_VD_EXP = ((LC_TD_REAL)(LC_EXPF(IN)))
#define lcfu_iec61131__EXP__LREAL(LC_this, IN, pEPDB) (LC_this)->LC_VD_EXP = ((LC_TD_LREAL)(LC_EXP(IN)))

#endif
