/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTUD_INT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTUD_INT__H
#define LC_PROT_LCFU_IEC61131__CTUD_INT__H

#include <LC3CGBase.h>
#include <LC3CGCounterImpl.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_CTUD_INT
{
  _typedef_FunctionBlock_CTUD_ANY(INT)
} LCCG_StructAttrib LC_TD_FunctionBlock_CTUD_INT;

/*                            Initialization Macro (cold start) */
#define LC_INIT_FunctionBlock_CTUD_INT(p) _INIT_FunctionBlock_CTUD_ANY(INT,p)

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_CTUD_INT(p,RF) { if (LC_WINIT_IS_NOT_RETAINED(RF)) LC_INIT_FunctionBlock_CTUD_INT(p) }


/*                            Prototype                        */
void  lcfu_iec61131__CTUD_INT(LC_TD_FunctionBlock_CTUD_INT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
