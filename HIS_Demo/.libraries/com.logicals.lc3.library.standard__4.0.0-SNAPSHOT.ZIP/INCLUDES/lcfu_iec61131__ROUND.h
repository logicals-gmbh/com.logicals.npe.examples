/* Copyright (C) logi.cals GmbH. All rights reserved.             */

/*
** TASK :: C implementation of rounding function ROUND for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__ROUND__H
#define LC_PROT_LCFU_IEC61131__ROUND__H

#include <LC3CGBase.h>

#define DEF_LC_TD_Function_ROUND_ANY_REAL(realtype) \
typedef struct _LC_TD_Function_ROUND__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##realtype LC_VD_ROUND; \
} LCCG_StructAttrib LC_TD_Function_ROUND__##realtype;

DEF_LC_TD_Function_ROUND_ANY_REAL(REAL)
DEF_LC_TD_Function_ROUND_ANY_REAL(LREAL)

/*                            Initialization Macro             */
#define LC_INIT_Function_ROUND_ANY_REAL(p,realtype) \
{ \
  LC_INIT_##realtype(&((p)->LC_VD_ROUND)); \
}

#define LC_INIT_Function_ROUND__REAL(p)  LC_INIT_Function_ROUND_ANY_REAL(p,REAL)
#define LC_INIT_Function_ROUND__LREAL(p) LC_INIT_Function_ROUND_ANY_REAL(p,LREAL)

/*                            Implementation helper            */
extern LC_TD_REAL LCfu_iec61131__ROUND_REAL(float value);
extern LC_TD_LREAL LCfu_iec61131__ROUND_LREAL(double value);

/*
**  Calculates the nearest integral value (rounding half-way cases away from zero) of input.
**  The output shall be of the same realtype as IN.
*/
/*  Prototype */
#define lcfu_iec61131__ROUND__REAL(LC_this, IN, pEPDB)  (LC_this)->LC_VD_ROUND = ((LC_TD_REAL)(LCfu_iec61131__ROUND_REAL(IN)))
#define lcfu_iec61131__ROUND__LREAL(LC_this, IN, pEPDB) (LC_this)->LC_VD_ROUND = ((LC_TD_LREAL)(LCfu_iec61131__ROUND_LREAL(IN)))

#endif
