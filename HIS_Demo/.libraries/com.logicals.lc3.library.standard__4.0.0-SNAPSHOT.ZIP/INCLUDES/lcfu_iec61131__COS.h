/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function COS for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__COS__H
#define LC_PROT_LCFU_IEC61131__COS__H

#include <LC3CGBase.h>
#include <LC3RTLibMath.h>       /* for cos() */

#define DEF_LC_TD_Function_COS_ANY_REAL(realtype) \
typedef struct _LC_TD_Function_COS__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##realtype LC_VD_COS; \
} LCCG_StructAttrib LC_TD_Function_COS__##realtype;

DEF_LC_TD_Function_COS_ANY_REAL(REAL)
DEF_LC_TD_Function_COS_ANY_REAL(LREAL)

/*                            Initialization Macro             */
#define LC_INIT_Function_COS_ANY_REAL(p,realtype) \
{ \
  LC_INIT_##realtype(&((p)->LC_VD_COS)); \
}

#define LC_INIT_Function_COS__REAL(p)  LC_INIT_Function_COS_ANY_REAL(p,REAL)
#define LC_INIT_Function_COS__LREAL(p) LC_INIT_Function_COS_ANY_REAL(p,LREAL)

/*
**  calculates the cosine of input in radians
**  The output shall be of the same realtype as IN.
*/
/*  Prototype */
#define lcfu_iec61131__COS__REAL(LC_this, IN, pEPDB)  (LC_this)->LC_VD_COS = ((LC_TD_REAL)(LC_COSF(IN)))
#define lcfu_iec61131__COS__LREAL(LC_this, IN, pEPDB) (LC_this)->LC_VD_COS = ((LC_TD_LREAL)(LC_COS(IN)))

#endif
