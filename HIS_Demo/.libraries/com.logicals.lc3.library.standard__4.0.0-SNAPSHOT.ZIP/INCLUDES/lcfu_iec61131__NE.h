/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function NE for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__NE__H
#define LC_PROT_LCFU_IEC61131__NE__H

#include <LC3CGAnyBitOp.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_NE
{
	LC_TD_BOOL LC_VD_ENO;
	LC_TD_BOOL LC_VD_NE;
} LCCG_StructAttrib LC_TD_Function_NE;

/*                            Initialization Macro             */
#define LC_INIT_Function_NE(p) \
{ \
	LC_INIT_BOOL(&((p)->LC_VD_NE)); \
}

/*                            Implementation of helper macros (inlined)  */

/* HIS helpers receive the concrete IEC type for the diverse implementation. */
#if NPE_HIS_ENABLED
#define LC_MF_NE_ANY_HIS(TYP,IN1,IN2) LC_MF_COMPARE_NE(TYP,(IN1),(IN2))
#define LC_MF_NE_ANY_HIS_TO_BOOL(TYP,IN1,IN2) LC_MF_EXPR_TO_BOOL(LC_MF_NE_ANY_HIS(TYP,IN1,IN2))
#endif

#define LC_MF_NE_CHAR(IN1,IN2) (LC_STRING_NE(IN1,IN2,LC_STR_CMP_MODE_CHAR))
#define LC_MF_NE_STRING(IN1,IN2) (LC_STRING_NE(LC_GET_STRING_PTR(IN1),LC_GET_STRING_PTR(IN2),LC_STR_CMP_MODE_STRING))
#define LC_MF_NE_CHAR_TO_BOOL(IN1,IN2) LC_MF_NE_CHAR(IN1,IN2)
#define LC_MF_NE_STRING_TO_BOOL(IN1,IN2) LC_MF_NE_STRING(IN1,IN2)

/* Legacy interface used when HIS code generation is disabled. */
#if !NPE_HIS_ENABLED
#define lcfu_iec61131__NE__ANY(LC_this, IN1, IN2, pEPDB) \
	(LC_this)->LC_VD_NE = ((LC_TD_BOOL)((IN1)!=(IN2)))
#endif

/* HIS interface used when HIS code generation is enabled. */
/*                            Impl (not inlined)                     */
#if NPE_HIS_ENABLED
#define lcfu_iec61131__NE__ANY__HIS(TYP, LC_this, IN1, IN2, pEPDB) \
	(LC_this)->LC_VD_NE = LC_MF_NE_ANY_HIS_TO_BOOL(TYP,IN1,IN2)
#endif

#define lcfu_iec61131__NE__CHAR(LC_this, IN1, IN2, pEPDB) \
	(LC_this)->LC_VD_NE = LC_MF_NE_CHAR_TO_BOOL(IN1,IN2)
#define lcfu_iec61131__NE__STRING(LC_this, IN1, IN2, pEPDB) \
	(LC_this)->LC_VD_NE = LC_MF_NE_STRING_TO_BOOL(IN1,IN2)

/* Legacy interface used when HIS code generation is disabled. */
#if !NPE_HIS_ENABLED
#define lcfu_iec61131__NE__ANY__INL(IN1, IN2) ((LC_TD_BOOL)((IN1)!=(IN2)))
#endif

/* HIS interface used when HIS code generation is enabled. */
/*                            Impl (inlined)                     */
#if NPE_HIS_ENABLED
#define lcfu_iec61131__NE__ANY__HIS__INL(TYP, IN1, IN2) LC_MF_NE_ANY_HIS_TO_BOOL(TYP,IN1,IN2)
#endif

#endif
