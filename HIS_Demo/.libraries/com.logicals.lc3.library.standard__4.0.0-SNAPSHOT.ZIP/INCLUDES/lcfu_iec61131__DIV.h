/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function DIV for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__DIV__H
#define LC_PROT_LCFU_IEC61131__DIV__H

#include <LC3CGBase.h>
#include <LC3CGAnyIntOp.h>
#include <LC3CGAnyBitOp.h>

/*                            Typedefs                         */
#define DEF_LC_TD_Function_DIV_ANY(type) \
typedef struct _LC_TD_Function_DIV__##type   \
{                                            \
	LC_TD_BOOL LC_VD_ENO;                \
	LC_TD_##type LC_VD_DIV;              \
} LCCG_StructAttrib LC_TD_Function_DIV__##type;

DEF_LC_TD_Function_DIV_ANY(SINT)
DEF_LC_TD_Function_DIV_ANY(INT)
DEF_LC_TD_Function_DIV_ANY(DINT)
DEF_LC_TD_Function_DIV_ANY(LINT)
DEF_LC_TD_Function_DIV_ANY(USINT)
DEF_LC_TD_Function_DIV_ANY(UINT)
DEF_LC_TD_Function_DIV_ANY(UDINT)
DEF_LC_TD_Function_DIV_ANY(ULINT)
DEF_LC_TD_Function_DIV_ANY(REAL)
DEF_LC_TD_Function_DIV_ANY(LREAL)
DEF_LC_TD_Function_DIV_ANY(TIME)

/*                            Initialization Macro             */
#define LC_INIT_Function_DIV_ANY(p,type) \
{ \
	LC_INIT_##type(&((p)->LC_VD_DIV)); \
}

#define LC_INIT_Function_DIV__SINT(p)   LC_INIT_Function_DIV_ANY(p,SINT)
#define LC_INIT_Function_DIV__INT(p)    LC_INIT_Function_DIV_ANY(p,INT)
#define LC_INIT_Function_DIV__DINT(p)   LC_INIT_Function_DIV_ANY(p,DINT)
#define LC_INIT_Function_DIV__LINT(p)   LC_INIT_Function_DIV_ANY(p,LINT)
#define LC_INIT_Function_DIV__USINT(p)  LC_INIT_Function_DIV_ANY(p,USINT)
#define LC_INIT_Function_DIV__UINT(p)   LC_INIT_Function_DIV_ANY(p,UINT)
#define LC_INIT_Function_DIV__UDINT(p)  LC_INIT_Function_DIV_ANY(p,UDINT)
#define LC_INIT_Function_DIV__ULINT(p)  LC_INIT_Function_DIV_ANY(p,ULINT)
#define LC_INIT_Function_DIV__REAL(p)   LC_INIT_Function_DIV_ANY(p,REAL)
#define LC_INIT_Function_DIV__LREAL(p)  LC_INIT_Function_DIV_ANY(p,LREAL)
#define LC_INIT_Function_DIV__TIME(p)   LC_INIT_Function_DIV_ANY(p,TIME)

/* Implementation of helper macros (inlined)  */

/* Call only after the library checks for zero divisors and signed overflow.
** Integer Channel-2 quotients are verified by the PTK; HIS TIME operators use their separate typed interface.
*/
#if NPE_HIS_CHANNEL2
#define LC_MF_DIV_QUOTIENT(TYPE,IN1,IN2) LC_MF_DIV_QUOTIENT_##TYPE(IN1,IN2)
#define LC_MF_DIV_QUOTIENT_SINT(IN1,IN2) LC_MF_NUMERIC_DIV(LC_TD_SINT,IN1,IN2)
#define LC_MF_DIV_QUOTIENT_INT(IN1,IN2) LC_MF_NUMERIC_DIV(LC_TD_INT,IN1,IN2)
#define LC_MF_DIV_QUOTIENT_DINT(IN1,IN2) LC_MF_NUMERIC_DIV(LC_TD_DINT,IN1,IN2)
#define LC_MF_DIV_QUOTIENT_LINT(IN1,IN2) LC_MF_NUMERIC_DIV(LC_TD_LINT,IN1,IN2)
#define LC_MF_DIV_QUOTIENT_USINT(IN1,IN2) LC_MF_NUMERIC_DIV(LC_TD_USINT,IN1,IN2)
#define LC_MF_DIV_QUOTIENT_UINT(IN1,IN2) LC_MF_NUMERIC_DIV(LC_TD_UINT,IN1,IN2)
#define LC_MF_DIV_QUOTIENT_UDINT(IN1,IN2) LC_MF_NUMERIC_DIV(LC_TD_UDINT,IN1,IN2)
#define LC_MF_DIV_QUOTIENT_ULINT(IN1,IN2) LC_MF_NUMERIC_DIV(LC_TD_ULINT,IN1,IN2)
#else
#define LC_MF_DIV_QUOTIENT(TYPE,IN1,IN2) ((IN1)/(IN2))
#endif

#define LC_MF_DIV_SETERR(THIS) (LC3CGERR_SetErrorInformation((THIS),pEPDB,LC3CGERR_ErrorId_DIV_BY_0))

/* Error predicates return C booleans; PTK comparisons and logical composition
** select the diverse C2 implementation while preserving short-circuit evaluation.
*/
#define LC_DIV_SIGNED_INT_OVF(IN1,IN2,TYPE) \
   LC_MF_COMPARE_AND(LC_TD_##TYPE,LC_MF_NUMERIC_EQ(LC_TD_##TYPE,(IN1),LC_IEC_##TYPE##_MIN),LC_MF_NUMERIC_EQ(LC_TD_##TYPE,(IN2),-1))
#define LC_DIV_IS_SIG_DIVERR(IN1,IN2,TYPE) \
   LC_MF_COMPARE_OR(LC_TD_##TYPE,LC_MF_NUMERIC_EQ(LC_TD_##TYPE,(IN2),0),LC_DIV_SIGNED_INT_OVF(IN1,IN2,TYPE))
#define LC_DIV_IS_USIG_DIVERR(IN1,IN2,TYPE) \
   LC_MF_NUMERIC_EQ(LC_TD_##TYPE,(IN2),0)


#define LC_MF_DIV_ANY_UINT_ERR(IN1,IN2,THIS,TYPE)   (LC_DIV_IS_USIG_DIVERR(IN1,IN2,TYPE)?LC_MF_DIV_SETERR(THIS),0:(LC_TD_##TYPE)LC_MF_DIV_QUOTIENT(TYPE,IN1,IN2))
#define LC_MF_DIV_ANY_INT_ERR(IN1,IN2,THIS,TYPE)    (LC_DIV_IS_SIG_DIVERR(IN1,IN2,TYPE)?LC_MF_DIV_SETERR(THIS),0:LC_MF_DIV_QUOTIENT(TYPE,(LC_TD_##TYPE)(IN1),(LC_TD_##TYPE)(IN2)))
#define LC_MF_DIV_REAL_ERR(IN1,IN2,THIS)            ((IN2)==0.0f?LC_MF_DIV_SETERR(THIS),0.0F:(LC_TD_REAL)((IN1)/(IN2)))
#define LC_MF_DIV_LREAL_ERR(IN1,IN2,THIS)           ((IN2)==0.0?LC_MF_DIV_SETERR(THIS),0.0:(LC_TD_LREAL)((IN1)/(IN2)))
#define LC_MF_DIV_ANY_INT_ERR_NINL(LC_this, IN1, IN2,TYPE) \
   (LC_this)->LC_VD_DIV = LC_MF_DIV_ANY_INT_ERR(IN1,IN2,(LC_this),TYPE)
#define LC_MF_DIV_ANY_UINT_ERR_NINL(LC_this, IN1, IN2,TYPE) \
   (LC_this)->LC_VD_DIV = LC_MF_DIV_ANY_UINT_ERR(IN1,IN2,(LC_this),TYPE)

#define LC_MF_DIV_REAL_ERR_NINL(LC_this, IN1, IN2) \
   (LC_this)->LC_VD_DIV = LC_MF_DIV_REAL_ERR(IN1,IN2,(LC_this))
#define LC_MF_DIV_LREAL_ERR_NINL(LC_this, IN1, IN2) \
   (LC_this)->LC_VD_DIV = LC_MF_DIV_LREAL_ERR(IN1,IN2,(LC_this))

/* Inline Impl Helper : ErrorHandling, but no Error Setting, RC=0 in case of Error */
#define LC_MF_DIV_ANY_INT_ERR_INL(IN1,IN2,TYPE)    (LC_DIV_IS_SIG_DIVERR(IN1,IN2,TYPE)?LC_MF_DIV_SETERR(LC_this),0:LC_MF_DIV_QUOTIENT(TYPE,(LC_TD_##TYPE)(IN1),(LC_TD_##TYPE)(IN2)))
#define LC_MF_DIV_ANY_UINT_ERR_INL(IN1,IN2,TYPE)   (LC_DIV_IS_USIG_DIVERR(IN1,IN2,TYPE)?LC_MF_DIV_SETERR(LC_this),0:(LC_TD_##TYPE)LC_MF_DIV_QUOTIENT(TYPE,IN1,IN2))

#define LC_MF_DIV_REAL_ERR_INL(IN1,IN2)            ((IN2)==0.0f?LC_MF_DIV_SETERR(LC_this),0.0F:(LC_TD_REAL)((IN1)/(IN2)))
#define LC_MF_DIV_LREAL_ERR_INL(IN1,IN2)           ((IN2)==0.0?LC_MF_DIV_SETERR(LC_this),0.0:(LC_TD_LREAL)((IN1)/(IN2)))

/* Impl (not inlined)                     */
#if !NPE_HIS_ENABLED
#define  lcfu_iec61131__DIV__SINT(LC_this, IN1, IN2, pEPDB)   LC_MF_DIV_ANY_INT_ERR_NINL(LC_this, IN1, IN2,SINT)
#define  lcfu_iec61131__DIV__INT(LC_this, IN1, IN2, pEPDB)    LC_MF_DIV_ANY_INT_ERR_NINL(LC_this, IN1, IN2,INT)
#define  lcfu_iec61131__DIV__DINT(LC_this, IN1, IN2, pEPDB)   LC_MF_DIV_ANY_INT_ERR_NINL(LC_this, IN1, IN2,DINT)
#define  lcfu_iec61131__DIV__LINT(LC_this, IN1, IN2, pEPDB)   LC_MF_DIV_ANY_INT_ERR_NINL(LC_this, IN1, IN2,LINT)

#define  lcfu_iec61131__DIV__USINT(LC_this, IN1, IN2, pEPDB)  LC_MF_DIV_ANY_UINT_ERR_NINL(LC_this, IN1, IN2,USINT)
#define  lcfu_iec61131__DIV__UINT(LC_this, IN1, IN2, pEPDB)   LC_MF_DIV_ANY_UINT_ERR_NINL(LC_this, IN1, IN2,UINT)
#define  lcfu_iec61131__DIV__UDINT(LC_this, IN1, IN2, pEPDB)  LC_MF_DIV_ANY_UINT_ERR_NINL(LC_this, IN1, IN2,UDINT)
#define  lcfu_iec61131__DIV__ULINT(LC_this, IN1, IN2, pEPDB)  LC_MF_DIV_ANY_UINT_ERR_NINL(LC_this, IN1, IN2,ULINT)

/* Legacy TIME function interface retained for non-HIS compatibility only. */
#define  lcfu_iec61131__DIV__TIME(LC_this, IN1, IN2, pEPDB)   LC_MF_DIV_ANY_INT_ERR_NINL(LC_this, IN1, IN2,TIME)

#define  lcfu_iec61131__DIV__REAL(LC_this, IN1, IN2, pEPDB)   LC_MF_DIV_REAL_ERR_NINL(LC_this, IN1, IN2)
#define  lcfu_iec61131__DIV__LREAL(LC_this, IN1, IN2, pEPDB)  LC_MF_DIV_LREAL_ERR_NINL(LC_this, IN1, IN2)
#endif

/* Impl (inlined)                     */
#if !NPE_HIS_ENABLED
#define  lcfu_iec61131__DIV__SINT__INL( IN1, IN2)   LC_MF_DIV_ANY_INT_ERR_INL( IN1, IN2,SINT)
#define  lcfu_iec61131__DIV__INT__INL( IN1, IN2)    LC_MF_DIV_ANY_INT_ERR_INL( IN1, IN2,INT)
#define  lcfu_iec61131__DIV__DINT__INL( IN1, IN2)   LC_MF_DIV_ANY_INT_ERR_INL( IN1, IN2,DINT)
#define  lcfu_iec61131__DIV__LINT__INL( IN1, IN2)   LC_MF_DIV_ANY_INT_ERR_INL( IN1, IN2,LINT)

#define  lcfu_iec61131__DIV__USINT__INL( IN1, IN2)  LC_MF_DIV_ANY_UINT_ERR_INL( IN1, IN2,USINT)
#define  lcfu_iec61131__DIV__UINT__INL( IN1, IN2)   LC_MF_DIV_ANY_UINT_ERR_INL( IN1, IN2,UINT)
#define  lcfu_iec61131__DIV__UDINT__INL( IN1, IN2)  LC_MF_DIV_ANY_UINT_ERR_INL( IN1, IN2,UDINT)
#define  lcfu_iec61131__DIV__ULINT__INL( IN1, IN2)  LC_MF_DIV_ANY_UINT_ERR_INL( IN1, IN2,ULINT)


#define  lcfu_iec61131__DIV__REAL__INL( IN1, IN2)   LC_MF_DIV_REAL_ERR_INL( IN1, IN2)
#define  lcfu_iec61131__DIV__LREAL__INL(IN1, IN2)   LC_MF_DIV_LREAL_ERR_INL( IN1, IN2)
#endif


/* Shared with the C2 TIME operators for REAL/LREAL divisors. */
#define LC_DIV_TIME_ORD(A,B)        (LC_TD_TIME)((B)==0?LC_MF_DIV_SETERR(LC_this),0:((A)/(B)))

/* Legacy TIME operator helpers are needed by non-HIS and HIS-C1 only. */
#if !NPE_HIS_CHANNEL2
#define LC_DIV_IS_UNSIGNED(IN)      (((IN)>0)&&(-(IN)>0))
#define LC_DIV_IS_ULL(IN)           ((sizeof(IN)==sizeof(LC_TD_ULINT))&&LC_DIV_IS_UNSIGNED(IN))
#define LC_DIV_IS_LARGE_ULL(IN)     (((LC_TD_LINT)(IN))<0)

#define LC_DIV_TIME_ULL_FIX(A,B)    (LC_TD_TIME)(LC_DIV_IS_LARGE_ULL(B)?LC_MF_DIV_SETERR(LC_this),0:(LC_DIV_TIME_ORD(A,((LC_TD_LINT)(B)))))


/* special handling because LL / ULL gives incorrect results, when the LL Value < 0 - therefore we need to know whether B's Type is ULL */
/* In this case the C norm asks A to be casted to an ULL value. So -10 div 2 should give -5, but give a large signed long value */
/* (sll)-4 / (ull)4 = 7ffffffffffffffe ! */
#define LC_DIV_TIME(A,B)            ((((A)<0)&&(LC_DIV_IS_ULL(B)))?LC_DIV_TIME_ULL_FIX(A,B):LC_DIV_TIME_ORD(A,B))
#endif /* !NPE_HIS_CHANNEL2 */

#if !NPE_HIS_ENABLED
#define  lcfu_iec61131__DIV__TIME__INL( IN1, IN2)   ((LC_TD_TIME)(LC_DIV_TIME(IN1,IN2)))
#endif

#if NPE_HIS_ENABLED
/* HIS TIME operators carry the divisor type separately from the TIME result.
** Keep C1 and non-HIS behavior unchanged. C2 checks zero in the library and
** verifies integer quotients in the PTK, including the full ULINT range.
** REAL/LREAL retain the legacy floating-point expression.
*/
#if NPE_HIS_CHANNEL2
#define LC_MF_DIV_TIME_OPERATOR_INT(TYP,IN1,IN2) \
   (LC_MF_NUMERIC_EQ(TYP,(IN2),0)?LC_MF_DIV_SETERR(LC_this),LC_MCI_DEF_TIME:LC_MF_NUMERIC_DIV_TIME(TYP,IN1,IN2))
#define LC_MF_DIV_TIME_OPERATOR_LC_TD_SINT(IN1,IN2) LC_MF_DIV_TIME_OPERATOR_INT(LC_TD_SINT,IN1,IN2)
#define LC_MF_DIV_TIME_OPERATOR_LC_TD_INT(IN1,IN2) LC_MF_DIV_TIME_OPERATOR_INT(LC_TD_INT,IN1,IN2)
#define LC_MF_DIV_TIME_OPERATOR_LC_TD_DINT(IN1,IN2) LC_MF_DIV_TIME_OPERATOR_INT(LC_TD_DINT,IN1,IN2)
#define LC_MF_DIV_TIME_OPERATOR_LC_TD_LINT(IN1,IN2) LC_MF_DIV_TIME_OPERATOR_INT(LC_TD_LINT,IN1,IN2)
#define LC_MF_DIV_TIME_OPERATOR_LC_TD_USINT(IN1,IN2) LC_MF_DIV_TIME_OPERATOR_INT(LC_TD_USINT,IN1,IN2)
#define LC_MF_DIV_TIME_OPERATOR_LC_TD_UINT(IN1,IN2) LC_MF_DIV_TIME_OPERATOR_INT(LC_TD_UINT,IN1,IN2)
#define LC_MF_DIV_TIME_OPERATOR_LC_TD_UDINT(IN1,IN2) LC_MF_DIV_TIME_OPERATOR_INT(LC_TD_UDINT,IN1,IN2)
#define LC_MF_DIV_TIME_OPERATOR_LC_TD_ULINT(IN1,IN2) LC_MF_DIV_TIME_OPERATOR_INT(LC_TD_ULINT,IN1,IN2)
#define LC_MF_DIV_TIME_OPERATOR_LC_TD_REAL(IN1,IN2) LC_DIV_TIME_ORD(IN1,IN2)
#define LC_MF_DIV_TIME_OPERATOR_LC_TD_LREAL(IN1,IN2) LC_DIV_TIME_ORD(IN1,IN2)
#define LC_MF_DIV_TIME_OPERATOR(TYP,IN1,IN2) LC_MF_DIV_TIME_OPERATOR_##TYP(IN1,IN2)
#define lcfu_iec61131__DIV__TIME__HIS__INL(TYP,IN1,IN2) ((LC_TD_TIME)LC_MF_DIV_TIME_OPERATOR(TYP,IN1,IN2))
#else
#define lcfu_iec61131__DIV__TIME__HIS__INL(TYP,IN1,IN2) ((LC_TD_TIME)(LC_DIV_TIME(IN1,IN2)))
#endif
#endif /* NPE_HIS_ENABLED */



/* Concrete-type interface used by newly generated calls and operators. */
#define LC_MF_DIV_TYPED_LC_TD_SINT(IN1,IN2,THIS) LC_MF_DIV_ANY_INT_ERR(IN1,IN2,THIS,SINT)
#define LC_MF_DIV_TYPED_LC_TD_INT(IN1,IN2,THIS) LC_MF_DIV_ANY_INT_ERR(IN1,IN2,THIS,INT)
#define LC_MF_DIV_TYPED_LC_TD_DINT(IN1,IN2,THIS) LC_MF_DIV_ANY_INT_ERR(IN1,IN2,THIS,DINT)
#define LC_MF_DIV_TYPED_LC_TD_LINT(IN1,IN2,THIS) LC_MF_DIV_ANY_INT_ERR(IN1,IN2,THIS,LINT)
#define LC_MF_DIV_TYPED_LC_TD_USINT(IN1,IN2,THIS) LC_MF_DIV_ANY_UINT_ERR(IN1,IN2,THIS,USINT)
#define LC_MF_DIV_TYPED_LC_TD_UINT(IN1,IN2,THIS) LC_MF_DIV_ANY_UINT_ERR(IN1,IN2,THIS,UINT)
#define LC_MF_DIV_TYPED_LC_TD_UDINT(IN1,IN2,THIS) LC_MF_DIV_ANY_UINT_ERR(IN1,IN2,THIS,UDINT)
#define LC_MF_DIV_TYPED_LC_TD_ULINT(IN1,IN2,THIS) LC_MF_DIV_ANY_UINT_ERR(IN1,IN2,THIS,ULINT)
#define LC_MF_DIV_TYPED_LC_TD_REAL(IN1,IN2,THIS) LC_MF_DIV_REAL_ERR(IN1,IN2,THIS)
#define LC_MF_DIV_TYPED_LC_TD_LREAL(IN1,IN2,THIS) LC_MF_DIV_LREAL_ERR(IN1,IN2,THIS)
#define LC_MF_DIV_TYPED(TYP,IN1,IN2,THIS) LC_MF_DIV_TYPED_##TYP(IN1,IN2,THIS)

#if !NPE_HIS_ENABLED
#define lcfu_iec61131__DIV__ANY(TYP,LC_this,IN1,IN2,pEPDB) \
   (LC_this)->LC_VD_DIV = LC_MF_DIV_TYPED(TYP,IN1,IN2,LC_this)
#define lcfu_iec61131__DIV__ANY__INL(TYP,IN1,IN2) LC_MF_DIV_TYPED(TYP,IN1,IN2,LC_this)
#endif

#if NPE_HIS_ENABLED
#define lcfu_iec61131__DIV__ANY__HIS(TYP,LC_this,IN1,IN2,pEPDB) \
   (LC_this)->LC_VD_DIV = LC_MF_DIV_TYPED(TYP,IN1,IN2,LC_this)
#define lcfu_iec61131__DIV__ANY__HIS__INL(TYP,IN1,IN2) LC_MF_DIV_TYPED(TYP,IN1,IN2,LC_this)

#endif /* NPE_HIS_ENABLED */

#endif
