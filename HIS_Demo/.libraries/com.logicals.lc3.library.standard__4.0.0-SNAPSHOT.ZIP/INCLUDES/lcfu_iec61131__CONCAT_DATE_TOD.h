/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: non-inlined C implementation of function CONCAT_DATE_TOD for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CONCAT_DATE_TOD__H
#define LC_PROT_LCFU_IEC61131__CONCAT_DATE_TOD__H

#include <LC3CGBase.h>
#include <LC3CGAnyIntOp.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_CONCAT_DATE_TOD
{
	LC_TD_BOOL LC_VD_ENO;
	LC_TD_DT LC_VD_CONCAT_DATE_TOD;
} LCCG_StructAttrib LC_TD_Function_CONCAT_DATE_TOD;

/*                            Initialization Macro             */
#define LC_INIT_Function_CONCAT_DATE_TOD(p) \
{ \
	LC_INIT_DT(&((p)->LC_VD_CONCAT_DATE_TOD)); \
}

/*  Prototype */
#define lcfu_iec61131__CONCAT_DATE_TOD(LC_this, IN1, IN2, pEPDB)  (LC_this)->LC_VD_CONCAT_DATE_TOD = LC_MF_NUMERIC_ADD(LC_TD_TIME,IN1,IN2)

#endif
