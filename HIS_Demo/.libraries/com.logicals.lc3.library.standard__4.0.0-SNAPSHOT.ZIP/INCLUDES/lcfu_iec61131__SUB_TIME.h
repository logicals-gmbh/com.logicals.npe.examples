/* Copyright (C) logi.cals GmbH. All rights reserved.             */

/*
** TASK :: C implementation of function SUB_TIME for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__SUB_TIME__H
#define LC_PROT_LCFU_IEC61131__SUB_TIME__H

#include <LC3CGBase.h>
#include <RTAPITimer.h>

/*                            Typedefs                            */
typedef struct _LC_TD_Function_SUB_TIME \
{                                          \
	LC_TD_BOOL LC_VD_ENO;                  \
	LC_TD_TIME LC_VD_SUB_TIME;                \
} LCCG_StructAttrib LC_TD_Function_SUB_TIME;


/*                      Initialization Macro                      */
#define LC_INIT_Function_SUB_TIME(p)    LC_INIT_TIME(&((p)->LC_VD_SUB_TIME));

/*                       Impl (not inlined)                       */
#define  lcfu_iec61131__SUB_TIME(LC_this, IN1, IN2, pEPDB) \
	(LC_this)->LC_VD_SUB_TIME = LC_MF_NUMERIC_SUB(LC_TD_TIME,IN1,IN2)

#endif
