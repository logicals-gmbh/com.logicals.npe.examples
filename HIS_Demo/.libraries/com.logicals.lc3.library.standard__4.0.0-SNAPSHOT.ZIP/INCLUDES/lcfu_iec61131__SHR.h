/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function SHR for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__SHR__H
#define LC_PROT_LCFU_IEC61131__SHR__H

#include <LC3CGBase.h>
#include <LC3CGAnyBitOp.h>

/*                            Typedefs                         */
#define DEF_LC_TD_Function_SHR_ANY(type) \
typedef struct _LC_TD_Function_SHR__##type   \
{                                            \
	LC_TD_BOOL LC_VD_ENO;                \
	LC_TD_##type LC_VD_SHR;              \
} LCCG_StructAttrib LC_TD_Function_SHR__##type;

DEF_LC_TD_Function_SHR_ANY(BOOL)
DEF_LC_TD_Function_SHR_ANY(BYTE)
DEF_LC_TD_Function_SHR_ANY(WORD)
DEF_LC_TD_Function_SHR_ANY(DWORD)
DEF_LC_TD_Function_SHR_ANY(LWORD)

DEF_LC_TD_Function_SHR_ANY(SINT)
DEF_LC_TD_Function_SHR_ANY(USINT)
DEF_LC_TD_Function_SHR_ANY(INT)
DEF_LC_TD_Function_SHR_ANY(UINT)
DEF_LC_TD_Function_SHR_ANY(DINT)
DEF_LC_TD_Function_SHR_ANY(UDINT)
DEF_LC_TD_Function_SHR_ANY(LINT)
DEF_LC_TD_Function_SHR_ANY(ULINT)

/*                            Initialization Macro             */
#define LC_INIT_Function_SHR_ANY(p,type) \
{ \
	LC_INIT_##type(&((p)->LC_VD_SHR)); \
}

#define LC_INIT_Function_SHR__BOOL(p)   LC_INIT_Function_SHR_ANY(p,BOOL)
#define LC_INIT_Function_SHR__BYTE(p)   LC_INIT_Function_SHR_ANY(p,BYTE)
#define LC_INIT_Function_SHR__WORD(p)   LC_INIT_Function_SHR_ANY(p,WORD)
#define LC_INIT_Function_SHR__DWORD(p)  LC_INIT_Function_SHR_ANY(p,DWORD)
#define LC_INIT_Function_SHR__LWORD(p)  LC_INIT_Function_SHR_ANY(p,LWORD)

#define LC_INIT_Function_SHR__SINT(p)  LC_INIT_Function_SHR_ANY(p,SINT)
#define LC_INIT_Function_SHR__USINT(p) LC_INIT_Function_SHR_ANY(p,USINT)
#define LC_INIT_Function_SHR__INT(p)   LC_INIT_Function_SHR_ANY(p,INT)
#define LC_INIT_Function_SHR__UINT(p)  LC_INIT_Function_SHR_ANY(p,UINT)
#define LC_INIT_Function_SHR__DINT(p)  LC_INIT_Function_SHR_ANY(p,DINT)
#define LC_INIT_Function_SHR__UDINT(p) LC_INIT_Function_SHR_ANY(p,UDINT)
#define LC_INIT_Function_SHR__LINT(p)  LC_INIT_Function_SHR_ANY(p,LINT)
#define LC_INIT_Function_SHR__ULINT(p) LC_INIT_Function_SHR_ANY(p,ULINT)

/*                            Shifting operation               */
#define LC_MF_SHR_BOOL(IN,N)             LC_MF_BITWISE_SHR(BOOL,IN,N)
#define LC_MF_SHR_ANY_BIT(type,IN,N)     LC_MF_BITWISE_SHR(type,IN,N)

#if !NPE_HIS_CHANNEL2
#define LC_MF_SHR_ANY_INT_WITH_RANGE_CHECK(stype,IN,N,op) ((LC_TD_size_t)(N) >= (LC_TD_size_t)(sizeof(stype)*8)) ? 0 : (((stype)(IN)) op (N))
#define LC_MF_SHR_ANY_INT(type,stype,IN,N)                (LC_TD_##type)((N) >= 0 ? LC_MF_SHR_ANY_INT_WITH_RANGE_CHECK(stype,IN,(N),>>) : LC_MF_SHR_ANY_INT_WITH_RANGE_CHECK(stype,IN,-(N),<<))
#else

/* Avoid -n here: negating INT_MIN would overflow before the range check can return 0. */
static inline LC_TD_size_t LCmfSHRAnyIntShiftCount(LC_TD_INT n)
{
	return (n >= (LC_TD_INT)0) ? (LC_TD_size_t)n : ((LC_TD_size_t)(-(n + (LC_TD_INT)1)) + (LC_TD_size_t)1);
}

#define LC_MF_SHR_DEFINE_ANY_INT_HELPER(type,stype) \
static inline LC_TD_##type LCmfSHR_LC_TD_##type(LC_TD_##type in, LC_TD_INT n) \
{ \
	const LC_TD_size_t shift = LCmfSHRAnyIntShiftCount(n); \
	const LC_TD_size_t width = (LC_TD_size_t)(sizeof(stype) * 8u); \
	const stype value = (stype)in; \
	if (shift >= width) \
	{ \
		return (LC_TD_##type)0; \
	} \
	return (LC_TD_##type)((n >= (LC_TD_INT)0) ? (stype)(value >> shift) : (stype)(value << shift)); \
}

LC_MF_SHR_DEFINE_ANY_INT_HELPER(SINT,uint8_t)
LC_MF_SHR_DEFINE_ANY_INT_HELPER(USINT,uint8_t)
LC_MF_SHR_DEFINE_ANY_INT_HELPER(INT,uint16_t)
LC_MF_SHR_DEFINE_ANY_INT_HELPER(UINT,uint16_t)
LC_MF_SHR_DEFINE_ANY_INT_HELPER(DINT,uint32_t)
LC_MF_SHR_DEFINE_ANY_INT_HELPER(UDINT,uint32_t)
LC_MF_SHR_DEFINE_ANY_INT_HELPER(LINT,uint64_t)
LC_MF_SHR_DEFINE_ANY_INT_HELPER(ULINT,uint64_t)

#undef LC_MF_SHR_DEFINE_ANY_INT_HELPER

#define LC_MF_SHR_ANY_INT(type,stype,IN,N) LCmfSHR_LC_TD_##type((LC_TD_##type)(IN),(LC_TD_INT)(N))

#endif

/*                            Impl (not inlined)               */
#define  lcfu_iec61131__SHR__BOOL(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_SHR = LC_MF_SHR_BOOL(IN,N)
#define  lcfu_iec61131__SHR__BYTE(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_SHR = LC_MF_SHR_ANY_BIT(BYTE,IN,N)
#define  lcfu_iec61131__SHR__WORD(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_SHR = LC_MF_SHR_ANY_BIT(WORD,IN,N)
#define  lcfu_iec61131__SHR__DWORD(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_SHR = LC_MF_SHR_ANY_BIT(DWORD,IN,N)
#define  lcfu_iec61131__SHR__LWORD(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_SHR = LC_MF_SHR_ANY_BIT(LWORD,IN,N)

#define lcfu_iec61131__SHR__SINT(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_SHR = LC_MF_SHR_ANY_INT(SINT,uint8_t,IN,N)
#define lcfu_iec61131__SHR__USINT(LC_this, IN, N, pEPDB) (LC_this)->LC_VD_SHR = LC_MF_SHR_ANY_INT(USINT,uint8_t,IN,N)
#define lcfu_iec61131__SHR__INT(LC_this, IN, N, pEPDB)   (LC_this)->LC_VD_SHR = LC_MF_SHR_ANY_INT(INT,uint16_t,IN,N)
#define lcfu_iec61131__SHR__UINT(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_SHR = LC_MF_SHR_ANY_INT(UINT,uint16_t,IN,N)
#define lcfu_iec61131__SHR__DINT(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_SHR = LC_MF_SHR_ANY_INT(DINT,uint32_t,IN,N)
#define lcfu_iec61131__SHR__UDINT(LC_this, IN, N, pEPDB) (LC_this)->LC_VD_SHR = LC_MF_SHR_ANY_INT(UDINT,uint32_t,IN,N)
#define lcfu_iec61131__SHR__LINT(LC_this, IN, N, pEPDB)  (LC_this)->LC_VD_SHR = LC_MF_SHR_ANY_INT(LINT,uint64_t,IN,N)
#define lcfu_iec61131__SHR__ULINT(LC_this, IN, N, pEPDB) (LC_this)->LC_VD_SHR = LC_MF_SHR_ANY_INT(ULINT,uint64_t,IN,N)

#endif
