/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block SR for RTS compatible Systems.
*/

#ifndef LC_PROT_IEC61131__SR__H
#define LC_PROT_IEC61131__SR__H

#include <LC3CGBase.h>
#include <LC3CGAnyBitOp.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_SR
{
  LC_TD_BOOL LC_VD_R;
  LC_TD_BOOL LC_VD_S1;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_Q1;
} LCCG_StructAttrib LC_TD_FunctionBlock_SR;

/*                            Initialization Macro (cold start) */
#define LC_INIT_FunctionBlock_SR(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_S1)); \
  LC_INIT_BOOL(&((p)->LC_VD_R)); \
  LC_INIT_BOOL(&((p)->LC_VD_Q1)); \
}

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_SR(p,RF) { if (LC_WINIT_IS_NOT_RETAINED(RF)) LC_INIT_FunctionBlock_SR(p) }


/*                            Impl (not inlined)               */
#define lcfu_iec61131__SR(LC_this, pEPDB) \
        (LC_this)->LC_VD_Q1 = LC_MF_LOGICAL_OR((LC_this)->LC_VD_S1, LC_MF_LOGICAL_AND(LC_MF_LOGICAL_NOT((LC_this)->LC_VD_R), (LC_this)->LC_VD_Q1))
        
        
#endif
