/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function ATAN2 for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__ATAN2__H
#define LC_PROT_LCFU_IEC61131__ATAN2__H

#include <LC3CGBase.h>
#include <LC3RTLibMath.h>       /* for atan2() */

#define DEF_LC_TD_Function_ATAN2_ANY_REAL(realtype) \
typedef struct _LC_TD_Function_ATAN2__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##realtype LC_VD_ATAN2; \
} LCCG_StructAttrib LC_TD_Function_ATAN2__##realtype;

DEF_LC_TD_Function_ATAN2_ANY_REAL(REAL)
DEF_LC_TD_Function_ATAN2_ANY_REAL(LREAL)

/*                            Initialization Macro             */
#define LC_INIT_Function_ATAN2_ANY_REAL(p,realtype) \
{ \
  LC_INIT_##realtype(&((p)->LC_VD_ATAN2)); \
}

#define LC_INIT_Function_ATAN2__REAL(p)  LC_INIT_Function_ATAN2_ANY_REAL(p,REAL)
#define LC_INIT_Function_ATAN2__LREAL(p) LC_INIT_Function_ATAN2_ANY_REAL(p,LREAL)

/*
**  calculates the principal arc tangent of inputs Y and X in radians
**  The output shall be of the same realtype as Y and X.
*/
/*  Prototype */
#define lcfu_iec61131__ATAN2__REAL(LC_this, Y, X, pEPDB)  (LC_this)->LC_VD_ATAN2 = ((LC_TD_REAL)(LC_ATAN2F(Y,X)))
#define lcfu_iec61131__ATAN2__LREAL(LC_this, Y, X, pEPDB) (LC_this)->LC_VD_ATAN2 = ((LC_TD_LREAL)(LC_ATAN2(Y,X)))

#endif
