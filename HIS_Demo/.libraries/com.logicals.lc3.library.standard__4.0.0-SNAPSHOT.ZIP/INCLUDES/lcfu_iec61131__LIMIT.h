/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function LIMIT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__LIMIT__H
#define LC_PROT_LCFU_IEC61131__LIMIT__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
#define DEF_LC_TD_Function_LIMIT(type) \
typedef struct _LC_TD_Function_LIMIT__##type \
{ \
	LC_TD_BOOL LC_VD_ENO; \
	LC_TD_##type LC_VD_LIMIT; \
} LCCG_StructAttrib LC_TD_Function_LIMIT__##type;

DEF_LC_TD_Function_LIMIT(BOOL)
DEF_LC_TD_Function_LIMIT(SINT)
DEF_LC_TD_Function_LIMIT(INT)
DEF_LC_TD_Function_LIMIT(DINT)
DEF_LC_TD_Function_LIMIT(LINT)
DEF_LC_TD_Function_LIMIT(USINT)
DEF_LC_TD_Function_LIMIT(UINT)
DEF_LC_TD_Function_LIMIT(UDINT)
DEF_LC_TD_Function_LIMIT(ULINT)
DEF_LC_TD_Function_LIMIT(BYTE)
DEF_LC_TD_Function_LIMIT(WORD)
DEF_LC_TD_Function_LIMIT(DWORD)
DEF_LC_TD_Function_LIMIT(LWORD)
DEF_LC_TD_Function_LIMIT(REAL)
DEF_LC_TD_Function_LIMIT(LREAL)
DEF_LC_TD_Function_LIMIT(TIME)
DEF_LC_TD_Function_LIMIT(DATE)
DEF_LC_TD_Function_LIMIT(TOD)
DEF_LC_TD_Function_LIMIT(DT)

/*                            Initialization Macro             */
#define LC_INIT_Function_LIMIT(p,type) \
{ \
	LC_INIT_##type(&((p)->LC_VD_LIMIT)); \
}

#define LC_INIT_Function_LIMIT__BOOL(p)  LC_INIT_Function_LIMIT(p,BOOL)
#define LC_INIT_Function_LIMIT__SINT(p)  LC_INIT_Function_LIMIT(p,SINT)
#define LC_INIT_Function_LIMIT__INT(p)   LC_INIT_Function_LIMIT(p,INT)
#define LC_INIT_Function_LIMIT__DINT(p)  LC_INIT_Function_LIMIT(p,DINT)
#define LC_INIT_Function_LIMIT__LINT(p)  LC_INIT_Function_LIMIT(p,LINT)
#define LC_INIT_Function_LIMIT__USINT(p) LC_INIT_Function_LIMIT(p,USINT)
#define LC_INIT_Function_LIMIT__UINT(p)  LC_INIT_Function_LIMIT(p,UINT)
#define LC_INIT_Function_LIMIT__UDINT(p) LC_INIT_Function_LIMIT(p,UDINT)
#define LC_INIT_Function_LIMIT__ULINT(p) LC_INIT_Function_LIMIT(p,ULINT)
#define LC_INIT_Function_LIMIT__BYTE(p)  LC_INIT_Function_LIMIT(p,BYTE)
#define LC_INIT_Function_LIMIT__WORD(p)  LC_INIT_Function_LIMIT(p,WORD)
#define LC_INIT_Function_LIMIT__DWORD(p) LC_INIT_Function_LIMIT(p,DWORD)
#define LC_INIT_Function_LIMIT__LWORD(p) LC_INIT_Function_LIMIT(p,LWORD)
#define LC_INIT_Function_LIMIT__REAL(p)  LC_INIT_Function_LIMIT(p,REAL)
#define LC_INIT_Function_LIMIT__LREAL(p) LC_INIT_Function_LIMIT(p,LREAL)
#define LC_INIT_Function_LIMIT__TIME(p)  LC_INIT_Function_LIMIT(p,TIME)
#define LC_INIT_Function_LIMIT__DATE(p)  LC_INIT_Function_LIMIT(p,DATE)
#define LC_INIT_Function_LIMIT__TOD(p)   LC_INIT_Function_LIMIT(p,TOD)
#define LC_INIT_Function_LIMIT__DT(p)    LC_INIT_Function_LIMIT(p,DT)

/*                            Impl (not inlined)               */
#if !NPE_HIS_ENABLED
#define  lcfu_iec61131__LIMIT__ANY(LC_this, MN, IN, MX, pEPDB) \
 (LC_this)->LC_VD_LIMIT = (MX)<=(MN)?(MX):(IN)>(MN)?((IN)<(MX)?(IN):(MX)):(MN)
#endif

/* HIS interface: snapshot inputs once, before selecting or verifying the result. */
#if NPE_HIS_ENABLED
#if NPE_HIS_CHANNEL2
#define LC_LIMIT_RESULT_STORAGE volatile
#define LC_LIMIT_BIT_LE >=
#define LC_LIMIT_BIT_GT <
#define LC_LIMIT_BIT_LT >
#define LC_LIMIT_VERIFY_NUMERIC(result,mn,in,mx) \
do \
{ \
  /* Preserve LIMIT's MX result for equal or reversed bounds. */ \
  if ((mx) <= (mn)) \
  { \
    LC_MF_NUMERIC_CHECK((result) == (mx), LC3CGERR_ErrorId_HIS_VERIFY_LIMIT_FAILED); \
  } \
  else \
  { \
    /* Range alone would accept a wrong value inside [MN, MX]. */ \
    LC_MF_NUMERIC_CHECK((result) >= (mn) && (result) <= (mx) && \
      ((in) >= (mn) || (result) == (mn)) && ((in) <= (mx) || (result) == (mx)) && \
      ((in) < (mn) || (in) > (mx) || (result) == (in)), \
      LC3CGERR_ErrorId_HIS_VERIFY_LIMIT_FAILED); \
  } \
} while (0)
#else
#define LC_LIMIT_RESULT_STORAGE
#define LC_LIMIT_BIT_LE <=
#define LC_LIMIT_BIT_GT >
#define LC_LIMIT_BIT_LT <
#define LC_LIMIT_VERIFY_NUMERIC(result,mn,in,mx) ((void)0)
#endif
#define LC_LIMIT_VERIFY_NONE(result,mn,in,mx) ((void)0)

/* C2 ANY_BIT comparisons retain their complemented ordering. Numeric selection
** uses the ordinary calculation, followed by an independent result check.
** Materialize the C2 result so optimization cannot eliminate that check.
*/
#define LC_LIMIT_DEFINE_HIS(type,LE,GT,LT,VERIFY) \
static inline void LCmfLimit_LC_TD_##type(LC_TD_Function_LIMIT__##type *LC_this, \
  LC_TD_##type mn, LC_TD_##type in, LC_TD_##type mx, \
  struct _lcoplck_epdb_1_impl const *pEPDB) \
{ \
  LC_LIMIT_RESULT_STORAGE LC_TD_##type result = \
    mx LE mn ? mx : in GT mn ? (in LT mx ? in : mx) : mn; \
  (void)pEPDB; \
  VERIFY(result,mn,in,mx); \
  LC_this->LC_VD_LIMIT = result; \
}

/* Choose operators and verification while preprocessing, without constant C branches. */
#define LC_LIMIT_DEFINE_BIT_HIS(type) \
  LC_LIMIT_DEFINE_HIS(type,LC_LIMIT_BIT_LE,LC_LIMIT_BIT_GT,LC_LIMIT_BIT_LT,LC_LIMIT_VERIFY_NONE)

LC_LIMIT_DEFINE_BIT_HIS(BOOL)
LC_LIMIT_DEFINE_HIS(SINT,<=,>,<,LC_LIMIT_VERIFY_NUMERIC)
LC_LIMIT_DEFINE_HIS(INT,<=,>,<,LC_LIMIT_VERIFY_NUMERIC)
LC_LIMIT_DEFINE_HIS(DINT,<=,>,<,LC_LIMIT_VERIFY_NUMERIC)
LC_LIMIT_DEFINE_HIS(LINT,<=,>,<,LC_LIMIT_VERIFY_NUMERIC)
LC_LIMIT_DEFINE_HIS(USINT,<=,>,<,LC_LIMIT_VERIFY_NUMERIC)
LC_LIMIT_DEFINE_HIS(UINT,<=,>,<,LC_LIMIT_VERIFY_NUMERIC)
LC_LIMIT_DEFINE_HIS(UDINT,<=,>,<,LC_LIMIT_VERIFY_NUMERIC)
LC_LIMIT_DEFINE_HIS(ULINT,<=,>,<,LC_LIMIT_VERIFY_NUMERIC)
LC_LIMIT_DEFINE_BIT_HIS(BYTE)
LC_LIMIT_DEFINE_BIT_HIS(WORD)
LC_LIMIT_DEFINE_BIT_HIS(DWORD)
LC_LIMIT_DEFINE_BIT_HIS(LWORD)
LC_LIMIT_DEFINE_HIS(REAL,<=,>,<,LC_LIMIT_VERIFY_NONE)
LC_LIMIT_DEFINE_HIS(LREAL,<=,>,<,LC_LIMIT_VERIFY_NONE)
LC_LIMIT_DEFINE_HIS(TIME,<=,>,<,LC_LIMIT_VERIFY_NUMERIC)
LC_LIMIT_DEFINE_HIS(DATE,<=,>,<,LC_LIMIT_VERIFY_NUMERIC)
LC_LIMIT_DEFINE_HIS(TOD,<=,>,<,LC_LIMIT_VERIFY_NUMERIC)
LC_LIMIT_DEFINE_HIS(DT,<=,>,<,LC_LIMIT_VERIFY_NUMERIC)

#undef LC_LIMIT_DEFINE_BIT_HIS
#undef LC_LIMIT_DEFINE_HIS
#undef LC_LIMIT_RESULT_STORAGE
#undef LC_LIMIT_BIT_LE
#undef LC_LIMIT_BIT_GT
#undef LC_LIMIT_BIT_LT
#undef LC_LIMIT_VERIFY_NUMERIC
#undef LC_LIMIT_VERIFY_NONE

#define LC_LIMIT_HIS_NAME(TYP) LC_LIMIT_HIS_NAME_(TYP)
#define LC_LIMIT_HIS_NAME_(TYP) LCmfLimit_##TYP
#define LCmfLimit_LC_TD_T LCmfLimit_LC_TD_TIME

#define lcfu_iec61131__LIMIT__ANY__HIS(TYP, LC_this, MN, IN, MX, pEPDB) \
do \
{ \
  const TYP lc_limit_mn = (MN); \
  const TYP lc_limit_in = (IN); \
  const TYP lc_limit_mx = (MX); \
  LC_LIMIT_HIS_NAME(TYP)((LC_this), lc_limit_mn, lc_limit_in, lc_limit_mx, (pEPDB)); \
} while (0)
#endif

#endif
