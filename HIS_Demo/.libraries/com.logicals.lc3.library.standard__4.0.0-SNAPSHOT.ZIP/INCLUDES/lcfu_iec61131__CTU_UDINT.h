/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTU_UDINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTU_UDINT__H
#define LC_PROT_LCFU_IEC61131__CTU_UDINT__H

#include <LC3CGBase.h>
#include <LC3CGCounterImpl.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_CTU_UDINT
{
  _typedef_FunctionBlock_CTU_ANY(UDINT)
} LCCG_StructAttrib LC_TD_FunctionBlock_CTU_UDINT;

/*                            Initialization Macro (cold start) */
#define LC_INIT_FunctionBlock_CTU_UDINT(p) _INIT_FunctionBlock_CTU_ANY(UDINT,p)

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_CTU_UDINT(p,RF) { if (LC_WINIT_IS_NOT_RETAINED(RF)) LC_INIT_FunctionBlock_CTU_UDINT(p) }


/*                            Prototype                        */
void  lcfu_iec61131__CTU_UDINT(LC_TD_FunctionBlock_CTU_UDINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
