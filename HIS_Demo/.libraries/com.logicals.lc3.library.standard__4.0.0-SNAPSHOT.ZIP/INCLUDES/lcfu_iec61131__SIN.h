/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function SIN for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__SIN__H
#define LC_PROT_LCFU_IEC61131__SIN__H

#include <LC3CGBase.h>
#include <LC3RTLibMath.h>       /* for sin() */

#define DEF_LC_TD_Function_SIN_ANY_REAL(realtype) \
typedef struct _LC_TD_Function_SIN__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##realtype LC_VD_SIN; \
} LCCG_StructAttrib LC_TD_Function_SIN__##realtype;

DEF_LC_TD_Function_SIN_ANY_REAL(REAL)
DEF_LC_TD_Function_SIN_ANY_REAL(LREAL)

/*                            Initialization Macro             */
#define LC_INIT_Function_SIN_ANY_REAL(p,realtype) \
{ \
  LC_INIT_##realtype(&((p)->LC_VD_SIN)); \
}

#define LC_INIT_Function_SIN__REAL(p)  LC_INIT_Function_SIN_ANY_REAL(p,REAL)
#define LC_INIT_Function_SIN__LREAL(p) LC_INIT_Function_SIN_ANY_REAL(p,LREAL)

/*
**  calculates the sine of input in radians
**  The output shall be of the same realtype as IN.
*/
/*  Prototype */
#define lcfu_iec61131__SIN__REAL(LC_this, IN, pEPDB)  (LC_this)->LC_VD_SIN = ((LC_TD_REAL)(LC_SINF(IN)))
#define lcfu_iec61131__SIN__LREAL(LC_this, IN, pEPDB) (LC_this)->LC_VD_SIN = ((LC_TD_LREAL)(LC_SIN(IN)))

#endif
