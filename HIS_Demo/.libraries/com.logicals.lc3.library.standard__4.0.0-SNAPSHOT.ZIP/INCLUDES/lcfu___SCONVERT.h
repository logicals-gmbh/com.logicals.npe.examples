#ifndef LC_PROT_LCFU___TO_SAFEANY__H
#define LC_PROT_LCFU___TO_SAFEANY__H

#include <LC3CGBase.h>

#include <lcdt___safeudint.h>
#include <lcdt___safetod.h>
#include <lcdt___safeusint.h>
#include <lcdt___safebool.h>
#include <lcdt___safeword.h>
#include <lcdt___safelword.h>
#include <lcdt___safereal.h>
#include <lcdt___safedate.h>
#include <lcdt___safelint.h>
#include <lcdt___safesint.h>
#include <lcdt___safebyte.h>
#include <lcdt___safedt.h>
#include <lcdt___safeint.h>
#include <lcdt___safeuint.h>
#include <lcdt___safeulint.h>
#include <lcdt___safetime.h>
#include <lcdt___safedint.h>
#include <lcdt___safelreal.h>
#include <lcdt___safedword.h>

/*                            Typedefs                         */
#define MAKE_LC_TD_Function_TO_SAFE(TYP) \
typedef struct _LC_TD_Function_TO_SAFE##TYP \
{                                                                        \
  LC_TD_BOOL LC_VD_ENO;                                                   \
  LC_TD_DataType_SAFE##TYP LC_VD_TO_SAFE##TYP;\
} LCCG_StructAttrib LC_TD_Function_TO_SAFE##TYP;


MAKE_LC_TD_Function_TO_SAFE(BOOL)
MAKE_LC_TD_Function_TO_SAFE(BYTE)
MAKE_LC_TD_Function_TO_SAFE(WORD)
MAKE_LC_TD_Function_TO_SAFE(DWORD)
MAKE_LC_TD_Function_TO_SAFE(LWORD)
MAKE_LC_TD_Function_TO_SAFE(SINT)
MAKE_LC_TD_Function_TO_SAFE(INT)
MAKE_LC_TD_Function_TO_SAFE(DINT)
MAKE_LC_TD_Function_TO_SAFE(LINT)
MAKE_LC_TD_Function_TO_SAFE(USINT)
MAKE_LC_TD_Function_TO_SAFE(UINT)
MAKE_LC_TD_Function_TO_SAFE(UDINT)
MAKE_LC_TD_Function_TO_SAFE(ULINT)
MAKE_LC_TD_Function_TO_SAFE(REAL)
MAKE_LC_TD_Function_TO_SAFE(LREAL)
MAKE_LC_TD_Function_TO_SAFE(TIME)
MAKE_LC_TD_Function_TO_SAFE(DATE)
MAKE_LC_TD_Function_TO_SAFE(DT)
MAKE_LC_TD_Function_TO_SAFE(TOD)


/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_TO_ANY(p,TYP) \
{ \
  LC_INIT_DataType_SAFE##TYP(&((p)->LC_VD_TO_SAFE##TYP)); \
}

#define LC_INIT_Function_TO_SAFEBOOL(p)   LC_INIT_Function_TO_ANY(p,BOOL)
#define LC_INIT_Function_TO_SAFEBYTE(p)   LC_INIT_Function_TO_ANY(p,BYTE)
#define LC_INIT_Function_TO_SAFEWORD(p)   LC_INIT_Function_TO_ANY(p,WORD)
#define LC_INIT_Function_TO_SAFEDWORD(p)  LC_INIT_Function_TO_ANY(p,DWORD)
#define LC_INIT_Function_TO_SAFELWORD(p)  LC_INIT_Function_TO_ANY(p,LWORD)
#define LC_INIT_Function_TO_SAFESINT(p)   LC_INIT_Function_TO_ANY(p,SINT)
#define LC_INIT_Function_TO_SAFEINT(p)    LC_INIT_Function_TO_ANY(p,INT)
#define LC_INIT_Function_TO_SAFEDINT(p)   LC_INIT_Function_TO_ANY(p,DINT)
#define LC_INIT_Function_TO_SAFELINT(p)   LC_INIT_Function_TO_ANY(p,LINT)
#define LC_INIT_Function_TO_SAFEUSINT(p)  LC_INIT_Function_TO_ANY(p,USINT)
#define LC_INIT_Function_TO_SAFEUINT(p)   LC_INIT_Function_TO_ANY(p,UINT)
#define LC_INIT_Function_TO_SAFEUDINT(p)  LC_INIT_Function_TO_ANY(p,UDINT)
#define LC_INIT_Function_TO_SAFEULINT(p)  LC_INIT_Function_TO_ANY(p,ULINT)
#define LC_INIT_Function_TO_SAFEREAL(p)   LC_INIT_Function_TO_ANY(p,REAL)
#define LC_INIT_Function_TO_SAFELREAL(p)  LC_INIT_Function_TO_ANY(p,LREAL)
#define LC_INIT_Function_TO_SAFETIME(p)   LC_INIT_Function_TO_ANY(p,TIME)
#define LC_INIT_Function_TO_SAFEDATE(p)   LC_INIT_Function_TO_ANY(p,DATE)
#define LC_INIT_Function_TO_SAFEDT(p)     LC_INIT_Function_TO_ANY(p,DT)
#define LC_INIT_Function_TO_SAFETOD(p)    LC_INIT_Function_TO_ANY(p,TOD)



/*                            Prototype                        */
#define lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB, TYP) { (LC_this)->LC_VD_TO_SAFE##TYP = (LC_VD_IN);}

#define lcfu___TO_SAFEBOOL(LC_this, LC_VD_IN, pEPDB)   lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,BOOL)
#define lcfu___TO_SAFEBYTE(LC_this, LC_VD_IN, pEPDB)   lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,BYTE)
#define lcfu___TO_SAFEWORD(LC_this, LC_VD_IN, pEPDB)   lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,WORD)
#define lcfu___TO_SAFEDWORD(LC_this, LC_VD_IN, pEPDB)  lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,DWORD)
#define lcfu___TO_SAFELWORD(LC_this, LC_VD_IN, pEPDB)  lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,LWORD)
#define lcfu___TO_SAFESINT(LC_this, LC_VD_IN, pEPDB)   lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,SINT)
#define lcfu___TO_SAFEINT(LC_this, LC_VD_IN, pEPDB)    lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,INT)
#define lcfu___TO_SAFEDINT(LC_this, LC_VD_IN, pEPDB)   lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,DINT)
#define lcfu___TO_SAFELINT(LC_this, LC_VD_IN, pEPDB)   lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,LINT)
#define lcfu___TO_SAFEUSINT(LC_this, LC_VD_IN, pEPDB)  lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,USINT)
#define lcfu___TO_SAFEUINT(LC_this, LC_VD_IN, pEPDB)   lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,UINT)
#define lcfu___TO_SAFEUDINT(LC_this, LC_VD_IN, pEPDB)  lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,UDINT)
#define lcfu___TO_SAFEULINT(LC_this, LC_VD_IN, pEPDB)  lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,ULINT)
#define lcfu___TO_SAFEREAL(LC_this, LC_VD_IN, pEPDB)   lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,REAL)
#define lcfu___TO_SAFELREAL(LC_this, LC_VD_IN, pEPDB)  lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,LREAL)
#define lcfu___TO_SAFETIME(LC_this, LC_VD_IN, pEPDB)   lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,TIME)
#define lcfu___TO_SAFEDATE(LC_this, LC_VD_IN, pEPDB)   lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,DATE)
#define lcfu___TO_SAFEDT(LC_this, LC_VD_IN, pEPDB)     lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,DT)
#define lcfu___TO_SAFETOD(LC_this, LC_VD_IN, pEPDB)    lcfu___TO_ANY(LC_this, LC_VD_IN, pEPDB,TOD)

#endif
