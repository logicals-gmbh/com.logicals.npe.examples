/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function block CTUD_LINT for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__CTUD_LINT__H
#define LC_PROT_LCFU_IEC61131__CTUD_LINT__H

#include <LC3CGBase.h>
#include <LC3CGCounterImpl.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_CTUD_LINT
{
  _typedef_FunctionBlock_CTUD_ANY(LINT)
} LCCG_StructAttrib LC_TD_FunctionBlock_CTUD_LINT;

/*                            Initialization Macro (cold start) */
#define LC_INIT_FunctionBlock_CTUD_LINT(p) _INIT_FunctionBlock_CTUD_ANY(LINT,p)

/*                            Initialization Macro (warm start) */
#define LC_WINIT_FunctionBlock_CTUD_LINT(p,RF) { if (LC_WINIT_IS_NOT_RETAINED(RF)) LC_INIT_FunctionBlock_CTUD_LINT(p) }

/*                            Prototype                        */
void  lcfu_iec61131__CTUD_LINT(LC_TD_FunctionBlock_CTUD_LINT* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
