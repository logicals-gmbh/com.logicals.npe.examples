/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK :: C implementation of function TRUNC_REAL* for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__TRUNC_REAL_ANY__H
#define LC_PROT_LCFU_IEC61131__TRUNC_REAL_ANY__H

#include <LC3CGBase.h>

#define DEF_LC_TD_Function_TRUNC_REAL_ANY_REAL(realtype) \
typedef struct _LC_TD_Function_TRUNC__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##realtype LC_VD_TRUNC; \
} LCCG_StructAttrib LC_TD_Function_TRUNC__##realtype;

DEF_LC_TD_Function_TRUNC_REAL_ANY_REAL(REAL)
DEF_LC_TD_Function_TRUNC_REAL_ANY_REAL(LREAL)

#define LC_INIT_Function_TRUNC_REAL_ANY_REAL(p,realtype) \
{ \
  LC_INIT_##realtype(&((p)->LC_VD_TRUNC)); \
}

#define LC_INIT_Function_TRUNC__REAL(p)  LC_INIT_Function_TRUNC_REAL_ANY_REAL(p,REAL)
#define LC_INIT_Function_TRUNC__LREAL(p) LC_INIT_Function_TRUNC_REAL_ANY_REAL(p,LREAL)

/*                            Implementation helper            */
extern LC_TD_REAL LCfu_iec61131__TRUNC_REAL_ANY__REAL(float value);
extern LC_TD_LREAL LCfu_iec61131__TRUNC_REAL_ANY__LREAL(double value);

/*                            Implementation                   */
#define lcfu_iec61131__TRUNC__REAL(LC_this,IN,pEPDB)  (LC_this)->LC_VD_TRUNC = ((LC_TD_REAL)LCfu_iec61131__TRUNC_REAL_ANY__REAL(IN))
#define lcfu_iec61131__TRUNC__LREAL(LC_this,IN,pEPDB) (LC_this)->LC_VD_TRUNC = ((LC_TD_LREAL)LCfu_iec61131__TRUNC_REAL_ANY__LREAL(IN))

#endif
