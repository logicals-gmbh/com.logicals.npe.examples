/* Copyright (C) logi.cals GmbH. All rights reserved.             */

/*
** TASK :: C implementation of rounding function FLOOR for RTS compatible Systems.
*/

#ifndef LC_PROT_LCFU_IEC61131__FLOOR__H
#define LC_PROT_LCFU_IEC61131__FLOOR__H

#include <LC3CGBase.h>
#include <LC3RTLibMath.h>

#define DEF_LC_TD_Function_FLOOR_ANY_REAL(realtype) \
typedef struct _LC_TD_Function_FLOOR__##realtype \
{ \
  LC_TD_BOOL LC_VD_ENO; \
  LC_TD_##realtype LC_VD_FLOOR; \
} LCCG_StructAttrib LC_TD_Function_FLOOR__##realtype;

DEF_LC_TD_Function_FLOOR_ANY_REAL(REAL)
DEF_LC_TD_Function_FLOOR_ANY_REAL(LREAL)

/*                            Initialization Macro             */
#define LC_INIT_Function_FLOOR_ANY_REAL(p,realtype) \
{ \
  LC_INIT_##realtype(&((p)->LC_VD_FLOOR)); \
}

#define LC_INIT_Function_FLOOR__REAL(p)  LC_INIT_Function_FLOOR_ANY_REAL(p,REAL)
#define LC_INIT_Function_FLOOR__LREAL(p) LC_INIT_Function_FLOOR_ANY_REAL(p,LREAL)

/*
**  Calculates the floor (down) rounding of input.
**  The output shall be of the same realtype as IN.
*/
/*  Prototype */
#define lcfu_iec61131__FLOOR__REAL(LC_this, IN, pEPDB)  (LC_this)->LC_VD_FLOOR = ((LC_TD_REAL)(LC_FLOORF(IN)))
#define lcfu_iec61131__FLOOR__LREAL(LC_this, IN, pEPDB) (LC_this)->LC_VD_FLOOR = ((LC_TD_LREAL)(LC_FLOOR(IN)))

#endif
