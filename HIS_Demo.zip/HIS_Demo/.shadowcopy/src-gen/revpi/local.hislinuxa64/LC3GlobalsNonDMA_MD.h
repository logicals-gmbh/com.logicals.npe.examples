#ifndef LC_PROT_LC3GLOBALSNONDMA_MD__H
#define LC_PROT_LC3GLOBALSNONDMA_MD__H
/* METADATA MACROS for GLOBAL VARIABLES (without DMA attribute) */
#define LC_MD_BASE_LC_VD_ESTOP                                                            (offsetof(LC_TD_LC3_GVType,LC_VD_ESTOP))
#define LC_MD_BASE_LC_VD_BUTTON2INDICATOR                                                 (offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON2INDICATOR))
#define LC_MD_BASE_LC_VD_DUMMY2                                                           (offsetof(LC_TD_LC3_GVType,LC_VD_DUMMY2))
#define LC_MD_BASE_LC_VD_BUTTON1INPUT                                                     (offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON1INPUT))
#define LC_MD_BASE_LC_VD_BUTTON3INDICATOR                                                 (offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON3INDICATOR))
#define LC_MD_BASE_LC_VD_BUTTON3INPUT                                                     (offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON3INPUT))
#define LC_MD_BASE_LC_VD_DUMMY1                                                           (offsetof(LC_TD_LC3_GVType,LC_VD_DUMMY1))
#define LC_MD_BASE_LC_VD_BUTTON1INDICATOR                                                 (offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON1INDICATOR))
#define LC_MD_BASE_LC_VD_BUTTON2INPUT                                                     (offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON2INPUT))

#define LC_MD_EP_ID_LC3_GVINSTANCE                                                        2
#define LC_MD_EP_TYPE_LC3_GVINSTANCE                                                      1

#endif
