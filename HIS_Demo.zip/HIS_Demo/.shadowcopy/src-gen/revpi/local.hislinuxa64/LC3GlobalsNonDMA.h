#ifndef LC_PROT_LC3GLOBALSNONDMA__H
#define LC_PROT_LC3GLOBALSNONDMA__H
/* MACROS for GLOBAL VARIABLES (without DMA attribute) */
#define LC_EXT_INIT_ELEM_LC_VD_ESTOP(ptrEPDB,varName,varType)                             (*(varType*)(&(g_LC3_GVInstanceData.varName)))
#define LC_EXT_INIT_ELEM_LC_VD_BUTTON2INDICATOR(ptrEPDB,varName,varType)                  (*(varType*)(&(g_LC3_GVInstanceData.varName)))
#define LC_EXT_INIT_ELEM_LC_VD_DUMMY2(ptrEPDB,varName,varType)                            (*(varType*)(&(g_LC3_GVInstanceData.varName)))
#define LC_EXT_INIT_ELEM_LC_VD_BUTTON1INPUT(ptrEPDB,varName,varType)                      (*(varType*)(&(g_LC3_GVInstanceData.varName)))
#define LC_EXT_INIT_ELEM_LC_VD_BUTTON3INDICATOR(ptrEPDB,varName,varType)                  (*(varType*)(&(g_LC3_GVInstanceData.varName)))
#define LC_EXT_INIT_ELEM_LC_VD_BUTTON3INPUT(ptrEPDB,varName,varType)                      (*(varType*)(&(g_LC3_GVInstanceData.varName)))
#define LC_EXT_INIT_ELEM_LC_VD_DUMMY1(ptrEPDB,varName,varType)                            (*(varType*)(&(g_LC3_GVInstanceData.varName)))
#define LC_EXT_INIT_ELEM_LC_VD_BUTTON1INDICATOR(ptrEPDB,varName,varType)                  (*(varType*)(&(g_LC3_GVInstanceData.varName)))
#define LC_EXT_INIT_ELEM_LC_VD_BUTTON2INPUT(ptrEPDB,varName,varType)                      (*(varType*)(&(g_LC3_GVInstanceData.varName)))

#endif
