#include <lcpu___prg_hisdemo.h>

LC_TD_Program_PRG_HISDEMO LC_ProgramInstanceData_PRG_HISDEMO;
