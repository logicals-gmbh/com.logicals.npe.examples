#include <LC3CGEntryData.h>

extern LC_TD_STRING_STACK LC_vg_StringStack_DEFAULTTASK;

/* Error Information - must be in R/W memory */
static LC3CGERR_ErrorInformation LC_PI_ErrorInformation_PRG_HISDEMO =
{
  LC3CGERR_ErrorId_NO_ERROR
 ,NULL
 ,0
 ,NULL
 ,NULL
};

/* CCodeData in EPDB */
LC_TD_EntryData LC_vg_CCED_PRG_HISDEMO = {
  0                                    /* unsigned long reloadVersion     */
 ,&LC_vg_StringStack_DEFAULTTASK       /* LC_TD_STRING_STACK *stringStack */
 ,&LC_PI_ErrorInformation_PRG_HISDEMO    /* ErrorInformation * */
};

