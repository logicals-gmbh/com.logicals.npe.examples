#ifndef LC_PROT_LC3ENTRYPOINT_MD__H
#define LC_PROT_LC3ENTRYPOINT_MD__H
/* default base addresses for entry points */
#define RISMD_EP_BASE_PRG_HISDEMO 0

#endif
