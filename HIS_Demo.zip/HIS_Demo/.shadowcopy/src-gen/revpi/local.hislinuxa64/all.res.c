/**
*** logi.CAD3 generated Source include file
*** This file has been generated automatically and will be overwritten. Do not edit!
**/

#include "src-gen/revpi/local.hislinuxa64/IOAccess.c"
#include "src-gen/revpi/local.hislinuxa64/LC3Task.c"
#include "src-gen/revpi/local.hislinuxa64/LC3_EPDB.c"
#include "src-gen/revpi/local.hislinuxa64/instances/LC3PI_CCED_PRG_HISDEMO.c"
#include "src-gen/revpi/local.hislinuxa64/instances/LC3PI_EPDB_PRG_HISDEMO.c"
#include "src-gen/revpi/local.hislinuxa64/instances/LC3PI_INSTANCE_DATA_PRG_HISDEMO.c"
#include "src-gen/revpi/local.hislinuxa64/tasks/LC3Task_DEFAULTTASK.c"

