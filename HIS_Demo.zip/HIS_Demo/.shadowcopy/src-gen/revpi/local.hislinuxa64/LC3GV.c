/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK      :: global variable implementation
** NOTES     ::
*/

/***************************************************************************
** Global Includes, Defines , Types
****************************************************************************/
#include <LC3Globals.h>

#if NPE_HIS_CHANNEL2
#include "LC3CGAnyBitOp.h"
#endif
/*
** This-Data of GVs
*/
LC_TD_LC3_GVType g_LC3_GVInstanceData;
#define LC_UNUSED_VAR(x) (void)(x)

#if !NPE_HIS_CHANNEL2

unsigned LC_GV_Init
(
  LCoplck_EPDB * pEPDB
 ,LCoplck_StartMode s
)
{
 /* LC_this required for exception handling of init of GV with expressions */
 /* LC_this and LC_this->LC_VD_ENO will be used in such a case via the macros */

 struct DummyStruct
   {
      LC_TD_BOOL LC_VD_ENO;
   } dummyVar = {.LC_VD_ENO = LC_EL_true};

 struct DummyStruct * LC_this = &dummyVar;
 /* NOP statement to avoid unused var warning for "-Wunused-variable", unused value warning for -Wunused-value */
 LC_UNUSED_VAR(LC_this);

 if (s==LCoplck_ColdStart)
    {
     LC_INIT_LC3_GVType(&g_LC3_GVInstanceData);
    }
 else if (s==LCoplck_WarmStart)
    {
     LC_WINIT_LC3_GVType(&g_LC3_GVInstanceData,0);
    }
 return 0;
}

#else

unsigned LC_GV_Init
(
  LCoplck_EPDB * pEPDB
 ,LCoplck_StartMode s
)
{
 /* LC_this required for exception handling of init of GV with expressions */
 /* LC_this and LC_this->LC_VD_ENO will be used in such a case via the macros */

 struct DummyStruct
   {
      LC_TD_BOOL LC_VD_ENO;
   } dummyVar = {.LC_VD_ENO = LC_EL_true};

 struct DummyStruct * LC_this = &dummyVar;
 /* NOP statement to avoid unused var warning for "-Wunused-variable", unused value warning for -Wunused-value */
 LC_UNUSED_VAR(LC_this);

 /* The numeric LCoplck_StartMode values and their order are part of the runtime interface and must not be changed. */
 if (LC_MF_COMPARE_NE(LC_TD_UDINT, s, LCoplck_ColdStart))
    {
     if (LC_MF_COMPARE_EQ(LC_TD_UDINT, s, LCoplck_WarmStart))
        {
         LC_WINIT_LC3_GVType(&g_LC3_GVInstanceData,0);
        }
    }
 else
    {
     LC_INIT_LC3_GVType(&g_LC3_GVInstanceData);
    }
 return 0;
}

#endif
