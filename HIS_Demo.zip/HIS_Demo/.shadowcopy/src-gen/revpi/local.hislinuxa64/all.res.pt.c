/**
*** logi.CAD3 generated Source include file
*** This file has been generated automatically and will be overwritten. Do not edit!
**/

#include "src-gen/revpi/local.hislinuxa64/types/LC3PT_PRG_HISDEMO.c"

