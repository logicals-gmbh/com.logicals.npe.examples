#ifndef LC3GV_H
#define LC3GV_H

/* Copyright (C) logi.cals GmbH. All rights reserved. */

/*
** TASK      :: global variable defines
** NOTES     ::
*/

/***************************************************************************
** Global Includes, Defines , Types
****************************************************************************/
#include <LCAPI.h>

#include <lcdt___safebool.h>
#include <lcpu___prg_hisdemo.gv.h>


typedef struct
{
  LC_TD_BOOL LC_VD_BUTTON1INDICATOR;
  LC_TD_BOOL LC_VD_BUTTON1INPUT;
  LC_TD_BOOL LC_VD_BUTTON2INDICATOR;
  LC_TD_BOOL LC_VD_BUTTON2INPUT;
  LC_TD_BOOL LC_VD_BUTTON3INDICATOR;
  LC_TD_BOOL LC_VD_BUTTON3INPUT;
  LC_TD_DataType_SAFEBOOL LC_VD_ESTOP;
  LC_TD_DataType_SAFEBOOL LC_VD_DUMMY1;
  LC_TD_DataType_SAFEBOOL LC_VD_DUMMY2;
  LC_TD_BOOL _LC_VD_dummy;        /* dummy structure member - to avoid empty struct, when no GVs are defined */
} LCCG_StructAttrib LC_TD_LC3_GVType;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_LC3_GVType(p) \
  LC_INIT_BOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_BUTTON1INDICATOR,LC_TD_BOOL))); \
  LC_INIT_BOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_BUTTON1INPUT,LC_TD_BOOL))); \
  LC_INIT_BOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_BUTTON2INDICATOR,LC_TD_BOOL))); \
  LC_INIT_BOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_BUTTON2INPUT,LC_TD_BOOL))); \
  LC_INIT_BOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_BUTTON3INDICATOR,LC_TD_BOOL))); \
  LC_INIT_BOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_BUTTON3INPUT,LC_TD_BOOL))); \
  LC_INIT_DataType_SAFEBOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_DUMMY1,LC_TD_DataType_SAFEBOOL))); \
  LC_INIT_DataType_SAFEBOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_DUMMY2,LC_TD_DataType_SAFEBOOL))); \
  LC_INIT_DataType_SAFEBOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_ESTOP,LC_TD_DataType_SAFEBOOL))); \

#define LC_INIT_LC3_GVType(p) \
{ \
  LC_INIT_NONDMA_LC3_GVType(p) \
}


/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_LC3_GVType(p,RF) \
  LC_WINIT_BOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_BUTTON1INDICATOR,LC_TD_BOOL)),RF); \
  LC_WINIT_BOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_BUTTON1INPUT,LC_TD_BOOL)),RF); \
  LC_WINIT_BOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_BUTTON2INDICATOR,LC_TD_BOOL)),RF); \
  LC_WINIT_BOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_BUTTON2INPUT,LC_TD_BOOL)),RF); \
  LC_WINIT_BOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_BUTTON3INDICATOR,LC_TD_BOOL)),RF); \
  LC_WINIT_BOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_BUTTON3INPUT,LC_TD_BOOL)),RF); \
  LC_WINIT_DataType_SAFEBOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_DUMMY1,LC_TD_DataType_SAFEBOOL)),RF); \
  LC_WINIT_DataType_SAFEBOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_DUMMY2,LC_TD_DataType_SAFEBOOL)),RF); \
  LC_WINIT_DataType_SAFEBOOL(&(LC_GV_INIT_ELEM(pEPDB,LC_VD_ESTOP,LC_TD_DataType_SAFEBOOL)),RF); \

#define LC_WINIT_LC3_GVType(p,RF) \
{ \
  LC_WINIT_NONDMA_LC3_GVType(p,RF) \
}


unsigned LC_GV_Init(LCoplck_EPDB * pEPDB, LCoplck_StartMode s);

extern LC_TD_LC3_GVType g_LC3_GVInstanceData;

#endif /* LC3GV_H */
