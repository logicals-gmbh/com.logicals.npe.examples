/* Copyright (C) logi.cals GmbH. All rights reserved. */

#ifndef RISMDATTRIBUTES_H
#define RISMDATTRIBUTES_H

#include <RTConfig.h>

#if defined RT_CC_RISMD_ATTRIB
#define RISMD_ATTRIBUTES RT_CC_RISMD_ATTRIB
#else
#define RISMD_ATTRIBUTES
#endif

#endif
