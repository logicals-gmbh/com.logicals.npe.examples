#include <RISMD.h>

RISMDFingerprint const lcmd_fingerprint RISMD_ATTRIBUTES = INIT_RISMDFingerprint(2371338467);

