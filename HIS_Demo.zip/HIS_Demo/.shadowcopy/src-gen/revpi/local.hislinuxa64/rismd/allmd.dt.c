/**
*** logi.CAD3 generated Source include file
*** This file has been generated automatically and will be overwritten. Do not edit!
**/

#include "src-gen/rismd/mddt___safebool.c"
#include "src-gen/rismd/mddt___safebyte.c"
#include "src-gen/rismd/mddt___safedint.c"
#include "src-gen/rismd/mddt___safedword.c"
#include "src-gen/rismd/mddt___safeint.c"
#include "src-gen/rismd/mddt___safesint.c"
#include "src-gen/rismd/mddt___safety.plcopen.sfb_genericsafetydemand_state.c"
#include "src-gen/rismd/mddt___safeudint.c"
#include "src-gen/rismd/mddt___safeuint.c"
#include "src-gen/rismd/mddt___safeusint.c"
#include "src-gen/rismd/mddt___safeword.c"

