/**
*** logi.CAD3 generated Source include file
*** This file has been generated automatically and will be overwritten. Do not edit!
**/

#include "src-gen/rismd/mdfu___fb_hissafety.c"
#include "src-gen/rismd/mdfu___fb_packagingindicators.c"
#include "src-gen/rismd/mdfu___fb_packagingline.c"
#include "src-gen/rismd/mdfu___fb_packagingsimulation.c"
#include "src-gen/rismd/mdfu___safety.plcopen.sfb_genericsafetydemand.c"

