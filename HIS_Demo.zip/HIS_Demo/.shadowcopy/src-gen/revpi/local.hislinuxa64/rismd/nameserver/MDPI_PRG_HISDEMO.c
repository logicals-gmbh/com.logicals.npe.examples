#include <RISMD.h>
#include <LC3EntryPoint_MD.h>

extern RISMDPOUType const lcmd_type_PRG_HISDEMO;

static char const lcmd_ep_name_pi_PRG_HISDEMO[] RISMD_ATTRIBUTES = "PRG_HISDemo";
RISMDEntryPoint const lcmd_entrypoint_pi_PRG_HISDemo RISMD_ATTRIBUTES =
  INIT_RISMDEntryPoint(RISMD_MEM_TYPE_EP, 256, lcmd_ep_name_pi_PRG_HISDEMO, &lcmd_type_PRG_HISDEMO, RISMD_EP_BASE_PRG_HISDEMO);
