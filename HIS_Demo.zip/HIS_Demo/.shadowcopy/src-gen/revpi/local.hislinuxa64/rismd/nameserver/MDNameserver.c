#include <RISMD.h>

extern const RISMDEntryPoint lcmd_entrypoint_pi_PRG_HISDemo;
extern const RISMDEntryPoint lcmd_entrypoint_gvinstance;
RISMDReference const lcmd_nameserver_ep_list[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_entrypoint_pi_PRG_HISDemo),
  INIT_RISMDReference(&lcmd_entrypoint_gvinstance),
};
RISMDNameserver_V1 const lcmd_nameserver RISMD_ATTRIBUTES = INIT_RISMDNameserver_V1(2,lcmd_nameserver_ep_list);

