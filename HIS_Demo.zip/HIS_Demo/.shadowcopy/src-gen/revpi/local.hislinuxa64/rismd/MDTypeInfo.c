#include <RISMD.h>

RISMDTypeInfo const lcmd_type_info RISMD_ATTRIBUTES = INIT_RISMDTypeInfo(0, NULL);
