#include <RISMD.h>
#include <LCAPI.h>

extern RISMDNameserver_V1 const lcmd_nameserver;
extern RISMDFingerprint const lcmd_fingerprint;
extern RISMDTypeInfo const lcmd_type_info;

RISMDReference const lcmd_root_md_list[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_nameserver),
  INIT_RISMDReference(&lcmd_fingerprint),
  INIT_RISMDReference(&lcmd_type_info),
};

RISMDRoot const risMdRoot RISMD_ATTRIBUTES = INIT_RISMDRoot(3,lcmd_root_md_list);

RISMDTargetInfo const risMdTargetInfo RISMD_ATTRIBUTES = INIT_RISMDTargetInfo();

void const *lc_get_ris_md_root(void)
{
  return &risMdRoot;
}

/*
 * lc_get_ris_md_target_info forces linking of RIS target info - needed for reload
 * => do not remove it, even if it is not needed by RTS
 */
void const *lc_get_ris_md_target_info(void)
{
  return &risMdTargetInfo;
}
