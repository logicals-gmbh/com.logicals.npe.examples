/**
*** logi.CAD3 generated Source include file
*** This file has been generated automatically and will be overwritten. Do not edit!
**/

#include "src-gen/lcfu___fb_hissafety.c"
#include "src-gen/lcfu___fb_packagingindicators.c"
#include "src-gen/lcfu___fb_packagingline.c"
#include "src-gen/lcfu___safety.plcopen.sfb_genericsafetydemand.c"

