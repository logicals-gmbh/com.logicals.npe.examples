/* Copyright (C) logi.cals GmbH. All rights reserved. */
#ifndef IO_ACCESS_HELPER_H_
#define IO_ACCESS_HELPER_H_

/* -- Include files --------------------------------------------------------- */
#include <stdint.h>
#include <LCAPIIOAccT.h>

/* -- Externals ------------------------------------------------------------- */

/* -- Defines --------------------------------------------------------------- */

/** \defgroup DocGrpLCAPIInternalStatic LCAPI - Internal interface to static code
 * It provides an internal interface to access the static (not generated) helper functions.
 * It provides optimized IO copy functions for the generated code. (IOAccessHelper.c/h)
 */

/** \defgroup DocGrpLCAPIDefines Defines
 * \ingroup DocGrpLCAPIInternalStatic
 *
 * Defines of LCAPI internal static interface.<br>
 * \{*/

/* Enable copy table CRC calculation and checks automatically in safety products */
#if defined(LC3CG_SAFETY_FEATURES_ONLY)
#define LC3CG_CALCULATE_AND_CHECK_COPY_TABLE_CRC
#endif

/* Disable copy table CRC fault injection if calculation and checks are turned off */
#if !defined(LC3CG_CALCULATE_AND_CHECK_COPY_TABLE_CRC)
#undef LC3CG_FAULT_INJECTION_FOR_COPY_TABLE_CRC
#endif

/* Macros for copy table CRC calculation (empty if feature is not used) */
#if defined(LC3CG_CALCULATE_AND_CHECK_COPY_TABLE_CRC)
/** Copy table CRC init macro (defines uint32_t crc variable and initializes it to zero) */
#define CRC_INIT(aCrc)                              \
  uint32_t aCrc = 0u
/** Copy table CRC update macro
 * Adds fields variable, bitOrByteOffset, and bitOrByteSize of the copy table entry to the crc.
 * Ensures that the crc never gets zero. (sets most significant bit of 32-bit crc)
 * \param[in,out] aCrc The crc to update
 * \param[in] aCopyEntry The copy table entry
 */
#define CRC_UPDATE(aCrc, aCopyEntry)                \
  {                                                 \
    /* Add pointer, offset and size */              \
    aCrc += (uint32_t)aCopyEntry->variable;         \
    aCrc += (uint32_t)aCopyEntry->bitOrByteOffset;  \
    aCrc += (uint32_t)aCopyEntry->bitOrByteSize;    \
    /* Make sure that the CRC never gets zero */    \
    aCrc |= (uint32_t)0x80000000u;                  \
  }                                                 \
  (void)0
/** Copy table CRC check macro
 * - If old crc pointer is NULL: return #LC_IOACC_COPY_RC_INVALID_ARG
 * - Else if old crc is zero: Update old crc to new crc and return #LC_IOACC_COPY_RC_OK (first cycle, crc not checked)
 * - Else if old crc != new crc: Reset old crc to zero and return #LC_IOACC_COPY_RC_INVALID_CRC
 * - Else: Do nothing (crc equal to previous crc)
 * \param[in] aNewCrc The newly calculated crc
 * \param[in] aOldCrcPtr Pointer to old (zero-initialized, or previously calculated crc)
 */
#define CRC_CHECK(aNewCrc, aOldCrcPtr)             \
  {                                                \
    if (aOldCrcPtr == NULL)                        \
    {                                              \
      return LC_IOACC_COPY_RC_INVALID_ARG;         \
    }                                              \
    else if (*aOldCrcPtr == 0u)                    \
    {                                              \
      *aOldCrcPtr = aNewCrc;                       \
      return LC_IOACC_COPY_RC_OK;                  \
    }                                              \
    else if (*aOldCrcPtr != aNewCrc)               \
    {                                              \
      *aOldCrcPtr = 0u;                            \
      return LC_IOACC_COPY_RC_INVALID_CRC;         \
    }                                              \
  }                                                \
  (void)0
#else
#define CRC_INIT(aCrc)                   (void)aCopyTableCrc
#define CRC_UPDATE(aCrc, aCopyEntry)     (void)0
#define CRC_CHECK(aNewCrc, aOldCrcPtr) (void)0
#endif

/* Macros for copy table CRC fault injection (empty if feature is not used) */
#if defined(LC3CG_FAULT_INJECTION_FOR_COPY_TABLE_CRC)
/** CRC fault injection macro
 * - If aErrorCounter is not zero
 *  - Decrement aErrorCounter
 *  - If aErrorCounter is zero (and was not zero)
 *   - Increment the crc (fault injection)
 * \param[in] aCrc The crc to modify
 * \param[in] aErrorCounter Error counter
 */
#define CRC_FAULT_INJECTION(aCrc, aErrorCounter)   \
  {                                                \
    if (aErrorCounter != 0u)                       \
    {                                              \
      aErrorCounter--;                             \
      if (aErrorCounter == 0u)                     \
      {                                            \
        aCrc++;                                    \
      }                                            \
    }                                              \
  }                                                \
  (void)0
#else
#define CRC_FAULT_INJECTION(aCrc, aErrorCounter) do {} while(0)
#endif

/* Macros for readability (to make distinction whether bits or bytes meant visible) */
#define IOACC_BITS(n)  (n)
#define IOACC_BYTES(n) (n)

/** Set LCAPI_IOACC_STATIC to empty from CTC compile to force coverage analysis */
#if !defined(LCAPI_IOACC_STATIC)
 #define LCAPI_IOACC_STATIC static
#endif

/** \}*/ /* DocGrpLCAPIDefines */

/* -- Typedefs -------------------------------------------------------------- */

/** \defgroup DocGrpLCAPITypes Type definitions
 * \ingroup DocGrpLCAPIInternalStatic
 *
 * Type definitions of LCAPI internal static interface.<br>
 * \{*/

/**
 * Function to read a variable from a process data image
 *
 * \param[out] aVariable        Address of the global variable
 * \param[in]  aPdi             Address of the process data image
 * \param[in]  aBitOrByteOffset Offset in the process data image
 * \param[in]  aBitOrByteSize   Size in the process data image
 */
typedef void (*LcIOAccReadFunctionPtr)(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOrByteOffset, uint32_t aBitOrByteSize);

/**
 * Function to write a variable to a process data image
 *
 * \param[out] aVariable        Address of the global variable
 * \param[in]  aPdi             Address of the process data image
 * \param[in]  aBitOrByteOffset Offset in the process data image
 * \param[in]  aBitOrByteSize   Size in the process data image
 */
typedef void (*LcIOAccWriteFunctionPtr)(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOrByteOffset, uint32_t aBitOrByteSize);

/** Structure for controlling the copy table CRC fault injection
 * Set counter to non-zero value to start a delayed modification of the crc.
 * The counter is decremented at each copy table processing, and the crc is modified if the counter reaches zero.
 */
#if defined(LC3CG_FAULT_INJECTION_FOR_COPY_TABLE_CRC)
typedef struct {
  uint32_t inputErrorCounter;            /**< Counter to use for input copy tables. */
  uint32_t outputErrorCounter;           /**< Counter to use for output copy tables. */
} LcIOAccFaultInjectionForCopyTableCrc;
#endif

/** Structure for an input copy table entry */
typedef struct
{
  uint32_t bitOrByteOffset;              /**< Bit offset in process data image */
  uint32_t bitOrByteSize;                /**< Bit size in process data image */
  void* variable;                        /**< Address of global variable */
  LcIOAccReadFunctionPtr readFunction;   /**< Read function */
} LcIOAccCopyEntryInput;

/** Structure for an output copy table entry */
typedef struct
{
  uint32_t bitOrByteOffset;              /**< Bit offset in process data image */
  uint32_t bitOrByteSize;                /**< Bit size in process data image */
  void* variable;                        /**< Address of global variable */
  LcIOAccWriteFunctionPtr writeFunction; /**< Write function */
} LcIOAccCopyEntryOutput;

/** Structure for a memory copy table entry */
typedef struct
{
  uint32_t bitOrByteOffset;              /**< Bit offset in process data image */
  uint32_t bitOrByteSize;                /**< Bit size in process data image */
  void* variable;                        /**< Address of global variable */
  LcIOAccReadFunctionPtr readFunction;   /**< Read function */
  LcIOAccWriteFunctionPtr writeFunction; /**< Write function */
} LcIOAccCopyEntryMemory;

/** Structure for an input copy table */
typedef struct
{
  uint32_t copyEntryCnt;                     /**< Number of table entries */
  LcIOAccCopyEntryInput const* copyEntries;  /**< Array with table entries */
} LcIOAccCopyTableInput;

/** Structure for an output copy table */
typedef struct
{
  uint32_t copyEntryCnt;                     /**< Number of table entries */
  LcIOAccCopyEntryOutput const* copyEntries; /**< Array with table entries */
} LcIOAccCopyTableOutput;

/** Structure for a memory copy table */
typedef struct
{
  uint32_t copyEntryCnt;                     /**< Number of table entries */
  LcIOAccCopyEntryMemory const* copyEntries; /**< Array with table entries */
} LcIOAccCopyTableMemory;

/** Structure for a table descriptor containing input, output and memory coyp tables */
typedef struct
{
  LcIOAccServiceId serviceId;                           /**< Service ID (non-zero) */
  uint32_t additionalIds[LC_IOACC_ADDITIONAL_IDS_SIZE]; /**< Additional IDs (0, 0 if not used) */
  LcIOAccCopyTableInput const* inputCopyTable;          /**< Copy table for input process data image */
  uint32_t* inputCopyTableCrc;                          /**< Copy table CRC for input process data image */
  uint32_t inputBitSize;                                /**< Size of input process data image */
  LcIOAccCopyTableOutput const* outputCopyTable;        /**< Copy table for output process data image */
  uint32_t* outputCopyTableCrc;                         /**< Copy table CRC for output process data image */
  uint32_t outputBitSize;                               /**< Size of output process data image */
  LcIOAccCopyTableMemory const* memoryCopyTable;        /**< Copy table for memory process data image */
  uint32_t* memoryCopyTableCrc;                         /**< Copy table CRC for memory process data image */
  uint32_t memoryBitSize;                               /**< Size of memory process data image */
} LcIOAccTableDescriptor;

/** \}*/ /* DocGrpLCAPITypes */

/* -- Variables ------------------------------------------------------------- */

/** \defgroup DocGrpLCAPIVariables Variables
 * \ingroup DocGrpLCAPIInternalStatic
 *
 * Global variables of LCAPI internal static interface.<br>
 * \{*/

/** Variable for controlling the copy table CRC fault injection */
#if defined(LC3CG_FAULT_INJECTION_FOR_COPY_TABLE_CRC)
/** Global variable to store the state of the crc fault injection */
extern LcIOAccFaultInjectionForCopyTableCrc lc_ioacc_faultInjectionForCopyTableCrc;
#endif

/** \}*/ /* DocGrpLCAPIVariables */

/* -- Prototypes ------------------------------------------------------------ */

/** \defgroup DocGrpLCAPIFunctions Functions
 * \ingroup DocGrpLCAPIInternalStatic
 *
 * Functions of LCAPI internal static interface.<br>
 * \{*/

/** Read a single bit from a process data image into an ANY variable
 * \note Output variable bits exceeding one bit are unchanged
 * \note \p aBitSize is ignored (assumed one bit)
 * \param[out] aVariable Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi       Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readBit(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Read multiple bits from one byte of a process data image into an ANY variable
 * \note Output variable bits exceeding the bit size are unchanged
 * \param[out] aVariable Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi       Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readBits8(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Read multiple bits from two bytes of a process data image into an ANY variable
 * \note Output variable bits exceeding the bit size are unchanged
 * \param[out] aVariable Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi       Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readBits16(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Read multiple bits from three bytes of a process data image into an ANY variable
 * \note Output variable bits exceeding the bit size are unchanged
 * \param[out] aVariable Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi       Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readBits24(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Read multiple bits from four bytes of a process data image into an ANY variable
 * \note Output variable bits exceeding the bit size are unchanged
 * \param[out] aVariable Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi       Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readBits32(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Read multiple bits from a process data image into an ANY variable
 * \note Output variable bits exceeding the bit size are unchanged
 * \param[out] aVariable Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi       Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readBits(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Read bits from a single aligned byte from a process data image into an ANY variable
 * \param[out] aVariable  Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi        Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aByteOffset Process data byte offset (overflow checked by caller)
 * \param[in] aBitSize    Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBits(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aBitSize);

/** Read a single aligned byte from a process data image into an ANY variable
 * \note \p aByteSize is ignored (assumed one byte)
 * \param[out] aVariable  Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi        Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aByteOffset Process data byte offset (overflow checked by caller)
 * \param[in] aByteSize   Process data byte size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readAlignedByte(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aByteSize);

/** Read multiple aligned bytes from a process data image into an ANY variable
 * \param[out] aVariable  Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi        Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aByteOffset Process data byte offset (overflow checked by caller)
 * \param[in] aByteSize   Process data byte size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBytes(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aByteSize);

/** Read multiple aligned bytes (ending with a partial byte) from a process data image into an ANY variable
 * \note Output variable bits exceeding the bit size are unchanged
 * \param[out] aVariable  Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi        Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aByteOffset Process data byte offset (overflow checked by caller)
 * \param[in] aBitSize    Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBytesAndBits(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aBitSize);

/** Read a single bit from a process data image into a BOOL variable
 * \note The output variable byte written is either zero or one
 * \note \p aBitSize is ignored (assumed one bit)
 * \param[out] aVariable Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi       Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readBool(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Read multiple bits from a process data image into an ARRAY OF BOOL variable
 * \note The output variable bytes written are either zero or one
 * \param[out] aVariable Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi       Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readBoolArray(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Read a single bit (which is byte aligned) from a process data image into a BOOL variable
 * \note The output variable byte written is either zero or one
 * \note \p aBitSize is ignored (assumed one bit)
 * \param[out] aVariable  Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi        Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aByteOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize    Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBool(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aBitSize);

/** Read multiple bits (which are byte aligned) from a process data image into an ARRAY OF BOOL variable
 * \note The output variable bytes written are either zero or one
 * \param[out] aVariable  Pointer to the output variable (pointer is NULL checked by caller)
 * \param[in] aPdi        Pointer to the process data image to read from (pointer is NULL checked by caller)
 * \param[in] aByteOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize    Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBoolArray(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aBitSize);

/** Write the least significant bit (LSB) from any non-BOOL variable to a process data image
 * \note \p aBitSize is ignored (assumed one bit)
 * \param[in] aVariable  Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi      Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeBit(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Write multiple bits from an ANY variable into one byte of a process data image
 * \param[in] aVariable  Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi      Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeBits8(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Write multiple bits from an ANY variable into two bytes of a process data image
 * \param[in] aVariable  Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi      Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeBits16(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Write multiple bits from an ANY variable into three bytes of a process data image
 * \param[in] aVariable  Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi      Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeBits24(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Write multiple bits from an ANY variable into four bytes of a process data image
 * \param[in] aVariable  Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi      Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeBits32(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Write multiple bits from an ANY variable into a process data image
 * \param[in] aVariable  Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi      Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeBits(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Write aligned bits of a single byte from an ANY variable into a process data image
 * \param[in] aVariable   Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi       Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aByteOffset Process data byte offset (overflow checked by caller)
 * \param[in] aBitSize    Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBits(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aBitSize);

/** Write a single aligned byte from an ANY variable into a process data image
 * \note \p aByteSize is ignored (assumed one byte)
 * \param[in] aVariable   Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi       Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aByteOffset Process data byte offset (overflow checked by caller)
 * \param[in] aByteSize   Process data byte size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedByte(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aByteSize);

/** Write multiple aligned bytes from an ANY variable into a process data image
 * \param[in] aVariable   Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi       Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aByteOffset Process data byte offset (overflow checked by caller)
 * \param[in] aByteSize   Process data byte size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBytes(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aByteSize);

/** Write multiple aligned bytes (ending with a partial byte) from an ANY variable into a process data image
 * \param[in] aVariable   Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi       Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aByteOffset Process data byte offset (overflow checked by caller)
 * \param[in] aBitSize    Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBytesAndBits(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aBitSize);

/** Write a BOOL variable (stored in a byte) to a single bit in the process data image
 * \note The process data image bit is set for any non-zero byte value, and cleared in case of the byte value being zero
 * \note \p aBitSize is ignored (assumed one bit)
 * \param[in] aVariable  Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi      Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeBool(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Write an array of BOOL variables (stored in an array of bytes) to multiple bits in the process data image
 * \note For every array element, the process data image bit is set for any non-zero byte value, and cleared in case of the
 * byte value being zero
 * \param[in] aVariable  Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi      Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aBitOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize   Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeBoolArray(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);

/** Write a BOOL variable (stored in a byte) to a single bit (which is byte aligned) in the process data image
 * \note The process data image bit is set for any non-zero byte value, and cleared in case of the byte value being zero
 * \note \p aBitSize is ignored (assumed one bit)
 * \param[in] aVariable   Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi       Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aByteOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize    Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBool(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aBitSize);

/** Write an array of BOOL variables (stored in an array of bytes) to multiple bits (which are byte aligned) in the process data image
 * \note For every array element, the process data image bit is set for any non-zero byte value, and cleared in case of the
 * byte value being zero
 * \param[in] aVariable   Pointer to the input variable (pointer is NULL checked by caller)
 * \param[out] aPdi       Pointer to the process data image to write to (pointer is NULL checked by caller)
 * \param[in] aByteOffset Process data bit offset (overflow checked by caller)
 * \param[in] aBitSize    Process data bit size (overflow checked by caller)
 */
LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBoolArray(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aBitSize);

/** Copy input data to global variables for a table
 * - Use #CRC_INIT to initialize the new copy table crc
 * - For each copy table entry
 *  - Call the #LcIOAccCopyEntryInput.readFunction of the copy table entry
 *  - Use #CRC_UPDATE to update the new crc
 * - Use #CRC_FAULT_INJECTION to optionally modify the crc
 *  - Use #lc_ioacc_faultInjectionForCopyTableCrc inputErrorCounter as counter
 * - Use #CRC_CHECK to check the crc
 *  - Update *aCopyTableCrc to the new crc only if *aCopyTableCrc is zero (first call)
 *  - Reset *aCopyTableCrc to zero if new crc is not equal to old crc (and old crc is not zero)
 *  - Optionally return an error
 *
 * \param[in] aCopyTable        The copy table to process (pointer is NULL checked by caller)
 * \param[in,out] aCopyTableCrc The previous copy table crc (zero before the first call)
 * \param[in] aIoSegment        Pointer to the input process data to read from (pointer is NULL checked by caller)
 * \return The return code
 * \retval #LC_IOACC_COPY_RC_OK          Success
 * \retval #LC_IOACC_COPY_RC_INVALID_ARG aCopyTableCrc is NULL
 * \retval #LC_IOACC_COPY_RC_INVALID_CRC CRC invalid
 */
LCAPI_IOACC_STATIC LcIOAccCopyRc lc_ioacc_copyInputDataForTable(LcIOAccCopyTableInput const* aCopyTable, uint32_t* aCopyTableCrc, uint8_t const* aIoSegment);

/** Copy output data from global variables for a table
 * - Use #CRC_INIT to initialize the new copy table crc
 * - For each copy table entry
 *  - Call the #LcIOAccCopyEntryOutput.writeFunction of the copy table entry
 *  - Use #CRC_UPDATE to update the new crc
 * - Use #CRC_FAULT_INJECTION to optionally modify the crc
 *  - Use #lc_ioacc_faultInjectionForCopyTableCrc outputErrorCounter as counter
 * - Use #CRC_CHECK to check the crc
 *  - Update *aCopyTableCrc to the new crc only if *aCopyTableCrc is zero (first call)
 *  - Reset *aCopyTableCrc to zero if new crc is not equal to old crc (and old crc is not zero)
 *  - Optionally return an error
 *
 * \param[in] aCopyTable        The copy table to process (pointer is NULL checked by caller)
 * \param[in,out] aCopyTableCrc The previous copy table crc (zero before the first call)
 * \param[in] aIoSegment        Pointer to the output process data to write to (pointer is NULL checked by caller)
 * \return The return code
 * \retval #LC_IOACC_COPY_RC_OK          Success
 * \retval #LC_IOACC_COPY_RC_INVALID_ARG aCopyTableCrc is NULL
 * \retval #LC_IOACC_COPY_RC_INVALID_CRC CRC invalid
 */
LCAPI_IOACC_STATIC LcIOAccCopyRc lc_ioacc_copyOutputDataForTable(LcIOAccCopyTableOutput const* aCopyTable, uint32_t* aCopyTableCrc, uint8_t* aIoSegment);

/** Copy memory data to global variables for a table
 * - Use #CRC_INIT to initialize the new copy table crc
 * - For each copy table entry
 *  - Call the #LcIOAccCopyEntryMemory.readFunction of the copy table entry
 *  - Use #CRC_UPDATE to update the new crc
 * - Use #CRC_FAULT_INJECTION to optionally modify the crc
 *  - Use #lc_ioacc_faultInjectionForCopyTableCrc inputErrorCounter as counter
 * - Use #CRC_CHECK to check the crc
 *  - Update *aCopyTableCrc to the new crc only if *aCopyTableCrc is zero (first call)
 *  - Reset *aCopyTableCrc to zero if new crc is not equal to old crc (and old crc is not zero)
 *  - Optionally return an error
 *
 * \param[in] aCopyTable        The copy table to process (pointer is NULL checked by caller)
 * \param[in,out] aCopyTableCrc The previous copy table crc (zero before the first call)
 * \param[in] aIoSegment        Pointer to the memory process data to read from (pointer is NULL checked by caller)
 * \return The return code
 * \retval #LC_IOACC_COPY_RC_OK          Success
 * \retval #LC_IOACC_COPY_RC_INVALID_ARG aCopyTableCrc is NULL
 * \retval #LC_IOACC_COPY_RC_INVALID_CRC CRC invalid
 */
LCAPI_IOACC_STATIC LcIOAccCopyRc lc_ioacc_copyMemoryDataToVariablesForTable(LcIOAccCopyTableMemory const* aCopyTable, uint32_t* aCopyTableCrc, uint8_t const* aIoSegment);

/** Copy memory data from global variables for a table
 * - Use #CRC_INIT to initialize the new copy table crc
 * - For each copy table entry
 *  - Call the #LcIOAccCopyEntryMemory.writeFunction of the copy table entry
 *  - Use #CRC_UPDATE to update the new crc
 * - Use #CRC_FAULT_INJECTION to optionally modify the crc
 *  - Use #lc_ioacc_faultInjectionForCopyTableCrc outputErrorCounter as counter
 * - Use #CRC_CHECK to check the crc
 *  - Update *aCopyTableCrc to the new crc only if *aCopyTableCrc is zero (first call)
 *  - Reset *aCopyTableCrc to zero if new crc is not equal to old crc (and old crc is not zero)
 *  - Optionally return an error
 *
 * \param[in] aCopyTable        The copy table to process (pointer is NULL checked by caller)
 * \param[in,out] aCopyTableCrc The previous copy table crc (zero before the first call)
 * \param[in] aIoSegment        Pointer to the memory process data to write to (pointer is NULL checked by caller)
 * \return The return code
 * \retval #LC_IOACC_COPY_RC_OK          Success
 * \retval #LC_IOACC_COPY_RC_INVALID_ARG aCopyTableCrc is NULL
 * \retval #LC_IOACC_COPY_RC_INVALID_CRC CRC invalid
 */
LCAPI_IOACC_STATIC LcIOAccCopyRc lc_ioacc_copyMemoryDataFromVariablesForTable(LcIOAccCopyTableMemory const* aCopyTable, uint32_t* aCopyTableCrc, uint8_t* aIoSegment);

/** \}*/ /* DocGrpLCAPIFunctions */

#if NPE_HIS_CHANNEL2
/** Channel 2 copy functions for supported non-ANY_BIT data. The mapped bits are stored one's-complemented in the process data image. */
LCAPI_IOACC_STATIC void lc_ioacc_readBitC2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_readBits8C2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_readBits16C2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_readBits24C2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_readBits32C2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_readBitsC2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBitsC2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_readAlignedByteC2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aByteSize);
LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBytesC2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aByteSize);
LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBytesAndBitsC2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_writeBitC2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_writeBits8C2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_writeBits16C2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_writeBits24C2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_writeBits32C2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_writeBitsC2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBitsC2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aBitSize);
LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedByteC2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aByteSize);
LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBytesC2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aByteSize);
LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBytesAndBitsC2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aBitSize);
#else
/* Channel 1 and non-HIS use the unchanged copy functions for all data types. */
#define lc_ioacc_readBitC2Inverted                  lc_ioacc_readBit
#define lc_ioacc_readBits8C2Inverted                lc_ioacc_readBits8
#define lc_ioacc_readBits16C2Inverted               lc_ioacc_readBits16
#define lc_ioacc_readBits24C2Inverted               lc_ioacc_readBits24
#define lc_ioacc_readBits32C2Inverted               lc_ioacc_readBits32
#define lc_ioacc_readBitsC2Inverted                 lc_ioacc_readBits
#define lc_ioacc_readAlignedBitsC2Inverted          lc_ioacc_readAlignedBits
#define lc_ioacc_readAlignedByteC2Inverted          lc_ioacc_readAlignedByte
#define lc_ioacc_readAlignedBytesC2Inverted         lc_ioacc_readAlignedBytes
#define lc_ioacc_readAlignedBytesAndBitsC2Inverted  lc_ioacc_readAlignedBytesAndBits
#define lc_ioacc_writeBitC2Inverted                 lc_ioacc_writeBit
#define lc_ioacc_writeBits8C2Inverted               lc_ioacc_writeBits8
#define lc_ioacc_writeBits16C2Inverted              lc_ioacc_writeBits16
#define lc_ioacc_writeBits24C2Inverted              lc_ioacc_writeBits24
#define lc_ioacc_writeBits32C2Inverted              lc_ioacc_writeBits32
#define lc_ioacc_writeBitsC2Inverted                lc_ioacc_writeBits
#define lc_ioacc_writeAlignedBitsC2Inverted         lc_ioacc_writeAlignedBits
#define lc_ioacc_writeAlignedByteC2Inverted         lc_ioacc_writeAlignedByte
#define lc_ioacc_writeAlignedBytesC2Inverted        lc_ioacc_writeAlignedBytes
#define lc_ioacc_writeAlignedBytesAndBitsC2Inverted lc_ioacc_writeAlignedBytesAndBits
#endif

#endif /* IO_ACCESS_HELPER_H_ */
