/**
*** logi.CAD3 generated Source include file
*** This file has been generated automatically and will be overwritten. Do not edit!
**/

#include "src-gen/lcdt___safebool.c"
#include "src-gen/lcdt___safebyte.c"
#include "src-gen/lcdt___safedint.c"
#include "src-gen/lcdt___safedword.c"
#include "src-gen/lcdt___safeint.c"
#include "src-gen/lcdt___safesint.c"
#include "src-gen/lcdt___safety.plcopen.sfb_genericsafetydemand_state.c"
#include "src-gen/lcdt___safeudint.c"
#include "src-gen/lcdt___safeuint.c"
#include "src-gen/lcdt___safeusint.c"
#include "src-gen/lcdt___safeword.c"

