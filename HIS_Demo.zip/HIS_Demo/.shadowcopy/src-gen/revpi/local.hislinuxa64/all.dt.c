/**
*** logi.CAD3 generated Source include file
*** This file has been generated automatically and will be overwritten. Do not edit!
**/

#include "src-gen/lcdt___safebool.c"
#include "src-gen/lcdt___safety.plcopen.sfb_genericsafetydemand_state.c"

