/* Copyright (c) logi.cals. All rights reserved. */

/* -- Include files --------------------------------------------------------- */
#include <IOAccessHelper.h>

/* -- Externals ------------------------------------------------------------- */

/* -- Defines --------------------------------------------------------------- */

/* -- Mocking --------------------------------------------------------------- */

/* -- Typedefs -------------------------------------------------------------- */

/* -- Variables ------------------------------------------------------------- */

/** Variable for controlling the copy table CRC fault injection */
#if defined(LC3CG_FAULT_INJECTION_FOR_COPY_TABLE_CRC)
LcIOAccFaultInjectionForCopyTableCrc lc_ioacc_faultInjectionForCopyTableCrc = {0};
#endif

/* -- Prototypes ------------------------------------------------------------ */

/* -- Legacy Code ----------------------------------------------------------- */

#ifdef __GNUC__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wconversion"
#endif

#define BITS_READ(src,offs,cnt)                    \
  (((src) >> (offs)) & (0xff >> (8-cnt)))

#define BITS_WRITE(dst,offs,cnt,value)             \
  {                                                \
    (dst) &= ~(BITS_READ(0xff,0,cnt) << (offs));   \
    (dst) |= (value) << (offs);                    \
  }                                                \
  (void)0

#define ADD_BIT_OFFS(ptr,offs,delta)               \
  {                                                \
    (offs) += (delta);                             \
    (ptr) += (offs) / 8;                           \
    (offs) %= 8;                                   \
  }                                                \
  (void)0

static void copyBits(uint8_t* dst, uint8_t dstBitOffs, uint8_t const* src, uint8_t srcBitOffs, uint32_t bitCnt)
{
  /* Note: dstBitOffs and srcBitOffs specify the start bit within the byte (always 0..7) */
  uint32_t bitCntCopy;
  uint8_t bitCntSrc;
  uint8_t bitCntDst;
  uint8_t copyValue;

  while (bitCnt)
  {
    bitCntCopy = bitCnt;
    bitCntSrc = 8u - srcBitOffs;
    if (bitCntCopy > bitCntSrc)
    {
      bitCntCopy = bitCntSrc;
    }
    bitCntDst = 8u - dstBitOffs;
    if (bitCntCopy > bitCntDst)
    {
      bitCntCopy = bitCntDst;
    }
    copyValue = BITS_READ(*src, srcBitOffs, bitCntCopy);
    BITS_WRITE(*dst, dstBitOffs, bitCntCopy, copyValue);
    ADD_BIT_OFFS(dst, dstBitOffs, bitCntCopy);
    ADD_BIT_OFFS(src, srcBitOffs, bitCntCopy);
    bitCnt -= bitCntCopy;
  }
}

#ifdef __GNUC__
#pragma GCC diagnostic pop
#endif

/* -- Optimized Code -------------------------------------------------------- */

static const uint32_t statBitMask[] = {
    0xFFFFFFFFu, 0x00000001u, 0x00000003u, 0x00000007u, 0x0000000Fu, 0x0000001Fu, 0x0000003Fu, 0x0000007Fu,
    0x000000FFu, 0x000001FFu, 0x000003FFu, 0x000007FFu, 0x00000FFFu, 0x00001FFFu, 0x00003FFFu, 0x00007FFFu,
    0x0000FFFFu, 0x0001FFFFu, 0x0003FFFFu, 0x0007FFFFu, 0x000FFFFFu, 0x001FFFFFu, 0x003FFFFFu, 0x007FFFFFu,
    0x00FFFFFFu, 0x01FFFFFFu, 0x03FFFFFFu, 0x07FFFFFFu, 0x0FFFFFFFu, 0x1FFFFFFFu, 0x3FFFFFFFu, 0x7FFFFFFFu,
};

static void readBits(uint8_t* aVariable, uint8_t const* aPdi, uint8_t aBitOffset, uint8_t aBitSize, uint8_t aByteSize)
{
  union {
    uint32_t dword;
    uint8_t byte[4u];
  } varValue, pdiValue;
  uint8_t idx;
  uint32_t bitMask;

  for (idx = 0; idx < aByteSize; idx++)
  {
    varValue.byte[idx] = aVariable[idx];
    pdiValue.byte[idx] = aPdi[idx];
  }

  /* Note: we must only change the bits in *aVariable that are specified by aBitSize!
   * Using "& 0x01Fu" prevents out of bounds access to array (max value = 31).
   */
  bitMask = statBitMask[aBitSize & 0x01Fu];
  pdiValue.dword = (pdiValue.dword >> aBitOffset) & bitMask;
  bitMask = ~bitMask;
  varValue.dword = (varValue.dword & bitMask) | pdiValue.dword;

  for (idx = 0; idx < aByteSize; idx++)
  {
    aVariable[idx] = varValue.byte[idx];
  }
}

static void writeBits(uint8_t const* aVariable, uint8_t* aPdi, uint8_t aBitOffset, uint8_t aBitSize, uint8_t aByteSize)
{
  union {
    uint32_t dword;
    uint8_t byte[4u];
  } varValue, pdiValue;
  uint8_t idx;
  uint32_t bitMask;

  for (idx = 0; idx < aByteSize; idx++)
  {
    varValue.byte[idx] = aVariable[idx];
    pdiValue.byte[idx] = aPdi[idx];
  }

  /* Note: we must only change the bits in *aVariable that are specified by aBitSize!
   * Using "& 0x01Fu" prevents out of bounds access to array (max value = 31).
   */
  bitMask = statBitMask[aBitSize & 0x01Fu] << aBitOffset;
  varValue.dword = (varValue.dword << aBitOffset) & bitMask;
  bitMask = ~bitMask;
  pdiValue.dword = (pdiValue.dword & bitMask) | varValue.dword;

  for (idx = 0; idx < aByteSize; idx++)
  {
    aPdi[idx] = pdiValue.byte[idx];
  }
}

/* -- Functions ------------------------------------------------------------- */

#ifdef __GNUC__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#endif

LCAPI_IOACC_STATIC void lc_ioacc_readBit(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  (void)aBitSize;

  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  if (((aPdi[aBitOffset >> 3u] >> (aBitOffset & 0x07u)) & (uint8_t)0x01u) == 0x01u)
  {
    *aVariable |= (uint8_t)0x01u;
  }
  else
  {
    *aVariable &= (uint8_t)0xFEu;
  }
}

LCAPI_IOACC_STATIC void lc_ioacc_readBits8(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  readBits(aVariable, aPdi + (aBitOffset >> 3u), (uint8_t)(aBitOffset & 0x07u), (uint8_t)aBitSize, (uint8_t)1u);
}

LCAPI_IOACC_STATIC void lc_ioacc_readBits16(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  readBits(aVariable, aPdi + (aBitOffset >> 3u), (uint8_t)(aBitOffset & 0x07u), (uint8_t)aBitSize, (uint8_t)2u);
}

LCAPI_IOACC_STATIC void lc_ioacc_readBits24(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  readBits(aVariable, aPdi + (aBitOffset >> 3u), (uint8_t)(aBitOffset & 0x07u), (uint8_t)aBitSize, (uint8_t)3u);
}

LCAPI_IOACC_STATIC void lc_ioacc_readBits32(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  readBits(aVariable, aPdi + (aBitOffset >> 3u), (uint8_t)(aBitOffset & 0x07u), (uint8_t)aBitSize, (uint8_t)4u);
}

LCAPI_IOACC_STATIC void lc_ioacc_readBits(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  copyBits(aVariable, 0u, aPdi + (aBitOffset >> 3u), (uint8_t)(aBitOffset & 0x07u), aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBits(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aBitSize)
{
  /* Note: using "& 0x07u" for modulus to help non-optimizing compilers */
  uint8_t lBitsToCopy   = (uint8_t)(aBitSize & 0x07u);

  /* Note: we can safely assume that aBitSize is in range 1 to 7 */
  uint32_t lPdiBitMask = statBitMask[lBitsToCopy];
  uint32_t lVarBitMask = ~lPdiBitMask;
  *aVariable = (uint8_t)((*aVariable & lVarBitMask) | (aPdi[aByteOffset] & lPdiBitMask));
}

LCAPI_IOACC_STATIC void lc_ioacc_readAlignedByte(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aByteSize)
{
  (void)aByteSize;

  *aVariable = aPdi[aByteOffset];
}

LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBytes(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aByteSize)
{
  aPdi += aByteOffset;
  while (aByteSize)
  {
    *aVariable = *aPdi;
    aPdi++;
    aVariable++;
    aByteSize--;
  }
}

LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBytesAndBits(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  uint32_t lBytesToCopy = (uint32_t)(aBitSize >> 3u);
  uint8_t lBitsToCopy   = (uint8_t)(aBitSize & 0x07u);

  aPdi += aByteOffset;
  while (lBytesToCopy)
  {
    *aVariable = *aPdi;
    aPdi++;
    aVariable++;
    lBytesToCopy--;
  }
  if (lBitsToCopy)
  {
    uint32_t lPdiBitMask = statBitMask[lBitsToCopy];
    uint32_t lVarBitMask = ~lPdiBitMask;
    *aVariable = (uint8_t)((*aVariable & lVarBitMask) | (*aPdi & lPdiBitMask));
  }
}

LCAPI_IOACC_STATIC void lc_ioacc_readBool(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  (void)aBitSize;

  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  *aVariable = (aPdi[aBitOffset >> 3u] >> (aBitOffset & 0x07u)) & (uint8_t)0x01u;
}

LCAPI_IOACC_STATIC void lc_ioacc_readBoolArray(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  while (aBitSize)
  {
    /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
    *aVariable = (aPdi[aBitOffset >> 3u] >> (aBitOffset & 0x07u)) & (uint8_t)0x01u;
    aBitOffset++;
    aVariable++;
    aBitSize--;
  }
}

LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBool(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aBitSize)
{
  (void)aBitSize;

  *aVariable = aPdi[aByteOffset] & (uint8_t)0x01u;
}

LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBoolArray(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aBitSize)
{
  aPdi += aByteOffset;
  while (aBitSize >= 8u)
  {
    uint8_t lTmpByte = *aPdi;
    *aVariable = (lTmpByte & 0x01u);
    aVariable++;
    *aVariable = (lTmpByte & 0x02u) >> 1u;
    aVariable++;
    *aVariable = (lTmpByte & 0x04u) >> 2u;
    aVariable++;
    *aVariable = (lTmpByte & 0x08u) >> 3u;
    aVariable++;
    *aVariable = (lTmpByte & 0x10u) >> 4u;
    aVariable++;
    *aVariable = (lTmpByte & 0x20u) >> 5u;
    aVariable++;
    *aVariable = (lTmpByte & 0x40u) >> 6u;
    aVariable++;
    *aVariable = (lTmpByte & 0x80u) >> 7u;
    aVariable++;
    aPdi++;
    aBitSize -= 8u;
  }
  if (aBitSize != 0u)
  {
    uint8_t lTmpByte = *aPdi;
    for (uint8_t lBitNr = 0u; lBitNr < aBitSize; lBitNr++)
    {
      *aVariable = lTmpByte & 0x01u;
      lTmpByte >>= 1u;
      aVariable++;
    }
  }
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBit(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  (void)aBitSize;

  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  if (*aVariable & 0x01u)
  {
    aPdi[aBitOffset >> 3u] |= (uint8_t)(1u << (aBitOffset & 0x07u));
  }
  else
  {
    aPdi[aBitOffset >> 3u] &= (uint8_t)(~(1u << (aBitOffset & 0x07u)));
  }
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBits8(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  writeBits(aVariable, aPdi + (aBitOffset >> 3u), (uint8_t)(aBitOffset & 0x07u), (uint8_t)aBitSize, (uint8_t)1u);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBits16(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  writeBits(aVariable, aPdi + (aBitOffset >> 3u), (uint8_t)(aBitOffset & 0x07u), (uint8_t)aBitSize, (uint8_t)2u);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBits24(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  writeBits(aVariable, aPdi + (aBitOffset >> 3u), (uint8_t)(aBitOffset & 0x07u), (uint8_t)aBitSize, (uint8_t)3u);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBits32(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  writeBits(aVariable, aPdi + (aBitOffset >> 3u), (uint8_t)(aBitOffset & 0x07u), (uint8_t)aBitSize, (uint8_t)4u);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBits(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  copyBits(aPdi + (aBitOffset >> 3u), (uint8_t)(aBitOffset & 0x07u), aVariable, 0u, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBits(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aBitSize)
{
  /* Note: using "& 0x07u" for modulus to help non-optimizing compilers */
  uint8_t lBitsToCopy   = (uint8_t)(aBitSize & 0x07u);

  aPdi += aByteOffset;

  /* Note: we can safely assume that aBitSize is in range 1 to 7 */
  uint32_t lVarBitMask = statBitMask[lBitsToCopy];
  uint32_t lPdiBitMask = ~lVarBitMask;
  *aPdi = (uint8_t)((*aPdi & lPdiBitMask) | (*aVariable & lVarBitMask));
}

LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedByte(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aByteSize)
{
  (void)aByteSize;

  aPdi[aByteOffset] = *aVariable;
}

LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBytes(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aByteSize)
{
  aPdi += aByteOffset;
  while (aByteSize)
  {
    *aPdi = *aVariable;
    aPdi++;
    aVariable++;
    aByteSize--;
  }
}

LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBytesAndBits(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  uint32_t lBytesToCopy = (uint32_t)(aBitSize >> 3u);
  uint8_t lBitsToCopy   = (uint8_t)(aBitSize & 0x07u);

  aPdi += aByteOffset;
  while (lBytesToCopy)
  {
    *aPdi = *aVariable;
    aPdi++;
    aVariable++;
    lBytesToCopy--;
  }
  if (lBitsToCopy)
  {
    uint32_t lVarBitMask = statBitMask[lBitsToCopy];
    uint32_t lPdiBitMask = ~lVarBitMask;
    *aPdi = (uint8_t)((*aPdi & lPdiBitMask) | (*aVariable & lVarBitMask));
  }
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBool(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  (void)aBitSize;

  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  if (*aVariable != 0u)
  {
    aPdi[aBitOffset >> 3u] |= (uint8_t)(1u << (aBitOffset & 0x07u));
  }
  else
  {
    aPdi[aBitOffset >> 3u] &= (uint8_t)(~(1u << (aBitOffset & 0x07u)));
  }
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBoolArray(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  while (aBitSize)
  {
    /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
    if (*aVariable != 0u)
    {
      aPdi[aBitOffset >> 3u] |= (uint8_t)(1u << (aBitOffset & 0x07u));
    }
    else
    {
      aPdi[aBitOffset >> 3u] &= (uint8_t)(~(1u << (aBitOffset & 0x07u)));
    }
    aBitOffset++;
    aVariable++;
    aBitSize--;
  }
}

LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBool(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aBitSize)
{
  (void)aBitSize;

  if (*aVariable != 0u)
  {
    aPdi[aByteOffset] |= (uint8_t)0x01u;
  }
  else
  {
    aPdi[aByteOffset] &= (uint8_t)0xFEu;
  }
}

LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBoolArray(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aBitSize)
{
  aPdi += aByteOffset;
  while (aBitSize >= 8u)
  {
    uint8_t lTmpByte = 0u;
    if (*aVariable != 0u)
    {
      lTmpByte |= (uint8_t)0x01u;
    }
    aVariable++;
    if (*aVariable != 0u)
    {
      lTmpByte |= (uint8_t)0x02u;
    }
    aVariable++;
    if (*aVariable != 0u)
    {
      lTmpByte |= (uint8_t)0x04u;
    }
    aVariable++;
    if (*aVariable != 0u)
    {
      lTmpByte |= (uint8_t)0x08u;
    }
    aVariable++;
    if (*aVariable != 0u)
    {
      lTmpByte |= (uint8_t)0x10u;
    }
    aVariable++;
    if (*aVariable != 0u)
    {
      lTmpByte |= (uint8_t)0x20u;
    }
    aVariable++;
    if (*aVariable != 0u)
    {
      lTmpByte |= (uint8_t)0x40u;
    }
    aVariable++;
    if (*aVariable != 0u)
    {
      lTmpByte |= (uint8_t)0x80u;
    }
    aVariable++;
    *aPdi = lTmpByte;
    aPdi++;
    aBitSize -= 8u;
  }
  if (aBitSize != 0u)
  {
    uint8_t lTmpByteMask = (uint8_t)0x01u;
    uint8_t lTmpByte = *aPdi;
    for (uint8_t lBitNr = 0u; lBitNr < aBitSize; lBitNr++)
    {
      if (*aVariable != 0u)
      {
        lTmpByte |= (uint8_t)lTmpByteMask;
      }
      else
      {
        lTmpByte &= (uint8_t)(~lTmpByteMask);
      }
      lTmpByteMask = (uint8_t)(lTmpByteMask << 1u);
      aVariable++;
    }
    *aPdi = lTmpByte;
  }
}

LCAPI_IOACC_STATIC LcIOAccCopyRc lc_ioacc_copyInputDataForTable(LcIOAccCopyTableInput const* aCopyTable, uint32_t* aCopyTableCrc, uint8_t const* aIoSegment)
{
  LcIOAccCopyEntryInput const* copyEntry;
  LcIOAccCopyEntryInput const* copyEntryEnd = aCopyTable->copyEntries + aCopyTable->copyEntryCnt;

  CRC_INIT(newCopyTableCrc);
  for (copyEntry = aCopyTable->copyEntries; copyEntry < copyEntryEnd; copyEntry++)
  {
    copyEntry->readFunction(copyEntry->variable, aIoSegment, copyEntry->bitOrByteOffset, copyEntry->bitOrByteSize);
    CRC_UPDATE(newCopyTableCrc, copyEntry);
  }
  CRC_FAULT_INJECTION(newCopyTableCrc, lc_ioacc_faultInjectionForCopyTableCrc.inputErrorCounter);
  CRC_CHECK(newCopyTableCrc, aCopyTableCrc);

  return LC_IOACC_COPY_RC_OK;
}

LCAPI_IOACC_STATIC LcIOAccCopyRc lc_ioacc_copyOutputDataForTable(LcIOAccCopyTableOutput const* aCopyTable, uint32_t* aCopyTableCrc, uint8_t* aIoSegment)
{
  LcIOAccCopyEntryOutput const* copyEntry;
  LcIOAccCopyEntryOutput const* copyEntryEnd = aCopyTable->copyEntries + aCopyTable->copyEntryCnt;

  CRC_INIT(newCopyTableCrc);
  for (copyEntry = aCopyTable->copyEntries; copyEntry < copyEntryEnd; copyEntry++)
  {
    copyEntry->writeFunction(copyEntry->variable, aIoSegment, copyEntry->bitOrByteOffset, copyEntry->bitOrByteSize);
    CRC_UPDATE(newCopyTableCrc, copyEntry);
  }
  CRC_FAULT_INJECTION(newCopyTableCrc, lc_ioacc_faultInjectionForCopyTableCrc.outputErrorCounter);
  CRC_CHECK(newCopyTableCrc, aCopyTableCrc);

  return LC_IOACC_COPY_RC_OK;
}

LCAPI_IOACC_STATIC LcIOAccCopyRc lc_ioacc_copyMemoryDataToVariablesForTable(LcIOAccCopyTableMemory const* aCopyTable, uint32_t* aCopyTableCrc, uint8_t const* aIoSegment)
{
  LcIOAccCopyEntryMemory const* copyEntry;
  LcIOAccCopyEntryMemory const* copyEntryEnd = aCopyTable->copyEntries + aCopyTable->copyEntryCnt;

  CRC_INIT(newCopyTableCrc);
  for (copyEntry = aCopyTable->copyEntries; copyEntry < copyEntryEnd; copyEntry++)
  {
    copyEntry->readFunction(copyEntry->variable, aIoSegment, copyEntry->bitOrByteOffset, copyEntry->bitOrByteSize);
    CRC_UPDATE(newCopyTableCrc, copyEntry);
  }
  CRC_FAULT_INJECTION(newCopyTableCrc, lc_ioacc_faultInjectionForCopyTableCrc.inputErrorCounter);
  CRC_CHECK(newCopyTableCrc, aCopyTableCrc);

  return LC_IOACC_COPY_RC_OK;
}

LCAPI_IOACC_STATIC LcIOAccCopyRc lc_ioacc_copyMemoryDataFromVariablesForTable(LcIOAccCopyTableMemory const* aCopyTable, uint32_t* aCopyTableCrc, uint8_t* aIoSegment)
{
  LcIOAccCopyEntryMemory const* copyEntry;
  LcIOAccCopyEntryMemory const* copyEntryEnd = aCopyTable->copyEntries + aCopyTable->copyEntryCnt;

  CRC_INIT(newCopyTableCrc);
  for (copyEntry = aCopyTable->copyEntries; copyEntry < copyEntryEnd; copyEntry++)
  {
    copyEntry->writeFunction(copyEntry->variable, aIoSegment, copyEntry->bitOrByteOffset, copyEntry->bitOrByteSize);
    CRC_UPDATE(newCopyTableCrc, copyEntry);
  }
  CRC_FAULT_INJECTION(newCopyTableCrc, lc_ioacc_faultInjectionForCopyTableCrc.outputErrorCounter);
  CRC_CHECK(newCopyTableCrc, aCopyTableCrc);

  return LC_IOACC_COPY_RC_OK;
}

#ifdef __GNUC__
#pragma GCC diagnostic pop
#endif

#if NPE_HIS_CHANNEL2
#ifdef __GNUC__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#endif

static void invertBits(uint8_t* aData, uint32_t aBitOffset, uint32_t aBitSize)
{
  while (aBitSize != 0u)
  {
    uint32_t lByteOffset = aBitOffset >> 3u;
    uint8_t lBitOffset = (uint8_t)(aBitOffset & 0x07u);
    uint8_t lBitsToInvert = (uint8_t)(8u - lBitOffset);
    if (aBitSize < lBitsToInvert)
    {
      lBitsToInvert = (uint8_t)aBitSize;
    }

    aData[lByteOffset] ^= (uint8_t)(statBitMask[lBitsToInvert] << lBitOffset);
    aBitOffset += lBitsToInvert;
    aBitSize -= lBitsToInvert;
  }
}

static void invertAlignedBits(uint8_t* aData, uint32_t aByteOffset, uint32_t aBitSize)
{
  /* Note: using "& 0x07u" for modulus to help non-optimizing compilers */
  uint8_t lBitsToInvert   = (uint8_t)(aBitSize & 0x07u);

  /* Note: we can safely assume that aBitSize is in range 1 to 7 */
  aData[aByteOffset] ^= (uint8_t)statBitMask[lBitsToInvert];
}

static void invertAlignedBytes(uint8_t* aData, uint32_t aByteOffset, uint32_t aByteSize)
{
  aData += aByteOffset;
  while (aByteSize != 0u)
  {
    *aData ^= (uint8_t)0xFFu;
    aData++;
    aByteSize--;
  }
}

static void invertAlignedBytesAndBits(uint8_t* aData, uint32_t aByteOffset, uint32_t aBitSize)
{
  /* Note: using ">> 3u" for division by 8, and "& 0x07u" for modulus to help non-optimizing compilers */
  uint32_t lBytesToInvert = (uint32_t)(aBitSize >> 3u);
  uint8_t lBitsToInvert   = (uint8_t)(aBitSize & 0x07u);

  aData += aByteOffset;
  while (lBytesToInvert)
  {
    *aData ^= (uint8_t)0xFFu;
    aData++;
    lBytesToInvert--;
  }
  if (lBitsToInvert > 0u)
  {
    *aData ^= (uint8_t)statBitMask[lBitsToInvert];
  }
}

LCAPI_IOACC_STATIC void lc_ioacc_readBitC2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: variables are always byte-aligned, use optimized inverter */
  lc_ioacc_readBit(aVariable, aPdi, aBitOffset, aBitSize);
  *aVariable ^= (uint8_t)0x01u;
}

LCAPI_IOACC_STATIC void lc_ioacc_readBits8C2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: variables are always byte-aligned, use optimized inverter */
  lc_ioacc_readBits8(aVariable, aPdi, aBitOffset, aBitSize);
  invertAlignedBits(aVariable, 0u, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_readBits16C2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: variables are always byte-aligned, use optimized inverter */
  lc_ioacc_readBits16(aVariable, aPdi, aBitOffset, aBitSize);
  invertAlignedBytesAndBits(aVariable, 0u, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_readBits24C2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: variables are always byte-aligned, use optimized inverter */
  lc_ioacc_readBits24(aVariable, aPdi, aBitOffset, aBitSize);
  invertAlignedBytesAndBits(aVariable, 0u, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_readBits32C2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: variables are always byte-aligned, use optimized inverter */
  lc_ioacc_readBits32(aVariable, aPdi, aBitOffset, aBitSize);
  invertAlignedBytesAndBits(aVariable, 0u, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_readBitsC2Inverted(uint8_t* aVariable, uint8_t const* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: variables are always byte-aligned, use optimized inverter */
  lc_ioacc_readBits(aVariable, aPdi, aBitOffset, aBitSize);
  invertAlignedBytesAndBits(aVariable, 0u, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBitsC2Inverted(
  uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aBitSize)
{
  /* Note: variables are always byte-aligned, use optimized inverter */
  lc_ioacc_readAlignedBits(aVariable, aPdi, aByteOffset, aBitSize);
  invertAlignedBytesAndBits(aVariable, 0u, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_readAlignedByteC2Inverted(
  uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aByteSize)
{
  /* Note: variables are always byte-aligned, use optimized inverter */
  lc_ioacc_readAlignedByte(aVariable, aPdi, aByteOffset, aByteSize);
  *aVariable ^= (uint8_t)0xFFu;
}

LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBytesC2Inverted(
  uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aByteSize)
{
  /* Note: variables are always byte-aligned, use optimized inverter */
  lc_ioacc_readAlignedBytes(aVariable, aPdi, aByteOffset, aByteSize);
  invertAlignedBytes(aVariable, 0u, aByteSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_readAlignedBytesAndBitsC2Inverted(
  uint8_t* aVariable, uint8_t const* aPdi, uint32_t aByteOffset, uint32_t aBitSize)
{
  /* Note: variables are always byte-aligned, use optimized inverter */
  lc_ioacc_readAlignedBytesAndBits(aVariable, aPdi, aByteOffset, aBitSize);
  invertAlignedBytesAndBits(aVariable, 0u, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBitC2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  /* Note: only one bit needs to be inverted, use optimized inverter */
  lc_ioacc_writeBit(aVariable, aPdi, aBitOffset, aBitSize);
  aPdi[aBitOffset >> 3u] ^= (uint8_t)(1u << (aBitOffset & 0x07u));
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBits8C2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  lc_ioacc_writeBits8(aVariable, aPdi, aBitOffset, aBitSize);
  invertBits(aPdi, aBitOffset, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBits16C2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  lc_ioacc_writeBits16(aVariable, aPdi, aBitOffset, aBitSize);
  invertBits(aPdi, aBitOffset, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBits24C2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  lc_ioacc_writeBits24(aVariable, aPdi, aBitOffset, aBitSize);
  invertBits(aPdi, aBitOffset, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBits32C2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  lc_ioacc_writeBits32(aVariable, aPdi, aBitOffset, aBitSize);
  invertBits(aPdi, aBitOffset, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeBitsC2Inverted(uint8_t const* aVariable, uint8_t* aPdi, uint32_t aBitOffset, uint32_t aBitSize)
{
  lc_ioacc_writeBits(aVariable, aPdi, aBitOffset, aBitSize);
  invertBits(aPdi, aBitOffset, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBitsC2Inverted(
  uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aBitSize)
{
  /* Note: process data is byte-aligned, use optimized inverter */
  lc_ioacc_writeAlignedBits(aVariable, aPdi, aByteOffset, aBitSize);
  invertAlignedBits(aPdi, aByteOffset, aBitSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedByteC2Inverted(
  uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aByteSize)
{
  /* Note: process data is byte-aligned, use optimized inverter */
  lc_ioacc_writeAlignedByte(aVariable, aPdi, aByteOffset, aByteSize);
  aPdi[aByteOffset] ^= (uint8_t)0xFFu;
}

LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBytesC2Inverted(
  uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aByteSize)
{
  /* Note: process data is byte-aligned, use optimized inverter */
  lc_ioacc_writeAlignedBytes(aVariable, aPdi, aByteOffset, aByteSize);
  invertAlignedBytes(aPdi, aByteOffset, aByteSize);
}

LCAPI_IOACC_STATIC void lc_ioacc_writeAlignedBytesAndBitsC2Inverted(
  uint8_t const* aVariable, uint8_t* aPdi, uint32_t aByteOffset, uint32_t aBitSize)
{
  /* Note: process data is byte-aligned, use optimized inverter */
  lc_ioacc_writeAlignedBytesAndBits(aVariable, aPdi, aByteOffset, aBitSize);
  invertAlignedBytesAndBits(aPdi, aByteOffset, aBitSize);
}

#ifdef __GNUC__
#pragma GCC diagnostic pop
#endif
#endif
