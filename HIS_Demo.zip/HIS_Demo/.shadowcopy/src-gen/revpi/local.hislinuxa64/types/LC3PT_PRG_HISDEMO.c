#include <LCAPI.h>
#include <LC3Globals.h>
#include <lcpu___prg_hisdemo.h>
#include "LC3CGEntryData.h"

#if NPE_HIS_CHANNEL2
#include "LC3CGAnyBitOp.h"
#else
#ifndef LC_MF_COMPARE_EQ
#define LC_MF_COMPARE_EQ(TYP,IN1,IN2)  ((IN1) == (IN2))
#endif
#ifndef LC_MF_COMPARE_NE
#define LC_MF_COMPARE_NE(TYP,IN1,IN2)  ((IN1) != (IN2))
#endif
#ifndef LC_MF_COMPARE_GE
#define LC_MF_COMPARE_GE(TYP,IN1,IN2)  ((IN1) >= (IN2))
#endif
#ifndef LC_MF_COMPARE_LE
#define LC_MF_COMPARE_LE(TYP,IN1,IN2)  ((IN1) <= (IN2))
#endif
#ifndef LC_MF_COMPARE_AND
#define LC_MF_COMPARE_AND(TYP,IN1,IN2) ((IN1) && (IN2))
#endif
#ifndef LC_MF_COMPARE_OR
#define LC_MF_COMPARE_OR(TYP,IN1,IN2)  ((IN1) || (IN2))
#endif
#endif

#ifndef LC3_PT_INIT_volatile
#define LC3_PT_INIT_volatile
#endif

#if !NPE_HIS_CHANNEL2

unsigned LC_PT_Init_PRG_HISDEMO(LCoplck_EPDB * pEPDB,LCoplck_StartMode s)
{
  LC3_PT_INIT_volatile LC_TD_Program_PRG_HISDEMO* LC_this = (LC_TD_Program_PRG_HISDEMO *)(pEPDB->thisData);

  if (s==LCoplck_ColdStart)
  {
    LC_INIT_Program_PRG_HISDEMO(LC_this);
  }
  else if (s==LCoplck_WarmStart)
  {
    LC_WINIT_Program_PRG_HISDEMO(LC_this,0);
  }

  switch (s)
  {
    case LCoplck_ColdStart :
    case LCoplck_WarmStart :
    case LCoplck_ReloadStart :
    case LCoplck_Continue :
    case LCoplck_CycleStart :
      LC_this->LC_VD_ENO = LC_EL_true;
      break;
    case LCoplck_Disable :
    case LCoplck_Stop :
    case LCoplck_Kill :
      LC_this->LC_VD_ENO = LC_EL_false;
      break;
    case LCoplck_NOTStarted :
    case LCoplck_Unload :
    case LCoplck_Load :
    case LCoplck_SM_InitCycle:
    case LCoplck_SM_StopStart:
    case LCoplck_SM_StopCycle:
    case LCoplck_UnknownSM :
    case LCoplck_SM_unused :
      break;
  }
  return LC_EL_false;
}

#else

unsigned LC_PT_Init_PRG_HISDEMO(LCoplck_EPDB * pEPDB,LCoplck_StartMode s)
{
  LC3_PT_INIT_volatile LC_TD_Program_PRG_HISDEMO* LC_this = (LC_TD_Program_PRG_HISDEMO *)(pEPDB->thisData);

  /* The numeric LCoplck_StartMode values and their order are part of the runtime interface and must not be changed. */
  if (LC_MF_COMPARE_NE(LC_TD_UDINT, s, LCoplck_ColdStart))
  {
    if (LC_MF_COMPARE_EQ(LC_TD_UDINT, s, LCoplck_WarmStart))
    {
      LC_WINIT_Program_PRG_HISDEMO(LC_this,0);
    }
  }
  else
  {
    LC_INIT_Program_PRG_HISDEMO(LC_this);
  }

  if (LC_MF_COMPARE_AND(
        LC_TD_UDINT,
        LC_MF_COMPARE_GE(LC_TD_UDINT, s, LCoplck_Disable),
        LC_MF_COMPARE_LE(LC_TD_UDINT, s, LCoplck_Kill)))
  {
    LC_this->LC_VD_ENO = LC_EL_false;
  }
  else if (LC_MF_COMPARE_OR(
             LC_TD_UDINT,
             LC_MF_COMPARE_AND(
               LC_TD_UDINT,
               LC_MF_COMPARE_GE(LC_TD_UDINT, s, LCoplck_ColdStart),
               LC_MF_COMPARE_LE(LC_TD_UDINT, s, LCoplck_Continue)),
             LC_MF_COMPARE_EQ(LC_TD_UDINT, s, LCoplck_CycleStart)))
  {
    LC_this->LC_VD_ENO = LC_EL_true;
  }

  return LC_EL_false;
}

#endif
#include "LC3CGError.h"
#include "LC3CGAppEvent.h"

/*
** PT wrapper returns 0 when program.ENO or centralized-ENO for EPDB is false
**                    1 else
*/
uint8_t LC_PT_Exec_PRG_HISDEMO(LCoplck_EPDB_PTR pEPDB)
{

#ifdef HAS_RT_ENHANCED_ENO_SUPPORT

#if NPE_HIS_CHANNEL2
  /* Checked numeric comparisons (LC_MF_COMPARE_...) report errors against the current program (LC_this). */
  LC_TD_Program_PRG_HISDEMO * LC_this = (LC_TD_Program_PRG_HISDEMO *)(pEPDB->thisData);
  /* will be used for HIS C2 in the LC_MF_NUMERIC... macros. */
  /* will not be NULL and contain LC_VD_ENO */

#endif

  LC_TD_EntryData * entryData=(LC_TD_EntryData *)( pEPDB-> ccodeData );
  LC3CGERR_ErrorInformation * errInfo = entryData->errorInformation;

  errInfo->errorId = LC3CGERR_ErrorId_NO_ERROR;

#endif

  /* call ProgramType */
  lcpu___PRG_HISDEMO( (LC_TD_Program_PRG_HISDEMO *)(pEPDB->thisData), pEPDB );

#ifdef HAS_RT_ENHANCED_ENO_SUPPORT

  /* check centralized error info */
  if (LC_MF_COMPARE_NE(LC_TD_UDINT, errInfo->errorId, LC3CGERR_ErrorId_NO_ERROR))
  {
   LCCG_APP_EVENT(pEPDB,errInfo);

   return 0;
  }

#endif

  /* return ENO */
  return LC_MF_COMPARE_EQ(LC_TD_BOOL, ((LC_TD_Program_PRG_HISDEMO *)(pEPDB->thisData))->LC_VD_ENO, LC_EL_false) ? 0 : 1;
}
