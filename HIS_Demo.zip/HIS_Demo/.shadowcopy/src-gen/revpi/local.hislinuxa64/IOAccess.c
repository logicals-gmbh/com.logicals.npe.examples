#include <LCAPIIOAcc.h>
#include <LC3GlobalsDMA.h>
#include <LC3GV.h>

#include <IOAccessHelper.h>
#include <IOAccessHelper.c>

static const LcIOAccCopyEntryInput ioCopyEntries_1_INPUT[] =
{
  {IOACC_BYTES(6), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_I01), lc_ioacc_readAlignedBool},
  {IOACC_BITS(49), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_I02), lc_ioacc_readBool},
  {IOACC_BITS(50), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_I03), lc_ioacc_readBool},
  {IOACC_BITS(51), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_I04), lc_ioacc_readBool},
  {IOACC_BYTES(22), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_BUTTON1INPUT), lc_ioacc_readAlignedBool},
  {IOACC_BYTES(22), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_I11), lc_ioacc_readAlignedBool},
  {IOACC_BITS(177), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_BUTTON2INPUT), lc_ioacc_readBool},
  {IOACC_BITS(177), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_I12), lc_ioacc_readBool},
  {IOACC_BITS(178), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_BUTTON3INPUT), lc_ioacc_readBool},
  {IOACC_BITS(178), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_I13), lc_ioacc_readBool},
  {IOACC_BITS(179), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_I14), lc_ioacc_readBool},
  {IOACC_BITS(180), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_I15), lc_ioacc_readBool},
  {IOACC_BITS(181), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_I16), lc_ioacc_readBool},
  {IOACC_BITS(182), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_I17), lc_ioacc_readBool},
  {IOACC_BITS(183), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_I18), lc_ioacc_readBool},
};

static const LcIOAccCopyTableInput ioCopyTable_1_INPUT = {15, ioCopyEntries_1_INPUT};

static const LcIOAccCopyEntryOutput ioCopyEntries_1_OUTPUT[] =
{
  {IOACC_BYTES(6), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_O01), lc_ioacc_writeAlignedBool},
  {IOACC_BITS(49), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_O02), lc_ioacc_writeBool},
  {IOACC_BITS(50), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_O03), lc_ioacc_writeBool},
  {IOACC_BITS(51), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_O04), lc_ioacc_writeBool},
  {IOACC_BYTES(22), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_BUTTON1INDICATOR), lc_ioacc_writeAlignedBool},
  {IOACC_BYTES(22), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_O11), lc_ioacc_writeAlignedBool},
  {IOACC_BITS(177), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_BUTTON2INDICATOR), lc_ioacc_writeBool},
  {IOACC_BITS(177), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_O12), lc_ioacc_writeBool},
  {IOACC_BITS(178), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_BUTTON3INDICATOR), lc_ioacc_writeBool},
  {IOACC_BITS(178), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_O13), lc_ioacc_writeBool},
  {IOACC_BITS(179), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_O14), lc_ioacc_writeBool},
  {IOACC_BITS(180), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_O15), lc_ioacc_writeBool},
  {IOACC_BITS(181), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_O16), lc_ioacc_writeBool},
  {IOACC_BITS(182), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_O17), lc_ioacc_writeBool},
  {IOACC_BITS(183), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_O18), lc_ioacc_writeBool},
};

static const LcIOAccCopyTableOutput ioCopyTable_1_OUTPUT = {15, ioCopyEntries_1_OUTPUT};

static const LcIOAccCopyTableMemory ioCopyTable_1_MEMORY = {0, NULL};

static const LcIOAccCopyEntryInput ioCopyEntries_2_INPUT[] =
{
  {IOACC_BYTES(0), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_DUMMY1), lc_ioacc_readAlignedBool},
  {IOACC_BYTES(0), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_SI01), lc_ioacc_readAlignedBool},
  {IOACC_BITS(1), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_SI02), lc_ioacc_readBool},
};

static const LcIOAccCopyTableInput ioCopyTable_2_INPUT = {3, ioCopyEntries_2_INPUT};

static const LcIOAccCopyEntryOutput ioCopyEntries_2_OUTPUT[] =
{
  {IOACC_BYTES(0), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_SO01), lc_ioacc_writeAlignedBool},
  {IOACC_BITS(1), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_SO02), lc_ioacc_writeBool},
};

static const LcIOAccCopyTableOutput ioCopyTable_2_OUTPUT = {2, ioCopyEntries_2_OUTPUT};

static const LcIOAccCopyEntryMemory ioCopyEntries_2_MEMORY[] =
{
  {IOACC_BYTES(0), IOACC_BYTES(16), &(g_LC3_GVInstanceData.LC_VD_SLAVE1PARA[0]), lc_ioacc_readAlignedBytes, lc_ioacc_writeAlignedBytes},
};

static const LcIOAccCopyTableMemory ioCopyTable_2_MEMORY = {1, ioCopyEntries_2_MEMORY};

static const LcIOAccCopyTableInput ioCopyTable_3_INPUT = {0, NULL};

static const LcIOAccCopyEntryOutput ioCopyEntries_3_OUTPUT[] =
{
  {IOACC_BYTES(0), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_DUMMY2), lc_ioacc_writeAlignedBool},
  {IOACC_BYTES(0), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_SO11), lc_ioacc_writeAlignedBool},
  {IOACC_BITS(1), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_SO12), lc_ioacc_writeBool},
  {IOACC_BITS(2), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_SO13), lc_ioacc_writeBool},
  {IOACC_BITS(3), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_SO14), lc_ioacc_writeBool},
};

static const LcIOAccCopyTableOutput ioCopyTable_3_OUTPUT = {5, ioCopyEntries_3_OUTPUT};

static const LcIOAccCopyEntryMemory ioCopyEntries_3_MEMORY[] =
{
  {IOACC_BYTES(0), IOACC_BYTES(8), &(g_LC3_GVInstanceData.LC_VD_SLAVE2PARA[0]), lc_ioacc_readAlignedBytes, lc_ioacc_writeAlignedBytes},
};

static const LcIOAccCopyTableMemory ioCopyTable_3_MEMORY = {1, ioCopyEntries_3_MEMORY};

static const LcIOAccCopyEntryInput ioCopyEntries_4_INPUT[] =
{
  {IOACC_BYTES(0), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_ESTOP), lc_ioacc_readAlignedBool},
  {IOACC_BYTES(0), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_SI11), lc_ioacc_readAlignedBool},
  {IOACC_BITS(1), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_SI12), lc_ioacc_readBool},
  {IOACC_BITS(2), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_SI13), lc_ioacc_readBool},
  {IOACC_BITS(3), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_SI14), lc_ioacc_readBool},
};

static const LcIOAccCopyTableInput ioCopyTable_4_INPUT = {5, ioCopyEntries_4_INPUT};

static const LcIOAccCopyTableOutput ioCopyTable_4_OUTPUT = {0, NULL};

static const LcIOAccCopyEntryMemory ioCopyEntries_4_MEMORY[] =
{
  {IOACC_BYTES(0), IOACC_BYTES(8), &(g_LC3_GVInstanceData.LC_VD_SLAVE3PARA[0]), lc_ioacc_readAlignedBytes, lc_ioacc_writeAlignedBytes},
};

static const LcIOAccCopyTableMemory ioCopyTable_4_MEMORY = {1, ioCopyEntries_4_MEMORY};

static uint32_t ioCopyTableCrc_1_INPUT = 0u;
static uint32_t ioCopyTableCrc_1_OUTPUT = 0u;
static uint32_t ioCopyTableCrc_1_MEMORY = 0u;
static uint32_t ioCopyTableCrc_2_INPUT = 0u;
static uint32_t ioCopyTableCrc_2_OUTPUT = 0u;
static uint32_t ioCopyTableCrc_2_MEMORY = 0u;
static uint32_t ioCopyTableCrc_3_INPUT = 0u;
static uint32_t ioCopyTableCrc_3_OUTPUT = 0u;
static uint32_t ioCopyTableCrc_3_MEMORY = 0u;
static uint32_t ioCopyTableCrc_4_INPUT = 0u;
static uint32_t ioCopyTableCrc_4_OUTPUT = 0u;
static uint32_t ioCopyTableCrc_4_MEMORY = 0u;

static const LcIOAccTableDescriptor ioTableDescriptors[4] =
{
  {1, {0, 0}, &ioCopyTable_1_INPUT, &ioCopyTableCrc_1_INPUT, 184, &ioCopyTable_1_OUTPUT, &ioCopyTableCrc_1_OUTPUT, 184, &ioCopyTable_1_MEMORY, &ioCopyTableCrc_1_MEMORY, 0},
  {2, {1, 0}, &ioCopyTable_2_INPUT, &ioCopyTableCrc_2_INPUT, 2, &ioCopyTable_2_OUTPUT, &ioCopyTableCrc_2_OUTPUT, 2, &ioCopyTable_2_MEMORY, &ioCopyTableCrc_2_MEMORY, 128},
  {2, {2, 0}, &ioCopyTable_3_INPUT, &ioCopyTableCrc_3_INPUT, 0, &ioCopyTable_3_OUTPUT, &ioCopyTableCrc_3_OUTPUT, 4, &ioCopyTable_3_MEMORY, &ioCopyTableCrc_3_MEMORY, 64},
  {2, {3, 0}, &ioCopyTable_4_INPUT, &ioCopyTableCrc_4_INPUT, 4, &ioCopyTable_4_OUTPUT, &ioCopyTableCrc_4_OUTPUT, 0, &ioCopyTable_4_MEMORY, &ioCopyTableCrc_4_MEMORY, 64},
};

static int compareTableDescriptor(
  LcIOAccServiceId serviceId, LcIOAccAdditionalData const* additionalData, LcIOAccTableDescriptor const* tableDescriptor)
{
  if (serviceId != tableDescriptor->serviceId) {
    return (serviceId < tableDescriptor->serviceId) ? -1 : 1;
  }
  if (additionalData != NULL)
  {
    if (additionalData->additionalIds[0] != tableDescriptor->additionalIds[0])
    {
      return (additionalData->additionalIds[0] < tableDescriptor->additionalIds[0]) ? -1 : 1;
    }
    if (additionalData->additionalIds[1] != tableDescriptor->additionalIds[1])
    {
      return (additionalData->additionalIds[1] < tableDescriptor->additionalIds[1]) ? -1 : 1;
    }
  }
  return 0;
}

static LcIOAccTableDescriptor const* getTableDescriptor(LcIOAccServiceId serviceId, LcIOAccAdditionalData *additionalData)
{
  int ioTableIndexUpper = 4;
  int ioTableIndexLower = 0;
  int iterations = 0;

  if ((additionalData != NULL) && (additionalData->dataVersion != LC_IOACC_ADDITIONAL_DATA_VERSION(1)))
  {
    return NULL;
  }

  while (ioTableIndexLower < ioTableIndexUpper)
  {
    int ioTableIndex = (ioTableIndexLower + ioTableIndexUpper) / 2u;
    int result = compareTableDescriptor(serviceId, additionalData, &ioTableDescriptors[ioTableIndex]);
    if (result < 0)
    {
      ioTableIndexUpper = ioTableIndex;
    }
    else if (result > 0)
    {
      ioTableIndexLower = ioTableIndex + 1u;
    }
    else
    {
      return &ioTableDescriptors[ioTableIndex];
    }
    iterations++;
    if (iterations > 20)
    {
      break;
    }
  }

  return NULL;
}

LcIOAccCopyRc lc_ioacc_copyInputData(
  LcIOAccServiceId serviceId, uint8_t const* ioInputData, LcIOAccSegmentSize inputBitSize, LcIOAccAdditionalData *additionalData)
{
  if (ioInputData == NULL) /* additionalData not checked because it may be NULL */
  {
    return LC_IOACC_COPY_RC_INVALID_ARG;
  }

  LcIOAccTableDescriptor const* tableDescriptor = getTableDescriptor(serviceId, additionalData);
  if (tableDescriptor == NULL)
  {
    return LC_IOACC_COPY_RC_INV_SERVICE_ID;
  }
  else if (inputBitSize < tableDescriptor->inputBitSize)
  {
    return LC_IOACC_COPY_RC_SEGMENT_SIZE_ERR;
  }
  else
  {
    return lc_ioacc_copyInputDataForTable(tableDescriptor->inputCopyTable, tableDescriptor->inputCopyTableCrc, ioInputData);
  }
}

LcIOAccCopyRc lc_ioacc_copyOutputData(
  LcIOAccServiceId serviceId, uint8_t* ioOutputData, LcIOAccSegmentSize outputBitSize, LcIOAccAdditionalData* additionalData)
{
  if (ioOutputData == NULL) /* additionalData not checked because it may be NULL */
  {
    return LC_IOACC_COPY_RC_INVALID_ARG;
  }

  LcIOAccTableDescriptor const* tableDescriptor = getTableDescriptor(serviceId, additionalData);
  if (tableDescriptor == NULL)
  {
    return LC_IOACC_COPY_RC_INV_SERVICE_ID;
  }
  else if (outputBitSize < tableDescriptor->outputBitSize)
  {
    return LC_IOACC_COPY_RC_SEGMENT_SIZE_ERR;
  }
  else
  {
    return lc_ioacc_copyOutputDataForTable(tableDescriptor->outputCopyTable, tableDescriptor->outputCopyTableCrc, ioOutputData);
  }
}

LcIOAccCopyRc lc_ioacc_copyMemoryDataToVariables(
  LcIOAccServiceId serviceId, uint8_t const* ioInputData, LcIOAccSegmentSize inputBitSize, LcIOAccAdditionalData *additionalData)
{
  if (ioInputData == NULL) /* additionalData not checked because it may be NULL */
  {
    return LC_IOACC_COPY_RC_INVALID_ARG;
  }

  LcIOAccTableDescriptor const* tableDescriptor = getTableDescriptor(serviceId, additionalData);
  if (tableDescriptor == NULL)
  {
    return LC_IOACC_COPY_RC_INV_SERVICE_ID;
  }
  else if (inputBitSize < tableDescriptor->memoryBitSize)
  {
    return LC_IOACC_COPY_RC_SEGMENT_SIZE_ERR;
  }
  else
  {
    return lc_ioacc_copyMemoryDataToVariablesForTable(tableDescriptor->memoryCopyTable, tableDescriptor->memoryCopyTableCrc, ioInputData);
  }
}

LcIOAccCopyRc lc_ioacc_copyMemoryDataFromVariables(
  LcIOAccServiceId serviceId, uint8_t* ioOutputData, LcIOAccSegmentSize outputBitSize, LcIOAccAdditionalData* additionalData)
{
  if (ioOutputData == NULL) /* additionalData not checked because it may be NULL */
  {
    return LC_IOACC_COPY_RC_INVALID_ARG;
  }

  LcIOAccTableDescriptor const* tableDescriptor = getTableDescriptor(serviceId, additionalData);
  if (tableDescriptor == NULL)
  {
    return LC_IOACC_COPY_RC_INV_SERVICE_ID;
  }
  else if (outputBitSize < tableDescriptor->memoryBitSize)
  {
    return LC_IOACC_COPY_RC_SEGMENT_SIZE_ERR;
  }
  else
  {
    return lc_ioacc_copyMemoryDataFromVariablesForTable(tableDescriptor->memoryCopyTable, tableDescriptor->memoryCopyTableCrc, ioOutputData);
  }
}

extern LCoplck_TASK LC_vg_Task_DEFAULTTASK;

#include <ioAccAdditionalData_EtherCAT_1_Def.inc>
#include <ioAccAdditionalData_FSoE_2_Def.inc>

static const LcIOAccServiceInfo ioServiceInfos[] =
{
  {"EtherCAT",1,&LC_vg_Task_DEFAULTTASK,&ioAccAdditionalData_EtherCAT_1,184,184,0},
  {"FSoE",2,&LC_vg_Task_DEFAULTTASK,&ioAccAdditionalData_FSoE_2,4,4,128},
};

static int serviceNameCompare(char const* iterServiceName, char const* searchedServiceName)
{
  while ((*iterServiceName == *searchedServiceName) && (*iterServiceName != '\0'))
  {
    iterServiceName++;
    searchedServiceName++;
  }
  return *iterServiceName - *searchedServiceName;
}

LcIOAccInfoRc lc_ioacc_getServiceInfoByName(char const* const serviceName, LcIOAccServiceInfo* serviceInfo)
{
  if ((serviceName == NULL) || (serviceInfo == NULL))
  {
    return LC_IOACC_INFO_RC_INVALID_ARG;
  }

  LcIOAccServiceInfo const* serviceInfoIter;
  for(serviceInfoIter = ioServiceInfos; serviceInfoIter < ioServiceInfos + 2; serviceInfoIter++)
  {
    if(serviceNameCompare(serviceInfoIter->serviceName, serviceName) == 0)
    {
      *serviceInfo = *serviceInfoIter;
      return LC_IOACC_INFO_RC_OK;
    }
  }

  return LC_IOACC_INFO_RC_SERVICE_NOT_FOUND;
}

