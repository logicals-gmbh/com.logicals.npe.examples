#include <LCAPIIOAcc.h>
#include <LC3GlobalsDMA.h>
#include <LC3GV.h>

#include <IOAccessHelper.h>
#include <IOAccessHelper.c>

static const LcIOAccCopyEntryInput ioCopyEntries_1_INPUT[] =
{
  {IOACC_BYTES(22), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_BUTTON1INPUT), lc_ioacc_readAlignedBool},
  {IOACC_BITS(177), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_BUTTON2INPUT), lc_ioacc_readBool},
  {IOACC_BITS(178), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_BUTTON3INPUT), lc_ioacc_readBool},
};

static const LcIOAccCopyTableInput ioCopyTable_1_INPUT = {3, ioCopyEntries_1_INPUT};

static const LcIOAccCopyEntryOutput ioCopyEntries_1_OUTPUT[] =
{
  {IOACC_BYTES(22), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_BUTTON1INDICATOR), lc_ioacc_writeAlignedBool},
  {IOACC_BITS(177), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_BUTTON2INDICATOR), lc_ioacc_writeBool},
  {IOACC_BITS(178), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_BUTTON3INDICATOR), lc_ioacc_writeBool},
};

static const LcIOAccCopyTableOutput ioCopyTable_1_OUTPUT = {3, ioCopyEntries_1_OUTPUT};

static const LcIOAccCopyTableMemory ioCopyTable_1_MEMORY = {0, NULL};

static const LcIOAccCopyEntryInput ioCopyEntries_2_INPUT[] =
{
  {IOACC_BYTES(0), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_DUMMY1), lc_ioacc_readAlignedBool},
};

static const LcIOAccCopyTableInput ioCopyTable_2_INPUT = {1, ioCopyEntries_2_INPUT};

static const LcIOAccCopyTableOutput ioCopyTable_2_OUTPUT = {0, NULL};

static const LcIOAccCopyTableMemory ioCopyTable_2_MEMORY = {0, NULL};

static const LcIOAccCopyTableInput ioCopyTable_3_INPUT = {0, NULL};

static const LcIOAccCopyEntryOutput ioCopyEntries_3_OUTPUT[] =
{
  {IOACC_BYTES(0), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_DUMMY2), lc_ioacc_writeAlignedBool},
};

static const LcIOAccCopyTableOutput ioCopyTable_3_OUTPUT = {1, ioCopyEntries_3_OUTPUT};

static const LcIOAccCopyTableMemory ioCopyTable_3_MEMORY = {0, NULL};

static const LcIOAccCopyEntryInput ioCopyEntries_4_INPUT[] =
{
  {IOACC_BYTES(0), IOACC_BITS(1), &(g_LC3_GVInstanceData.LC_VD_ESTOP), lc_ioacc_readAlignedBool},
};

static const LcIOAccCopyTableInput ioCopyTable_4_INPUT = {1, ioCopyEntries_4_INPUT};

static const LcIOAccCopyTableOutput ioCopyTable_4_OUTPUT = {0, NULL};

static const LcIOAccCopyTableMemory ioCopyTable_4_MEMORY = {0, NULL};

static uint32_t ioCopyTableCrc_1_INPUT = 0u;
static uint32_t ioCopyTableCrc_1_OUTPUT = 0u;
static uint32_t ioCopyTableCrc_1_MEMORY = 0u;
static uint32_t ioCopyTableCrc_2_INPUT = 0u;
static uint32_t ioCopyTableCrc_2_OUTPUT = 0u;
static uint32_t ioCopyTableCrc_2_MEMORY = 0u;
static uint32_t ioCopyTableCrc_3_INPUT = 0u;
static uint32_t ioCopyTableCrc_3_OUTPUT = 0u;
static uint32_t ioCopyTableCrc_3_MEMORY = 0u;
static uint32_t ioCopyTableCrc_4_INPUT = 0u;
static uint32_t ioCopyTableCrc_4_OUTPUT = 0u;
static uint32_t ioCopyTableCrc_4_MEMORY = 0u;

static const LcIOAccTableDescriptor ioTableDescriptors[4] =
{
  {1, {0, 0}, &ioCopyTable_1_INPUT, &ioCopyTableCrc_1_INPUT, 179, &ioCopyTable_1_OUTPUT, &ioCopyTableCrc_1_OUTPUT, 179, &ioCopyTable_1_MEMORY, &ioCopyTableCrc_1_MEMORY, 0},
  {2, {1, 0}, &ioCopyTable_2_INPUT, &ioCopyTableCrc_2_INPUT, 1, &ioCopyTable_2_OUTPUT, &ioCopyTableCrc_2_OUTPUT, 0, &ioCopyTable_2_MEMORY, &ioCopyTableCrc_2_MEMORY, 0},
  {2, {2, 0}, &ioCopyTable_3_INPUT, &ioCopyTableCrc_3_INPUT, 0, &ioCopyTable_3_OUTPUT, &ioCopyTableCrc_3_OUTPUT, 1, &ioCopyTable_3_MEMORY, &ioCopyTableCrc_3_MEMORY, 0},
  {2, {3, 0}, &ioCopyTable_4_INPUT, &ioCopyTableCrc_4_INPUT, 1, &ioCopyTable_4_OUTPUT, &ioCopyTableCrc_4_OUTPUT, 0, &ioCopyTable_4_MEMORY, &ioCopyTableCrc_4_MEMORY, 0},
};

static int compareTableDescriptor(
  LcIOAccServiceId serviceId, LcIOAccAdditionalData const* additionalData, LcIOAccTableDescriptor const* tableDescriptor)
{
  if (serviceId != tableDescriptor->serviceId) {
    return (serviceId < tableDescriptor->serviceId) ? -1 : 1;
  }
  if (additionalData != NULL)
  {
    if (additionalData->additionalIds[0] != tableDescriptor->additionalIds[0])
    {
      return (additionalData->additionalIds[0] < tableDescriptor->additionalIds[0]) ? -1 : 1;
    }
    if (additionalData->additionalIds[1] != tableDescriptor->additionalIds[1])
    {
      return (additionalData->additionalIds[1] < tableDescriptor->additionalIds[1]) ? -1 : 1;
    }
  }
  return 0;
}

static LcIOAccTableDescriptor const* getTableDescriptor(LcIOAccServiceId serviceId, LcIOAccAdditionalData *additionalData)
{
  int ioTableIndexUpper = 4;
  int ioTableIndexLower = 0;
  int iterations = 0;

  if ((additionalData != NULL) && (additionalData->dataVersion != LC_IOACC_ADDITIONAL_DATA_VERSION(1)))
  {
    return NULL;
  }

  while (ioTableIndexLower < ioTableIndexUpper)
  {
    int ioTableIndex = (ioTableIndexLower + ioTableIndexUpper) / 2u;
    int result = compareTableDescriptor(serviceId, additionalData, &ioTableDescriptors[ioTableIndex]);
    if (result < 0)
    {
      ioTableIndexUpper = ioTableIndex;
    }
    else if (result > 0)
    {
      ioTableIndexLower = ioTableIndex + 1u;
    }
    else
    {
      return &ioTableDescriptors[ioTableIndex];
    }
    iterations++;
    if (iterations > 20)
    {
      break;
    }
  }

  return NULL;
}

LcIOAccCopyRc lc_ioacc_copyInputData(
  LcIOAccServiceId serviceId, uint8_t const* ioInputData, LcIOAccSegmentSize inputBitSize, LcIOAccAdditionalData *additionalData)
{
  if (ioInputData == NULL) /* additionalData not checked because it may be NULL */
  {
    return LC_IOACC_COPY_RC_INVALID_ARG;
  }

  LcIOAccTableDescriptor const* tableDescriptor = getTableDescriptor(serviceId, additionalData);
  if (tableDescriptor == NULL)
  {
    return LC_IOACC_COPY_RC_INV_SERVICE_ID;
  }
  else if (inputBitSize < tableDescriptor->inputBitSize)
  {
    return LC_IOACC_COPY_RC_SEGMENT_SIZE_ERR;
  }
  else
  {
    return lc_ioacc_copyInputDataForTable(tableDescriptor->inputCopyTable, tableDescriptor->inputCopyTableCrc, ioInputData);
  }
}

LcIOAccCopyRc lc_ioacc_copyOutputData(
  LcIOAccServiceId serviceId, uint8_t* ioOutputData, LcIOAccSegmentSize outputBitSize, LcIOAccAdditionalData* additionalData)
{
  if (ioOutputData == NULL) /* additionalData not checked because it may be NULL */
  {
    return LC_IOACC_COPY_RC_INVALID_ARG;
  }

  LcIOAccTableDescriptor const* tableDescriptor = getTableDescriptor(serviceId, additionalData);
  if (tableDescriptor == NULL)
  {
    return LC_IOACC_COPY_RC_INV_SERVICE_ID;
  }
  else if (outputBitSize < tableDescriptor->outputBitSize)
  {
    return LC_IOACC_COPY_RC_SEGMENT_SIZE_ERR;
  }
  else
  {
    return lc_ioacc_copyOutputDataForTable(tableDescriptor->outputCopyTable, tableDescriptor->outputCopyTableCrc, ioOutputData);
  }
}

LcIOAccCopyRc lc_ioacc_copyMemoryDataToVariables(
  LcIOAccServiceId serviceId, uint8_t const* ioInputData, LcIOAccSegmentSize inputBitSize, LcIOAccAdditionalData *additionalData)
{
  if (ioInputData == NULL) /* additionalData not checked because it may be NULL */
  {
    return LC_IOACC_COPY_RC_INVALID_ARG;
  }

  LcIOAccTableDescriptor const* tableDescriptor = getTableDescriptor(serviceId, additionalData);
  if (tableDescriptor == NULL)
  {
    return LC_IOACC_COPY_RC_INV_SERVICE_ID;
  }
  else if (inputBitSize < tableDescriptor->memoryBitSize)
  {
    return LC_IOACC_COPY_RC_SEGMENT_SIZE_ERR;
  }
  else
  {
    return lc_ioacc_copyMemoryDataToVariablesForTable(tableDescriptor->memoryCopyTable, tableDescriptor->memoryCopyTableCrc, ioInputData);
  }
}

LcIOAccCopyRc lc_ioacc_copyMemoryDataFromVariables(
  LcIOAccServiceId serviceId, uint8_t* ioOutputData, LcIOAccSegmentSize outputBitSize, LcIOAccAdditionalData* additionalData)
{
  if (ioOutputData == NULL) /* additionalData not checked because it may be NULL */
  {
    return LC_IOACC_COPY_RC_INVALID_ARG;
  }

  LcIOAccTableDescriptor const* tableDescriptor = getTableDescriptor(serviceId, additionalData);
  if (tableDescriptor == NULL)
  {
    return LC_IOACC_COPY_RC_INV_SERVICE_ID;
  }
  else if (outputBitSize < tableDescriptor->memoryBitSize)
  {
    return LC_IOACC_COPY_RC_SEGMENT_SIZE_ERR;
  }
  else
  {
    return lc_ioacc_copyMemoryDataFromVariablesForTable(tableDescriptor->memoryCopyTable, tableDescriptor->memoryCopyTableCrc, ioOutputData);
  }
}

extern LCoplck_TASK LC_vg_Task_DEFAULTTASK;

#include <ioAccAdditionalData_EtherCAT_1_Def.inc>
#include <ioAccAdditionalData_FSoE_2_Def.inc>

static const LcIOAccServiceInfo ioServiceInfos[] =
{
  {"EtherCAT",1,&LC_vg_Task_DEFAULTTASK,&ioAccAdditionalData_EtherCAT_1,179,179,0},
  {"FSoE",2,&LC_vg_Task_DEFAULTTASK,&ioAccAdditionalData_FSoE_2,1,1,0},
};

static int serviceNameCompare(char const* iterServiceName, char const* searchedServiceName)
{
  while ((*iterServiceName == *searchedServiceName) && (*iterServiceName != '\0'))
  {
    iterServiceName++;
    searchedServiceName++;
  }
  return *iterServiceName - *searchedServiceName;
}

LcIOAccInfoRc lc_ioacc_getServiceInfoByName(char const* const serviceName, LcIOAccServiceInfo* serviceInfo)
{
  if ((serviceName == NULL) || (serviceInfo == NULL))
  {
    return LC_IOACC_INFO_RC_INVALID_ARG;
  }

  LcIOAccServiceInfo const* serviceInfoIter;
  for(serviceInfoIter = ioServiceInfos; serviceInfoIter < ioServiceInfos + 2; serviceInfoIter++)
  {
    if(serviceNameCompare(serviceInfoIter->serviceName, serviceName) == 0)
    {
      *serviceInfo = *serviceInfoIter;
      return LC_IOACC_INFO_RC_OK;
    }
  }

  return LC_IOACC_INFO_RC_SERVICE_NOT_FOUND;
}

