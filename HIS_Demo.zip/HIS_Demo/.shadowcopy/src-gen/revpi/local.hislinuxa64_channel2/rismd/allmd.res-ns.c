/**
*** logi.CAD3 generated Source include file
*** This file has been generated automatically and will be overwritten. Do not edit!
**/

#include "src-gen/revpi/local.hislinuxa64_channel2/rismd/MDTypeInfo.c"
#include "src-gen/revpi/local.hislinuxa64_channel2/rismd/nameserver/MDNameserver.c"
#include "src-gen/revpi/local.hislinuxa64_channel2/rismd/nameserver/MDPI_PRG_HISDEMO.c"
#include "src-gen/revpi/local.hislinuxa64_channel2/rismd/nameserver/MDResourceGV.c"

