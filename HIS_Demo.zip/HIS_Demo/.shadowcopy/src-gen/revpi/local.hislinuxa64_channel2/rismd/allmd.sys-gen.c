/**
*** logi.CAD3 generated Source include file
*** This file has been generated automatically and will be overwritten. Do not edit!
**/

#include "target/revpi/local.hislinuxa64_channel2/sys-gen/rismd/mdfu___r_trig.c"
#include "target/revpi/local.hislinuxa64_channel2/sys-gen/rismd/mdfu___safety.plcopen.sf_emergencystop.c"
#include "target/revpi/local.hislinuxa64_channel2/sys-gen/rismd/mdfu___safety.plcopen.sf_equivalent.c"
#include "target/revpi/local.hislinuxa64_channel2/sys-gen/rismd/mdfu___ton.c"

