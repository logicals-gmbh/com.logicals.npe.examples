/**
*** logi.CAD3 generated Source include file
*** This file has been generated automatically and will be overwritten. Do not edit!
**/

#include "target/revpi/local.hislinuxa64_channel2/sys-gen/lcfu___safety.plcopen.sf_emergencystop.c"
#include "target/revpi/local.hislinuxa64_channel2/sys-gen/lcfu___safety.plcopen.sf_equivalent.c"
#include "target/revpi/local.hislinuxa64_channel2/sys-gen/lcfu_iec61131__CONVERT.c"
#include "target/revpi/local.hislinuxa64_channel2/sys-gen/lcfu_iec61131__EXPT.c"
#include "target/revpi/local.hislinuxa64_channel2/sys-gen/lcfu_iec61131__TON.c"

