#ifndef LC_PROT_LCDT___SAFELREAL__C
#define LC_PROT_LCDT___SAFELREAL__C

extern void* dummyCode4EmptyFile;
#endif
