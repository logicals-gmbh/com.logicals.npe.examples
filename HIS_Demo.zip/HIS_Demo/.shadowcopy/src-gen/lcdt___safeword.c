#ifndef LC_PROT_LCDT___SAFEWORD__C
#define LC_PROT_LCDT___SAFEWORD__C

extern void* dummyCode4EmptyFile;
#endif
