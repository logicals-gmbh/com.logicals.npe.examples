#ifndef LC_PROT_LCDT___SAFELINT__C
#define LC_PROT_LCDT___SAFELINT__C

extern void* dummyCode4EmptyFile;
#endif
