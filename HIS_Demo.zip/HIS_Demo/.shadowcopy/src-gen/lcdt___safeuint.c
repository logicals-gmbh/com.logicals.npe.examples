#ifndef LC_PROT_LCDT___SAFEUINT__C
#define LC_PROT_LCDT___SAFEUINT__C

extern void* dummyCode4EmptyFile;
#endif
