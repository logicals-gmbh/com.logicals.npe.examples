#ifndef LC_PROT_LCDT___SAFEDINT__C
#define LC_PROT_LCDT___SAFEDINT__C

extern void* dummyCode4EmptyFile;
#endif
