#ifndef LC_PROT_LCDT___SAFELWORD__C
#define LC_PROT_LCDT___SAFELWORD__C

extern void* dummyCode4EmptyFile;
#endif
