#ifndef LC_PROT_LCDT___SAFEDT__C
#define LC_PROT_LCDT___SAFEDT__C

extern void* dummyCode4EmptyFile;
#endif
