#ifndef LC_PROT_LCFU___FB_PACKAGINGLINE__C
#define LC_PROT_LCFU___FB_PACKAGINGLINE__C

#include <lcfu___fb_packagingline.h>
#include <LC3CGStmt.h>
#include <LC3CGAnyBitOp.h>
#include <lcfu_iec61131__ADD.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__EQ.h>
#include <lcfu_iec61131__LT.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_FB_PACKAGINGLINE(LC_TD_FunctionBlock_FB_PACKAGINGLINE* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_FB_PACKAGINGLINE* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_ENABLE)); \
  LC_INIT_BOOL(&((p)->LC_VD_PERMIT)); \
  LC_INIT_BOOL(&((p)->LC_VD_START)); \
  LC_INIT_BOOL(&((p)->LC_VD_STOP)); \
  LC_INIT_BOOL(&((p)->LC_VD_FASTCYCLE)); \
  LC_INIT_BOOL(&((p)->LC_VD_JAM)); \
  LC_INIT_BOOL(&((p)->LC_VD_ACKJAM)); \
  LC_INIT_UINT(&((p)->LC_VD_STATE)); \
  LC_INIT_BOOL(&((p)->LC_VD_READY)); \
  LC_INIT_BOOL(&((p)->LC_VD_INFEED)); \
  LC_INIT_BOOL(&((p)->LC_VD_SEALING)); \
  LC_INIT_BOOL(&((p)->LC_VD_OUTFEED)); \
  LC_INIT_BOOL(&((p)->LC_VD_COMPLETE)); \
  LC_INIT_BOOL(&((p)->LC_VD_BLOCKED)); \
  LC_INIT_BOOL(&((p)->LC_VD_FAULT)); \
  LC_INIT_BOOL(&((p)->LC_VD_RUNNING)); \
  LC_INIT_BOOL(&((p)->LC_VD_HEARTBEAT)); \
  LC_INIT_BOOL(&((p)->LC_VD_CYCLEDONE)); \
  LC_INIT_UDINT(&((p)->LC_VD_CARTONSPACKED)); \
  LC_INIT_BOOL(&((p)->LC_VD_FASTCYCLEACTIVE)); \
  LC_INIT_BOOL(&((p)->LC_VD_PREVSTART)); \
  LC_INIT_BOOL(&((p)->LC_VD_PREVACK)); \
  (p)->LC_VD_FIRSTSCAN = LC_EL_true; \
  LC_INIT_BOOL(&((p)->LC_VD_STARTEDGE)); \
  LC_INIT_BOOL(&((p)->LC_VD_ACKEDGE)); \
  LC_INIT_BOOL(&((p)->LC_VD_STARTARMED)); \
  LC_INIT_BOOL(&((p)->LC_VD_FAULTLATCHED)); \
  (p)->LC_VD_INFEEDTIME = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(3),RT_CC_CONST_LL(0)); \
  (p)->LC_VD_SEALTIME = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(2),RT_CC_CONST_LL(0)); \
  (p)->LC_VD_OUTFEEDTIME = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(2),RT_CC_CONST_LL(0)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TINFEED)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TSEAL)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TOUTFEED)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TSUCCESS)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TBLINK)); \
}

void LC_WINIT_FUN_FunctionBlock_FB_PACKAGINGLINE(LC_TD_FunctionBlock_FB_PACKAGINGLINE* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_FB_PACKAGINGLINE* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_ENABLE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_PERMIT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_START),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_STOP),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_FASTCYCLE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_JAM),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_ACKJAM),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_STATE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_READY),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_INFEED),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_SEALING),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_OUTFEED),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_COMPLETE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_BLOCKED),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_FAULT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_RUNNING),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_HEARTBEAT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_CYCLEDONE),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_CARTONSPACKED),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_FASTCYCLEACTIVE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_PREVSTART),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_PREVACK),RF); \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (p)->LC_VD_FIRSTSCAN = LC_EL_true; \
  LC_WINIT_BOOL(&((p)->LC_VD_STARTEDGE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_ACKEDGE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_STARTARMED),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_FAULTLATCHED),RF); \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (p)->LC_VD_INFEEDTIME = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(3),RT_CC_CONST_LL(0)); \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (p)->LC_VD_SEALTIME = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(2),RT_CC_CONST_LL(0)); \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (p)->LC_VD_OUTFEEDTIME = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(2),RT_CC_CONST_LL(0)); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TINFEED),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TSEAL),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TOUTFEED),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TSUCCESS),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TBLINK),0); \
}

void  lcfu___FB_PACKAGINGLINE(LC_TD_FunctionBlock_FB_PACKAGINGLINE* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  NPE_HIS_CHANNEL2_NOP_VAR
  LC_this->LC_VD_STARTEDGE = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_START,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_PREVSTART)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_FIRSTSCAN))));
  LC_this->LC_VD_ACKEDGE = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_ACKJAM,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_PREVACK)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_FIRSTSCAN))));
  LC_this->LC_VD_PREVSTART = LC_this->LC_VD_START;
  LC_this->LC_VD_PREVACK = LC_this->LC_VD_ACKJAM;
  LC_this->LC_VD_FIRSTSCAN = LC_EL_false;
  LC_this->LC_VD_CYCLEDONE = LC_EL_false;
  {
    LC_this->LC_VD_TBLINK.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TBLINK.LC_VD_IN = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_TBLINK.LC_VD_Q));
    LC_this->LC_VD_TBLINK.LC_VD_PT = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(0),RT_CC_CONST_LL(250000000));
    lcfu_iec61131__TON(&(LC_this->LC_VD_TBLINK), pEPDB);
  }
  LC3_MST_IF (LC_this->LC_VD_TBLINK.LC_VD_Q)
  {
    LC_this->LC_VD_HEARTBEAT = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_HEARTBEAT));
  }
  {
    LC_this->LC_VD_TINFEED.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TINFEED.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)20)),LC_this->LC_VD_ENABLE)),LC_this->LC_VD_PERMIT)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_STOP)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_JAM))));
    LC_this->LC_VD_TINFEED.LC_VD_PT = LC_this->LC_VD_INFEEDTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TINFEED), pEPDB);
  }
  {
    LC_this->LC_VD_TSEAL.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TSEAL.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)30)),LC_this->LC_VD_ENABLE)),LC_this->LC_VD_PERMIT)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_STOP)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_JAM))));
    LC_this->LC_VD_TSEAL.LC_VD_PT = LC_this->LC_VD_SEALTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TSEAL), pEPDB);
  }
  {
    LC_this->LC_VD_TOUTFEED.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TOUTFEED.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)40)),LC_this->LC_VD_ENABLE)),LC_this->LC_VD_PERMIT)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_STOP)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_JAM))));
    LC_this->LC_VD_TOUTFEED.LC_VD_PT = LC_this->LC_VD_OUTFEEDTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TOUTFEED), pEPDB);
  }
  {
    LC_this->LC_VD_TSUCCESS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TSUCCESS.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)50)),LC_this->LC_VD_ENABLE)),LC_this->LC_VD_PERMIT)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_STOP)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_JAM))));
    LC_this->LC_VD_TSUCCESS.LC_VD_PT = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0));
    lcfu_iec61131__TON(&(LC_this->LC_VD_TSUCCESS), pEPDB);
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_JAM,LC_this->LC_VD_ENABLE)),LC_this->LC_VD_PERMIT)),(lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)20)),(lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)30)))),(lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)40))))));
    LC3_MST_IF (conditionResult)
    {
      LC_this->LC_VD_FAULTLATCHED = LC_EL_true;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_ACKEDGE,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_JAM)))),LC_this->LC_VD_ENABLE)),LC_this->LC_VD_PERMIT));
    LC3_MST_IF (conditionResult)
    {
      LC_this->LC_VD_FAULTLATCHED = LC_EL_false;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ENABLE)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_PERMIT))));
    LC3_MST_IF (conditionResult)
    {
      LC_this->LC_VD_STATE = (LC_TD_UINT)0;
      LC_this->LC_VD_FASTCYCLEACTIVE = LC_EL_false;
      LC_this->LC_VD_STARTARMED = LC_EL_false;
    }
    else
    {
      LC3_MST_IF (LC_this->LC_VD_FAULTLATCHED)
      {
        LC_this->LC_VD_STATE = (LC_TD_UINT)90;
        LC_this->LC_VD_FASTCYCLEACTIVE = LC_EL_false;
        LC_this->LC_VD_STARTARMED = LC_EL_false;
      }
      else
      {
        LC3_MST_IF (LC_this->LC_VD_STOP)
        {
          LC_this->LC_VD_STATE = (LC_TD_UINT)10;
          LC_this->LC_VD_FASTCYCLEACTIVE = LC_EL_false;
          LC_this->LC_VD_STARTARMED = LC_EL_false;
        }
        else
        {
          {
            LC_TD_UINT caseSelector;
            caseSelector = LC_this->LC_VD_STATE;
            LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_OR(LC_TD_UINT,LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)0),LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)90))))
            {
              LC_this->LC_VD_STATE = (LC_TD_UINT)10;
              LC_this->LC_VD_FASTCYCLEACTIVE = LC_EL_false;
              LC_this->LC_VD_STARTARMED = LC_EL_false;
            }
            else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)10)))
            {
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_START));
                LC3_MST_IF (conditionResult)
                {
                  LC_this->LC_VD_STARTARMED = LC_EL_true;
                }
              }
              {
                LC_TD_BOOL conditionResult = LC_EL_false;
                conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_STARTEDGE,LC_this->LC_VD_STARTARMED)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_JAM)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ACKJAM))));
                LC3_MST_IF (conditionResult)
                {
                  LC_this->LC_VD_FASTCYCLEACTIVE = LC_this->LC_VD_FASTCYCLE;
                  LC3_MST_IF (LC_this->LC_VD_FASTCYCLEACTIVE)
                  {
                    LC_this->LC_VD_INFEEDTIME = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(1),RT_CC_CONST_LL(500000000));
                    LC_this->LC_VD_SEALTIME = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0));
                    LC_this->LC_VD_OUTFEEDTIME = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0));
                  }
                  else
                  {
                    LC_this->LC_VD_INFEEDTIME = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(3),RT_CC_CONST_LL(0));
                    LC_this->LC_VD_SEALTIME = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(2),RT_CC_CONST_LL(0));
                    LC_this->LC_VD_OUTFEEDTIME = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(2),RT_CC_CONST_LL(0));
                  }
                  LC_this->LC_VD_STARTARMED = LC_EL_false;
                  LC_this->LC_VD_STATE = (LC_TD_UINT)20;
                }
              }
            }
            else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)20)))
            {
              LC3_MST_IF (LC_this->LC_VD_TINFEED.LC_VD_Q)
              {
                LC_this->LC_VD_STATE = (LC_TD_UINT)30;
              }
            }
            else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)30)))
            {
              LC3_MST_IF (LC_this->LC_VD_TSEAL.LC_VD_Q)
              {
                LC_this->LC_VD_STATE = (LC_TD_UINT)40;
              }
            }
            else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)40)))
            {
              LC3_MST_IF (LC_this->LC_VD_TOUTFEED.LC_VD_Q)
              {
                {
                  LC_TD_BOOL conditionResult = LC_EL_false;
                  conditionResult = (lcfu_iec61131__LT__ANY__HIS__2__INL(LC_TD_UDINT,LC_this->LC_VD_CARTONSPACKED,(LC_TD_UDINT)LC_IEC_UDINT_MAX));
                  LC3_MST_IF (conditionResult)
                  {
                    LC_this->LC_VD_CARTONSPACKED = (LC_TD_UDINT)(lcfu_iec61131__ADD__ANY__HIS__2__INL(LC_TD_UDINT,LC_this->LC_VD_CARTONSPACKED,(LC_TD_UDINT)1UL));
                  }
                }
                LC_this->LC_VD_CYCLEDONE = LC_EL_true;
                LC_this->LC_VD_STATE = (LC_TD_UINT)50;
              }
            }
            else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)50)))
            {
              LC3_MST_IF (LC_this->LC_VD_TSUCCESS.LC_VD_Q)
              {
                LC_this->LC_VD_STATE = (LC_TD_UINT)10;
                LC_this->LC_VD_FASTCYCLEACTIVE = LC_EL_false;
                LC_this->LC_VD_STARTARMED = LC_EL_false;
              }
            }
            else
            {
              LC_this->LC_VD_FAULTLATCHED = LC_EL_true;
              LC_this->LC_VD_STATE = (LC_TD_UINT)90;
              LC_this->LC_VD_FASTCYCLEACTIVE = LC_EL_false;
              LC_this->LC_VD_STARTARMED = LC_EL_false;
            }
          }
        }
      }
    }
  }
  LC_this->LC_VD_BLOCKED = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ENABLE)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_PERMIT))));
  LC_this->LC_VD_FAULT = LC_this->LC_VD_FAULTLATCHED;
  LC_this->LC_VD_READY = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)10)),LC_this->LC_VD_ENABLE)),LC_this->LC_VD_PERMIT)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_FAULTLATCHED)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_STOP)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_JAM)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_ACKJAM))));
  LC_this->LC_VD_INFEED = (lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)20));
  LC_this->LC_VD_SEALING = (lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)30));
  LC_this->LC_VD_OUTFEED = (lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)40));
  LC_this->LC_VD_COMPLETE = (lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)50));
  LC_this->LC_VD_RUNNING = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_INFEED,LC_this->LC_VD_SEALING)),LC_this->LC_VD_OUTFEED));
  NPE_HIS_CHANNEL2_NOP_VAR_USE
}

#endif
