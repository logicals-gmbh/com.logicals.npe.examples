#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_GUARD_STATE__C
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_GUARD_STATE__C

extern void* dummyCode4EmptyFile;

#endif
