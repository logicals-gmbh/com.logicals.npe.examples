#ifndef LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE__C
#define LC_PROT_LCFU___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE__C

#include <lcfu___safety.plcopen.sf_guardlocking_2_determinesafetylostsubstate.h>
#include <LC3CGStmt.h>
#include <lcfu_iec61131__AND.h>

/*                            Functions                        */
void  lcfu___SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE(LC_TD_Function_SAFETYx2EPLCOPENx2ESF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE* LC_this, LC_TD_DataType_SAFEBOOL LC_VD_S_GUARD, LC_TD_DataType_SAFEBOOL LC_VD_S_GUARDLOCK, struct _lcoplck_epdb_1_impl* pEPDB)
{
  NPE_HIS_CHANNEL2_NOP_VAR
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_VD_S_GUARD,LC_VD_S_GUARDLOCK));
    LC3_MST_IF (conditionResult)
    {
      {
        LC_TD_Function_TO_WORD lFunction_TO_WORD;
        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Safety_Lost_S_Guard_And_S_GuardLock_True, pEPDB);
        LC_this->LC_VD_SF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE = lFunction_TO_WORD.LC_VD_TO_WORD;
      }
    }
    else
    {
      {
        LC_TD_Function_TO_WORD lFunction_TO_WORD;
        LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
        lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_WORD__UINT(&lFunction_TO_WORD, LC_ED__safetyx2Eplcopenx2ESF_GuardLocking_2_State__Safety_Lost_S_Guard_Or_S_GuardLock_False, pEPDB);
        LC_this->LC_VD_SF_GUARDLOCKING_2_DETERMINESAFETYLOSTSUBSTATE = lFunction_TO_WORD.LC_VD_TO_WORD;
      }
    }
  }
  NPE_HIS_CHANNEL2_NOP_VAR_USE
}

#endif
