#ifndef LC_PROT_LCDT___SAFEULINT__C
#define LC_PROT_LCDT___SAFEULINT__C

extern void* dummyCode4EmptyFile;
#endif
