#ifndef LC_PROT_LCDT___SAFEREAL__C
#define LC_PROT_LCDT___SAFEREAL__C

extern void* dummyCode4EmptyFile;
#endif
