#ifndef LC_PROT_LCDT___SAFEBYTE__C
#define LC_PROT_LCDT___SAFEBYTE__C

extern void* dummyCode4EmptyFile;
#endif
