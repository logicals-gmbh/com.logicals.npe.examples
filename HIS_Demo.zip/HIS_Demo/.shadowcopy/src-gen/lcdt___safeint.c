#ifndef LC_PROT_LCDT___SAFEINT__C
#define LC_PROT_LCDT___SAFEINT__C

extern void* dummyCode4EmptyFile;
#endif
