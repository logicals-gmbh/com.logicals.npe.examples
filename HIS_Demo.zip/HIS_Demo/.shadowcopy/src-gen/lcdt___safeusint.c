#ifndef LC_PROT_LCDT___SAFEUSINT__C
#define LC_PROT_LCDT___SAFEUSINT__C

extern void* dummyCode4EmptyFile;
#endif
