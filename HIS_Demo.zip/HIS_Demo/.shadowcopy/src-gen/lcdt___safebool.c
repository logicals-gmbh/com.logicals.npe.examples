#ifndef LC_PROT_LCDT___SAFEBOOL__C
#define LC_PROT_LCDT___SAFEBOOL__C

extern void* dummyCode4EmptyFile;
#endif
