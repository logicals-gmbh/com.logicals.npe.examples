#ifndef LC_PROT_LCDT___SAFESINT__C
#define LC_PROT_LCDT___SAFESINT__C

extern void* dummyCode4EmptyFile;
#endif
