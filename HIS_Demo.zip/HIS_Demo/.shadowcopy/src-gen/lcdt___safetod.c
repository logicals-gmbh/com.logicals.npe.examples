#ifndef LC_PROT_LCDT___SAFETOD__C
#define LC_PROT_LCDT___SAFETOD__C

extern void* dummyCode4EmptyFile;
#endif
