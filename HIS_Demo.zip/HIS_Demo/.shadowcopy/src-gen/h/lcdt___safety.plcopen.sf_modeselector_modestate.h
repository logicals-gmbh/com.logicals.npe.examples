#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_INT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__Only_One_S_ModeX ((LC_TD_INT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__No_S_ModeX ((LC_TD_INT)1)
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__More_Than_One_S_ModeX ((LC_TD_INT)2)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__Only_One_S_ModeX; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_ModeState__Only_One_S_ModeX; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE(p,ARRAYSIZE); \
  } \
}

#endif
