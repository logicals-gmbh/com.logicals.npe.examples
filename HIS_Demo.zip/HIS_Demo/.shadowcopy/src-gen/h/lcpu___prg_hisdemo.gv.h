#ifndef LC_PROT_LCPU___PRG_HISDEMO__GVH
#define LC_PROT_LCPU___PRG_HISDEMO__GVH

#include <LC3CGBase.h>
#endif
