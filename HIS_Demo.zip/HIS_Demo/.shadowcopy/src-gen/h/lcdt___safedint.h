#ifndef LC_PROT_LCDT___SAFEDINT__H
#define LC_PROT_LCDT___SAFEDINT__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_DINT LC_TD_DataType_SAFEDINT;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEDINT(p) \
{ \
  LC_INIT_DINT(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEDINT(p,RF) \
{ \
  LC_WINIT_DINT(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEDINT(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEDINT,ptrToElement_ArrayOf_SAFEDINT,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEDINT(ptrToElement_ArrayOf_SAFEDINT); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEDINT(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEDINT(p,ARRAYSIZE); \
  } \
}

#endif
