#ifndef LC_PROT_LCDT___SAFETIME__H
#define LC_PROT_LCDT___SAFETIME__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_TIME LC_TD_DataType_SAFETIME;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETIME(p) \
{ \
  LC_INIT_TIME(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETIME(p,RF) \
{ \
  LC_WINIT_TIME(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETIME(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETIME,ptrToElement_ArrayOf_SAFETIME,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETIME(ptrToElement_ArrayOf_SAFETIME); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETIME(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETIME(p,ARRAYSIZE); \
  } \
}

#endif
