#ifndef LC_PROT_LCDT___SAFEINT__H
#define LC_PROT_LCDT___SAFEINT__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_INT LC_TD_DataType_SAFEINT;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEINT(p) \
{ \
  LC_INIT_INT(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEINT(p,RF) \
{ \
  LC_WINIT_INT(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEINT(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEINT,ptrToElement_ArrayOf_SAFEINT,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEINT(ptrToElement_ArrayOf_SAFEINT); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEINT(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEINT(p,ARRAYSIZE); \
  } \
}

#endif
