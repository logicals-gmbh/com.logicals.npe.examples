#ifndef LC_PROT_LCDT___SAFELWORD__H
#define LC_PROT_LCDT___SAFELWORD__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_LWORD LC_TD_DataType_SAFELWORD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFELWORD(p) \
{ \
  LC_INIT_LWORD(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFELWORD(p,RF) \
{ \
  LC_WINIT_LWORD(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFELWORD(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFELWORD,ptrToElement_ArrayOf_SAFELWORD,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFELWORD(ptrToElement_ArrayOf_SAFELWORD); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFELWORD(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFELWORD(p,ARRAYSIZE); \
  } \
}

#endif
