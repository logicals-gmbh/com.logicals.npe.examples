#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_Override_State__Idle ((LC_TD_UINT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_Override_State__Reset_Error ((LC_TD_UINT)49169)
#define LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Error ((LC_TD_UINT)50192)
#define LC_ED__safetyx2Eplcopenx2ESF_Override_State__Safety_Demand_AOPD ((LC_TD_UINT)32770)
#define LC_ED__safetyx2Eplcopenx2ESF_Override_State__Muting_Error_but_Override_not_possible ((LC_TD_UINT)32786)
#define LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Possible ((LC_TD_UINT)32802)
#define LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Interrupt ((LC_TD_UINT)34866)
#define LC_ED__safetyx2Eplcopenx2ESF_Override_State__Override_Active ((LC_TD_UINT)32768)
#define LC_ED__safetyx2Eplcopenx2ESF_Override_State__AOPD_Free ((LC_TD_UINT)33024)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_Override_State__Idle; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_Override_State__Idle; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE(p,ARRAYSIZE); \
  } \
}

#endif
