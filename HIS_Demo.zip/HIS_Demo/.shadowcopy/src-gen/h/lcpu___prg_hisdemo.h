#ifndef LC_PROT_LCPU___PRG_HISDEMO__H
#define LC_PROT_LCPU___PRG_HISDEMO__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcfu___fb_hissafety.h>
#include <lcfu___fb_packagingindicators.h>
#include <lcfu___fb_packagingline.h>
#include <lcpu___prg_hisdemo.gv.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Program_PRG_HISDEMO
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_CMDACKJAM;
  LC_TD_BOOL LC_VD_CMDENABLE;
  LC_TD_BOOL LC_VD_CMDFASTCYCLE;
  LC_TD_BOOL LC_VD_CMDJAM;
  LC_TD_BOOL LC_VD_CMDSAFETYRESET;
  LC_TD_BOOL LC_VD_CMDSTART;
  LC_TD_BOOL LC_VD_CMDSTOP;
  LC_TD_BOOL LC_VD_LEDATTENTION;
  LC_TD_BOOL LC_VD_LEDCONVEYOR;
  LC_TD_BOOL LC_VD_LEDREADY;
  LC_TD_BOOL LC_VD_LEDSEALING;
  LC_TD_FunctionBlock_FB_PACKAGINGINDICATORS LC_VD_LAMPS;
  LC_TD_FunctionBlock_FB_PACKAGINGLINE LC_VD_LINE;
  LC_TD_FunctionBlock_FB_HISSAFETY LC_VD_SAFETY;
  LC_TD_DataType_SAFEBOOL LC_VD_SIM_ESTOPRELEASED;
  LC_TD_DataType_SAFEBOOL LC_VD_S_DEMOENABLE;
  LC_TD_DataType_SAFEBOOL LC_VD_S_ESTOPA;
  LC_TD_DataType_SAFEBOOL LC_VD_S_ESTOPB;
} LCCG_StructAttrib LC_TD_Program_PRG_HISDEMO;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_Program_PRG_HISDEMO(p) \
  (p)->LC_VD_SIM_ESTOPRELEASED = LC_EL_false; \
  LC_INIT_DataType_SAFEBOOL(&((p)->LC_VD_S_ESTOPA)); \
  LC_INIT_DataType_SAFEBOOL(&((p)->LC_VD_S_ESTOPB)); \
  LC_INIT_BOOL(&((p)->LC_VD_CMDENABLE)); \
  LC_INIT_BOOL(&((p)->LC_VD_CMDSTART)); \
  LC_INIT_BOOL(&((p)->LC_VD_CMDSTOP)); \
  LC_INIT_BOOL(&((p)->LC_VD_CMDFASTCYCLE)); \
  LC_INIT_BOOL(&((p)->LC_VD_CMDJAM)); \
  LC_INIT_BOOL(&((p)->LC_VD_CMDSAFETYRESET)); \
  LC_INIT_BOOL(&((p)->LC_VD_CMDACKJAM)); \
  LC_INIT_DataType_SAFEBOOL(&((p)->LC_VD_S_DEMOENABLE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LEDREADY)); \
  LC_INIT_BOOL(&((p)->LC_VD_LEDCONVEYOR)); \
  LC_INIT_BOOL(&((p)->LC_VD_LEDSEALING)); \
  LC_INIT_BOOL(&((p)->LC_VD_LEDATTENTION)); \
  LC_INIT_FunctionBlock_FB_HISSAFETY(&((p)->LC_VD_SAFETY)); \
  LC_INIT_FunctionBlock_FB_PACKAGINGLINE(&((p)->LC_VD_LINE)); \
  LC_INIT_FunctionBlock_FB_PACKAGINGINDICATORS(&((p)->LC_VD_LAMPS)); \

#define LC_INIT_Program_PRG_HISDEMO(p) \
{ \
  LC_INIT_NONDMA_Program_PRG_HISDEMO(p) \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_Program_PRG_HISDEMO(p,RF) \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (p)->LC_VD_SIM_ESTOPRELEASED = LC_EL_false; \
  LC_WINIT_DataType_SAFEBOOL(&((p)->LC_VD_S_ESTOPA),RF); \
  LC_WINIT_DataType_SAFEBOOL(&((p)->LC_VD_S_ESTOPB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_CMDENABLE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_CMDSTART),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_CMDSTOP),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_CMDFASTCYCLE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_CMDJAM),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_CMDSAFETYRESET),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_CMDACKJAM),RF); \
  LC_WINIT_DataType_SAFEBOOL(&((p)->LC_VD_S_DEMOENABLE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LEDREADY),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LEDCONVEYOR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LEDSEALING),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LEDATTENTION),RF); \
  LC_WINIT_FunctionBlock_FB_HISSAFETY(&((p)->LC_VD_SAFETY),0); \
  LC_WINIT_FunctionBlock_FB_PACKAGINGLINE(&((p)->LC_VD_LINE),0); \
  LC_WINIT_FunctionBlock_FB_PACKAGINGINDICATORS(&((p)->LC_VD_LAMPS),0); \

#define LC_WINIT_Program_PRG_HISDEMO(p,RF) \
{ \
  LC_WINIT_NONDMA_Program_PRG_HISDEMO(p,RF) \
}

/*                            Prototype                        */
void  lcpu___PRG_HISDEMO(LC_TD_Program_PRG_HISDEMO* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
