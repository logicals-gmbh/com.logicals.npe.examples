#ifndef LC_PROT_LCFU___FB_HISSAFETY__H
#define LC_PROT_LCFU___FB_HISSAFETY__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcfu___safety.plcopen.sf_emergencystop.h>
#include <lcfu___safety.plcopen.sf_equivalent.h>
#include <lcfu_iec61131__OR.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_FB_HISSAFETY
{
  LC_TD_BOOL LC_VD_RESET;
  LC_TD_DataType_SAFEBOOL LC_VD_S_ESTOPA;
  LC_TD_DataType_SAFEBOOL LC_VD_S_ESTOPB;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_ERROR;
  LC_TD_BOOL LC_VD_RESETREQUEST;
  LC_TD_BOOL LC_VD_SAFETYDEMAND;
  LC_TD_WORD LC_VD_EQUIVALENTDIAG;
  LC_TD_WORD LC_VD_ESTOPDIAG;
  LC_TD_DataType_SAFEBOOL LC_VD_S_PERMIT;
  LC_TD_BOOL LC_VD___11_OR;
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_EMERGENCYSTOP LC_VD_FBEMERGENCYSTOP;
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_EQUIVALENT LC_VD_FBEQUIVALENT;
  LC_TD_DataType_SAFEBOOL LC_VD_S_RESETDISABLED;
} LCCG_StructAttrib LC_TD_FunctionBlock_FB_HISSAFETY;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_FB_HISSAFETY(LC_TD_FunctionBlock_FB_HISSAFETY* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_FB_HISSAFETY(p) LC_INIT_FUN_FunctionBlock_FB_HISSAFETY((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_FB_HISSAFETY(LC_TD_FunctionBlock_FB_HISSAFETY* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_FB_HISSAFETY(p,RF) LC_WINIT_FUN_FunctionBlock_FB_HISSAFETY((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___FB_HISSAFETY(LC_TD_FunctionBlock_FB_HISSAFETY* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
