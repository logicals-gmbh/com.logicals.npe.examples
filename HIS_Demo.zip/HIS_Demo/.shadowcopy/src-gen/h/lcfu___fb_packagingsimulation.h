#ifndef LC_PROT_LCFU___FB_PACKAGINGSIMULATION__H
#define LC_PROT_LCFU___FB_PACKAGINGSIMULATION__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_FB_PACKAGINGSIMULATION
{
  LC_TD_BOOL LC_VD_FASTCYCLE;
  LC_TD_BOOL LC_VD_INJECTFAULTS;
  LC_TD_BOOL LC_VD_LINEFAULT;
  LC_TD_BOOL LC_VD_LINEREADY;
  LC_TD_BOOL LC_VD_PERMIT;
  LC_TD_BOOL LC_VD_RESET;
  LC_TD_UINT LC_VD_LINESTATE;
  LC_TD_BOOL LC_VD_ACKJAM;
  LC_TD_BOOL LC_VD_ENABLE;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_FASTCYCLECOMMAND;
  LC_TD_BOOL LC_VD_JAM;
  LC_TD_BOOL LC_VD_SAFETYRESET;
  LC_TD_BOOL LC_VD_START;
  LC_TD_BOOL LC_VD_STOP;
  LC_TD_UINT LC_VD_ATTEMPTINROUND;
  LC_TD_UINT LC_VD_SCENARIO;
  LC_TD_UINT LC_VD_STATE;
  LC_TD_DataType_SAFEBOOL LC_VD_ESTOPRELEASED;
  LC_TD_FunctionBlock_TON LC_VD_TACK;
  LC_TD_FunctionBlock_TON LC_VD_TBOOT;
  LC_TD_FunctionBlock_TON LC_VD_TESTOP;
  LC_TD_FunctionBlock_TON LC_VD_TJAM;
  LC_TD_FunctionBlock_TON LC_VD_TJAMCLEAR;
  LC_TD_FunctionBlock_TON LC_VD_TREADY;
  LC_TD_FunctionBlock_TON LC_VD_TRELEASE;
  LC_TD_FunctionBlock_TON LC_VD_TRESETGAP;
  LC_TD_FunctionBlock_TON LC_VD_TRESETPULSE;
  LC_TD_FunctionBlock_TON LC_VD_TSTART;
} LCCG_StructAttrib LC_TD_FunctionBlock_FB_PACKAGINGSIMULATION;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_FB_PACKAGINGSIMULATION(LC_TD_FunctionBlock_FB_PACKAGINGSIMULATION* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_FB_PACKAGINGSIMULATION(p) LC_INIT_FUN_FunctionBlock_FB_PACKAGINGSIMULATION((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_FB_PACKAGINGSIMULATION(LC_TD_FunctionBlock_FB_PACKAGINGSIMULATION* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_FB_PACKAGINGSIMULATION(p,RF) LC_WINIT_FUN_FunctionBlock_FB_PACKAGINGSIMULATION((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___FB_PACKAGINGSIMULATION(LC_TD_FunctionBlock_FB_PACKAGINGSIMULATION* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
