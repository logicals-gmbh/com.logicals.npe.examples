#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_STATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_MODESELECTOR_STATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_STATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Short_Circuit ((LC_TD_UINT)49168)
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Short_Circuit_Fixed ((LC_TD_UINT)50192)
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Open_Circuit ((LC_TD_UINT)49184)
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Open_Circuit_Fixed ((LC_TD_UINT)50208)
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Reset_Error_1 ((LC_TD_UINT)49169)
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Reset_Error_2 ((LC_TD_UINT)49185)
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Idle ((LC_TD_UINT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Changed ((LC_TD_UINT)34818)
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Selected ((LC_TD_UINT)32768)
#define LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Mode_Locked ((LC_TD_UINT)32784)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_STATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Short_Circuit; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_STATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_ModeSelector_State__Error_Short_Circuit; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_STATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_STATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_STATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_STATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_STATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_STATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_STATE(p,ARRAYSIZE); \
  } \
}

#endif
