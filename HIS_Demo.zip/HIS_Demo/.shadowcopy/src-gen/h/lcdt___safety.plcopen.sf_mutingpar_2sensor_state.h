#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR_STATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR_STATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR_STATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Reset_Error_1 ((LC_TD_UINT)49153)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Reset_Error_2 ((LC_TD_UINT)49169)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Error_Muting_Sequence_Base ((LC_TD_UINT)49156)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Parameter_Error ((LC_TD_UINT)49168)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Error_Timer_MaxMuting ((LC_TD_UINT)49184)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Error_Timer_Entry ((LC_TD_UINT)49200)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Idle ((LC_TD_UINT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__AOPD_Free ((LC_TD_UINT)32768)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Init ((LC_TD_UINT)33793)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Safety_Demand_AOPD ((LC_TD_UINT)34818)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Wait_For_Reset ((LC_TD_UINT)33794)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Safe ((LC_TD_UINT)34820)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Muting_Start_1 ((LC_TD_UINT)32784)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Muting_Start_2 ((LC_TD_UINT)33552)
#define LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Muting_Active ((LC_TD_UINT)32800)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR_STATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Reset_Error_1; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR_STATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_MutingPar_2Sensor_State__Reset_Error_1; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR_STATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR_STATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR_STATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR_STATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR_STATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR_STATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_MUTINGPAR_2SENSOR_STATE(p,ARRAYSIZE); \
  } \
}

#endif
