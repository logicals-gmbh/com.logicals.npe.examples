#ifndef LC_PROT_LCDT___SAFEDATE__H
#define LC_PROT_LCDT___SAFEDATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_DATE LC_TD_DataType_SAFEDATE;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEDATE(p) \
{ \
  LC_INIT_DATE(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEDATE(p,RF) \
{ \
  LC_WINIT_DATE(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEDATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEDATE,ptrToElement_ArrayOf_SAFEDATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEDATE(ptrToElement_ArrayOf_SAFEDATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEDATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEDATE(p,ARRAYSIZE); \
  } \
}

#endif
