#ifndef LC_PROT_LCDT___SAFEULINT__H
#define LC_PROT_LCDT___SAFEULINT__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_ULINT LC_TD_DataType_SAFEULINT;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEULINT(p) \
{ \
  LC_INIT_ULINT(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEULINT(p,RF) \
{ \
  LC_WINIT_ULINT(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEULINT(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEULINT,ptrToElement_ArrayOf_SAFEULINT,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEULINT(ptrToElement_ArrayOf_SAFEULINT); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEULINT(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEULINT(p,ARRAYSIZE); \
  } \
}

#endif
