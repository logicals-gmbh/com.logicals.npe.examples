#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_STATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_STATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_STATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Reset_Error_0 ((LC_TD_UINT)49153)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Guard_Error ((LC_TD_UINT)49168)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Reset_Error_1 ((LC_TD_UINT)49169)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Guard_Return ((LC_TD_UINT)50192)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Safety_Lost_S_Guard_True ((LC_TD_UINT)50256)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Safety_Lost_S_Guard_False ((LC_TD_UINT)49232)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Reset_Error_2 ((LC_TD_UINT)49185)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Safety_Return ((LC_TD_UINT)50208)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Reset_Error_3 ((LC_TD_UINT)49201)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Unlock_Request_Error_S_Guard_True ((LC_TD_UINT)50240)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Unlock_Request_Error_S_Guard_False ((LC_TD_UINT)49216)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Reset_Error_4 ((LC_TD_UINT)49217)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Idle ((LC_TD_UINT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Guard_Closed_And_Locked ((LC_TD_UINT)32768)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Init_S_Guard_True ((LC_TD_UINT)33793)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Init_S_Guard_False ((LC_TD_UINT)34817)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Wait_For_Reset ((LC_TD_UINT)33840)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Wait_For_Operator ((LC_TD_UINT)34834)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Guard_Open_And_Or_Unlocked ((LC_TD_UINT)34850)
#define LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Wait_For_Unlocked ((LC_TD_UINT)33808)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_STATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Reset_Error_0; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_STATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_GuardLockingSerial_State__Reset_Error_0; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_STATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_STATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_STATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_STATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_STATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_STATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_GUARDLOCKINGSERIAL_STATE(p,ARRAYSIZE); \
  } \
}

#endif
