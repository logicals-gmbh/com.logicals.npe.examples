#ifndef LC_PROT_LCDT___SAFEUDINT__H
#define LC_PROT_LCDT___SAFEUDINT__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UDINT LC_TD_DataType_SAFEUDINT;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEUDINT(p) \
{ \
  LC_INIT_UDINT(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEUDINT(p,RF) \
{ \
  LC_WINIT_UDINT(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEUDINT(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEUDINT,ptrToElement_ArrayOf_SAFEUDINT,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEUDINT(ptrToElement_ArrayOf_SAFEUDINT); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEUDINT(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEUDINT(p,ARRAYSIZE); \
  } \
}

#endif
