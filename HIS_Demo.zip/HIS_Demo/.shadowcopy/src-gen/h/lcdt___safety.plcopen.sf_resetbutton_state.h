#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_RESETBUTTON_STATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_RESETBUTTON_STATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_RESETBUTTON_STATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Parameter_Error ((LC_TD_UINT)49152)
#define LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Reset_Error ((LC_TD_UINT)49153)
#define LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Error_Trailing_Maximum ((LC_TD_UINT)50144)
#define LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Error_Trailing_Minimum ((LC_TD_UINT)50160)
#define LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Idle ((LC_TD_UINT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Wait_for_R_TRIG ((LC_TD_UINT)33762)
#define LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Wait_for_F_TRIG ((LC_TD_UINT)33778)
#define LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Reset_Detected ((LC_TD_UINT)32768)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_RESETBUTTON_STATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Parameter_Error; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_RESETBUTTON_STATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_ResetButton_State__Parameter_Error; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_RESETBUTTON_STATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_RESETBUTTON_STATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_RESETBUTTON_STATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_RESETBUTTON_STATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_RESETBUTTON_STATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_RESETBUTTON_STATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_RESETBUTTON_STATE(p,ARRAYSIZE); \
  } \
}

#endif
