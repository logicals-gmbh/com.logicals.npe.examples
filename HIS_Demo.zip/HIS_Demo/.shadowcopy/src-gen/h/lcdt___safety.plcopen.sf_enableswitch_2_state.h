#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2_STATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2_STATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2_STATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Reset_Error_1 ((LC_TD_UINT)49153)
#define LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Operation_Error_1_EnableIn ((LC_TD_UINT)49168)
#define LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Operation_Error_1_Not_EnableIn ((LC_TD_UINT)50192)
#define LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Idle ((LC_TD_UINT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Basic_Operation_Mode ((LC_TD_UINT)32770)
#define LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Safe_Operation_Mode ((LC_TD_UINT)32772)
#define LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Not_Enabled ((LC_TD_UINT)34818)
#define LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Enabled ((LC_TD_UINT)32768)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2_STATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Reset_Error_1; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2_STATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_EnableSwitch_2_State__Reset_Error_1; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2_STATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2_STATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2_STATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2_STATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2_STATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2_STATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_ENABLESWITCH_2_STATE(p,ARRAYSIZE); \
  } \
}

#endif
