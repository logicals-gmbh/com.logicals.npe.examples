#ifndef LC_PROT_LCDT___SAFEWORD__H
#define LC_PROT_LCDT___SAFEWORD__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_WORD LC_TD_DataType_SAFEWORD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEWORD(p) \
{ \
  LC_INIT_WORD(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEWORD(p,RF) \
{ \
  LC_WINIT_WORD(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEWORD(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEWORD,ptrToElement_ArrayOf_SAFEWORD,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEWORD(ptrToElement_ArrayOf_SAFEWORD); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEWORD(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEWORD(p,ARRAYSIZE); \
  } \
}

#endif
