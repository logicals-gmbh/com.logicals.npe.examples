#ifndef LC_PROT_LCDT___SAFEBOOL__H
#define LC_PROT_LCDT___SAFEBOOL__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_BOOL LC_TD_DataType_SAFEBOOL;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEBOOL(p) \
{ \
  LC_INIT_BOOL(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEBOOL(p,RF) \
{ \
  LC_WINIT_BOOL(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEBOOL(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEBOOL,ptrToElement_ArrayOf_SAFEBOOL,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEBOOL(ptrToElement_ArrayOf_SAFEBOOL); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEBOOL(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEBOOL(p,ARRAYSIZE); \
  } \
}

#endif
