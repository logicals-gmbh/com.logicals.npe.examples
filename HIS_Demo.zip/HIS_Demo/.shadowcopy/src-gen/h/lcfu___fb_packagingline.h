#ifndef LC_PROT_LCFU___FB_PACKAGINGLINE__H
#define LC_PROT_LCFU___FB_PACKAGINGLINE__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_FB_PACKAGINGLINE
{
  LC_TD_BOOL LC_VD_ACKJAM;
  LC_TD_BOOL LC_VD_ENABLE;
  LC_TD_BOOL LC_VD_FASTCYCLE;
  LC_TD_BOOL LC_VD_JAM;
  LC_TD_BOOL LC_VD_PERMIT;
  LC_TD_BOOL LC_VD_START;
  LC_TD_BOOL LC_VD_STOP;
  LC_TD_BOOL LC_VD_BLOCKED;
  LC_TD_BOOL LC_VD_COMPLETE;
  LC_TD_BOOL LC_VD_CYCLEDONE;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_FASTCYCLEACTIVE;
  LC_TD_BOOL LC_VD_FAULT;
  LC_TD_BOOL LC_VD_HEARTBEAT;
  LC_TD_BOOL LC_VD_INFEED;
  LC_TD_BOOL LC_VD_OUTFEED;
  LC_TD_BOOL LC_VD_READY;
  LC_TD_BOOL LC_VD_RUNNING;
  LC_TD_BOOL LC_VD_SEALING;
  LC_TD_UINT LC_VD_STATE;
  LC_TD_UDINT LC_VD_CARTONSPACKED;
  LC_TD_BOOL LC_VD_ACKEDGE;
  LC_TD_BOOL LC_VD_FAULTLATCHED;
  LC_TD_BOOL LC_VD_FIRSTSCAN;
  LC_TD_BOOL LC_VD_PREVACK;
  LC_TD_BOOL LC_VD_PREVSTART;
  LC_TD_BOOL LC_VD_STARTARMED;
  LC_TD_BOOL LC_VD_STARTEDGE;
  LC_TD_TIME LC_VD_INFEEDTIME;
  LC_TD_TIME LC_VD_OUTFEEDTIME;
  LC_TD_TIME LC_VD_SEALTIME;
  LC_TD_FunctionBlock_TON LC_VD_TBLINK;
  LC_TD_FunctionBlock_TON LC_VD_TINFEED;
  LC_TD_FunctionBlock_TON LC_VD_TOUTFEED;
  LC_TD_FunctionBlock_TON LC_VD_TSEAL;
  LC_TD_FunctionBlock_TON LC_VD_TSUCCESS;
} LCCG_StructAttrib LC_TD_FunctionBlock_FB_PACKAGINGLINE;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_FB_PACKAGINGLINE(LC_TD_FunctionBlock_FB_PACKAGINGLINE* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_FB_PACKAGINGLINE(p) LC_INIT_FUN_FunctionBlock_FB_PACKAGINGLINE((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_FB_PACKAGINGLINE(LC_TD_FunctionBlock_FB_PACKAGINGLINE* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_FB_PACKAGINGLINE(p,RF) LC_WINIT_FUN_FunctionBlock_FB_PACKAGINGLINE((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___FB_PACKAGINGLINE(LC_TD_FunctionBlock_FB_PACKAGINGLINE* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
