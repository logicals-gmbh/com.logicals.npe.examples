#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_GUARD_STATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_GUARD_STATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_GUARD_STATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Reset_Error ((LC_TD_UINT)49153)
#define LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Discrepancytime_Error_1 ((LC_TD_UINT)49168)
#define LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Discrepancytime_Error_2 ((LC_TD_UINT)49184)
#define LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Idle ((LC_TD_UINT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Normal ((LC_TD_UINT)32768)
#define LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Init ((LC_TD_UINT)32769)
#define LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Open_Guard_Request ((LC_TD_UINT)34818)
#define LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_Reset ((LC_TD_UINT)33794)
#define LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Guard_Opened ((LC_TD_UINT)34820)
#define LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_GuardSwitch2 ((LC_TD_UINT)34822)
#define LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Wait_For_GuardSwitch1 ((LC_TD_UINT)34824)
#define LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Guard_Closed ((LC_TD_UINT)32770)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_GUARD_STATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Reset_Error; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_GUARD_STATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_Guard_State__Reset_Error; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_GUARD_STATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_GUARD_STATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_GUARD_STATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_GUARD_STATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_GUARD_STATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_GUARD_STATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_GUARD_STATE(p,ARRAYSIZE); \
  } \
}

#endif
