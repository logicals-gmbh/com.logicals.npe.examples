#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Parameter_Error ((LC_TD_UINT)49152)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_1 ((LC_TD_UINT)49153)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_2 ((LC_TD_UINT)49169)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_3 ((LC_TD_UINT)49185)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_4 ((LC_TD_UINT)49201)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_5 ((LC_TD_UINT)49217)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Reset_Error_6 ((LC_TD_UINT)49233)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_1 ((LC_TD_UINT)50192)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Error_2 ((LC_TD_UINT)49168)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Idle ((LC_TD_UINT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Init ((LC_TD_UINT)33793)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_1 ((LC_TD_UINT)34818)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Wait_for_Reset_1 ((LC_TD_UINT)33794)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__External_Function_Test ((LC_TD_UINT)32770)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_External_Test ((LC_TD_UINT)34820)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__End_External_Test ((LC_TD_UINT)33796)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_No_Test ((LC_TD_UINT)32784)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Interrupted_2 ((LC_TD_UINT)34822)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Wait_for_Reset_2 ((LC_TD_UINT)33798)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Request ((LC_TD_UINT)32800)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Test_Active ((LC_TD_UINT)32816)
#define LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__ESPE_Free_Test_ok ((LC_TD_UINT)32768)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Parameter_Error; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_TestableSafetySensor_State__Parameter_Error; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE(p,ARRAYSIZE); \
  } \
}

#endif
