#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_EDM_STATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_EDM_STATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_EDM_STATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_1 ((LC_TD_UINT)49153)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_21 ((LC_TD_UINT)49169)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_22 ((LC_TD_UINT)49185)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_23 ((LC_TD_UINT)49201)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_31 ((LC_TD_UINT)49217)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_32 ((LC_TD_UINT)49233)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_33 ((LC_TD_UINT)49249)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_41 ((LC_TD_UINT)49265)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_42 ((LC_TD_UINT)49281)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_43 ((LC_TD_UINT)49297)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_11a ((LC_TD_UINT)49168)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_11b ((LC_TD_UINT)50192)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_12a ((LC_TD_UINT)49184)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_12b ((LC_TD_UINT)50208)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_13a ((LC_TD_UINT)49200)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_13b ((LC_TD_UINT)50224)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_21a ((LC_TD_UINT)49216)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_21b ((LC_TD_UINT)50240)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_22a ((LC_TD_UINT)49232)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_22b ((LC_TD_UINT)50256)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_23a ((LC_TD_UINT)49248)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_23b ((LC_TD_UINT)50272)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_31 ((LC_TD_UINT)49264)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_32 ((LC_TD_UINT)49280)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__EDM_Error_33 ((LC_TD_UINT)49296)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Init_Error ((LC_TD_UINT)49408)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Idle ((LC_TD_UINT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Init ((LC_TD_UINT)33793)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Disable ((LC_TD_UINT)34832)
#define LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Output_Enable ((LC_TD_UINT)32768)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_EDM_STATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_1; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_EDM_STATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_EDM_State__Reset_Error_1; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_EDM_STATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_EDM_STATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_EDM_STATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_EDM_STATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_EDM_STATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_EDM_STATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_EDM_STATE(p,ARRAYSIZE); \
  } \
}

#endif
