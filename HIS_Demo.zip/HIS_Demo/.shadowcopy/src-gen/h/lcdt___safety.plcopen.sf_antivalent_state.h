#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_Antivalent_State__Error_1 ((LC_TD_UINT)49168)
#define LC_ED__safetyx2Eplcopenx2ESF_Antivalent_State__Error_2 ((LC_TD_UINT)49184)
#define LC_ED__safetyx2Eplcopenx2ESF_Antivalent_State__Error_3 ((LC_TD_UINT)49200)
#define LC_ED__safetyx2Eplcopenx2ESF_Antivalent_State__Idle ((LC_TD_UINT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_Antivalent_State__Init ((LC_TD_UINT)34817)
#define LC_ED__safetyx2Eplcopenx2ESF_Antivalent_State__Safety_Output_Enabled ((LC_TD_UINT)32768)
#define LC_ED__safetyx2Eplcopenx2ESF_Antivalent_State__Wait_for_NO ((LC_TD_UINT)34818)
#define LC_ED__safetyx2Eplcopenx2ESF_Antivalent_State__Wait_for_NC ((LC_TD_UINT)34820)
#define LC_ED__safetyx2Eplcopenx2ESF_Antivalent_State__From_Active_Wait ((LC_TD_UINT)34822)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_Antivalent_State__Error_1; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_Antivalent_State__Error_1; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE(p,ARRAYSIZE); \
  } \
}

#endif
