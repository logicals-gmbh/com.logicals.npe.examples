#ifndef LC_PROT_LCDT___SAFEUSINT__H
#define LC_PROT_LCDT___SAFEUSINT__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_USINT LC_TD_DataType_SAFEUSINT;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEUSINT(p) \
{ \
  LC_INIT_USINT(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEUSINT(p,RF) \
{ \
  LC_WINIT_USINT(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEUSINT(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEUSINT,ptrToElement_ArrayOf_SAFEUSINT,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEUSINT(ptrToElement_ArrayOf_SAFEUSINT); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEUSINT(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEUSINT(p,ARRAYSIZE); \
  } \
}

#endif
