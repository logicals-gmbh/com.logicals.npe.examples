#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_SAFETYREQUEST_STATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_SAFETYREQUEST_STATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_SAFETYREQUEST_STATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Acknowledge_Lost ((LC_TD_UINT)49168)
#define LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__MonitoringTime_Elapsed ((LC_TD_UINT)49184)
#define LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Reset_Error_1 ((LC_TD_UINT)49153)
#define LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Reset_Error_2 ((LC_TD_UINT)49172)
#define LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Reset_Error_3 ((LC_TD_UINT)49169)
#define LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Idle ((LC_TD_UINT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Safe_Mode ((LC_TD_UINT)32768)
#define LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Init ((LC_TD_UINT)33793)
#define LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Operation_Mode ((LC_TD_UINT)34818)
#define LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Wait_For_Confirmation_OpMode ((LC_TD_UINT)34820)
#define LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Wait_For_Confirmation ((LC_TD_UINT)32770)
#define LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Wait_For_OpMode ((LC_TD_UINT)32772)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_SAFETYREQUEST_STATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Acknowledge_Lost; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_SAFETYREQUEST_STATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_SafetyRequest_State__Acknowledge_Lost; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_SAFETYREQUEST_STATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_SAFETYREQUEST_STATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_SAFETYREQUEST_STATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_SAFETYREQUEST_STATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_SAFETYREQUEST_STATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_SAFETYREQUEST_STATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_SAFETYREQUEST_STATE(p,ARRAYSIZE); \
  } \
}

#endif
