#ifndef LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEIII_STATE__H
#define LC_PROT_LCDT___SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEIII_STATE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEIII_STATE;

/*                            Named Value Constants                         */
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Error_1_B1 ((LC_TD_UINT)49168)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Error_1_B2 ((LC_TD_UINT)49184)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Error_1_B1_and_B2 ((LC_TD_UINT)49200)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Error_2_B1 ((LC_TD_UINT)49216)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Error_2_B2 ((LC_TD_UINT)49232)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Error_2_B1_and_B2 ((LC_TD_UINT)49248)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Idle ((LC_TD_UINT)0)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Buttons_Actuated ((LC_TD_UINT)32768)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Init ((LC_TD_UINT)32769)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Buttons_Released ((LC_TD_UINT)34818)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Button_1_Actuated ((LC_TD_UINT)34820)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Button_2_Actuated ((LC_TD_UINT)34822)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Button_2_Released ((LC_TD_UINT)34824)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Button_1_Released ((LC_TD_UINT)34826)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Locked_Off ((LC_TD_UINT)34828)
#define LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Locked_On ((LC_TD_UINT)34830)

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEIII_STATE(p) \
{ \
  (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Error_1_B1; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEIII_STATE(p,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (*(p)) = LC_ED__safetyx2Eplcopenx2ESF_TwoHandControlTypeIII_State__Error_1_B1; \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEIII_STATE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEIII_STATE,ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEIII_STATE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEIII_STATE(ptrToElement_ArrayOf_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEIII_STATE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEIII_STATE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFETYx2EPLCOPENx2ESF_TWOHANDCONTROLTYPEIII_STATE(p,ARRAYSIZE); \
  } \
}

#endif
