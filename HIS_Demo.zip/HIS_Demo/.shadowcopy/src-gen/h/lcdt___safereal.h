#ifndef LC_PROT_LCDT___SAFEREAL__H
#define LC_PROT_LCDT___SAFEREAL__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_REAL LC_TD_DataType_SAFEREAL;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEREAL(p) \
{ \
  LC_INIT_REAL(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEREAL(p,RF) \
{ \
  LC_WINIT_REAL(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEREAL(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEREAL,ptrToElement_ArrayOf_SAFEREAL,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEREAL(ptrToElement_ArrayOf_SAFEREAL); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEREAL(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEREAL(p,ARRAYSIZE); \
  } \
}

#endif
