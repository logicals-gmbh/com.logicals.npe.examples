#ifndef LC_PROT_LCDT___SAFEDWORD__H
#define LC_PROT_LCDT___SAFEDWORD__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_DWORD LC_TD_DataType_SAFEDWORD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEDWORD(p) \
{ \
  LC_INIT_DWORD(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEDWORD(p,RF) \
{ \
  LC_WINIT_DWORD(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEDWORD(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEDWORD,ptrToElement_ArrayOf_SAFEDWORD,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEDWORD(ptrToElement_ArrayOf_SAFEDWORD); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEDWORD(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEDWORD(p,ARRAYSIZE); \
  } \
}

#endif
