#ifndef LC_PROT_LCDT___SAFESINT__H
#define LC_PROT_LCDT___SAFESINT__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_SINT LC_TD_DataType_SAFESINT;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFESINT(p) \
{ \
  LC_INIT_SINT(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFESINT(p,RF) \
{ \
  LC_WINIT_SINT(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFESINT(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFESINT,ptrToElement_ArrayOf_SAFESINT,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFESINT(ptrToElement_ArrayOf_SAFESINT); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFESINT(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFESINT(p,ARRAYSIZE); \
  } \
}

#endif
