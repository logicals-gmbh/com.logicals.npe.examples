#ifndef LC_PROT_LCFU___FB_PACKAGINGINDICATORS__H
#define LC_PROT_LCFU___FB_PACKAGINGINDICATORS__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_FB_PACKAGINGINDICATORS
{
  LC_TD_BOOL LC_VD_BLOCKED;
  LC_TD_BOOL LC_VD_COMPLETE;
  LC_TD_BOOL LC_VD_HEARTBEAT;
  LC_TD_BOOL LC_VD_INFEED;
  LC_TD_BOOL LC_VD_OUTFEED;
  LC_TD_BOOL LC_VD_PERMIT;
  LC_TD_BOOL LC_VD_PROCESSFAULT;
  LC_TD_BOOL LC_VD_READY;
  LC_TD_BOOL LC_VD_RESETREQUEST;
  LC_TD_BOOL LC_VD_SAFETYERROR;
  LC_TD_BOOL LC_VD_SEALING;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_LEDATTENTION;
  LC_TD_BOOL LC_VD_LEDCONVEYOR;
  LC_TD_BOOL LC_VD_LEDREADY;
  LC_TD_BOOL LC_VD_LEDSEALING;
  LC_TD_BOOL LC_VD___1_OR;
  LC_TD_BOOL LC_VD___4_AND;
  LC_TD_BOOL LC_VD___7_OR;
  LC_TD_BOOL LC_VD___10_AND;
  LC_TD_BOOL LC_VD___14_AND;
  LC_TD_BOOL LC_VD___19_NOT;
  LC_TD_BOOL LC_VD___21_AND;
  LC_TD_BOOL LC_VD___23_AND;
  LC_TD_BOOL LC_VD___26_OR;
} LCCG_StructAttrib LC_TD_FunctionBlock_FB_PACKAGINGINDICATORS;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_FB_PACKAGINGINDICATORS(LC_TD_FunctionBlock_FB_PACKAGINGINDICATORS* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_FB_PACKAGINGINDICATORS(p) LC_INIT_FUN_FunctionBlock_FB_PACKAGINGINDICATORS((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_FB_PACKAGINGINDICATORS(LC_TD_FunctionBlock_FB_PACKAGINGINDICATORS* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_FB_PACKAGINGINDICATORS(p,RF) LC_WINIT_FUN_FunctionBlock_FB_PACKAGINGINDICATORS((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___FB_PACKAGINGINDICATORS(LC_TD_FunctionBlock_FB_PACKAGINGINDICATORS* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
