#ifndef LC_PROT_LCDT___SAFEBYTE__H
#define LC_PROT_LCDT___SAFEBYTE__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_BYTE LC_TD_DataType_SAFEBYTE;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEBYTE(p) \
{ \
  LC_INIT_BYTE(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEBYTE(p,RF) \
{ \
  LC_WINIT_BYTE(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEBYTE(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEBYTE,ptrToElement_ArrayOf_SAFEBYTE,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEBYTE(ptrToElement_ArrayOf_SAFEBYTE); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEBYTE(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEBYTE(p,ARRAYSIZE); \
  } \
}

#endif
