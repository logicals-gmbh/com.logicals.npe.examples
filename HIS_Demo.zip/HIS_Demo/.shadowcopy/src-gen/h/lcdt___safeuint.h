#ifndef LC_PROT_LCDT___SAFEUINT__H
#define LC_PROT_LCDT___SAFEUINT__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_UINT LC_TD_DataType_SAFEUINT;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEUINT(p) \
{ \
  LC_INIT_UINT(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEUINT(p,RF) \
{ \
  LC_WINIT_UINT(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEUINT(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEUINT,ptrToElement_ArrayOf_SAFEUINT,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEUINT(ptrToElement_ArrayOf_SAFEUINT); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEUINT(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEUINT(p,ARRAYSIZE); \
  } \
}

#endif
