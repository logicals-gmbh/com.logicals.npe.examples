#ifndef LC_PROT_LCDT___SAFEDT__H
#define LC_PROT_LCDT___SAFEDT__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef LC_TD_DT LC_TD_DataType_SAFEDT;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_DataType_SAFEDT(p) \
{ \
  LC_INIT_DT(p); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_DataType_SAFEDT(p,RF) \
{ \
  LC_WINIT_DT(p,RF); \
}

/*                ColdBoot Initialization Macro for Arrays            */
#define LC_INIT_ARRAY_OF_DataType_SAFEDT(p,ARRAYSIZE) \
{ \
  LC_MF_INIT_ARRAY_LOOP_START(LC_TD_DataType_SAFEDT,ptrToElement_ArrayOf_SAFEDT,p,ARRAYSIZE) \
    LC_INIT_DataType_SAFEDT(ptrToElement_ArrayOf_SAFEDT); \
  LC_MF_INIT_ARRAY_LOOP_END() \
}

/*                WarmBoot Initialization Macro for Arrays            */
#define LC_WINIT_ARRAY_OF_DataType_SAFEDT(p,ARRAYSIZE,RF) \
{ \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) \
  { \
    LC_INIT_ARRAY_OF_DataType_SAFEDT(p,ARRAYSIZE); \
  } \
}

#endif
