#ifndef LC_PROT_LCPU___ESTOPDEMO__H
#define LC_PROT_LCPU___ESTOPDEMO__H

#include <LC3CGBase.h>
#include <lcdt___safebool.h>
#include <lcfu___safety.plcopen.sf_emergencystop.h>
#include <lcfu___safety.plcopen.sf_espe.h>
#include <lcfu___safety.plcopen.sf_outcontrol.h>
#include <lcfu_iec61131__AND.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Program_ESTOPDEMO
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_ENABLE;
  LC_TD_BOOL LC_VD_MOTORLOGIC;
  LC_TD_BOOL LC_VD_RESET;
  LC_TD_BOOL LC_VD___19_AND;
  LC_TD_DataType_SAFEBOOL LC_VD_ESTOPINPUT;
  LC_TD_DataType_SAFEBOOL LC_VD_LIGHTCURTAININPUT;
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_EMERGENCYSTOP LC_VD_LOGICALS_SAFETY_PLCOPEN_SF_EMERGENCYSTOP1;
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ESPE LC_VD_LOGICALS_SAFETY_PLCOPEN_SF_ESPE1;
  LC_TD_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL LC_VD_LOGICALS_SAFETY_PLCOPEN_SF_OUTCONTROL1;
  LC_TD_DataType_SAFEBOOL LC_VD_MOTOROUTPUT;
  LC_TD_DataType_SAFEBOOL LC_VD_SAFETRUE;
} LCCG_StructAttrib LC_TD_Program_ESTOPDEMO;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_Program_ESTOPDEMO(p) \
  LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_EMERGENCYSTOP(&((p)->LC_VD_LOGICALS_SAFETY_PLCOPEN_SF_EMERGENCYSTOP1)); \
  LC_INIT_BOOL(&((p)->LC_VD_ENABLE)); \
  LC_INIT_DataType_SAFEBOOL(&((p)->LC_VD_ESTOPINPUT)); \
  LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ESPE(&((p)->LC_VD_LOGICALS_SAFETY_PLCOPEN_SF_ESPE1)); \
  LC_INIT_DataType_SAFEBOOL(&((p)->LC_VD_LIGHTCURTAININPUT)); \
  (p)->LC_VD_SAFETRUE = LC_EL_true; \
  LC_INIT_BOOL(&((p)->LC_VD_RESET)); \
  LC_INIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL(&((p)->LC_VD_LOGICALS_SAFETY_PLCOPEN_SF_OUTCONTROL1)); \
  LC_INIT_BOOL(&((p)->LC_VD_MOTORLOGIC)); \
  LC_INIT_DataType_SAFEBOOL(&((p)->LC_VD_MOTOROUTPUT)); \

#define LC_INIT_Program_ESTOPDEMO(p) \
{ \
  LC_INIT_NONDMA_Program_ESTOPDEMO(p) \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_Program_ESTOPDEMO(p,RF) \
  LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_EMERGENCYSTOP(&((p)->LC_VD_LOGICALS_SAFETY_PLCOPEN_SF_EMERGENCYSTOP1),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_ENABLE),RF); \
  LC_WINIT_DataType_SAFEBOOL(&((p)->LC_VD_ESTOPINPUT),RF); \
  LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_ESPE(&((p)->LC_VD_LOGICALS_SAFETY_PLCOPEN_SF_ESPE1),0); \
  LC_WINIT_DataType_SAFEBOOL(&((p)->LC_VD_LIGHTCURTAININPUT),RF); \
  if (LC_WINIT_IS_NOT_RETAINED(RF)) (p)->LC_VD_SAFETRUE = LC_EL_true; \
  LC_WINIT_BOOL(&((p)->LC_VD_RESET),RF); \
  LC_WINIT_FunctionBlock_SAFETYx2EPLCOPENx2ESF_OUTCONTROL(&((p)->LC_VD_LOGICALS_SAFETY_PLCOPEN_SF_OUTCONTROL1),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_MOTORLOGIC),RF); \
  LC_WINIT_DataType_SAFEBOOL(&((p)->LC_VD_MOTOROUTPUT),RF); \

#define LC_WINIT_Program_ESTOPDEMO(p,RF) \
{ \
  LC_WINIT_NONDMA_Program_ESTOPDEMO(p,RF) \
}

/*                            Prototype                        */
void  lcpu___ESTOPDEMO(LC_TD_Program_ESTOPDEMO* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
