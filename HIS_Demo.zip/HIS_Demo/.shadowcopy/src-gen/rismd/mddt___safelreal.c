#include <RISMD.h>
#include <lcdt___safelreal.h>

static char const lcmd_type_name_SAFELREAL[] RISMD_ATTRIBUTES = "SAFELREAL";
extern RISMDSimpleNumType const risMdType_LREAL;
RISMDDerivedType const lcmd_type_SAFELREAL RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFELREAL, &risMdType_LREAL);
