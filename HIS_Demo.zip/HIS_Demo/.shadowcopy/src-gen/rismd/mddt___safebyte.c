#include <RISMD.h>
#include <lcdt___safebyte.h>

static char const lcmd_type_name_SAFEBYTE[] RISMD_ATTRIBUTES = "SAFEBYTE";
extern RISMDSimpleNumType const risMdType_BYTE;
RISMDDerivedType const lcmd_type_SAFEBYTE RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEBYTE, &risMdType_BYTE);
