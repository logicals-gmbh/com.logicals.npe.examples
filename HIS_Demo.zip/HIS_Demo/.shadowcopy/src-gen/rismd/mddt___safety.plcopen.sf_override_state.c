#include <RISMD.h>
#include <lcdt___safety.plcopen.sf_override_state.h>

static char const lcmd_type_name_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE[] RISMD_ATTRIBUTES = "SAFETY.PLCOPEN.SF_OVERRIDE_STATE";
extern RISMDSimpleNumType const risMdType_UINT;
RISMDDerivedType const lcmd_type_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFETYx2EPLCOPENx2ESF_OVERRIDE_STATE, &risMdType_UINT);
