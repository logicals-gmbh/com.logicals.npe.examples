#include <RISMD.h>
#include <lcdt___safeuint.h>

static char const lcmd_type_name_SAFEUINT[] RISMD_ATTRIBUTES = "SAFEUINT";
extern RISMDSimpleNumType const risMdType_UINT;
RISMDDerivedType const lcmd_type_SAFEUINT RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEUINT, &risMdType_UINT);
