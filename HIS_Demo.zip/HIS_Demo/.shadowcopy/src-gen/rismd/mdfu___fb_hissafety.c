#include <RISMD.h>
#include <lcfu___fb_hissafety.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_FB_HISSAFETY_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_FB_HISSAFETY_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_HISSAFETY_ENO, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDSimpleNumType const risMdType_WORD;
static char const lcmd_var_name_FB_HISSAFETY_EQUIVALENTDIAG[] RISMD_ATTRIBUTES = "EquivalentDiag";
static RISMDInterfaceVariable const lcmd_var_FB_HISSAFETY_EQUIVALENTDIAG RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_HISSAFETY_EQUIVALENTDIAG, &risMdType_WORD, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_EQUIVALENTDIAG), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_HISSAFETY_ERROR[] RISMD_ATTRIBUTES = "Error";
static RISMDInterfaceVariable const lcmd_var_FB_HISSAFETY_ERROR RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_HISSAFETY_ERROR, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_ERROR), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_HISSAFETY_ESTOPDIAG[] RISMD_ATTRIBUTES = "EStopDiag";
static RISMDInterfaceVariable const lcmd_var_FB_HISSAFETY_ESTOPDIAG RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_HISSAFETY_ESTOPDIAG, &risMdType_WORD, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_ESTOPDIAG), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDPOUType const lcmd_type_SAFETYx2EPLCOPENx2ESF_EMERGENCYSTOP;
static char const lcmd_var_name_FB_HISSAFETY_FBEMERGENCYSTOP[] RISMD_ATTRIBUTES = "fbEmergencyStop";
static RISMDStdVariable const lcmd_var_FB_HISSAFETY_FBEMERGENCYSTOP RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_HISSAFETY_FBEMERGENCYSTOP, &lcmd_type_SAFETYx2EPLCOPENx2ESF_EMERGENCYSTOP, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_FBEMERGENCYSTOP));

extern RISMDPOUType const lcmd_type_SAFETYx2EPLCOPENx2ESF_EQUIVALENT;
static char const lcmd_var_name_FB_HISSAFETY_FBEQUIVALENT[] RISMD_ATTRIBUTES = "fbEquivalent";
static RISMDStdVariable const lcmd_var_FB_HISSAFETY_FBEQUIVALENT RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_HISSAFETY_FBEQUIVALENT, &lcmd_type_SAFETYx2EPLCOPENx2ESF_EQUIVALENT, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_FBEQUIVALENT));

static char const lcmd_var_name_FB_HISSAFETY_RESET[] RISMD_ATTRIBUTES = "Reset";
static RISMDInterfaceVariable const lcmd_var_FB_HISSAFETY_RESET RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_HISSAFETY_RESET, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_RESET), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_HISSAFETY_RESETREQUEST[] RISMD_ATTRIBUTES = "ResetRequest";
static RISMDInterfaceVariable const lcmd_var_FB_HISSAFETY_RESETREQUEST RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_HISSAFETY_RESETREQUEST, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_RESETREQUEST), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_HISSAFETY_SAFETYDEMAND[] RISMD_ATTRIBUTES = "SafetyDemand";
static RISMDInterfaceVariable const lcmd_var_FB_HISSAFETY_SAFETYDEMAND RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_HISSAFETY_SAFETYDEMAND, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_SAFETYDEMAND), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDDerivedType const lcmd_type_SAFEBOOL;
static char const lcmd_var_name_FB_HISSAFETY_S_ESTOPA[] RISMD_ATTRIBUTES = "S_EStopA";
static RISMDInterfaceVariable const lcmd_var_FB_HISSAFETY_S_ESTOPA RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_HISSAFETY_S_ESTOPA, &lcmd_type_SAFEBOOL, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_S_ESTOPA), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_HISSAFETY_S_ESTOPB[] RISMD_ATTRIBUTES = "S_EStopB";
static RISMDInterfaceVariable const lcmd_var_FB_HISSAFETY_S_ESTOPB RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_HISSAFETY_S_ESTOPB, &lcmd_type_SAFEBOOL, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_S_ESTOPB), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_HISSAFETY_S_PERMIT[] RISMD_ATTRIBUTES = "S_Permit";
static RISMDInterfaceVariable const lcmd_var_FB_HISSAFETY_S_PERMIT RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_HISSAFETY_S_PERMIT, &lcmd_type_SAFEBOOL, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_S_PERMIT), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_HISSAFETY_S_RESETDISABLED[] RISMD_ATTRIBUTES = "S_ResetDisabled";
static RISMDStorageClassAttr const lcmd_attr_FB_HISSAFETY_S_RESETDISABLED_StorageClassAttr RISMD_ATTRIBUTES = INIT_RISMDStorageClassAttr(RISMD_STORAGE_CLASS_CONST);
static RISMDReference const lcmd_attr_list_FB_HISSAFETY_S_RESETDISABLED[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_FB_HISSAFETY_S_RESETDISABLED_StorageClassAttr),
};
static RISMDStdAttrVariable const lcmd_var_FB_HISSAFETY_S_RESETDISABLED RISMD_ATTRIBUTES =
INIT_RISMDStdAttrVariable(lcmd_var_name_FB_HISSAFETY_S_RESETDISABLED, &lcmd_type_SAFEBOOL, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD_S_RESETDISABLED),1,lcmd_attr_list_FB_HISSAFETY_S_RESETDISABLED);

static char const lcmd_var_name_FB_HISSAFETY___11_OR[] RISMD_ATTRIBUTES = "__11_OR";
static RISMDStdVariable const lcmd_var_FB_HISSAFETY___11_OR RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_HISSAFETY___11_OR, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_HISSAFETY,LC_VD___11_OR));

static RISMDReference const lcmd_var_list_FB_HISSAFETY[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_ENO),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_EQUIVALENTDIAG),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_ERROR),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_ESTOPDIAG),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_FBEMERGENCYSTOP),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_FBEQUIVALENT),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_RESET),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_RESETREQUEST),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_SAFETYDEMAND),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_S_ESTOPA),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_S_ESTOPB),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_S_PERMIT),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY_S_RESETDISABLED),
  INIT_RISMDReference(&lcmd_var_FB_HISSAFETY___11_OR),
};

static char const lcmd_type_name_FB_HISSAFETY[] RISMD_ATTRIBUTES = "FB_HISSAFETY";
RISMDPOUType const lcmd_type_FB_HISSAFETY RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_FB_HISSAFETY, sizeof(LC_TD_FunctionBlock_FB_HISSAFETY), 14, lcmd_var_list_FB_HISSAFETY);
