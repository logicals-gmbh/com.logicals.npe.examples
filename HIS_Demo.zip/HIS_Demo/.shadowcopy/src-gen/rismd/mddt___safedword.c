#include <RISMD.h>
#include <lcdt___safedword.h>

static char const lcmd_type_name_SAFEDWORD[] RISMD_ATTRIBUTES = "SAFEDWORD";
extern RISMDSimpleNumType const risMdType_DWORD;
RISMDDerivedType const lcmd_type_SAFEDWORD RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEDWORD, &risMdType_DWORD);
