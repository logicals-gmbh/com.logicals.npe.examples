#include <RISMD.h>
#include <lcdt___safelint.h>

static char const lcmd_type_name_SAFELINT[] RISMD_ATTRIBUTES = "SAFELINT";
extern RISMDSimpleNumType const risMdType_LINT;
RISMDDerivedType const lcmd_type_SAFELINT RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFELINT, &risMdType_LINT);
