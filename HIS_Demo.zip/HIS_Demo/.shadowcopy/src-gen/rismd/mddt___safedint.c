#include <RISMD.h>
#include <lcdt___safedint.h>

static char const lcmd_type_name_SAFEDINT[] RISMD_ATTRIBUTES = "SAFEDINT";
extern RISMDSimpleNumType const risMdType_DINT;
RISMDDerivedType const lcmd_type_SAFEDINT RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEDINT, &risMdType_DINT);
