#include <RISMD.h>
#include <lcdt___safebool.h>

static char const lcmd_type_name_SAFEBOOL[] RISMD_ATTRIBUTES = "SAFEBOOL";
extern RISMDSimpleNumType const risMdType_BOOL;
RISMDDerivedType const lcmd_type_SAFEBOOL RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEBOOL, &risMdType_BOOL);
