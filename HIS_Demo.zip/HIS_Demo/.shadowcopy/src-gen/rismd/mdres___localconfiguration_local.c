#include <RISMD.h>
#include <LC3Globals_MD.h>
#include <LC3GlobalsDMA_MD.h>

extern RISMDSimpleNumType const risMdType_BOOL;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_BUTTON1INDICATOR[] RISMD_ATTRIBUTES = "Button1Indicator";
static char const lcmd_attr_val_LOCAL_BUTTON1INDICATOR_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_BUTTON1INDICATOR_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_BUTTON1INDICATOR_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_BUTTON1INDICATOR[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_BUTTON1INDICATOR_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_BUTTON1INDICATOR RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_BUTTON1INDICATOR, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON1INDICATOR), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_BUTTON1INDICATOR);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_BUTTON1INPUT[] RISMD_ATTRIBUTES = "Button1Input";
static char const lcmd_attr_val_LOCAL_BUTTON1INPUT_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_BUTTON1INPUT_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_BUTTON1INPUT_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_BUTTON1INPUT[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_BUTTON1INPUT_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_BUTTON1INPUT RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_BUTTON1INPUT, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON1INPUT), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_BUTTON1INPUT);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_BUTTON2INDICATOR[] RISMD_ATTRIBUTES = "Button2Indicator";
static char const lcmd_attr_val_LOCAL_BUTTON2INDICATOR_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.1";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_BUTTON2INDICATOR_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_BUTTON2INDICATOR_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_BUTTON2INDICATOR[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_BUTTON2INDICATOR_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_BUTTON2INDICATOR RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_BUTTON2INDICATOR, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON2INDICATOR), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_BUTTON2INDICATOR);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_BUTTON2INPUT[] RISMD_ATTRIBUTES = "Button2Input";
static char const lcmd_attr_val_LOCAL_BUTTON2INPUT_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.1";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_BUTTON2INPUT_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_BUTTON2INPUT_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_BUTTON2INPUT[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_BUTTON2INPUT_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_BUTTON2INPUT RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_BUTTON2INPUT, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON2INPUT), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_BUTTON2INPUT);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_BUTTON3INDICATOR[] RISMD_ATTRIBUTES = "Button3Indicator";
static char const lcmd_attr_val_LOCAL_BUTTON3INDICATOR_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.2";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_BUTTON3INDICATOR_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_BUTTON3INDICATOR_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_BUTTON3INDICATOR[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_BUTTON3INDICATOR_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_BUTTON3INDICATOR RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_BUTTON3INDICATOR, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON3INDICATOR), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_BUTTON3INDICATOR);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_BUTTON3INPUT[] RISMD_ATTRIBUTES = "Button3Input";
static char const lcmd_attr_val_LOCAL_BUTTON3INPUT_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.2";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_BUTTON3INPUT_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_BUTTON3INPUT_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_BUTTON3INPUT[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_BUTTON3INPUT_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_BUTTON3INPUT RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_BUTTON3INPUT, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON3INPUT), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_BUTTON3INPUT);

extern RISMDDerivedType const lcmd_type_SAFEBOOL;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_DUMMY1[] RISMD_ATTRIBUTES = "dummy1";
static char const lcmd_attr_val_LOCAL_DUMMY1_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX2.1.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_DUMMY1_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_DUMMY1_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_DUMMY1[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_DUMMY1_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_DUMMY1 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_DUMMY1, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_DUMMY1), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_DUMMY1);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_DUMMY2[] RISMD_ATTRIBUTES = "dummy2";
static char const lcmd_attr_val_LOCAL_DUMMY2_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX2.2.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_DUMMY2_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_DUMMY2_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_DUMMY2[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_DUMMY2_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_DUMMY2 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_DUMMY2, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_DUMMY2), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_DUMMY2);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_ESTOP[] RISMD_ATTRIBUTES = "EStop";
static char const lcmd_attr_val_LOCAL_ESTOP_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX2.3.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_ESTOP_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_ESTOP_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_ESTOP[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_ESTOP_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_ESTOP RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_ESTOP, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_ESTOP), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_ESTOP);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_I01[] RISMD_ATTRIBUTES = "I01";
static char const lcmd_attr_val_LOCAL_I01_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.6.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_I01_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_I01_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_I01[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_I01_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_I01 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_I01, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_I01), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_I01);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_I02[] RISMD_ATTRIBUTES = "I02";
static char const lcmd_attr_val_LOCAL_I02_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.6.1";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_I02_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_I02_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_I02[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_I02_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_I02 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_I02, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_I02), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_I02);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_I03[] RISMD_ATTRIBUTES = "I03";
static char const lcmd_attr_val_LOCAL_I03_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.6.2";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_I03_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_I03_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_I03[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_I03_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_I03 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_I03, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_I03), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_I03);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_I04[] RISMD_ATTRIBUTES = "I04";
static char const lcmd_attr_val_LOCAL_I04_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.6.3";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_I04_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_I04_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_I04[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_I04_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_I04 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_I04, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_I04), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_I04);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_I11[] RISMD_ATTRIBUTES = "I11";
static char const lcmd_attr_val_LOCAL_I11_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_I11_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_I11_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_I11[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_I11_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_I11 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_I11, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_I11), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_I11);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_I12[] RISMD_ATTRIBUTES = "I12";
static char const lcmd_attr_val_LOCAL_I12_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.1";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_I12_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_I12_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_I12[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_I12_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_I12 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_I12, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_I12), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_I12);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_I13[] RISMD_ATTRIBUTES = "I13";
static char const lcmd_attr_val_LOCAL_I13_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.2";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_I13_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_I13_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_I13[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_I13_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_I13 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_I13, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_I13), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_I13);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_I14[] RISMD_ATTRIBUTES = "I14";
static char const lcmd_attr_val_LOCAL_I14_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.3";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_I14_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_I14_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_I14[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_I14_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_I14 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_I14, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_I14), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_I14);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_I15[] RISMD_ATTRIBUTES = "I15";
static char const lcmd_attr_val_LOCAL_I15_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.4";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_I15_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_I15_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_I15[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_I15_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_I15 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_I15, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_I15), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_I15);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_I16[] RISMD_ATTRIBUTES = "I16";
static char const lcmd_attr_val_LOCAL_I16_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.5";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_I16_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_I16_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_I16[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_I16_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_I16 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_I16, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_I16), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_I16);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_I17[] RISMD_ATTRIBUTES = "I17";
static char const lcmd_attr_val_LOCAL_I17_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.6";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_I17_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_I17_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_I17[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_I17_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_I17 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_I17, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_I17), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_I17);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_I18[] RISMD_ATTRIBUTES = "I18";
static char const lcmd_attr_val_LOCAL_I18_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.7";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_I18_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_I18_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_I18[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_I18_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_I18 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_I18, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_I18), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_I18);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_O01[] RISMD_ATTRIBUTES = "O01";
static char const lcmd_attr_val_LOCAL_O01_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.6.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_O01_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_O01_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_O01[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_O01_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_O01 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_O01, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_O01), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_O01);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_O02[] RISMD_ATTRIBUTES = "O02";
static char const lcmd_attr_val_LOCAL_O02_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.6.1";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_O02_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_O02_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_O02[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_O02_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_O02 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_O02, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_O02), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_O02);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_O03[] RISMD_ATTRIBUTES = "O03";
static char const lcmd_attr_val_LOCAL_O03_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.6.2";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_O03_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_O03_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_O03[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_O03_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_O03 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_O03, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_O03), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_O03);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_O04[] RISMD_ATTRIBUTES = "O04";
static char const lcmd_attr_val_LOCAL_O04_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.6.3";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_O04_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_O04_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_O04[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_O04_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_O04 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_O04, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_O04), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_O04);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_O11[] RISMD_ATTRIBUTES = "O11";
static char const lcmd_attr_val_LOCAL_O11_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_O11_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_O11_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_O11[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_O11_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_O11 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_O11, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_O11), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_O11);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_O12[] RISMD_ATTRIBUTES = "O12";
static char const lcmd_attr_val_LOCAL_O12_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.1";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_O12_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_O12_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_O12[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_O12_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_O12 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_O12, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_O12), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_O12);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_O13[] RISMD_ATTRIBUTES = "O13";
static char const lcmd_attr_val_LOCAL_O13_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.2";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_O13_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_O13_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_O13[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_O13_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_O13 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_O13, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_O13), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_O13);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_O14[] RISMD_ATTRIBUTES = "O14";
static char const lcmd_attr_val_LOCAL_O14_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.3";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_O14_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_O14_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_O14[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_O14_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_O14 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_O14, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_O14), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_O14);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_O15[] RISMD_ATTRIBUTES = "O15";
static char const lcmd_attr_val_LOCAL_O15_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.4";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_O15_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_O15_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_O15[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_O15_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_O15 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_O15, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_O15), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_O15);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_O16[] RISMD_ATTRIBUTES = "O16";
static char const lcmd_attr_val_LOCAL_O16_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.5";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_O16_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_O16_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_O16[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_O16_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_O16 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_O16, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_O16), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_O16);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_O17[] RISMD_ATTRIBUTES = "O17";
static char const lcmd_attr_val_LOCAL_O17_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.6";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_O17_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_O17_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_O17[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_O17_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_O17 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_O17, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_O17), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_O17);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_O18[] RISMD_ATTRIBUTES = "O18";
static char const lcmd_attr_val_LOCAL_O18_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.7";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_O18_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_O18_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_O18[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_O18_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_O18 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_O18, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_O18), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_O18);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SI01[] RISMD_ATTRIBUTES = "SI01";
static char const lcmd_attr_val_LOCAL_SI01_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX2.1.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SI01_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SI01_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SI01[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SI01_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SI01 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SI01, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_SI01), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SI01);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SI02[] RISMD_ATTRIBUTES = "SI02";
static char const lcmd_attr_val_LOCAL_SI02_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX2.1.0.1";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SI02_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SI02_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SI02[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SI02_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SI02 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SI02, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_SI02), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SI02);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SI11[] RISMD_ATTRIBUTES = "SI11";
static char const lcmd_attr_val_LOCAL_SI11_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX2.3.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SI11_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SI11_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SI11[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SI11_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SI11 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SI11, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_SI11), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SI11);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SI12[] RISMD_ATTRIBUTES = "SI12";
static char const lcmd_attr_val_LOCAL_SI12_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX2.3.0.1";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SI12_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SI12_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SI12[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SI12_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SI12 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SI12, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_SI12), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SI12);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SI13[] RISMD_ATTRIBUTES = "SI13";
static char const lcmd_attr_val_LOCAL_SI13_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX2.3.0.2";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SI13_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SI13_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SI13[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SI13_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SI13 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SI13, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_SI13), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SI13);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SI14[] RISMD_ATTRIBUTES = "SI14";
static char const lcmd_attr_val_LOCAL_SI14_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX2.3.0.3";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SI14_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SI14_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SI14[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SI14_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SI14 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SI14, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_SI14), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SI14);

extern RISMDSimpleNumType const risMdType_BYTE;
RISMDArrayType const lcmd_type_LOCAL_SLAVE1PARA_ARR RISMD_ATTRIBUTES = INIT_RISMDArrayType(0,15,sizeof(LC_TD_BYTE),&risMdType_BYTE);
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SLAVE1PARA[] RISMD_ATTRIBUTES = "Slave1Para";
static char const lcmd_attr_val_LOCAL_SLAVE1PARA_HWAddrAttr[] RISMD_ATTRIBUTES = "%MW2.1.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SLAVE1PARA_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SLAVE1PARA_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SLAVE1PARA[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SLAVE1PARA_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SLAVE1PARA RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SLAVE1PARA, &lcmd_type_LOCAL_SLAVE1PARA_ARR, offsetof(LC_TD_LC3_GVType,LC_VD_SLAVE1PARA), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SLAVE1PARA);

RISMDArrayType const lcmd_type_LOCAL_SLAVE2PARA_ARR RISMD_ATTRIBUTES = INIT_RISMDArrayType(0,7,sizeof(LC_TD_BYTE),&risMdType_BYTE);
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SLAVE2PARA[] RISMD_ATTRIBUTES = "Slave2Para";
static char const lcmd_attr_val_LOCAL_SLAVE2PARA_HWAddrAttr[] RISMD_ATTRIBUTES = "%MW2.2.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SLAVE2PARA_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SLAVE2PARA_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SLAVE2PARA[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SLAVE2PARA_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SLAVE2PARA RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SLAVE2PARA, &lcmd_type_LOCAL_SLAVE2PARA_ARR, offsetof(LC_TD_LC3_GVType,LC_VD_SLAVE2PARA), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SLAVE2PARA);

RISMDArrayType const lcmd_type_LOCAL_SLAVE3PARA_ARR RISMD_ATTRIBUTES = INIT_RISMDArrayType(0,7,sizeof(LC_TD_BYTE),&risMdType_BYTE);
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SLAVE3PARA[] RISMD_ATTRIBUTES = "Slave3Para";
static char const lcmd_attr_val_LOCAL_SLAVE3PARA_HWAddrAttr[] RISMD_ATTRIBUTES = "%MW2.3.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SLAVE3PARA_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SLAVE3PARA_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SLAVE3PARA[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SLAVE3PARA_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SLAVE3PARA RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SLAVE3PARA, &lcmd_type_LOCAL_SLAVE3PARA_ARR, offsetof(LC_TD_LC3_GVType,LC_VD_SLAVE3PARA), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SLAVE3PARA);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SO01[] RISMD_ATTRIBUTES = "SO01";
static char const lcmd_attr_val_LOCAL_SO01_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX2.1.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SO01_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SO01_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SO01[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SO01_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SO01 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SO01, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_SO01), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SO01);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SO02[] RISMD_ATTRIBUTES = "SO02";
static char const lcmd_attr_val_LOCAL_SO02_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX2.1.0.1";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SO02_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SO02_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SO02[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SO02_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SO02 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SO02, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_SO02), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SO02);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SO11[] RISMD_ATTRIBUTES = "SO11";
static char const lcmd_attr_val_LOCAL_SO11_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX2.2.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SO11_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SO11_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SO11[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SO11_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SO11 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SO11, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_SO11), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SO11);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SO12[] RISMD_ATTRIBUTES = "SO12";
static char const lcmd_attr_val_LOCAL_SO12_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX2.2.0.1";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SO12_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SO12_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SO12[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SO12_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SO12 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SO12, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_SO12), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SO12);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SO13[] RISMD_ATTRIBUTES = "SO13";
static char const lcmd_attr_val_LOCAL_SO13_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX2.2.0.2";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SO13_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SO13_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SO13[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SO13_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SO13 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SO13, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_SO13), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SO13);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_SO14[] RISMD_ATTRIBUTES = "SO14";
static char const lcmd_attr_val_LOCAL_SO14_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX2.2.0.3";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_SO14_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_SO14_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_SO14[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_SO14_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_SO14 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_SO14, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_SO14), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_SO14);

extern RISMDDerivedType const lcmd_type_SAFEDWORD;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_ACTIVESAFETYDEMANDMASK[] RISMD_ATTRIBUTES = "S_ActiveSafetyDemandMask";
RISMDStdGV const lcmd_var_gv_S_ACTIVESAFETYDEMANDMASK RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_ACTIVESAFETYDEMANDMASK, &lcmd_type_SAFEDWORD, offsetof(LC_TD_LC3_GVType,LC_VD_S_ACTIVESAFETYDEMANDMASK), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_AIRSUPPLYREADY[] RISMD_ATTRIBUTES = "S_AirSupplyReady";
RISMDStdGV const lcmd_var_gv_S_AIRSUPPLYREADY RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_AIRSUPPLYREADY, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_S_AIRSUPPLYREADY), &lcmd_entrypoint_gvinstance);

extern RISMDDerivedType const lcmd_type_SAFEINT;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_AMBIENTTEMPERATUREACTUAL_DC[] RISMD_ATTRIBUTES = "S_AmbientTemperatureActual_dC";
RISMDStdGV const lcmd_var_gv_S_AMBIENTTEMPERATUREACTUAL_DC RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_AMBIENTTEMPERATUREACTUAL_DC, &lcmd_type_SAFEINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_AMBIENTTEMPERATUREACTUAL_DC), &lcmd_entrypoint_gvinstance);

extern RISMDDerivedType const lcmd_type_SAFEDINT;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_CARTONTRACKINGPOSITION_MM[] RISMD_ATTRIBUTES = "S_CartonTrackingPosition_mm";
RISMDStdGV const lcmd_var_gv_S_CARTONTRACKINGPOSITION_MM RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_CARTONTRACKINGPOSITION_MM, &lcmd_type_SAFEDINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_CARTONTRACKINGPOSITION_MM), &lcmd_entrypoint_gvinstance);

extern RISMDDerivedType const lcmd_type_SAFEUDINT;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_COMPLETEDCARTONCOUNT[] RISMD_ATTRIBUTES = "S_CompletedCartonCount";
RISMDStdGV const lcmd_var_gv_S_COMPLETEDCARTONCOUNT RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_COMPLETEDCARTONCOUNT, &lcmd_type_SAFEUDINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_COMPLETEDCARTONCOUNT), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_CONFIRMEDSAFETYDEMANDMASK[] RISMD_ATTRIBUTES = "S_ConfirmedSafetyDemandMask";
RISMDStdGV const lcmd_var_gv_S_CONFIRMEDSAFETYDEMANDMASK RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_CONFIRMEDSAFETYDEMANDMASK, &lcmd_type_SAFEDWORD, offsetof(LC_TD_LC3_GVType,LC_VD_S_CONFIRMEDSAFETYDEMANDMASK), &lcmd_entrypoint_gvinstance);

extern RISMDDerivedType const lcmd_type_SAFEWORD;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_DRIVEDIAGNOSTICCODE[] RISMD_ATTRIBUTES = "S_DriveDiagnosticCode";
RISMDStdGV const lcmd_var_gv_S_DRIVEDIAGNOSTICCODE RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_DRIVEDIAGNOSTICCODE, &lcmd_type_SAFEWORD, offsetof(LC_TD_LC3_GVType,LC_VD_S_DRIVEDIAGNOSTICCODE), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_DRIVEENABLEMASK[] RISMD_ATTRIBUTES = "S_DriveEnableMask";
RISMDStdGV const lcmd_var_gv_S_DRIVEENABLEMASK RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_DRIVEENABLEMASK, &lcmd_type_SAFEDWORD, offsetof(LC_TD_LC3_GVType,LC_VD_S_DRIVEENABLEMASK), &lcmd_entrypoint_gvinstance);

extern RISMDDerivedType const lcmd_type_SAFEUSINT;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_DRIVEFEEDBACKCHANNELCOUNT[] RISMD_ATTRIBUTES = "S_DriveFeedbackChannelCount";
RISMDStdGV const lcmd_var_gv_S_DRIVEFEEDBACKCHANNELCOUNT RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_DRIVEFEEDBACKCHANNELCOUNT, &lcmd_type_SAFEUSINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_DRIVEFEEDBACKCHANNELCOUNT), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_ESTOPDEMANDCOUNT[] RISMD_ATTRIBUTES = "S_EStopDemandCount";
RISMDStdGV const lcmd_var_gv_S_ESTOPDEMANDCOUNT RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_ESTOPDEMANDCOUNT, &lcmd_type_SAFEUDINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_ESTOPDEMANDCOUNT), &lcmd_entrypoint_gvinstance);

extern RISMDDerivedType const lcmd_type_SAFESINT;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_FILMFEEDMOTIONDIRECTION[] RISMD_ATTRIBUTES = "S_FilmFeedMotionDirection";
RISMDStdGV const lcmd_var_gv_S_FILMFEEDMOTIONDIRECTION RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_FILMFEEDMOTIONDIRECTION, &lcmd_type_SAFESINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_FILMFEEDMOTIONDIRECTION), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_GUARDCHANNELCOUNT[] RISMD_ATTRIBUTES = "S_GuardChannelCount";
RISMDStdGV const lcmd_var_gv_S_GUARDCHANNELCOUNT RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_GUARDCHANNELCOUNT, &lcmd_type_SAFEUSINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_GUARDCHANNELCOUNT), &lcmd_entrypoint_gvinstance);

extern RISMDDerivedType const lcmd_type_SAFEBYTE;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_GUARDLOCKSTATUS[] RISMD_ATTRIBUTES = "S_GuardLockStatus";
RISMDStdGV const lcmd_var_gv_S_GUARDLOCKSTATUS RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_GUARDLOCKSTATUS, &lcmd_type_SAFEBYTE, offsetof(LC_TD_LC3_GVType,LC_VD_S_GUARDLOCKSTATUS), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_GUARDMONITORINGMASK[] RISMD_ATTRIBUTES = "S_GuardMonitoringMask";
RISMDStdGV const lcmd_var_gv_S_GUARDMONITORINGMASK RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_GUARDMONITORINGMASK, &lcmd_type_SAFEDWORD, offsetof(LC_TD_LC3_GVType,LC_VD_S_GUARDMONITORINGMASK), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_GUARDOPENINGCOUNT[] RISMD_ATTRIBUTES = "S_GuardOpeningCount";
RISMDStdGV const lcmd_var_gv_S_GUARDOPENINGCOUNT RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_GUARDOPENINGCOUNT, &lcmd_type_SAFEUDINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_GUARDOPENINGCOUNT), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_INFEEDDIAGNOSTICCODE[] RISMD_ATTRIBUTES = "S_InfeedDiagnosticCode";
RISMDStdGV const lcmd_var_gv_S_INFEEDDIAGNOSTICCODE RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_INFEEDDIAGNOSTICCODE, &lcmd_type_SAFEWORD, offsetof(LC_TD_LC3_GVType,LC_VD_S_INFEEDDIAGNOSTICCODE), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_INFEEDGUARDCLOSED[] RISMD_ATTRIBUTES = "S_InfeedGuardClosed";
RISMDStdGV const lcmd_var_gv_S_INFEEDGUARDCLOSED RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_INFEEDGUARDCLOSED, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_S_INFEEDGUARDCLOSED), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_INFEEDMOTIONDIRECTION[] RISMD_ATTRIBUTES = "S_InfeedMotionDirection";
RISMDStdGV const lcmd_var_gv_S_INFEEDMOTIONDIRECTION RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_INFEEDMOTIONDIRECTION, &lcmd_type_SAFESINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_INFEEDMOTIONDIRECTION), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_INFEEDSENSORCOUNT[] RISMD_ATTRIBUTES = "S_InfeedSensorCount";
RISMDStdGV const lcmd_var_gv_S_INFEEDSENSORCOUNT RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_INFEEDSENSORCOUNT, &lcmd_type_SAFEUSINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_INFEEDSENSORCOUNT), &lcmd_entrypoint_gvinstance);

extern RISMDDerivedType const lcmd_type_SAFEUINT;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_INFEEDSPEEDLIMIT_MM_S[] RISMD_ATTRIBUTES = "S_InfeedSpeedLimit_mm_s";
RISMDStdGV const lcmd_var_gv_S_INFEEDSPEEDLIMIT_MM_S RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_INFEEDSPEEDLIMIT_MM_S, &lcmd_type_SAFEUINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_INFEEDSPEEDLIMIT_MM_S), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_INFEEDSTOPPOSITION_MM[] RISMD_ATTRIBUTES = "S_InfeedStopPosition_mm";
RISMDStdGV const lcmd_var_gv_S_INFEEDSTOPPOSITION_MM RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_INFEEDSTOPPOSITION_MM, &lcmd_type_SAFEDINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_INFEEDSTOPPOSITION_MM), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_INFEEDZONESTATUS[] RISMD_ATTRIBUTES = "S_InfeedZoneStatus";
RISMDStdGV const lcmd_var_gv_S_INFEEDZONESTATUS RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_INFEEDZONESTATUS, &lcmd_type_SAFEBYTE, offsetof(LC_TD_LC3_GVType,LC_VD_S_INFEEDZONESTATUS), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_MAXAIRPRESSURE_MBAR[] RISMD_ATTRIBUTES = "S_MaxAirPressure_mbar";
RISMDStdGV const lcmd_var_gv_S_MAXAIRPRESSURE_MBAR RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_MAXAIRPRESSURE_MBAR, &lcmd_type_SAFEUINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_MAXAIRPRESSURE_MBAR), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_MAXSEALINGTEMPERATURE_DC[] RISMD_ATTRIBUTES = "S_MaxSealingTemperature_dC";
RISMDStdGV const lcmd_var_gv_S_MAXSEALINGTEMPERATURE_DC RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_MAXSEALINGTEMPERATURE_DC, &lcmd_type_SAFEINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_MAXSEALINGTEMPERATURE_DC), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_MAXSTOPPINGDISTANCE_MM[] RISMD_ATTRIBUTES = "S_MaxStoppingDistance_mm";
RISMDStdGV const lcmd_var_gv_S_MAXSTOPPINGDISTANCE_MM RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_MAXSTOPPINGDISTANCE_MM, &lcmd_type_SAFEDINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_MAXSTOPPINGDISTANCE_MM), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_MINAIRPRESSURE_MBAR[] RISMD_ATTRIBUTES = "S_MinAirPressure_mbar";
RISMDStdGV const lcmd_var_gv_S_MINAIRPRESSURE_MBAR RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_MINAIRPRESSURE_MBAR, &lcmd_type_SAFEUINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_MINAIRPRESSURE_MBAR), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_MINSEALINGTEMPERATURE_DC[] RISMD_ATTRIBUTES = "S_MinSealingTemperature_dC";
RISMDStdGV const lcmd_var_gv_S_MINSEALINGTEMPERATURE_DC RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_MINSEALINGTEMPERATURE_DC, &lcmd_type_SAFEINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_MINSEALINGTEMPERATURE_DC), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_MOTORCURRENTLIMIT_MA[] RISMD_ATTRIBUTES = "S_MotorCurrentLimit_mA";
RISMDStdGV const lcmd_var_gv_S_MOTORCURRENTLIMIT_MA RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_MOTORCURRENTLIMIT_MA, &lcmd_type_SAFEUINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_MOTORCURRENTLIMIT_MA), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_OPERATINGTIME_S[] RISMD_ATTRIBUTES = "S_OperatingTime_s";
RISMDStdGV const lcmd_var_gv_S_OPERATINGTIME_S RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_OPERATINGTIME_S, &lcmd_type_SAFEUDINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_OPERATINGTIME_S), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_OUTFEEDDIAGNOSTICCODE[] RISMD_ATTRIBUTES = "S_OutfeedDiagnosticCode";
RISMDStdGV const lcmd_var_gv_S_OUTFEEDDIAGNOSTICCODE RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_OUTFEEDDIAGNOSTICCODE, &lcmd_type_SAFEWORD, offsetof(LC_TD_LC3_GVType,LC_VD_S_OUTFEEDDIAGNOSTICCODE), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_OUTFEEDGUARDCLOSED[] RISMD_ATTRIBUTES = "S_OutfeedGuardClosed";
RISMDStdGV const lcmd_var_gv_S_OUTFEEDGUARDCLOSED RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_OUTFEEDGUARDCLOSED, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_S_OUTFEEDGUARDCLOSED), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_OUTFEEDMOTIONDIRECTION[] RISMD_ATTRIBUTES = "S_OutfeedMotionDirection";
RISMDStdGV const lcmd_var_gv_S_OUTFEEDMOTIONDIRECTION RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_OUTFEEDMOTIONDIRECTION, &lcmd_type_SAFESINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_OUTFEEDMOTIONDIRECTION), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_OUTFEEDSENSORCOUNT[] RISMD_ATTRIBUTES = "S_OutfeedSensorCount";
RISMDStdGV const lcmd_var_gv_S_OUTFEEDSENSORCOUNT RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_OUTFEEDSENSORCOUNT, &lcmd_type_SAFEUSINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_OUTFEEDSENSORCOUNT), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_OUTFEEDSPEEDLIMIT_MM_S[] RISMD_ATTRIBUTES = "S_OutfeedSpeedLimit_mm_s";
RISMDStdGV const lcmd_var_gv_S_OUTFEEDSPEEDLIMIT_MM_S RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_OUTFEEDSPEEDLIMIT_MM_S, &lcmd_type_SAFEUINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_OUTFEEDSPEEDLIMIT_MM_S), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_OUTFEEDSTOPPOSITION_MM[] RISMD_ATTRIBUTES = "S_OutfeedStopPosition_mm";
RISMDStdGV const lcmd_var_gv_S_OUTFEEDSTOPPOSITION_MM RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_OUTFEEDSTOPPOSITION_MM, &lcmd_type_SAFEDINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_OUTFEEDSTOPPOSITION_MM), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_OUTFEEDZONESTATUS[] RISMD_ATTRIBUTES = "S_OutfeedZoneStatus";
RISMDStdGV const lcmd_var_gv_S_OUTFEEDZONESTATUS RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_OUTFEEDZONESTATUS, &lcmd_type_SAFEBYTE, offsetof(LC_TD_LC3_GVType,LC_VD_S_OUTFEEDZONESTATUS), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_REJECTEDCARTONCOUNT[] RISMD_ATTRIBUTES = "S_RejectedCartonCount";
RISMDStdGV const lcmd_var_gv_S_REJECTEDCARTONCOUNT RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_REJECTEDCARTONCOUNT, &lcmd_type_SAFEUDINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_REJECTEDCARTONCOUNT), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_REJECTGATEMOTIONDIRECTION[] RISMD_ATTRIBUTES = "S_RejectGateMotionDirection";
RISMDStdGV const lcmd_var_gv_S_REJECTGATEMOTIONDIRECTION RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_REJECTGATEMOTIONDIRECTION, &lcmd_type_SAFESINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_REJECTGATEMOTIONDIRECTION), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_SAFEDRIVESTATUS[] RISMD_ATTRIBUTES = "S_SafeDriveStatus";
RISMDStdGV const lcmd_var_gv_S_SAFEDRIVESTATUS RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_SAFEDRIVESTATUS, &lcmd_type_SAFEBYTE, offsetof(LC_TD_LC3_GVType,LC_VD_S_SAFEDRIVESTATUS), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_SAFETYBUSDIAGNOSTICCODE[] RISMD_ATTRIBUTES = "S_SafetyBusDiagnosticCode";
RISMDStdGV const lcmd_var_gv_S_SAFETYBUSDIAGNOSTICCODE RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_SAFETYBUSDIAGNOSTICCODE, &lcmd_type_SAFEWORD, offsetof(LC_TD_LC3_GVType,LC_VD_S_SAFETYBUSDIAGNOSTICCODE), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_SEALINGDIAGNOSTICCODE[] RISMD_ATTRIBUTES = "S_SealingDiagnosticCode";
RISMDStdGV const lcmd_var_gv_S_SEALINGDIAGNOSTICCODE RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_SEALINGDIAGNOSTICCODE, &lcmd_type_SAFEWORD, offsetof(LC_TD_LC3_GVType,LC_VD_S_SEALINGDIAGNOSTICCODE), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_SEALINGGUARDCLOSED[] RISMD_ATTRIBUTES = "S_SealingGuardClosed";
RISMDStdGV const lcmd_var_gv_S_SEALINGGUARDCLOSED RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_SEALINGGUARDCLOSED, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_S_SEALINGGUARDCLOSED), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_SEALINGMOTIONDIRECTION[] RISMD_ATTRIBUTES = "S_SealingMotionDirection";
RISMDStdGV const lcmd_var_gv_S_SEALINGMOTIONDIRECTION RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_SEALINGMOTIONDIRECTION, &lcmd_type_SAFESINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_SEALINGMOTIONDIRECTION), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_SEALINGSENSORCOUNT[] RISMD_ATTRIBUTES = "S_SealingSensorCount";
RISMDStdGV const lcmd_var_gv_S_SEALINGSENSORCOUNT RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_SEALINGSENSORCOUNT, &lcmd_type_SAFEUSINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_SEALINGSENSORCOUNT), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_SEALINGSTOPPOSITION_MM[] RISMD_ATTRIBUTES = "S_SealingStopPosition_mm";
RISMDStdGV const lcmd_var_gv_S_SEALINGSTOPPOSITION_MM RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_SEALINGSTOPPOSITION_MM, &lcmd_type_SAFEDINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_SEALINGSTOPPOSITION_MM), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_SEALINGTEMPERATUREACTUAL_DC[] RISMD_ATTRIBUTES = "S_SealingTemperatureActual_dC";
RISMDStdGV const lcmd_var_gv_S_SEALINGTEMPERATUREACTUAL_DC RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_SEALINGTEMPERATUREACTUAL_DC, &lcmd_type_SAFEINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_SEALINGTEMPERATUREACTUAL_DC), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_SEALINGTEMPERATURELIMIT_DC[] RISMD_ATTRIBUTES = "S_SealingTemperatureLimit_dC";
RISMDStdGV const lcmd_var_gv_S_SEALINGTEMPERATURELIMIT_DC RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_SEALINGTEMPERATURELIMIT_DC, &lcmd_type_SAFEINT, offsetof(LC_TD_LC3_GVType,LC_VD_S_SEALINGTEMPERATURELIMIT_DC), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_SEALINGZONESTATUS[] RISMD_ATTRIBUTES = "S_SealingZoneStatus";
RISMDStdGV const lcmd_var_gv_S_SEALINGZONESTATUS RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_SEALINGZONESTATUS, &lcmd_type_SAFEBYTE, offsetof(LC_TD_LC3_GVType,LC_VD_S_SEALINGZONESTATUS), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_SERVICEDOORCLOSED[] RISMD_ATTRIBUTES = "S_ServiceDoorClosed";
RISMDStdGV const lcmd_var_gv_S_SERVICEDOORCLOSED RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_SERVICEDOORCLOSED, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_S_SERVICEDOORCLOSED), &lcmd_entrypoint_gvinstance);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_S_ZONEPERMISSIONMASK[] RISMD_ATTRIBUTES = "S_ZonePermissionMask";
RISMDStdGV const lcmd_var_gv_S_ZONEPERMISSIONMASK RISMD_ATTRIBUTES =
INIT_RISMDStdGV(lcmd_var_name_LOCAL_S_ZONEPERMISSIONMASK, &lcmd_type_SAFEDWORD, offsetof(LC_TD_LC3_GVType,LC_VD_S_ZONEPERMISSIONMASK), &lcmd_entrypoint_gvinstance);

static RISMDReference const lcmd_var_list_gv[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_gv_BUTTON1INDICATOR),
  INIT_RISMDReference(&lcmd_var_gv_BUTTON1INPUT),
  INIT_RISMDReference(&lcmd_var_gv_BUTTON2INDICATOR),
  INIT_RISMDReference(&lcmd_var_gv_BUTTON2INPUT),
  INIT_RISMDReference(&lcmd_var_gv_BUTTON3INDICATOR),
  INIT_RISMDReference(&lcmd_var_gv_BUTTON3INPUT),
  INIT_RISMDReference(&lcmd_var_gv_DUMMY1),
  INIT_RISMDReference(&lcmd_var_gv_DUMMY2),
  INIT_RISMDReference(&lcmd_var_gv_ESTOP),
  INIT_RISMDReference(&lcmd_var_gv_I01),
  INIT_RISMDReference(&lcmd_var_gv_I02),
  INIT_RISMDReference(&lcmd_var_gv_I03),
  INIT_RISMDReference(&lcmd_var_gv_I04),
  INIT_RISMDReference(&lcmd_var_gv_I11),
  INIT_RISMDReference(&lcmd_var_gv_I12),
  INIT_RISMDReference(&lcmd_var_gv_I13),
  INIT_RISMDReference(&lcmd_var_gv_I14),
  INIT_RISMDReference(&lcmd_var_gv_I15),
  INIT_RISMDReference(&lcmd_var_gv_I16),
  INIT_RISMDReference(&lcmd_var_gv_I17),
  INIT_RISMDReference(&lcmd_var_gv_I18),
  INIT_RISMDReference(&lcmd_var_gv_O01),
  INIT_RISMDReference(&lcmd_var_gv_O02),
  INIT_RISMDReference(&lcmd_var_gv_O03),
  INIT_RISMDReference(&lcmd_var_gv_O04),
  INIT_RISMDReference(&lcmd_var_gv_O11),
  INIT_RISMDReference(&lcmd_var_gv_O12),
  INIT_RISMDReference(&lcmd_var_gv_O13),
  INIT_RISMDReference(&lcmd_var_gv_O14),
  INIT_RISMDReference(&lcmd_var_gv_O15),
  INIT_RISMDReference(&lcmd_var_gv_O16),
  INIT_RISMDReference(&lcmd_var_gv_O17),
  INIT_RISMDReference(&lcmd_var_gv_O18),
  INIT_RISMDReference(&lcmd_var_gv_SI01),
  INIT_RISMDReference(&lcmd_var_gv_SI02),
  INIT_RISMDReference(&lcmd_var_gv_SI11),
  INIT_RISMDReference(&lcmd_var_gv_SI12),
  INIT_RISMDReference(&lcmd_var_gv_SI13),
  INIT_RISMDReference(&lcmd_var_gv_SI14),
  INIT_RISMDReference(&lcmd_var_gv_SLAVE1PARA),
  INIT_RISMDReference(&lcmd_var_gv_SLAVE2PARA),
  INIT_RISMDReference(&lcmd_var_gv_SLAVE3PARA),
  INIT_RISMDReference(&lcmd_var_gv_SO01),
  INIT_RISMDReference(&lcmd_var_gv_SO02),
  INIT_RISMDReference(&lcmd_var_gv_SO11),
  INIT_RISMDReference(&lcmd_var_gv_SO12),
  INIT_RISMDReference(&lcmd_var_gv_SO13),
  INIT_RISMDReference(&lcmd_var_gv_SO14),
  INIT_RISMDReference(&lcmd_var_gv_S_ACTIVESAFETYDEMANDMASK),
  INIT_RISMDReference(&lcmd_var_gv_S_AIRSUPPLYREADY),
  INIT_RISMDReference(&lcmd_var_gv_S_AMBIENTTEMPERATUREACTUAL_DC),
  INIT_RISMDReference(&lcmd_var_gv_S_CARTONTRACKINGPOSITION_MM),
  INIT_RISMDReference(&lcmd_var_gv_S_COMPLETEDCARTONCOUNT),
  INIT_RISMDReference(&lcmd_var_gv_S_CONFIRMEDSAFETYDEMANDMASK),
  INIT_RISMDReference(&lcmd_var_gv_S_DRIVEDIAGNOSTICCODE),
  INIT_RISMDReference(&lcmd_var_gv_S_DRIVEENABLEMASK),
  INIT_RISMDReference(&lcmd_var_gv_S_DRIVEFEEDBACKCHANNELCOUNT),
  INIT_RISMDReference(&lcmd_var_gv_S_ESTOPDEMANDCOUNT),
  INIT_RISMDReference(&lcmd_var_gv_S_FILMFEEDMOTIONDIRECTION),
  INIT_RISMDReference(&lcmd_var_gv_S_GUARDCHANNELCOUNT),
  INIT_RISMDReference(&lcmd_var_gv_S_GUARDLOCKSTATUS),
  INIT_RISMDReference(&lcmd_var_gv_S_GUARDMONITORINGMASK),
  INIT_RISMDReference(&lcmd_var_gv_S_GUARDOPENINGCOUNT),
  INIT_RISMDReference(&lcmd_var_gv_S_INFEEDDIAGNOSTICCODE),
  INIT_RISMDReference(&lcmd_var_gv_S_INFEEDGUARDCLOSED),
  INIT_RISMDReference(&lcmd_var_gv_S_INFEEDMOTIONDIRECTION),
  INIT_RISMDReference(&lcmd_var_gv_S_INFEEDSENSORCOUNT),
  INIT_RISMDReference(&lcmd_var_gv_S_INFEEDSPEEDLIMIT_MM_S),
  INIT_RISMDReference(&lcmd_var_gv_S_INFEEDSTOPPOSITION_MM),
  INIT_RISMDReference(&lcmd_var_gv_S_INFEEDZONESTATUS),
  INIT_RISMDReference(&lcmd_var_gv_S_MAXAIRPRESSURE_MBAR),
  INIT_RISMDReference(&lcmd_var_gv_S_MAXSEALINGTEMPERATURE_DC),
  INIT_RISMDReference(&lcmd_var_gv_S_MAXSTOPPINGDISTANCE_MM),
  INIT_RISMDReference(&lcmd_var_gv_S_MINAIRPRESSURE_MBAR),
  INIT_RISMDReference(&lcmd_var_gv_S_MINSEALINGTEMPERATURE_DC),
  INIT_RISMDReference(&lcmd_var_gv_S_MOTORCURRENTLIMIT_MA),
  INIT_RISMDReference(&lcmd_var_gv_S_OPERATINGTIME_S),
  INIT_RISMDReference(&lcmd_var_gv_S_OUTFEEDDIAGNOSTICCODE),
  INIT_RISMDReference(&lcmd_var_gv_S_OUTFEEDGUARDCLOSED),
  INIT_RISMDReference(&lcmd_var_gv_S_OUTFEEDMOTIONDIRECTION),
  INIT_RISMDReference(&lcmd_var_gv_S_OUTFEEDSENSORCOUNT),
  INIT_RISMDReference(&lcmd_var_gv_S_OUTFEEDSPEEDLIMIT_MM_S),
  INIT_RISMDReference(&lcmd_var_gv_S_OUTFEEDSTOPPOSITION_MM),
  INIT_RISMDReference(&lcmd_var_gv_S_OUTFEEDZONESTATUS),
  INIT_RISMDReference(&lcmd_var_gv_S_REJECTEDCARTONCOUNT),
  INIT_RISMDReference(&lcmd_var_gv_S_REJECTGATEMOTIONDIRECTION),
  INIT_RISMDReference(&lcmd_var_gv_S_SAFEDRIVESTATUS),
  INIT_RISMDReference(&lcmd_var_gv_S_SAFETYBUSDIAGNOSTICCODE),
  INIT_RISMDReference(&lcmd_var_gv_S_SEALINGDIAGNOSTICCODE),
  INIT_RISMDReference(&lcmd_var_gv_S_SEALINGGUARDCLOSED),
  INIT_RISMDReference(&lcmd_var_gv_S_SEALINGMOTIONDIRECTION),
  INIT_RISMDReference(&lcmd_var_gv_S_SEALINGSENSORCOUNT),
  INIT_RISMDReference(&lcmd_var_gv_S_SEALINGSTOPPOSITION_MM),
  INIT_RISMDReference(&lcmd_var_gv_S_SEALINGTEMPERATUREACTUAL_DC),
  INIT_RISMDReference(&lcmd_var_gv_S_SEALINGTEMPERATURELIMIT_DC),
  INIT_RISMDReference(&lcmd_var_gv_S_SEALINGZONESTATUS),
  INIT_RISMDReference(&lcmd_var_gv_S_SERVICEDOORCLOSED),
  INIT_RISMDReference(&lcmd_var_gv_S_ZONEPERMISSIONMASK),
};

static char const lcmd_type_name_gv[] RISMD_ATTRIBUTES = "gv";
RISMDCompoundType const lcmd_type_global_var RISMD_ATTRIBUTES = INIT_RISMDCompoundType(lcmd_type_name_gv, sizeof(LC_TD_LC3_GVType), 98, lcmd_var_list_gv);
