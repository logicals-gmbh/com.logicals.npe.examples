#include <RISMD.h>
#include <LC3Globals_MD.h>
#include <LC3GlobalsDMA_MD.h>

extern RISMDSimpleNumType const risMdType_BOOL;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_BUTTON1INDICATOR[] RISMD_ATTRIBUTES = "Button1Indicator";
static char const lcmd_attr_val_LOCAL_BUTTON1INDICATOR_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_BUTTON1INDICATOR_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_BUTTON1INDICATOR_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_BUTTON1INDICATOR[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_BUTTON1INDICATOR_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_BUTTON1INDICATOR RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_BUTTON1INDICATOR, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON1INDICATOR), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_BUTTON1INDICATOR);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_BUTTON1INPUT[] RISMD_ATTRIBUTES = "Button1Input";
static char const lcmd_attr_val_LOCAL_BUTTON1INPUT_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_BUTTON1INPUT_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_BUTTON1INPUT_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_BUTTON1INPUT[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_BUTTON1INPUT_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_BUTTON1INPUT RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_BUTTON1INPUT, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON1INPUT), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_BUTTON1INPUT);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_BUTTON2INDICATOR[] RISMD_ATTRIBUTES = "Button2Indicator";
static char const lcmd_attr_val_LOCAL_BUTTON2INDICATOR_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.1";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_BUTTON2INDICATOR_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_BUTTON2INDICATOR_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_BUTTON2INDICATOR[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_BUTTON2INDICATOR_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_BUTTON2INDICATOR RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_BUTTON2INDICATOR, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON2INDICATOR), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_BUTTON2INDICATOR);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_BUTTON2INPUT[] RISMD_ATTRIBUTES = "Button2Input";
static char const lcmd_attr_val_LOCAL_BUTTON2INPUT_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.1";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_BUTTON2INPUT_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_BUTTON2INPUT_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_BUTTON2INPUT[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_BUTTON2INPUT_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_BUTTON2INPUT RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_BUTTON2INPUT, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON2INPUT), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_BUTTON2INPUT);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_BUTTON3INDICATOR[] RISMD_ATTRIBUTES = "Button3Indicator";
static char const lcmd_attr_val_LOCAL_BUTTON3INDICATOR_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX1.22.2";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_BUTTON3INDICATOR_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_BUTTON3INDICATOR_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_BUTTON3INDICATOR[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_BUTTON3INDICATOR_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_BUTTON3INDICATOR RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_BUTTON3INDICATOR, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON3INDICATOR), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_BUTTON3INDICATOR);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_BUTTON3INPUT[] RISMD_ATTRIBUTES = "Button3Input";
static char const lcmd_attr_val_LOCAL_BUTTON3INPUT_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX1.22.2";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_BUTTON3INPUT_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_BUTTON3INPUT_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_BUTTON3INPUT[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_BUTTON3INPUT_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_BUTTON3INPUT RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_BUTTON3INPUT, &risMdType_BOOL, offsetof(LC_TD_LC3_GVType,LC_VD_BUTTON3INPUT), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_BUTTON3INPUT);

extern RISMDDerivedType const lcmd_type_SAFEBOOL;
extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_DUMMY1[] RISMD_ATTRIBUTES = "dummy1";
static char const lcmd_attr_val_LOCAL_DUMMY1_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX2.1.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_DUMMY1_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_DUMMY1_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_DUMMY1[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_DUMMY1_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_DUMMY1 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_DUMMY1, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_DUMMY1), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_DUMMY1);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_DUMMY2[] RISMD_ATTRIBUTES = "dummy2";
static char const lcmd_attr_val_LOCAL_DUMMY2_HWAddrAttr[] RISMD_ATTRIBUTES = "%QX2.2.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_DUMMY2_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_DUMMY2_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_DUMMY2[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_DUMMY2_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_DUMMY2 RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_DUMMY2, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_DUMMY2), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_DUMMY2);

extern RISMDEntryPoint const lcmd_entrypoint_gvinstance;

static char const lcmd_var_name_LOCAL_ESTOP[] RISMD_ATTRIBUTES = "EStop";
static char const lcmd_attr_val_LOCAL_ESTOP_HWAddrAttr[] RISMD_ATTRIBUTES = "%IX2.3.0.0";
static RISMDHWAddrAttr const lcmd_attr_LOCAL_ESTOP_HWAddrAttr RISMD_ATTRIBUTES = INIT_RISMDHWAddrAttr(lcmd_attr_val_LOCAL_ESTOP_HWAddrAttr);
static RISMDReference const lcmd_attr_list_LOCAL_ESTOP[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_attr_LOCAL_ESTOP_HWAddrAttr),
};
RISMDStdAttrGV const lcmd_var_gv_ESTOP RISMD_ATTRIBUTES =
INIT_RISMDStdAttrGV(lcmd_var_name_LOCAL_ESTOP, &lcmd_type_SAFEBOOL, offsetof(LC_TD_LC3_GVType,LC_VD_ESTOP), &lcmd_entrypoint_gvinstance,1,lcmd_attr_list_LOCAL_ESTOP);

static RISMDReference const lcmd_var_list_gv[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_gv_BUTTON1INDICATOR),
  INIT_RISMDReference(&lcmd_var_gv_BUTTON1INPUT),
  INIT_RISMDReference(&lcmd_var_gv_BUTTON2INDICATOR),
  INIT_RISMDReference(&lcmd_var_gv_BUTTON2INPUT),
  INIT_RISMDReference(&lcmd_var_gv_BUTTON3INDICATOR),
  INIT_RISMDReference(&lcmd_var_gv_BUTTON3INPUT),
  INIT_RISMDReference(&lcmd_var_gv_DUMMY1),
  INIT_RISMDReference(&lcmd_var_gv_DUMMY2),
  INIT_RISMDReference(&lcmd_var_gv_ESTOP),
};

static char const lcmd_type_name_gv[] RISMD_ATTRIBUTES = "gv";
RISMDCompoundType const lcmd_type_global_var RISMD_ATTRIBUTES = INIT_RISMDCompoundType(lcmd_type_name_gv, sizeof(LC_TD_LC3_GVType), 9, lcmd_var_list_gv);
