#include <RISMD.h>
#include <lcdt___safedate.h>

static char const lcmd_type_name_SAFEDATE[] RISMD_ATTRIBUTES = "SAFEDATE";
extern RISMDSimpleNumType const risMdType_DATE;
RISMDDerivedType const lcmd_type_SAFEDATE RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEDATE, &risMdType_DATE);
