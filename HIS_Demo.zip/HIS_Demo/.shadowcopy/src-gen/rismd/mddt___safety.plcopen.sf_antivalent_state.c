#include <RISMD.h>
#include <lcdt___safety.plcopen.sf_antivalent_state.h>

static char const lcmd_type_name_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE[] RISMD_ATTRIBUTES = "SAFETY.PLCOPEN.SF_ANTIVALENT_STATE";
extern RISMDSimpleNumType const risMdType_UINT;
RISMDDerivedType const lcmd_type_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFETYx2EPLCOPENx2ESF_ANTIVALENT_STATE, &risMdType_UINT);
