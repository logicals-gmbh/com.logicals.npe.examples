#include <RISMD.h>
#include <lcdt___safeulint.h>

static char const lcmd_type_name_SAFEULINT[] RISMD_ATTRIBUTES = "SAFEULINT";
extern RISMDSimpleNumType const risMdType_ULINT;
RISMDDerivedType const lcmd_type_SAFEULINT RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEULINT, &risMdType_ULINT);
