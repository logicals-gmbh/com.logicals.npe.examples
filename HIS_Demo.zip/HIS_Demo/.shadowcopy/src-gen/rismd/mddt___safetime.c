#include <RISMD.h>
#include <lcdt___safetime.h>

static char const lcmd_type_name_SAFETIME[] RISMD_ATTRIBUTES = "SAFETIME";
extern RISMDSimpleNumType const risMdType_TIME;
RISMDDerivedType const lcmd_type_SAFETIME RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFETIME, &risMdType_TIME);
