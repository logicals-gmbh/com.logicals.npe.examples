#include <RISMD.h>
#include <lcdt___safelword.h>

static char const lcmd_type_name_SAFELWORD[] RISMD_ATTRIBUTES = "SAFELWORD";
extern RISMDSimpleNumType const risMdType_LWORD;
RISMDDerivedType const lcmd_type_SAFELWORD RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFELWORD, &risMdType_LWORD);
