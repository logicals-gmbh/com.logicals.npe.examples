#include <RISMD.h>
#include <lcdt___safety.plcopen.sf_modeselector_modestate.h>

static char const lcmd_type_name_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE[] RISMD_ATTRIBUTES = "SAFETY.PLCOPEN.SF_MODESELECTOR_MODESTATE";
extern RISMDSimpleNumType const risMdType_INT;
RISMDDerivedType const lcmd_type_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFETYx2EPLCOPENx2ESF_MODESELECTOR_MODESTATE, &risMdType_INT);
