#include <RISMD.h>
#include <lcfu___fb_packagingline.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_FB_PACKAGINGLINE_ACKEDGE[] RISMD_ATTRIBUTES = "AckEdge";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_ACKEDGE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_ACKEDGE, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_ACKEDGE));

static char const lcmd_var_name_FB_PACKAGINGLINE_ACKJAM[] RISMD_ATTRIBUTES = "AckJam";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_ACKJAM RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_ACKJAM, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_ACKJAM), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_BLOCKED[] RISMD_ATTRIBUTES = "Blocked";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_BLOCKED RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_BLOCKED, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_BLOCKED), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDSimpleNumType const risMdType_UDINT;
static char const lcmd_var_name_FB_PACKAGINGLINE_CARTONSPACKED[] RISMD_ATTRIBUTES = "CartonsPacked";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_CARTONSPACKED RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_CARTONSPACKED, &risMdType_UDINT, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_CARTONSPACKED), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_COMPLETE[] RISMD_ATTRIBUTES = "Complete";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_COMPLETE RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_COMPLETE, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_COMPLETE), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_CYCLEDONE[] RISMD_ATTRIBUTES = "CycleDone";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_CYCLEDONE RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_CYCLEDONE, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_CYCLEDONE), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_ENABLE[] RISMD_ATTRIBUTES = "Enable";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_ENABLE RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_ENABLE, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_ENABLE), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_ENO, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_FASTCYCLE[] RISMD_ATTRIBUTES = "FastCycle";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_FASTCYCLE RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_FASTCYCLE, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_FASTCYCLE), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_FASTCYCLEACTIVE[] RISMD_ATTRIBUTES = "FastCycleActive";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_FASTCYCLEACTIVE RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_FASTCYCLEACTIVE, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_FASTCYCLEACTIVE), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_FAULT[] RISMD_ATTRIBUTES = "Fault";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_FAULT RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_FAULT, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_FAULT), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_FAULTLATCHED[] RISMD_ATTRIBUTES = "FaultLatched";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_FAULTLATCHED RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_FAULTLATCHED, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_FAULTLATCHED));

static char const lcmd_var_name_FB_PACKAGINGLINE_FIRSTSCAN[] RISMD_ATTRIBUTES = "FirstScan";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_FIRSTSCAN RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_FIRSTSCAN, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_FIRSTSCAN));

static char const lcmd_var_name_FB_PACKAGINGLINE_HEARTBEAT[] RISMD_ATTRIBUTES = "Heartbeat";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_HEARTBEAT RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_HEARTBEAT, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_HEARTBEAT), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_INFEED[] RISMD_ATTRIBUTES = "Infeed";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_INFEED RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_INFEED, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_INFEED), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDSimpleNumType const risMdType_TIME;
static char const lcmd_var_name_FB_PACKAGINGLINE_INFEEDTIME[] RISMD_ATTRIBUTES = "InfeedTime";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_INFEEDTIME RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_INFEEDTIME, &risMdType_TIME, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_INFEEDTIME));

static char const lcmd_var_name_FB_PACKAGINGLINE_JAM[] RISMD_ATTRIBUTES = "Jam";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_JAM RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_JAM, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_JAM), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_OUTFEED[] RISMD_ATTRIBUTES = "Outfeed";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_OUTFEED RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_OUTFEED, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_OUTFEED), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_OUTFEEDTIME[] RISMD_ATTRIBUTES = "OutfeedTime";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_OUTFEEDTIME RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_OUTFEEDTIME, &risMdType_TIME, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_OUTFEEDTIME));

static char const lcmd_var_name_FB_PACKAGINGLINE_PERMIT[] RISMD_ATTRIBUTES = "Permit";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_PERMIT RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_PERMIT, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_PERMIT), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_PREVACK[] RISMD_ATTRIBUTES = "PrevAck";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_PREVACK RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_PREVACK, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_PREVACK));

static char const lcmd_var_name_FB_PACKAGINGLINE_PREVSTART[] RISMD_ATTRIBUTES = "PrevStart";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_PREVSTART RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_PREVSTART, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_PREVSTART));

static char const lcmd_var_name_FB_PACKAGINGLINE_READY[] RISMD_ATTRIBUTES = "Ready";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_READY RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_READY, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_READY), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_RUNNING[] RISMD_ATTRIBUTES = "Running";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_RUNNING RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_RUNNING, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_RUNNING), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_SEALING[] RISMD_ATTRIBUTES = "Sealing";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_SEALING RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_SEALING, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_SEALING), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_SEALTIME[] RISMD_ATTRIBUTES = "SealTime";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_SEALTIME RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_SEALTIME, &risMdType_TIME, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_SEALTIME));

static char const lcmd_var_name_FB_PACKAGINGLINE_START[] RISMD_ATTRIBUTES = "Start";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_START RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_START, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_START), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_STARTARMED[] RISMD_ATTRIBUTES = "StartArmed";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_STARTARMED RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_STARTARMED, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_STARTARMED));

static char const lcmd_var_name_FB_PACKAGINGLINE_STARTEDGE[] RISMD_ATTRIBUTES = "StartEdge";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_STARTEDGE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_STARTEDGE, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_STARTEDGE));

extern RISMDSimpleNumType const risMdType_UINT;
static char const lcmd_var_name_FB_PACKAGINGLINE_STATE[] RISMD_ATTRIBUTES = "State";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_STATE RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_STATE, &risMdType_UINT, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_STATE), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_PACKAGINGLINE_STOP[] RISMD_ATTRIBUTES = "Stop";
static RISMDInterfaceVariable const lcmd_var_FB_PACKAGINGLINE_STOP RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_PACKAGINGLINE_STOP, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_STOP), RISMD_VARIABLE_SECTION_INPUT);

extern RISMDPOUType const lcmd_type_TON;
static char const lcmd_var_name_FB_PACKAGINGLINE_TBLINK[] RISMD_ATTRIBUTES = "tBlink";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_TBLINK RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_TBLINK, &lcmd_type_TON, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_TBLINK));

static char const lcmd_var_name_FB_PACKAGINGLINE_TINFEED[] RISMD_ATTRIBUTES = "tInfeed";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_TINFEED RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_TINFEED, &lcmd_type_TON, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_TINFEED));

static char const lcmd_var_name_FB_PACKAGINGLINE_TOUTFEED[] RISMD_ATTRIBUTES = "tOutfeed";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_TOUTFEED RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_TOUTFEED, &lcmd_type_TON, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_TOUTFEED));

static char const lcmd_var_name_FB_PACKAGINGLINE_TSEAL[] RISMD_ATTRIBUTES = "tSeal";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_TSEAL RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_TSEAL, &lcmd_type_TON, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_TSEAL));

static char const lcmd_var_name_FB_PACKAGINGLINE_TSUCCESS[] RISMD_ATTRIBUTES = "tSuccess";
static RISMDStdVariable const lcmd_var_FB_PACKAGINGLINE_TSUCCESS RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_PACKAGINGLINE_TSUCCESS, &lcmd_type_TON, offsetof(LC_TD_FunctionBlock_FB_PACKAGINGLINE,LC_VD_TSUCCESS));

static RISMDReference const lcmd_var_list_FB_PACKAGINGLINE[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_ACKEDGE),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_ACKJAM),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_BLOCKED),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_CARTONSPACKED),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_COMPLETE),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_CYCLEDONE),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_ENABLE),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_ENO),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_FASTCYCLE),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_FASTCYCLEACTIVE),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_FAULT),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_FAULTLATCHED),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_FIRSTSCAN),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_HEARTBEAT),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_INFEED),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_INFEEDTIME),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_JAM),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_OUTFEED),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_OUTFEEDTIME),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_PERMIT),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_PREVACK),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_PREVSTART),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_READY),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_RUNNING),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_SEALING),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_SEALTIME),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_START),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_STARTARMED),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_STARTEDGE),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_STATE),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_STOP),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_TBLINK),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_TINFEED),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_TOUTFEED),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_TSEAL),
  INIT_RISMDReference(&lcmd_var_FB_PACKAGINGLINE_TSUCCESS),
};

static char const lcmd_type_name_FB_PACKAGINGLINE[] RISMD_ATTRIBUTES = "FB_PACKAGINGLINE";
RISMDPOUType const lcmd_type_FB_PACKAGINGLINE RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_FB_PACKAGINGLINE, sizeof(LC_TD_FunctionBlock_FB_PACKAGINGLINE), 36, lcmd_var_list_FB_PACKAGINGLINE);
