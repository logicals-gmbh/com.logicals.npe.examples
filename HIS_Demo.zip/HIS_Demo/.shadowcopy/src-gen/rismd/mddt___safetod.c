#include <RISMD.h>
#include <lcdt___safetod.h>

static char const lcmd_type_name_SAFETOD[] RISMD_ATTRIBUTES = "SAFETOD";
extern RISMDSimpleNumType const risMdType_TOD;
RISMDDerivedType const lcmd_type_SAFETOD RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFETOD, &risMdType_TOD);
