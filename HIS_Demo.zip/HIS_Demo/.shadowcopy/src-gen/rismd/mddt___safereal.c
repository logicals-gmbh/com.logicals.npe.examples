#include <RISMD.h>
#include <lcdt___safereal.h>

static char const lcmd_type_name_SAFEREAL[] RISMD_ATTRIBUTES = "SAFEREAL";
extern RISMDSimpleNumType const risMdType_REAL;
RISMDDerivedType const lcmd_type_SAFEREAL RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEREAL, &risMdType_REAL);
