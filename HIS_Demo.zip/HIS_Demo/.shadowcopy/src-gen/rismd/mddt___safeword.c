#include <RISMD.h>
#include <lcdt___safeword.h>

static char const lcmd_type_name_SAFEWORD[] RISMD_ATTRIBUTES = "SAFEWORD";
extern RISMDSimpleNumType const risMdType_WORD;
RISMDDerivedType const lcmd_type_SAFEWORD RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEWORD, &risMdType_WORD);
