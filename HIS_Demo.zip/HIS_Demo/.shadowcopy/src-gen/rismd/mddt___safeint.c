#include <RISMD.h>
#include <lcdt___safeint.h>

static char const lcmd_type_name_SAFEINT[] RISMD_ATTRIBUTES = "SAFEINT";
extern RISMDSimpleNumType const risMdType_INT;
RISMDDerivedType const lcmd_type_SAFEINT RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEINT, &risMdType_INT);
