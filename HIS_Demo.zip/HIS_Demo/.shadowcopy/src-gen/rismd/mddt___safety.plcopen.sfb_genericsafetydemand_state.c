#include <RISMD.h>
#include <lcdt___safety.plcopen.sfb_genericsafetydemand_state.h>

static char const lcmd_type_name_SAFETYx2EPLCOPENx2ESFB_GENERICSAFETYDEMAND_STATE[] RISMD_ATTRIBUTES = "SAFETY.PLCOPEN.SFB_GENERICSAFETYDEMAND_STATE";
extern RISMDSimpleNumType const risMdType_UINT;
RISMDDerivedType const lcmd_type_SAFETYx2EPLCOPENx2ESFB_GENERICSAFETYDEMAND_STATE RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFETYx2EPLCOPENx2ESFB_GENERICSAFETYDEMAND_STATE, &risMdType_UINT);
