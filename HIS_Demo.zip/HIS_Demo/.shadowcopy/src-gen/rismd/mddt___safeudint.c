#include <RISMD.h>
#include <lcdt___safeudint.h>

static char const lcmd_type_name_SAFEUDINT[] RISMD_ATTRIBUTES = "SAFEUDINT";
extern RISMDSimpleNumType const risMdType_UDINT;
RISMDDerivedType const lcmd_type_SAFEUDINT RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEUDINT, &risMdType_UDINT);
