#include <RISMD.h>
#include <lcpu___prg_hisdemo.h>

extern RISMDVariable const lcmd_var_gv_BUTTON1INDICATOR;
static char const lcmd_var_name_PRG_HISDEMO_BUTTON1INDICATOR[] RISMD_ATTRIBUTES = "Button1Indicator";
static RISMDExtVariable const lcmd_var_PRG_HISDEMO_BUTTON1INDICATOR RISMD_ATTRIBUTES = INIT_RISMDExtVariable(lcmd_var_name_PRG_HISDEMO_BUTTON1INDICATOR, &lcmd_var_gv_BUTTON1INDICATOR);

extern RISMDVariable const lcmd_var_gv_BUTTON1INPUT;
static char const lcmd_var_name_PRG_HISDEMO_BUTTON1INPUT[] RISMD_ATTRIBUTES = "Button1Input";
static RISMDExtVariable const lcmd_var_PRG_HISDEMO_BUTTON1INPUT RISMD_ATTRIBUTES = INIT_RISMDExtVariable(lcmd_var_name_PRG_HISDEMO_BUTTON1INPUT, &lcmd_var_gv_BUTTON1INPUT);

extern RISMDVariable const lcmd_var_gv_BUTTON2INDICATOR;
static char const lcmd_var_name_PRG_HISDEMO_BUTTON2INDICATOR[] RISMD_ATTRIBUTES = "Button2Indicator";
static RISMDExtVariable const lcmd_var_PRG_HISDEMO_BUTTON2INDICATOR RISMD_ATTRIBUTES = INIT_RISMDExtVariable(lcmd_var_name_PRG_HISDEMO_BUTTON2INDICATOR, &lcmd_var_gv_BUTTON2INDICATOR);

extern RISMDVariable const lcmd_var_gv_BUTTON2INPUT;
static char const lcmd_var_name_PRG_HISDEMO_BUTTON2INPUT[] RISMD_ATTRIBUTES = "Button2Input";
static RISMDExtVariable const lcmd_var_PRG_HISDEMO_BUTTON2INPUT RISMD_ATTRIBUTES = INIT_RISMDExtVariable(lcmd_var_name_PRG_HISDEMO_BUTTON2INPUT, &lcmd_var_gv_BUTTON2INPUT);

extern RISMDVariable const lcmd_var_gv_BUTTON3INDICATOR;
static char const lcmd_var_name_PRG_HISDEMO_BUTTON3INDICATOR[] RISMD_ATTRIBUTES = "Button3Indicator";
static RISMDExtVariable const lcmd_var_PRG_HISDEMO_BUTTON3INDICATOR RISMD_ATTRIBUTES = INIT_RISMDExtVariable(lcmd_var_name_PRG_HISDEMO_BUTTON3INDICATOR, &lcmd_var_gv_BUTTON3INDICATOR);

extern RISMDVariable const lcmd_var_gv_BUTTON3INPUT;
static char const lcmd_var_name_PRG_HISDEMO_BUTTON3INPUT[] RISMD_ATTRIBUTES = "Button3Input";
static RISMDExtVariable const lcmd_var_PRG_HISDEMO_BUTTON3INPUT RISMD_ATTRIBUTES = INIT_RISMDExtVariable(lcmd_var_name_PRG_HISDEMO_BUTTON3INPUT, &lcmd_var_gv_BUTTON3INPUT);

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_PRG_HISDEMO_CMDACKJAM[] RISMD_ATTRIBUTES = "CmdAckJam";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_CMDACKJAM RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_CMDACKJAM, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_CMDACKJAM));

static char const lcmd_var_name_PRG_HISDEMO_CMDENABLE[] RISMD_ATTRIBUTES = "CmdEnable";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_CMDENABLE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_CMDENABLE, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_CMDENABLE));

static char const lcmd_var_name_PRG_HISDEMO_CMDFASTCYCLE[] RISMD_ATTRIBUTES = "CmdFastCycle";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_CMDFASTCYCLE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_CMDFASTCYCLE, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_CMDFASTCYCLE));

static char const lcmd_var_name_PRG_HISDEMO_CMDJAM[] RISMD_ATTRIBUTES = "CmdJam";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_CMDJAM RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_CMDJAM, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_CMDJAM));

static char const lcmd_var_name_PRG_HISDEMO_CMDSAFETYRESET[] RISMD_ATTRIBUTES = "CmdSafetyReset";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_CMDSAFETYRESET RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_CMDSAFETYRESET, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_CMDSAFETYRESET));

static char const lcmd_var_name_PRG_HISDEMO_CMDSTART[] RISMD_ATTRIBUTES = "CmdStart";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_CMDSTART RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_CMDSTART, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_CMDSTART));

static char const lcmd_var_name_PRG_HISDEMO_CMDSTOP[] RISMD_ATTRIBUTES = "CmdStop";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_CMDSTOP RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_CMDSTOP, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_CMDSTOP));

static char const lcmd_var_name_PRG_HISDEMO_ENABLEBUTTONFIRSTSCAN[] RISMD_ATTRIBUTES = "EnableButtonFirstScan";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_ENABLEBUTTONFIRSTSCAN RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_ENABLEBUTTONFIRSTSCAN, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_ENABLEBUTTONFIRSTSCAN));

static char const lcmd_var_name_PRG_HISDEMO_ENABLEBUTTONPREV[] RISMD_ATTRIBUTES = "EnableButtonPrev";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_ENABLEBUTTONPREV RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_ENABLEBUTTONPREV, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_ENABLEBUTTONPREV));

static char const lcmd_var_name_PRG_HISDEMO_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_PRG_HISDEMO_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_PRG_HISDEMO_ENO, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDVariable const lcmd_var_gv_ESTOP;
static char const lcmd_var_name_PRG_HISDEMO_ESTOP[] RISMD_ATTRIBUTES = "EStop";
static RISMDExtVariable const lcmd_var_PRG_HISDEMO_ESTOP RISMD_ATTRIBUTES = INIT_RISMDExtVariable(lcmd_var_name_PRG_HISDEMO_ESTOP, &lcmd_var_gv_ESTOP);

static char const lcmd_var_name_PRG_HISDEMO_HARDWARECOMMANDSARMED[] RISMD_ATTRIBUTES = "HardwareCommandsArmed";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_HARDWARECOMMANDSARMED RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_HARDWARECOMMANDSARMED, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_HARDWARECOMMANDSARMED));

extern RISMDPOUType const lcmd_type_FB_PACKAGINGINDICATORS;
static char const lcmd_var_name_PRG_HISDEMO_LAMPS[] RISMD_ATTRIBUTES = "Lamps";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_LAMPS RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_LAMPS, &lcmd_type_FB_PACKAGINGINDICATORS, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_LAMPS));

static char const lcmd_var_name_PRG_HISDEMO_LEDATTENTION[] RISMD_ATTRIBUTES = "LedAttention";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_LEDATTENTION RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_LEDATTENTION, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_LEDATTENTION));

static char const lcmd_var_name_PRG_HISDEMO_LEDCONVEYOR[] RISMD_ATTRIBUTES = "LedConveyor";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_LEDCONVEYOR RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_LEDCONVEYOR, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_LEDCONVEYOR));

static char const lcmd_var_name_PRG_HISDEMO_LEDREADY[] RISMD_ATTRIBUTES = "LedReady";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_LEDREADY RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_LEDREADY, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_LEDREADY));

static char const lcmd_var_name_PRG_HISDEMO_LEDSEALING[] RISMD_ATTRIBUTES = "LedSealing";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_LEDSEALING RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_LEDSEALING, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_LEDSEALING));

extern RISMDPOUType const lcmd_type_FB_PACKAGINGLINE;
static char const lcmd_var_name_PRG_HISDEMO_LINE[] RISMD_ATTRIBUTES = "Line";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_LINE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_LINE, &lcmd_type_FB_PACKAGINGLINE, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_LINE));

static char const lcmd_var_name_PRG_HISDEMO_MODECHANGED[] RISMD_ATTRIBUTES = "ModeChanged";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_MODECHANGED RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_MODECHANGED, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_MODECHANGED));

extern RISMDPOUType const lcmd_type_FB_HISSAFETY;
static char const lcmd_var_name_PRG_HISDEMO_SAFETY[] RISMD_ATTRIBUTES = "Safety";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_SAFETY RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_SAFETY, &lcmd_type_FB_HISSAFETY, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_SAFETY));

static char const lcmd_var_name_PRG_HISDEMO_SIMFASTCYCLE[] RISMD_ATTRIBUTES = "SimFastCycle";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_SIMFASTCYCLE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_SIMFASTCYCLE, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_SIMFASTCYCLE));

static char const lcmd_var_name_PRG_HISDEMO_SIMINJECTFAULTS[] RISMD_ATTRIBUTES = "SimInjectFaults";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_SIMINJECTFAULTS RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_SIMINJECTFAULTS, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_SIMINJECTFAULTS));

static char const lcmd_var_name_PRG_HISDEMO_SIMMODE[] RISMD_ATTRIBUTES = "SimMode";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_SIMMODE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_SIMMODE, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_SIMMODE));

static char const lcmd_var_name_PRG_HISDEMO_SIMMODEPREV[] RISMD_ATTRIBUTES = "SimModePrev";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_SIMMODEPREV RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_SIMMODEPREV, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_SIMMODEPREV));

extern RISMDPOUType const lcmd_type_FB_PACKAGINGSIMULATION;
static char const lcmd_var_name_PRG_HISDEMO_SIMULATION[] RISMD_ATTRIBUTES = "Simulation";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_SIMULATION RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_SIMULATION, &lcmd_type_FB_PACKAGINGSIMULATION, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_SIMULATION));

extern RISMDDerivedType const lcmd_type_SAFEBOOL;
static char const lcmd_var_name_PRG_HISDEMO_SIM_ESTOPRELEASED[] RISMD_ATTRIBUTES = "Sim_EStopReleased";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_SIM_ESTOPRELEASED RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_SIM_ESTOPRELEASED, &lcmd_type_SAFEBOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_SIM_ESTOPRELEASED));

static char const lcmd_var_name_PRG_HISDEMO_S_DEMOENABLE[] RISMD_ATTRIBUTES = "S_DemoEnable";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_S_DEMOENABLE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_S_DEMOENABLE, &lcmd_type_SAFEBOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_S_DEMOENABLE));

static char const lcmd_var_name_PRG_HISDEMO_S_ESTOPA[] RISMD_ATTRIBUTES = "S_EStopA";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_S_ESTOPA RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_S_ESTOPA, &lcmd_type_SAFEBOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_S_ESTOPA));

static char const lcmd_var_name_PRG_HISDEMO_S_ESTOPB[] RISMD_ATTRIBUTES = "S_EStopB";
static RISMDStdVariable const lcmd_var_PRG_HISDEMO_S_ESTOPB RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_HISDEMO_S_ESTOPB, &lcmd_type_SAFEBOOL, offsetof(LC_TD_Program_PRG_HISDEMO,LC_VD_S_ESTOPB));

static RISMDReference const lcmd_var_list_PRG_HISDEMO[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_BUTTON1INDICATOR),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_BUTTON1INPUT),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_BUTTON2INDICATOR),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_BUTTON2INPUT),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_BUTTON3INDICATOR),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_BUTTON3INPUT),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_CMDACKJAM),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_CMDENABLE),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_CMDFASTCYCLE),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_CMDJAM),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_CMDSAFETYRESET),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_CMDSTART),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_CMDSTOP),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_ENABLEBUTTONFIRSTSCAN),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_ENABLEBUTTONPREV),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_ENO),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_ESTOP),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_HARDWARECOMMANDSARMED),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_LAMPS),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_LEDATTENTION),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_LEDCONVEYOR),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_LEDREADY),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_LEDSEALING),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_LINE),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_MODECHANGED),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_SAFETY),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_SIMFASTCYCLE),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_SIMINJECTFAULTS),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_SIMMODE),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_SIMMODEPREV),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_SIMULATION),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_SIM_ESTOPRELEASED),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_S_DEMOENABLE),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_S_ESTOPA),
  INIT_RISMDReference(&lcmd_var_PRG_HISDEMO_S_ESTOPB),
};

static char const lcmd_type_name_PRG_HISDEMO[] RISMD_ATTRIBUTES = "PRG_HISDEMO";
RISMDPOUType const lcmd_type_PRG_HISDEMO RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_PRG_HISDEMO, sizeof(LC_TD_Program_PRG_HISDEMO), 35, lcmd_var_list_PRG_HISDEMO);
