#include <RISMD.h>
#include <lcpu___estopdemo.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_ESTOPDEMO_ENABLE[] RISMD_ATTRIBUTES = "Enable";
static RISMDStdVariable const lcmd_var_ESTOPDEMO_ENABLE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_ESTOPDEMO_ENABLE, &risMdType_BOOL, offsetof(LC_TD_Program_ESTOPDEMO,LC_VD_ENABLE));

static char const lcmd_var_name_ESTOPDEMO_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_ESTOPDEMO_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_ESTOPDEMO_ENO, &risMdType_BOOL, offsetof(LC_TD_Program_ESTOPDEMO,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDDerivedType const lcmd_type_SAFEBOOL;
static char const lcmd_var_name_ESTOPDEMO_ESTOPINPUT[] RISMD_ATTRIBUTES = "EstopInput";
static RISMDStdVariable const lcmd_var_ESTOPDEMO_ESTOPINPUT RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_ESTOPDEMO_ESTOPINPUT, &lcmd_type_SAFEBOOL, offsetof(LC_TD_Program_ESTOPDEMO,LC_VD_ESTOPINPUT));

static char const lcmd_var_name_ESTOPDEMO_LIGHTCURTAININPUT[] RISMD_ATTRIBUTES = "LightCurtainInput";
static RISMDStdVariable const lcmd_var_ESTOPDEMO_LIGHTCURTAININPUT RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_ESTOPDEMO_LIGHTCURTAININPUT, &lcmd_type_SAFEBOOL, offsetof(LC_TD_Program_ESTOPDEMO,LC_VD_LIGHTCURTAININPUT));

extern RISMDPOUType const lcmd_type_SAFETYx2EPLCOPENx2ESF_EMERGENCYSTOP;
static char const lcmd_var_name_ESTOPDEMO_LOGICALS_SAFETY_PLCOPEN_SF_EMERGENCYSTOP1[] RISMD_ATTRIBUTES = "logicals_safety_plcopen_SF_EmergencyStop1";
static RISMDStdVariable const lcmd_var_ESTOPDEMO_LOGICALS_SAFETY_PLCOPEN_SF_EMERGENCYSTOP1 RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_ESTOPDEMO_LOGICALS_SAFETY_PLCOPEN_SF_EMERGENCYSTOP1, &lcmd_type_SAFETYx2EPLCOPENx2ESF_EMERGENCYSTOP, offsetof(LC_TD_Program_ESTOPDEMO,LC_VD_LOGICALS_SAFETY_PLCOPEN_SF_EMERGENCYSTOP1));

extern RISMDPOUType const lcmd_type_SAFETYx2EPLCOPENx2ESF_ESPE;
static char const lcmd_var_name_ESTOPDEMO_LOGICALS_SAFETY_PLCOPEN_SF_ESPE1[] RISMD_ATTRIBUTES = "logicals_safety_plcopen_SF_ESPE1";
static RISMDStdVariable const lcmd_var_ESTOPDEMO_LOGICALS_SAFETY_PLCOPEN_SF_ESPE1 RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_ESTOPDEMO_LOGICALS_SAFETY_PLCOPEN_SF_ESPE1, &lcmd_type_SAFETYx2EPLCOPENx2ESF_ESPE, offsetof(LC_TD_Program_ESTOPDEMO,LC_VD_LOGICALS_SAFETY_PLCOPEN_SF_ESPE1));

extern RISMDPOUType const lcmd_type_SAFETYx2EPLCOPENx2ESF_OUTCONTROL;
static char const lcmd_var_name_ESTOPDEMO_LOGICALS_SAFETY_PLCOPEN_SF_OUTCONTROL1[] RISMD_ATTRIBUTES = "logicals_safety_plcopen_SF_OutControl1";
static RISMDStdVariable const lcmd_var_ESTOPDEMO_LOGICALS_SAFETY_PLCOPEN_SF_OUTCONTROL1 RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_ESTOPDEMO_LOGICALS_SAFETY_PLCOPEN_SF_OUTCONTROL1, &lcmd_type_SAFETYx2EPLCOPENx2ESF_OUTCONTROL, offsetof(LC_TD_Program_ESTOPDEMO,LC_VD_LOGICALS_SAFETY_PLCOPEN_SF_OUTCONTROL1));

static char const lcmd_var_name_ESTOPDEMO_MOTORLOGIC[] RISMD_ATTRIBUTES = "MotorLogic";
static RISMDStdVariable const lcmd_var_ESTOPDEMO_MOTORLOGIC RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_ESTOPDEMO_MOTORLOGIC, &risMdType_BOOL, offsetof(LC_TD_Program_ESTOPDEMO,LC_VD_MOTORLOGIC));

static char const lcmd_var_name_ESTOPDEMO_MOTOROUTPUT[] RISMD_ATTRIBUTES = "MotorOutput";
static RISMDStdVariable const lcmd_var_ESTOPDEMO_MOTOROUTPUT RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_ESTOPDEMO_MOTOROUTPUT, &lcmd_type_SAFEBOOL, offsetof(LC_TD_Program_ESTOPDEMO,LC_VD_MOTOROUTPUT));

static char const lcmd_var_name_ESTOPDEMO_RESET[] RISMD_ATTRIBUTES = "Reset";
static RISMDStdVariable const lcmd_var_ESTOPDEMO_RESET RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_ESTOPDEMO_RESET, &risMdType_BOOL, offsetof(LC_TD_Program_ESTOPDEMO,LC_VD_RESET));

static char const lcmd_var_name_ESTOPDEMO_SAFETRUE[] RISMD_ATTRIBUTES = "SAFETRUE";
static RISMDStdVariable const lcmd_var_ESTOPDEMO_SAFETRUE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_ESTOPDEMO_SAFETRUE, &lcmd_type_SAFEBOOL, offsetof(LC_TD_Program_ESTOPDEMO,LC_VD_SAFETRUE));

static char const lcmd_var_name_ESTOPDEMO___19_AND[] RISMD_ATTRIBUTES = "__19_AND";
static RISMDStdVariable const lcmd_var_ESTOPDEMO___19_AND RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_ESTOPDEMO___19_AND, &risMdType_BOOL, offsetof(LC_TD_Program_ESTOPDEMO,LC_VD___19_AND));

static RISMDReference const lcmd_var_list_ESTOPDEMO[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_ESTOPDEMO_ENABLE),
  INIT_RISMDReference(&lcmd_var_ESTOPDEMO_ENO),
  INIT_RISMDReference(&lcmd_var_ESTOPDEMO_ESTOPINPUT),
  INIT_RISMDReference(&lcmd_var_ESTOPDEMO_LIGHTCURTAININPUT),
  INIT_RISMDReference(&lcmd_var_ESTOPDEMO_LOGICALS_SAFETY_PLCOPEN_SF_EMERGENCYSTOP1),
  INIT_RISMDReference(&lcmd_var_ESTOPDEMO_LOGICALS_SAFETY_PLCOPEN_SF_ESPE1),
  INIT_RISMDReference(&lcmd_var_ESTOPDEMO_LOGICALS_SAFETY_PLCOPEN_SF_OUTCONTROL1),
  INIT_RISMDReference(&lcmd_var_ESTOPDEMO_MOTORLOGIC),
  INIT_RISMDReference(&lcmd_var_ESTOPDEMO_MOTOROUTPUT),
  INIT_RISMDReference(&lcmd_var_ESTOPDEMO_RESET),
  INIT_RISMDReference(&lcmd_var_ESTOPDEMO_SAFETRUE),
  INIT_RISMDReference(&lcmd_var_ESTOPDEMO___19_AND),
};

static char const lcmd_type_name_ESTOPDEMO[] RISMD_ATTRIBUTES = "ESTOPDEMO";
RISMDPOUType const lcmd_type_ESTOPDEMO RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_ESTOPDEMO, sizeof(LC_TD_Program_ESTOPDEMO), 12, lcmd_var_list_ESTOPDEMO);
