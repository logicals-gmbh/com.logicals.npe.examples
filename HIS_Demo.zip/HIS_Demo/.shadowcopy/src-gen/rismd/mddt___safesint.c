#include <RISMD.h>
#include <lcdt___safesint.h>

static char const lcmd_type_name_SAFESINT[] RISMD_ATTRIBUTES = "SAFESINT";
extern RISMDSimpleNumType const risMdType_SINT;
RISMDDerivedType const lcmd_type_SAFESINT RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFESINT, &risMdType_SINT);
