#include <RISMD.h>
#include <lcdt___safeusint.h>

static char const lcmd_type_name_SAFEUSINT[] RISMD_ATTRIBUTES = "SAFEUSINT";
extern RISMDSimpleNumType const risMdType_USINT;
RISMDDerivedType const lcmd_type_SAFEUSINT RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEUSINT, &risMdType_USINT);
