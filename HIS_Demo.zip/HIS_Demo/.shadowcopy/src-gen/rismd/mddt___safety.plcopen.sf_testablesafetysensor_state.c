#include <RISMD.h>
#include <lcdt___safety.plcopen.sf_testablesafetysensor_state.h>

static char const lcmd_type_name_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE[] RISMD_ATTRIBUTES = "SAFETY.PLCOPEN.SF_TESTABLESAFETYSENSOR_STATE";
extern RISMDSimpleNumType const risMdType_UINT;
RISMDDerivedType const lcmd_type_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFETYx2EPLCOPENx2ESF_TESTABLESAFETYSENSOR_STATE, &risMdType_UINT);
