#include <RISMD.h>
#include <lcdt___safedt.h>

static char const lcmd_type_name_SAFEDT[] RISMD_ATTRIBUTES = "SAFEDT";
extern RISMDSimpleNumType const risMdType_DT;
RISMDDerivedType const lcmd_type_SAFEDT RISMD_ATTRIBUTES = INIT_RISMDDerivedType(lcmd_type_name_SAFEDT, &risMdType_DT);
