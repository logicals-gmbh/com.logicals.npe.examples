#ifndef LC_PROT_LCFU___FB_PACKAGINGINDICATORS__C
#define LC_PROT_LCFU___FB_PACKAGINGINDICATORS__C

#include <lcfu___fb_packagingindicators.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_FB_PACKAGINGINDICATORS(LC_TD_FunctionBlock_FB_PACKAGINGINDICATORS* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_FB_PACKAGINGINDICATORS* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_PERMIT)); \
  LC_INIT_BOOL(&((p)->LC_VD_READY)); \
  LC_INIT_BOOL(&((p)->LC_VD_INFEED)); \
  LC_INIT_BOOL(&((p)->LC_VD_SEALING)); \
  LC_INIT_BOOL(&((p)->LC_VD_OUTFEED)); \
  LC_INIT_BOOL(&((p)->LC_VD_COMPLETE)); \
  LC_INIT_BOOL(&((p)->LC_VD_BLOCKED)); \
  LC_INIT_BOOL(&((p)->LC_VD_PROCESSFAULT)); \
  LC_INIT_BOOL(&((p)->LC_VD_SAFETYERROR)); \
  LC_INIT_BOOL(&((p)->LC_VD_RESETREQUEST)); \
  LC_INIT_BOOL(&((p)->LC_VD_HEARTBEAT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LEDREADY)); \
  LC_INIT_BOOL(&((p)->LC_VD_LEDCONVEYOR)); \
  LC_INIT_BOOL(&((p)->LC_VD_LEDSEALING)); \
  LC_INIT_BOOL(&((p)->LC_VD_LEDATTENTION)); \
  LC_INIT_BOOL(&((p)->LC_VD___1_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___4_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___7_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___10_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___14_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___19_NOT)); \
  LC_INIT_BOOL(&((p)->LC_VD___21_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___23_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___26_OR)); \
}

void LC_WINIT_FUN_FunctionBlock_FB_PACKAGINGINDICATORS(LC_TD_FunctionBlock_FB_PACKAGINGINDICATORS* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_FB_PACKAGINGINDICATORS* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_PERMIT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_READY),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_INFEED),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_SEALING),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_OUTFEED),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_COMPLETE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_BLOCKED),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_PROCESSFAULT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_SAFETYERROR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_RESETREQUEST),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_HEARTBEAT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LEDREADY),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LEDCONVEYOR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LEDSEALING),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LEDATTENTION),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___1_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___4_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___7_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___10_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___14_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___19_NOT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___21_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___23_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___26_OR),RF); \
}

void  lcfu___FB_PACKAGINGINDICATORS(LC_TD_FunctionBlock_FB_PACKAGINGINDICATORS* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  NPE_HIS_CHANNEL2_NOP_VAR
  /* Network 1 */
  {
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_READY, LC_this->LC_VD_COMPLETE, pEPDB);
      LC_this->LC_VD___1_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_PERMIT, LC_this->LC_VD___1_OR, pEPDB);
      LC_this->LC_VD_LEDREADY = lFunction_AND.LC_VD_AND;
      LC_this->LC_VD___4_AND = lFunction_AND.LC_VD_AND;
    }
  }
  /* Network 2 */
  {
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_INFEED, LC_this->LC_VD_OUTFEED, pEPDB);
      LC_this->LC_VD___7_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__3(&lFunction_AND, LC_this->LC_VD_PERMIT, LC_this->LC_VD___7_OR, LC_this->LC_VD_HEARTBEAT, pEPDB);
      LC_this->LC_VD_LEDCONVEYOR = lFunction_AND.LC_VD_AND;
      LC_this->LC_VD___10_AND = lFunction_AND.LC_VD_AND;
    }
  }
  /* Network 3 */
  {
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__3(&lFunction_AND, LC_this->LC_VD_PERMIT, LC_this->LC_VD_SEALING, LC_this->LC_VD_HEARTBEAT, pEPDB);
      LC_this->LC_VD_LEDSEALING = lFunction_AND.LC_VD_AND;
      LC_this->LC_VD___14_AND = lFunction_AND.LC_VD_AND;
    }
  }
  /* Network 4 */
  {
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_RESETREQUEST, pEPDB);
      LC_this->LC_VD___19_NOT = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_BLOCKED, LC_this->LC_VD___19_NOT, pEPDB);
      LC_this->LC_VD___21_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_RESETREQUEST, LC_this->LC_VD_HEARTBEAT, pEPDB);
      LC_this->LC_VD___23_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__4(&lFunction_OR, LC_this->LC_VD___21_AND, LC_this->LC_VD_PROCESSFAULT, LC_this->LC_VD_SAFETYERROR, LC_this->LC_VD___23_AND, pEPDB);
      LC_this->LC_VD_LEDATTENTION = lFunction_OR.LC_VD_OR;
      LC_this->LC_VD___26_OR = lFunction_OR.LC_VD_OR;
    }
  }
  NPE_HIS_CHANNEL2_NOP_VAR_USE
}

#endif
