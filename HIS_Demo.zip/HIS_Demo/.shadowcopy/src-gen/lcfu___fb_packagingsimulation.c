#ifndef LC_PROT_LCFU___FB_PACKAGINGSIMULATION__C
#define LC_PROT_LCFU___FB_PACKAGINGSIMULATION__C

#include <lcfu___fb_packagingsimulation.h>
#include <LC3CGStmt.h>
#include <LC3CGAnyBitOp.h>
#include <lcfu_iec61131__ADD.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__EQ.h>
#include <lcfu_iec61131__GE.h>
#include <lcfu_iec61131__NE.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_FB_PACKAGINGSIMULATION(LC_TD_FunctionBlock_FB_PACKAGINGSIMULATION* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_FB_PACKAGINGSIMULATION* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_RESET)); \
  LC_INIT_BOOL(&((p)->LC_VD_PERMIT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LINEREADY)); \
  LC_INIT_UINT(&((p)->LC_VD_LINESTATE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LINEFAULT)); \
  LC_INIT_BOOL(&((p)->LC_VD_INJECTFAULTS)); \
  LC_INIT_BOOL(&((p)->LC_VD_FASTCYCLE)); \
  LC_INIT_DataType_SAFEBOOL(&((p)->LC_VD_ESTOPRELEASED)); \
  LC_INIT_BOOL(&((p)->LC_VD_ENABLE)); \
  LC_INIT_BOOL(&((p)->LC_VD_START)); \
  LC_INIT_BOOL(&((p)->LC_VD_STOP)); \
  LC_INIT_BOOL(&((p)->LC_VD_SAFETYRESET)); \
  LC_INIT_BOOL(&((p)->LC_VD_JAM)); \
  LC_INIT_BOOL(&((p)->LC_VD_ACKJAM)); \
  LC_INIT_BOOL(&((p)->LC_VD_FASTCYCLECOMMAND)); \
  LC_INIT_UINT(&((p)->LC_VD_STATE)); \
  LC_INIT_UINT(&((p)->LC_VD_ATTEMPTINROUND)); \
  LC_INIT_UINT(&((p)->LC_VD_SCENARIO)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TBOOT)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TRELEASE)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TRESETGAP)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TRESETPULSE)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TREADY)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TSTART)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TJAM)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TJAMCLEAR)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TACK)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TESTOP)); \
}

void LC_WINIT_FUN_FunctionBlock_FB_PACKAGINGSIMULATION(LC_TD_FunctionBlock_FB_PACKAGINGSIMULATION* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_FB_PACKAGINGSIMULATION* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_RESET),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_PERMIT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LINEREADY),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_LINESTATE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LINEFAULT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_INJECTFAULTS),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_FASTCYCLE),RF); \
  LC_WINIT_DataType_SAFEBOOL(&((p)->LC_VD_ESTOPRELEASED),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_ENABLE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_START),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_STOP),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_SAFETYRESET),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_JAM),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_ACKJAM),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_FASTCYCLECOMMAND),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_STATE),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_ATTEMPTINROUND),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_SCENARIO),RF); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TBOOT),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TRELEASE),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TRESETGAP),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TRESETPULSE),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TREADY),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TSTART),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TJAM),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TJAMCLEAR),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TACK),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TESTOP),0); \
}

void  lcfu___FB_PACKAGINGSIMULATION(LC_TD_FunctionBlock_FB_PACKAGINGSIMULATION* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  NPE_HIS_CHANNEL2_NOP_VAR
  LC3_MST_IF (LC_this->LC_VD_RESET)
  {
    LC_this->LC_VD_STATE = (LC_TD_UINT)0;
    LC_this->LC_VD_ATTEMPTINROUND = (LC_TD_UINT)0;
    LC_this->LC_VD_SCENARIO = (LC_TD_UINT)0;
  }
  {
    LC_this->LC_VD_TBOOT.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TBOOT.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)0)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET))));
    LC_this->LC_VD_TBOOT.LC_VD_PT = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0));
    lcfu_iec61131__TON(&(LC_this->LC_VD_TBOOT), pEPDB);
  }
  {
    LC_this->LC_VD_TRELEASE.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TRELEASE.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)10)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET))));
    LC_this->LC_VD_TRELEASE.LC_VD_PT = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0));
    lcfu_iec61131__TON(&(LC_this->LC_VD_TRELEASE), pEPDB);
  }
  {
    LC_this->LC_VD_TRESETGAP.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TRESETGAP.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)20)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET))));
    LC_this->LC_VD_TRESETGAP.LC_VD_PT = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000));
    lcfu_iec61131__TON(&(LC_this->LC_VD_TRESETGAP), pEPDB);
  }
  {
    LC_this->LC_VD_TRESETPULSE.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TRESETPULSE.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)30)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET))));
    LC_this->LC_VD_TRESETPULSE.LC_VD_PT = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000));
    lcfu_iec61131__TON(&(LC_this->LC_VD_TRESETPULSE), pEPDB);
  }
  {
    LC_this->LC_VD_TREADY.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TREADY.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)40)),LC_this->LC_VD_LINEREADY)),LC_this->LC_VD_PERMIT)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET))));
    LC_this->LC_VD_TREADY.LC_VD_PT = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000));
    lcfu_iec61131__TON(&(LC_this->LC_VD_TREADY), pEPDB);
  }
  {
    LC_this->LC_VD_TSTART.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TSTART.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)50)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET))));
    LC_this->LC_VD_TSTART.LC_VD_PT = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000));
    lcfu_iec61131__TON(&(LC_this->LC_VD_TSTART), pEPDB);
  }
  {
    LC_this->LC_VD_TJAM.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TJAM.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)70)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET))));
    LC_this->LC_VD_TJAM.LC_VD_PT = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(3),RT_CC_CONST_LL(0));
    lcfu_iec61131__TON(&(LC_this->LC_VD_TJAM), pEPDB);
  }
  {
    LC_this->LC_VD_TJAMCLEAR.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TJAMCLEAR.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)80)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET))));
    LC_this->LC_VD_TJAMCLEAR.LC_VD_PT = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000));
    lcfu_iec61131__TON(&(LC_this->LC_VD_TJAMCLEAR), pEPDB);
  }
  {
    LC_this->LC_VD_TACK.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TACK.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)90)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET))));
    LC_this->LC_VD_TACK.LC_VD_PT = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000));
    lcfu_iec61131__TON(&(LC_this->LC_VD_TACK), pEPDB);
  }
  {
    LC_this->LC_VD_TESTOP.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TESTOP.LC_VD_IN = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)100)),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET))));
    LC_this->LC_VD_TESTOP.LC_VD_PT = LC_TIME_VALUE_IMPL(RT_CC_CONST_LL(3),RT_CC_CONST_LL(0));
    lcfu_iec61131__TON(&(LC_this->LC_VD_TESTOP), pEPDB);
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_RESET));
    LC3_MST_IF (conditionResult)
    {
      {
        LC_TD_UINT caseSelector;
        caseSelector = LC_this->LC_VD_STATE;
        LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)0)))
        {
          LC3_MST_IF (LC_this->LC_VD_TBOOT.LC_VD_Q)
          {
            LC_this->LC_VD_STATE = (LC_TD_UINT)10;
          }
        }
        else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)10)))
        {
          LC3_MST_IF (LC_this->LC_VD_TRELEASE.LC_VD_Q)
          {
            LC_this->LC_VD_STATE = (LC_TD_UINT)20;
          }
        }
        else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)20)))
        {
          LC3_MST_IF (LC_this->LC_VD_PERMIT)
          {
            LC3_MST_IF (LC_this->LC_VD_LINEFAULT)
            {
              LC_this->LC_VD_STATE = (LC_TD_UINT)80;
            }
            else
            {
              LC_this->LC_VD_STATE = (LC_TD_UINT)40;
            }
          }
          else
          {
            LC3_MST_IF (LC_this->LC_VD_TRESETGAP.LC_VD_Q)
            {
              LC_this->LC_VD_STATE = (LC_TD_UINT)30;
            }
          }
        }
        else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)30)))
        {
          LC3_MST_IF (LC_this->LC_VD_TRESETPULSE.LC_VD_Q)
          {
            LC3_MST_IF (LC_this->LC_VD_PERMIT)
            {
              LC3_MST_IF (LC_this->LC_VD_LINEFAULT)
              {
                LC_this->LC_VD_STATE = (LC_TD_UINT)80;
              }
              else
              {
                LC_this->LC_VD_STATE = (LC_TD_UINT)40;
              }
            }
            else
            {
              LC_this->LC_VD_STATE = (LC_TD_UINT)20;
            }
          }
        }
        else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)40)))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_PERMIT));
            LC3_MST_IF (conditionResult)
            {
              LC_this->LC_VD_STATE = (LC_TD_UINT)10;
            }
            else
            {
              LC3_MST_IF (LC_this->LC_VD_LINEFAULT)
              {
                LC_this->LC_VD_STATE = (LC_TD_UINT)80;
              }
              else
              {
                LC3_MST_IF (LC_this->LC_VD_TREADY.LC_VD_Q)
                {
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__GE__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_ATTEMPTINROUND,(LC_TD_UINT)6));
                    LC3_MST_IF (conditionResult)
                    {
                      LC_this->LC_VD_ATTEMPTINROUND = (LC_TD_UINT)0;
                    }
                  }
                  LC_this->LC_VD_ATTEMPTINROUND = (LC_TD_UINT)(lcfu_iec61131__ADD__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_ATTEMPTINROUND,(LC_TD_UINT)1));
                  LC_this->LC_VD_SCENARIO = (LC_TD_UINT)1;
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_INJECTFAULTS,(lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_ATTEMPTINROUND,(LC_TD_UINT)3))));
                    LC3_MST_IF (conditionResult)
                    {
                      LC_this->LC_VD_SCENARIO = (LC_TD_UINT)2;
                    }
                  }
                  {
                    LC_TD_BOOL conditionResult = LC_EL_false;
                    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_INJECTFAULTS,(lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_ATTEMPTINROUND,(LC_TD_UINT)6))));
                    LC3_MST_IF (conditionResult)
                    {
                      LC_this->LC_VD_SCENARIO = (LC_TD_UINT)3;
                    }
                  }
                  LC_this->LC_VD_STATE = (LC_TD_UINT)50;
                }
              }
            }
          }
        }
        else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)50)))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_PERMIT));
            LC3_MST_IF (conditionResult)
            {
              LC_this->LC_VD_STATE = (LC_TD_UINT)10;
            }
            else
            {
              LC3_MST_IF (LC_this->LC_VD_TSTART.LC_VD_Q)
              {
                LC_this->LC_VD_STATE = (LC_TD_UINT)60;
              }
            }
          }
        }
        else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)60)))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_PERMIT));
            LC3_MST_IF (conditionResult)
            {
              LC_this->LC_VD_STATE = (LC_TD_UINT)10;
            }
            else
            {
              LC3_MST_IF (LC_this->LC_VD_LINEFAULT)
              {
                LC_this->LC_VD_STATE = (LC_TD_UINT)80;
              }
              else
              {
                {
                  LC_TD_BOOL conditionResult = LC_EL_false;
                  conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_SCENARIO,(LC_TD_UINT)2)),(lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_LINESTATE,(LC_TD_UINT)30))));
                  LC3_MST_IF (conditionResult)
                  {
                    LC_this->LC_VD_STATE = (LC_TD_UINT)70;
                  }
                  else
                  {
                    {
                      LC_TD_BOOL conditionResult = LC_EL_false;
                      conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_SCENARIO,(LC_TD_UINT)3)),(lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_LINESTATE,(LC_TD_UINT)30))));
                      LC3_MST_IF (conditionResult)
                      {
                        LC_this->LC_VD_STATE = (LC_TD_UINT)100;
                      }
                      else
                      {
                        {
                          LC_TD_BOOL conditionResult = LC_EL_false;
                          conditionResult = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_LINESTATE,(LC_TD_UINT)50)),LC_this->LC_VD_LINEREADY));
                          LC3_MST_IF (conditionResult)
                          {
                            LC_this->LC_VD_STATE = (LC_TD_UINT)40;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)70)))
        {
          LC3_MST_IF (LC_this->LC_VD_TJAM.LC_VD_Q)
          {
            LC_this->LC_VD_STATE = (LC_TD_UINT)80;
          }
        }
        else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)80)))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_PERMIT));
            LC3_MST_IF (conditionResult)
            {
              LC_this->LC_VD_STATE = (LC_TD_UINT)10;
            }
            else
            {
              LC3_MST_IF (LC_this->LC_VD_TJAMCLEAR.LC_VD_Q)
              {
                LC_this->LC_VD_STATE = (LC_TD_UINT)90;
              }
            }
          }
        }
        else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)90)))
        {
          {
            LC_TD_BOOL conditionResult = LC_EL_false;
            conditionResult = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_PERMIT));
            LC3_MST_IF (conditionResult)
            {
              LC_this->LC_VD_STATE = (LC_TD_UINT)10;
            }
            else
            {
              LC3_MST_IF (LC_this->LC_VD_TACK.LC_VD_Q)
              {
                LC3_MST_IF (LC_this->LC_VD_LINEFAULT)
                {
                  LC_this->LC_VD_STATE = (LC_TD_UINT)80;
                }
                else
                {
                  LC_this->LC_VD_STATE = (LC_TD_UINT)40;
                }
              }
            }
          }
        }
        else LC3_MST_IF (LC_MF_EXPR_TO_BOOL(LC_MF_COMPARE_EQ(LC_TD_UINT,caseSelector,(LC_TD_UINT)100)))
        {
          LC3_MST_IF (LC_this->LC_VD_TESTOP.LC_VD_Q)
          {
            LC_this->LC_VD_STATE = (LC_TD_UINT)10;
          }
        }
        else
        {
          LC_this->LC_VD_STATE = (LC_TD_UINT)0;
          LC_this->LC_VD_SCENARIO = (LC_TD_UINT)0;
        }
      }
    }
  }
  LC_this->LC_VD_ESTOPRELEASED = LC_EL_false;
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__NE__ANY__HIS__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)0)),(lcfu_iec61131__NE__ANY__HIS__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)100))));
    LC3_MST_IF (conditionResult)
    {
      LC_this->LC_VD_ESTOPRELEASED = LC_EL_true;
    }
  }
  LC_this->LC_VD_ENABLE = (lcfu_iec61131__NE__ANY__HIS__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)0));
  LC_this->LC_VD_START = (lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)50));
  LC_this->LC_VD_STOP = LC_EL_false;
  LC_this->LC_VD_SAFETYRESET = (lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)30));
  LC_this->LC_VD_JAM = (lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)70));
  LC_this->LC_VD_ACKJAM = (lcfu_iec61131__EQ__ANY__HIS__2__INL(LC_TD_UINT,LC_this->LC_VD_STATE,(LC_TD_UINT)90));
  LC_this->LC_VD_FASTCYCLECOMMAND = LC_this->LC_VD_FASTCYCLE;
  NPE_HIS_CHANNEL2_NOP_VAR_USE
}

#endif
