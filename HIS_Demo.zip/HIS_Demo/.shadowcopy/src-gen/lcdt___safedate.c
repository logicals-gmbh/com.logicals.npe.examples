#ifndef LC_PROT_LCDT___SAFEDATE__C
#define LC_PROT_LCDT___SAFEDATE__C

extern void* dummyCode4EmptyFile;
#endif
