#ifndef LC_PROT_LCDT___SAFETIME__C
#define LC_PROT_LCDT___SAFETIME__C

extern void* dummyCode4EmptyFile;
#endif
